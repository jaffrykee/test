#include "FlowElement.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(FlowElement, 500, 1000);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(FlowElement)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::FlowElement::createSelf() {

}

void ssui::FlowElement::disposeSelf() {

}

FlowElement& ssui::FlowElement::assign(const Self& other) {
    Base::assign(other);
    return *this;
}

const ArrayList<SlotType_e>& ssui::FlowElement::getSlotList() const {
    if (m_curSlot == 0xff) {
        return getSlotListDef(SLOT_text);
    } else {
        return getSlotListDef((SlotType_e)m_curSlot);
    }
}
void ssui::FlowElement::setLineNo(s32 value) {
    m_lineNo = value;
}
s32 ssui::FlowElement::getLineNo() const {
    return m_lineNo;
}
void ssui::FlowElement::setIsTouchComponent(b2 value) {
    m_isTouchComp = value;
}
bool ssui::FlowElement::isTouchComponent() const {
    return m_isTouchComp;
}
void ssui::FlowElement::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    Base::onEventScript(event);
}