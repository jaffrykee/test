#include "InputBox.h"
#include "Control.h"
#include "Control.h"
#include "AppEngine.h"
#include "UIManager.h"
#include "BasicContent.h"
#include "EventNodeGroup.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(InputBox, 5, 20);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(InputBox)
NODETYPE_COMMON_PART_DEFINITION_END

void InputBox::disposeSelf() {
    if (UIManager::getInstance()->m_pCurInputBox == this) {
        UIManager::getInstance()->m_pCurInputBox = nullptr;
    }
}

void InputBox::dealWstrBeforeInput() {
    s32 size = 0;
    s32 index = 0;
    wstring text = getHost()->getText();
    b2 isDel = false;
    do {
        isDel = false;
        for (auto wstr : UIManager::getInstance()->arr_canNotInputWstr) {
            size = wstr.size();
            index = text.find(wstr);
            if (index != -1) {
                isDel = true;
                break;
            }
        }
        if (isDel) {
            wstring str = text.substr(0, index);
            str += text.substr(index + size, -1);
            text.swap(str);
        }
    } while (isDel);
    getHost()->setText(text);
}

void InputBox::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    case ET_Press:
    {
        event.m_blockAnimation = true;
        getHost()->setDataIsPressed(true);
        getHost()->setEventType(event, PT_BlockStatusChange);
    }
    break;
    case ET_Release:
    {
        getHost()->setDataIsPressed(false);
//          if (getHost()->getDataIsVisible() == false || getHost()->getDataIsEnable() == false ||
//              getHost()->isIn(event.m_iData1, event.m_iData2) == false || getHost()->getEventNodeGroup() == nullptr) {
//              setCanTriggerScript(false);
//              return;
//          }
        event.m_blockAnimation = true;
        getHost()->setEventType(event, PT_BlockStatusChange);
    }
    break;
    case ET_Click:
    {
        //PlatformMessenger::MESSAGE_SHOW_INPUT
        //AppEngine::send("303");
        UIManager::getInstance()->m_pCurInputBox = this;
        if (getHost()->getDataIsVisible() == false || getHost()->getDataIsEnable() == false ||
            getHost()->isIn(event.m_iData1, event.m_iData2) == false) {
            setCanTriggerScript(false);
            return;
        }
        event.m_blockAnimation = true;
        getHost()->setEventType(event, PT_BlockStatusChange);
    }
    break;
    case ET_Text:
    {
        getHost()->enableBasicContent()->appendDataText(util::unicode2wstr((wstring::value_type*)event.m_pData1));
        dealWstrBeforeInput();
    }
    break;
    case ET_Char:
    {
        if (event.m_iData1 > 32 && event.m_iData1 < 127) {
            getHost()->enableBasicContent()->appendDataText(event.m_iData1);
            dealWstrBeforeInput();
        }
#ifdef _WIN32
        else if (event.m_iData1 == VK_BACK) {
            getHost()->enableBasicContent()->backspaceDataText();
        }
#endif
    }
    break;
    default:
    {

    }
    break;
    }
    Base::onEventScript(event);
}

bool ssui::InputBox::isTouchComponent() const {
    return true;
}
