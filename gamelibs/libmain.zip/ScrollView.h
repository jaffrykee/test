#pragma once
#include "SimpleComponent.h"
#include "GameTime.h"
#include "Timer.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ScrollView : public SimpleComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ScrollView);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(ScrollView, SimpleComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
    static const ArrayList<SlotType_e> sc_arrSlotList[4];
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    Border m_selfAabb;
    Border m_childAabb;
public:
    //����ϵ��
    ft m_damping = 0.95f;
    //��������ϵ����
    ft m_stack = 1.f;
    //��С�ٶ�(px/ms)
    ft m_minSpeed = 0.005f;
    //��ҳ������ʽ�ٶ�
    ft m_pagePanelSpeed = 0.5f;
    //������Χ
    //u16 mt_dataSpanTime = 500;
    //��������
    //u16 mt_dataPrecision = 1;
public:
    //�ٶȵ�λ��px/ms
    ft m_curSpeedX = 0.f;
    ft m_curSpeedY = 0.f;
    u32 m_lastTime;
    u32 m_curTime;
    s16 m_lastX;
    s16 m_lastY;
    s16 m_curX;
    s16 m_curY;
    s16 m_pressX;
    s16 m_pressY;
    s16 m_drawDx = 0;
    s16 m_drawDy = 0;
public:
    union {
        struct {
            bool mt_dataShowBar : 1;
            bool m_enableHorizontal : 1;
            bool m_enableVertical : 1;
            bool m_touchSelfAabb : 1;
            bool m_touchChildAabb : 1;
            bool m_isPagePanel : 1;
            bool m_isTouchComp : 1;
            bool m_em7 : 1;
        };
        unsigned char mt_initData = (0 << 0) + (1 << 1) + (1 << 2) + (1 << 3) + (1 << 4) + (0 << 5) + (0 << 6);
    };
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    f32 getDamping() const;
    void setDamping(f32 value);
    f32 getStack() const;
    void setStack(f32 value);
    f32 getMinSpeed() const;
    void setMinSpeed(f32 value);
    f32 getPagePanelSpeed() const;
    void setPagePanelSpeed(f32 value);
    bool getIsPagePanel() const;
    void setIsPagePanel(bool value);
public:
    virtual SlotType_e getSlotId() const;
    virtual const ArrayList<SlotType_e>& getSlotList() const;
#pragma endregion
public:
    Self& assign(const Self& other);
    virtual void onEvent(SSUIEvent& event) override;
public:
    //virtual void onChildrenTransformSuf(unsigned char drawStep, bool isReDraw) override;
    virtual void onTransform(unsigned char drawStep) override;
    //virtual void applyTransformToPosterity(Control* pPosterity) override;
    virtual bool isTouchComponent() const override;
public:
    //void checkValidity();
    //�����Ϸ��ԡ�
    void correctValidity();
public:
    void refreshSelfAabb();
    void refreshChildAabb();
    bool appendDrawPoi(const int dx, const int dy);
    //ˢ�µ�ǰ�ٶȡ�
    void refreshSpeed();
    void speedUpdate(u32 targerTime);
    void createTimer();
    void clearTimer();
public:
    void refreshTouchComp();
#pragma endregion

public:
    virtual void debugString(string& outString) override;
};

_SSUINamespaceEnd
