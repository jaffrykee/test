#include "GeometryPoly.h"
#include "GeometryManager.h"
#include "UIManager.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(GeometryPoly, 0, 0);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(GeometryPoly)
NODETYPE_COMMON_PART_DEFINITION_END

GeometryPoly* ssui::GeometryPoly::createObject(const Poly& poly) {
    auto pNew = GeometryPoly::createObject();
    pNew->m_poly = poly;
    return pNew;
}

GeometryPoly& ssui::GeometryPoly::assign(const GeometryPoly& other) {
    Base::assign(other);
    return *this;
}

bool GeometryPoly::isIn(ft x, ft y) {
    return GeometryManager::getPointIsInPoly(x, y, m_poly);
}

void GeometryPoly::appendOutline(Poly& poly) {
    if (m_poly.size() < 3) {
        return;
    }
    for (auto it = &m_poly.back(); it != m_poly.begin() - 1; --it) {
        //��������˳ʱ�뻹����ʱ�룿
        poly.push_back(*it);
    }
    return;
}

void ssui::GeometryPoly::getCenter(ft& cx, ft& cy) const {
    Border aabb;
    getBorder(aabb);
    cx = (aabb.m_left + aabb.m_right) * 0.5;
    cy = (aabb.m_top + aabb.m_bottom) * 0.5;
}

void ssui::GeometryPoly::getBorder(Border& aabb) const {
    aabb.m_left = m_poly[0].x;
    aabb.m_top = m_poly[0].y;
    aabb.m_right = m_poly[0].x;
    aabb.m_bottom = m_poly[0].y;
    for (auto itp = m_poly.begin() + 1; itp != m_poly.end(); ++itp) {
        aabb.m_left = math::minimum(aabb.m_left, itp->x);
        aabb.m_right = math::maximum(aabb.m_right, itp->x);
        aabb.m_top = math::minimum(aabb.m_top, itp->y);
        aabb.m_bottom = math::maximum(aabb.m_bottom, itp->y);
    }
}

void ssui::GeometryPoly::transformPosition(ft x, ft y) {
    for (auto& poi : m_poly) {
        poi.x += x;
        poi.y += y;
    }
}
