#pragma once
#include "SSUIPublic.h"
#include "StaticCache.h"

using namespace ss2;
using namespace gstl;

_SSUINamespaceBegin

#define BORDER_CACHE_WB        10

class Border {
public:
    static const Border s_null;
    static StaticCache<Border, BORDER_CACHE_WB> s_cache;
public:
    static Border& createStaticCache();
    static Border& createStaticCache(ft left, ft top, ft right, ft bottom);
public:
    //��߾�
    ft m_left = 0.f;
    //�ϱ߾�
    ft m_top = 0.f;
    //�ұ߾�
    ft m_right = 0.f;
    //�ױ߾�
    ft m_bottom = 0.f;

public:
    Border();
    Border(ft left, ft top, ft right, ft bottom);
    bool operator==(const Border& other) const;
    bool operator!=(const Border& other) const;
    const Border& operator|=(const Border& other);
    const Border& operator+=(const vec2& other);
    bool operator<=(const Border& other) const;
    bool cross(const Border& other);
    void clear();
    void outString(int lv = 3) const;
    ft width() const;
    ft height() const;
    vec2 center() const;
    void getCenter(ft& cx, ft& cy);
    void debugString(string& outString);
};

_SSUINamespaceEnd
