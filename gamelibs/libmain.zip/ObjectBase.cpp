#include "ObjectBase.h"
#include "UIManager.h"
#include "Control.h"
#include "UIComponent.h"

#include "DataHeaders.h"
#include "ObjectAttrDef.hpp"

gstl::HashMap<ssui::strHash, BoloVar>* ssui::ObjectBase::s_pUserAttrMapNull = nullptr;

BoloVar bolo_ui_createCopy(bolo_stack stack, void* self) {
    auto pNew = ((ObjectBase*)self)->createCopy();
    return bolo_create(stack, pNew, false);
}

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ObjectBase, 0, 0);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("ssueId", SsueId, ObjectBase, HS64);
NODETYPE_COMMON_PART_DEFINITION_MID(ObjectBase)
    NBSCRIPT_ATTR_REGISTER("ssueId", SsueId, ObjectBase, HS64);
    BoloRegisterDefaultProp(getUserAttr, setUserAttr);
    registerFunc(id, "createCopy", bolo_ui_createCopy, "(ObjectBase*)create Copy()");
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_END

ObjectBase::ObjectBase() {
    createSelf();
}

void ObjectBase::createSelf() {

}

void ObjectBase::disposeSelf() {
    if (UIManager::getInstance()) {
        UIManager::getInstance()->deleteSsueNode(this);
    }
    if (userAttrMap() != nullptr) {
        RPM::s_rpMapUserAttr.releaseObject(userAttrMap());
    }
}

int ObjectBase::setData(const DataInfoNode& dataNode) {
    for (auto& pChildInfoNode : dataNode.m_arrNode) {
        addDataChild(*pChildInfoNode);
    }
    for (auto& pAttrInfo : dataNode.m_arrAttr) {
        setAttrValue(pAttrInfo);
    }
    return 0;
}

ObjectBase* ObjectBase::createObject(const DataInfoNode& data, bool isSetData) {
    auto pSelf = createObject(data.m_objType);
    if (isSetData) {
        pSelf->setData(data);
    }
    return pSelf;
}

s64 ObjectBase::getSsueId() const {
    if (UIManager::getInstance()) {
        return UIManager::getInstance()->getSsueNodeId(this);
    } else {
        return 0;
    }
}

void ObjectBase::setSsueId(s64 value) {
    if (UIManager::getInstance()) {
        UIManager::getInstance()->insertSsueNode(value, this);
    }
}

bool ssui::ObjectBase::checkValidity(AttrSetting* pAs, AttrDataType_e dataType) {
    if (pAs->m_dataType == dataType || pAs->m_dataType == ADT_HU32 && dataType == ADT_U32 
        || pAs->m_dataType == ADT_HS64 && dataType == ADT_S64) {
        return true;
    }
    return false;
}

int ssui::ObjectBase::dealAttrValueFromAttrData(AttrSetting* pAs, AttrDataType_e dataType) {
    if (!checkValidity(pAs, dataType)) {
        //���Ͳ���
        return -1;
    }
    if (is(pAs->m_nodeType) == false) {
        //������Բ��Ǵ˽ڵ�����������ġ�
        return -2;
    }
    return 0;
}

int ObjectBase::setAttrValue(AttrSetting* pAs, AttrDataType_e dataType, const wstring& attrValue) {
    StringManager::getInstance()->m_tmpString.clear();
    util::str2str(attrValue, StringManager::getInstance()->m_tmpString);
    switch (dataType) {
    case ADT_B2:
    {
        return setAttrValue<bool, ADT_B2, boloClassSetFuncB2>(pAs, attrValue == StringManager::getInstance()->mc_wstrTrueDef);
    }
    break;
    case ADT_S32:
    {
        return setAttrValue<int, ADT_S32, boloClassSetFuncS32>(pAs, util::atoi_s(StringManager::getInstance()->m_tmpString));
    }
    break;
    case ADT_U32:
    {
        return setAttrValue<unsigned int, ADT_U32, boloClassSetFuncU32>(pAs, util::aton_s(StringManager::getInstance()->m_tmpString, 10));
    }
    break;
    case ADT_F32:
    {
        return setAttrValue<f32, ADT_F32, boloClassSetFuncF32>(pAs, util::atof_s(StringManager::getInstance()->m_tmpString));
    }
    break;
    case ADT_S64:
    {
        return setAttrValue<s64, ADT_S64, boloClassSetFuncS64>(pAs, util::aton_s(StringManager::getInstance()->m_tmpString, 10));
    }
    break;
    case ADT_HU32:
    {
        return setAttrValue<unsigned int, ADT_HU32, boloClassSetFuncU32>(pAs, util::aton_s(StringManager::getInstance()->m_tmpString, 16));
    }
    break;
    case ADT_HS64:
    {
        return setAttrValue<s64, ADT_HS64, boloClassSetFuncS64>(pAs, util::aton_s(StringManager::getInstance()->m_tmpString, 16));
    }
    break;
    case ADT_STR:
    {
        StringManager::getInstance()->m_tmpString.clear();
        util::str2str(attrValue, StringManager::getInstance()->m_tmpString);
        return setAttrValue<const string, ADT_STR, boloClassSetFuncString>(pAs, StringManager::getInstance()->m_tmpString);
    }
    break;
    case ADT_WSTR:
    {
        return setAttrValue<const wstring, ADT_WSTR, boloClassSetFuncWString>(pAs, attrValue);
    }
    break;
    default:
        break;
    }
    return -1;
}

int ObjectBase::setAttrValue(DataInfoAttr* pAttrRow) {
    switch (pAttrRow->m_dataType) {
    case ADT_B2:
    {
        return setAttrValue<bool, ADT_B2, boloClassSetFuncB2>(DataManager::getInstance()->m_arrAttrSetting[pAttrRow->m_attrType], pAttrRow->m_bData, pAttrRow);
    }
    break;
    case ADT_S32:
    {
        return setAttrValue<int, ADT_S32, boloClassSetFuncS32>(DataManager::getInstance()->m_arrAttrSetting[pAttrRow->m_attrType], pAttrRow->m_iData, pAttrRow);
    }
    break;
    case ADT_U32:
    {
        return setAttrValue<unsigned int, ADT_U32, boloClassSetFuncU32>(DataManager::getInstance()->m_arrAttrSetting[pAttrRow->m_attrType], pAttrRow->m_uData, pAttrRow);
    }
    break;
    case ADT_F32:
    {
        return setAttrValue<f32, ADT_F32, boloClassSetFuncF32>(DataManager::getInstance()->m_arrAttrSetting[pAttrRow->m_attrType], pAttrRow->m_fData, pAttrRow);
    }
    break;
    case ADT_S64:
    {
        return setAttrValue<s64, ADT_S64, boloClassSetFuncS64>(DataManager::getInstance()->m_arrAttrSetting[pAttrRow->m_attrType], pAttrRow->m_lData, pAttrRow);
    }
    break;
    case ADT_STR:
    {
        return setAttrValue<const string, ADT_STR, boloClassSetFuncString>(DataManager::getInstance()->m_arrAttrSetting[pAttrRow->m_attrType], *pAttrRow->m_pStrData, pAttrRow);
    }
    break;
    case ADT_WSTR:
    {
        return setAttrValue<const wstring, ADT_WSTR, boloClassSetFuncWString>(DataManager::getInstance()->m_arrAttrSetting[pAttrRow->m_attrType], *pAttrRow->m_pWstrData, pAttrRow);
    }
    break;
    default:
        break;
    }
    return -1;
}

int ObjectBase::setAttrValue(const wstring& attrName, const wstring& attrValue) {
    const auto& pairAttrRow = DataManager::getInstance()->m_mapAttrSetting.find(attrName.hashCode());
    if (pairAttrRow != DataManager::getInstance()->m_mapAttrSetting.end()) {
        return setAttrValue(pairAttrRow->second, pairAttrRow->second->m_dataType, attrValue);
    }
    return -1;
}

void ObjectBase::onEvent(SSUIEvent& event) {
    s64 key = event.m_type;
    if (event.m_type == ET_AttrValueChanged) {
        key |= (((s64)event.m_iData1) << 32);
    }
}

void ssui::ObjectBase::printData(PrintDataType_e pdt /*= PDT_Debug*/) {
    string outString;
    switch (pdt) {
        case PDT_Debug:
            debugString(outString);
            break;
        case PDT_Tree:
            treeString(outString, 0);
            break;
        default:
            debugString(outString);
            break;
    }
    LogPrintf("%s", 3, outString.c_str());
}
