#pragma once
#include "ButtonBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ToggleButton : public ButtonBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ToggleButton)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(ToggleButton, ButtonBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
public:
    inline ToggleButton& assign(const ToggleButton& other) {
        Base::assign(other);
        return *this;
    }
#pragma endregion
};

_SSUINamespaceEnd
