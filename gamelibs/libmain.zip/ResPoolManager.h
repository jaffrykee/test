#pragma once
#include "ssuiBasic.h"
#include "NodeManager.h"
#include "ResPool.h"
#include "StaticCache.h"

_SSUINamespaceBegin

class EventNodeBase;
class UIComponent;
class ResPoolManager {
public:
    static ResPool<ArrayList<EventNodeBase*>> s_rpEventNode;
    static ResPool<ArrayList<UIComponent*>> s_rpIEventComponent;
    static ResPool<ArrayList<UIComponent*>> s_rpIDrawComponent;
    static ResPool<HashMap<strHash, BoloVar>> s_rpMapUserAttr;
    static ResPool<ArrayList<wstring>> s_rpArrStringW;
    static ResPool<string> s_rpString;
    static ResPool<wstring> s_rpStringW;

    inline static void releaseArrStringW(ArrayList<wstring>* pSelf) {
        if (pSelf != nullptr) {
            pSelf->clear();
        }
    }
    inline static void releaseString(string* pSelf) {
        if (pSelf != nullptr) {
            pSelf->clear();
        }
    }
    inline static void releaseStringW(wstring* pSelf) {
        if (pSelf != nullptr) {
            pSelf->clear();
        }
    }
};

using RPM = ResPoolManager;

_SSUINamespaceEnd
