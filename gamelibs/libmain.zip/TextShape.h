#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class TextShape : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(TextShape);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(TextShape, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static Tpid_t s_tmpArrTpid[256];
    static wstring s_tmpFontNames;
    static wstring s_tmpTextDirectionAttrList;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    Color mt_dataColorUp = Color::white;
    Color mt_dataColorDown = Color::white;
    // Border
    f32 mt_exSizeBorder = 0;
    Color mt_colorBorder = Color::white;
    // Shadow
    f32 mt_exSizeShadow = 0;
    f32 mt_angleShadow = 0;
    Color mt_colorShadow = Color::white;
    // Light
    f32 mt_exSizeLight = 0;
    f32 mt_LightWeight = 1.0f;
    Color mt_colorLight = Color::white;
    // underLine
    f32 mt_underLineOffsetY = 0;
    f32 mt_underLineWidth = 0;
    Color mt_colorUnderLine = Color::white;
    // deleteLine
    f32 mt_deleteLineOffsetY = 0;
    f32 mt_deleteLineWidth = 0;
    Color mt_colorDeleteLine = Color::white;
private:
    u16 mt_dataFontSize = 20;
    FontDir mt_textDirection = FontDir::LeftRigth;
    // normal
    u8 mt_dataFont = 0;
    s8 mt_textSpacing = 0;
    union {
        struct {
            bool mt_enableLightFont : 1;
            bool mt_enableBorderFont : 1;
            bool mt_enableShadowFont : 1;
            bool mt_underLine : 1;
            bool mt_DeleteLine : 1;
        };
        u8 mt_enInitData = 0;
    };
#pragma endregion

#pragma region "����"
private:
    void fillRect(const vec2& start, const vec2& end, float width, const Color& color);
    void drawDeleteLine();
    void drawUnderLine();
    void getTextMinAndMaxPos(vec3& minPos, vec3& maxPos) const;
    void renderString(const wstring& text, const Font& font, const Color& upColor, const Color& downColor);

#pragma region "���Է���"
public:
    int getDataFont() const;
    void setDataFont(int value);
    int getDataFontSize() const;
    void setDataFontSize(int value);
    int getTextDirection() const;
    void setTextDirection(int value);
    int getTextSpacing() const;
    void setTextSpacing(int value);
    u32 getDataColorUp() const;
    void setDataColorUp(u32 value);
    u32 getDataColorDown() const;
    void setDataColorDown(u32 value);
    u32 getDataColorBorder() const;
    void setDataColorBorder(u32 value);
    u32 getDataColorShadow() const;
    void setDataColorShadow(u32 value);
    u32 getDataColorLight() const;
    void setDataColorLight(u32 value);
    u32 getDataColorUnderLine() const;
    void setDataColorUnderLine(u32 value);
    u32 getDataColorDeleteLine() const;
    void setDataColorDeleteLine(u32 value);
    f32 getDataLightWeight() const;
    void setDataLightWeight(f32 value);
    f32 getDataExSizeBorder() const;
    void setDataExSizeBorder(f32 value);
    f32 getDataExSizeShadow() const;
    void setDataExSizeShadow(f32 value);
    f32 getDataExSizeLight() const;
    void setDataExSizeLight(f32 value);
    f32 getDataAngleShadow() const;
    void setDataAngleShadow(f32 value);
    f32 getDataUnderLineOffsetY() const;
    void setDataUnderLineOffsetY(f32 value);
    f32 getDataDeleteLineOffsetY() const;
    void setDataDeleteLineOffsetY(f32 value);
    f32 getDataDeleteLineWidth() const;
    void setDataDeleteLineWidth(f32 value);
    b2 getDataUnderLine() const;
    void setDataUnderLine(b2 value);
    f32 getDataUnderLineWidth() const;
    void setDataUnderLineWidth(f32 value);
    b2 getDataDeleteLine() const;
    void setDataDeleteLine(b2 value);
    b2 getDataEnableLightFont() const;
    void setDataEnableLightFont(b2 value);
    b2 getDataEnableBorderFont() const;
    void setDataEnableBorderFont(b2 value);
    b2 getDataEnableShadowFont() const;
    void setDataEnableShadowFont(b2 value);

#pragma endregion
public:
    TextShape& assign(const TextShape& other);
    const wstring& getShowText();
    void getMinAndMaxPos(vec3& minPos, vec3& maxPos) const;
public:
    virtual void onMeasure(unsigned char drawStep) override;
    virtual void onRender(unsigned char drawStep) override;
    virtual void onShow() override;
#pragma endregion

public:
    Font toFontInfo(FontStyle style) const;
};

_SSUINamespaceEnd
