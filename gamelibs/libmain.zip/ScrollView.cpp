#include "ScrollView.h"
#include "Control.h"
#include "Geometry.h"

#include "DataHeaders.h"

const gstl::ArrayList<ssui::SlotType_e> ssui::ScrollView::sc_arrSlotList[4] = {{}, {SLOT_hSliderBack, SLOT_hSliderBody},
    {SLOT_vSliderBack, SLOT_vSliderBody}, {SLOT_hSliderBack, SLOT_hSliderBody, SLOT_vSliderBack, SLOT_vSliderBody}};

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ScrollView, 500, 2000);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("damping", Damping, ScrollView, F32);
NODEBASE_ATTR_REGISTER("stack", Stack, ScrollView, F32);
NODEBASE_ATTR_REGISTER("minSpeed", MinSpeed, ScrollView, F32);
NODEBASE_ATTR_REGISTER("pagePanelSpeed", PagePanelSpeed, ScrollView, F32);
NODEBASE_ATTR_REGISTER("isPagePanel", IsPagePanel, ScrollView, B2);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ScrollView)
NBSCRIPT_ATTR_REGISTER("damping", Damping, ScrollView, F32);
NBSCRIPT_ATTR_REGISTER("stack", Stack, ScrollView, F32);
NBSCRIPT_ATTR_REGISTER("minSpeed", MinSpeed, ScrollView, F32);
NBSCRIPT_ATTR_REGISTER("pagePanelSpeed", PagePanelSpeed, ScrollView, F32);
NBSCRIPT_ATTR_REGISTER("isPagePanel", IsPagePanel, ScrollView, B2);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(ScrollView, Damping, ft)
UIComponent_ControlAttr_Def(ScrollView, Stack, ft)
UIComponent_ControlAttr_Def(ScrollView, MinSpeed, ft)
UIComponent_ControlAttr_Def(ScrollView, PagePanelSpeed, ft)
UIComponent_ControlAttr_Def(ScrollView, IsPagePanel, bool)
#pragma endregion

gstl::f32 ssui::ScrollView::getDamping() const {
    return m_damping;
}

void ssui::ScrollView::setDamping(f32 value) {
    m_damping = value;
}

gstl::f32 ssui::ScrollView::getStack() const {
    return m_stack;
}

void ssui::ScrollView::setStack(f32 value) {
    m_stack = value;
}

gstl::f32 ssui::ScrollView::getMinSpeed() const {
    return m_minSpeed;
}

void ssui::ScrollView::setMinSpeed(f32 value) {
    m_minSpeed = value;
}

gstl::f32 ssui::ScrollView::getPagePanelSpeed() const {
    return m_pagePanelSpeed;
}

void ssui::ScrollView::setPagePanelSpeed(f32 value) {
    m_pagePanelSpeed = value;
}

bool ssui::ScrollView::getIsPagePanel() const {
    return m_isPagePanel;
}

void ssui::ScrollView::setIsPagePanel(bool value) {
    m_isPagePanel = value;
}

ssui::SlotType_e ssui::ScrollView::getSlotId() const {
    return SLOT_null;
}

const ArrayList<SlotType_e>& ssui::ScrollView::getSlotList() const {
    if (mt_dataShowBar == false) {
        return sc_nullSlotList;
    } else {
        return sc_arrSlotList[((m_enableHorizontal ? 1 : 0) + ((m_enableVertical ? 1 : 0) << 1))];
    }
}

ScrollView& ssui::ScrollView::assign(const Self& other) {
    Base::assign(other);
    m_damping = other.m_damping;
    m_stack = other.m_stack;
    m_minSpeed = other.m_minSpeed;
    m_pagePanelSpeed = other.m_pagePanelSpeed;
    m_isPagePanel = other.m_isPagePanel;
    m_isTouchComp = other.m_isTouchComp;
    return *this; 
}

void ssui::ScrollView::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    case ET_Press:
    {
        clearTimer();
        m_lastTime = GameTime::getUseTimeStable();
        m_lastX = event.m_iData1;
        m_lastY = event.m_iData2;
        m_pressX = m_lastX;
        m_pressY = m_lastY;
        m_curSpeedX = 0;
        m_curSpeedY = 0;
    }
    break;
    case ET_Drag:
    {
        m_curTime = GameTime::getUseTimeStable();
        m_curX = event.m_iData1;
        m_curY = event.m_iData2;
        refreshSpeed();
        m_lastTime = m_curTime; 
        appendDrawPoi(m_curX - m_lastX, m_curY - m_lastY);
        m_lastX = m_curX;
        m_lastY = m_curY;
        event.m_enDragged = true;
        //printData();
    }
    break;
    case ET_Release:
    {
        m_curTime = GameTime::getUseTimeStable();
        m_curX = event.m_iData1;
        m_curY = event.m_iData2;
        m_pressX = -1;
        m_pressY = -1;
        refreshSpeed();
        appendDrawPoi(m_curX - m_lastX, m_curY - m_lastY);
        createTimer();
        getHost()->touchRenderChanged();
    }
    break;
    default:
    {

    }
    break;
    }
    Base::onEventScript(event);
}

// void ssui::ScrollView::onChildrenTransformSuf(unsigned char drawStep, bool isReDraw) {
//     if (m_drawDx == 0 && m_drawDy == 0) {
//         return;
//     }
//     for (auto& pComp : *getHost()) {
//         for (auto& pChild : *pComp) {
//             if (pChild->m_isDidRender = true) {
//                 applyTransformToSelfChildGrandChildAndSoOn(pChild, m_drawDx, m_drawDy);
//             }
//         }
//     }
// }

void ssui::ScrollView::onTransform(unsigned char drawStep) {
    if (m_drawDx == 0 && m_drawDy == 0) {
        return;
    }
    refreshSelfAabb();
    refreshChildAabb();
    correctValidity();
    for (auto& pComp : *getHost()) {
        if (pComp->isContainerComponent() || pComp->is(NT_TextFlow)) {
            for (auto& pChild : *pComp) {
                if (pChild->m_isDidRender = true) {
                    applyTransformToSelfChildGrandChildAndSoOn(pChild, m_drawDx, m_drawDy);
                }
            }
        }
    }
}

bool ssui::ScrollView::isTouchComponent() const {
    return m_isTouchComp;
}

void ssui::ScrollView::correctValidity() {
    ft curLeft = m_childAabb.m_left + m_drawDx;
    ft curRight = m_childAabb.m_right + m_drawDx;
    ft curTop = m_childAabb.m_top + m_drawDy;
    ft curBottom = m_childAabb.m_bottom + m_drawDy;
    if (curLeft < m_selfAabb.m_left) {
        if (curRight < m_selfAabb.m_right) {
            m_drawDx += (m_selfAabb.m_right - curRight);
        } else {
            //iIIi
            //ʲôҲ����
        }
    } else {
        if (curRight > m_selfAabb.m_right) {
            m_drawDx -= (curLeft - m_selfAabb.m_left);
        } else {
            //IiiI
            //ʲôҲ����
        }
    }
    if (curTop < m_selfAabb.m_top) {
        if (curBottom < m_selfAabb.m_bottom) {
            m_drawDy += (m_selfAabb.m_bottom - curBottom);
        } else {
            //iIIi
            //ʲôҲ����
        }
    } else {
        if (curBottom > m_selfAabb.m_bottom) {
            m_drawDy -= (curTop - m_selfAabb.m_top);
        } else {
            //IiiI
            //ʲôҲ����
        }
    }
}

void ssui::ScrollView::refreshSelfAabb() {
    const auto& pGeo = getHost()->getInnerMeasure().m_pTransGeo;
    if (pGeo == nullptr) {
        m_selfAabb.clear();
    } else {
        pGeo->getBorder(m_selfAabb);
    }
    m_touchSelfAabb = false;
}

void ssui::ScrollView::refreshChildAabb() {
    Border tmpAabb;
    bool isHad = false;
    auto pContainer = getHost()->m_pChildrenComponent;
    if (pContainer == nullptr && getHost()->mt_dataCcit == CCIT_TextFlow) {
        pContainer = getHost()->getComponent(NT_TextFlow);
    }
    if (pContainer != nullptr) {
        for (const auto& pChild : *pContainer) {
            const auto& pChildGeo = pChild->getOuterMeasure().m_pTransGeo;
            if (pChildGeo != nullptr) {
                pChildGeo->getBorder(tmpAabb);
                if (isHad == false) {
                    m_childAabb = tmpAabb;
                    isHad = true;
                } else {
                    m_childAabb |= tmpAabb;
                }
            }
        }
    }
    if (isHad == false) {
        m_childAabb.clear();
    }
    m_touchChildAabb = false;
}

void refreshPagePanelDrawLen(b2& isPageChanged, b2& isOverArea, s16& drawDLen, const ft childLen, const ft selfLen, const int dLen) {
    if (childLen > selfLen + 1) {
        double fTimes = (double)childLen / (double)selfLen;
        //����ȡ����һ���еĴ�����
        int times = Math::ceil(fTimes);
        double lastPage = drawDLen / (double)selfLen;
        drawDLen += dLen;
        double curPage = drawDLen / (double)selfLen;
        if (lastPage == Math::ceil(lastPage)) {
            //����(�磺4.00000)
            auto lp = Math::ceil(lastPage);
            ft dp = Math::abs(curPage - lp);
            if (dLen >= 0) {
                //���
            } else {
                //��С
            }
        } else {
            if (dLen >= 0) {
                //���
            } else {
                //��С
            }
        }
        if (curPage != lastPage) {
            drawDLen = curPage *  selfLen;
            isPageChanged = true;
        }
        isOverArea = true;
    }
}

bool ssui::ScrollView::appendDrawPoi(const int dx, const int dy) {
    refreshSelfAabb();
    refreshChildAabb();
    bool isOverArea = false;
    bool isPageChanged = false;
    if (m_isPagePanel == false) {
        if (m_childAabb.width() > m_selfAabb.width() + 1) {
            m_drawDx += dx;
            isOverArea = true;
        }
        if (m_childAabb.height() > m_selfAabb.height() + 1) {
            m_drawDy += dy;
            isOverArea = true;
        }
    } else {
        refreshPagePanelDrawLen(isPageChanged, isOverArea, m_drawDx, m_childAabb.width(), m_selfAabb.width(), dx);
        refreshPagePanelDrawLen(isPageChanged, isOverArea, m_drawDy, m_childAabb.height(), m_selfAabb.height(), dy);
        //printf("\n%d, %d", m_drawDx, m_drawDy);
    }
    if (isOverArea) {
        getHost()->touchRenderChanged();
    }
    return isPageChanged;
}

void ssui::ScrollView::refreshSpeed() {
    auto dt = m_curTime - m_lastTime;
    if (dt == 0) {
        return;
    }
    ft dx = m_curX - m_lastX;
    ft dy = m_curY - m_lastY;
    if (m_enableHorizontal == true) {
        if (m_enableVertical == true) {
            if (m_stack == 1.f) {
                m_curSpeedX = (m_curSpeedX + dx / dt) * 0.5f;
                m_curSpeedY = (m_curSpeedY + dy / dt) * 0.5f;
            } else {
                m_curSpeedX = (m_curSpeedX * m_stack + dx / dt) / (1.f + m_stack);
                m_curSpeedY = (m_curSpeedY * m_stack + dy / dt) / (1.f + m_stack);
            }
        } else {
            if (m_stack == 1.f) {
                m_curSpeedX = (m_curSpeedX + dx / dt) * 0.5f;
            } else {
                m_curSpeedX = (m_curSpeedX * m_stack + dx / dt) / (1.f + m_stack);
            }
        }
    } else {
        if (m_enableVertical == true) {
            if (m_stack == 1.f) {
                m_curSpeedY = (m_curSpeedY + dy / dt) * 0.5f;
            } else {
                m_curSpeedY = (m_curSpeedY * m_stack + dy / dt) / (1.f + m_stack);
            }
        } else {
        }
    }
}

void ssui::ScrollView::speedUpdate(u32 targerTime) {
    if (m_isPagePanel == false && Math::abs(m_curSpeedX) + Math::abs(m_curSpeedY) < m_minSpeed) {
        return;
    }
    m_lastTime = m_curTime;
    m_curTime = GameTime::getUseTimeStable();
    auto dt = m_curTime - m_lastTime;
    if (dt <= 0) {
        return;
    }
    if (m_isPagePanel) {
        auto sax = Math::abs(m_curSpeedX);
        auto say = Math::abs(m_curSpeedY);
        auto sumSpeed = sax + say;
        bool isPageChanged = appendDrawPoi(m_curSpeedX * dt, m_curSpeedY * dt);
        if (Math::equal(sumSpeed, m_pagePanelSpeed, 0.0001f) == false) {
            //�������
            auto wb = m_damping * m_damping;
            m_curSpeedX *= wb;
            m_curSpeedY *= wb;
            sax = Math::abs(m_curSpeedX);
            say = Math::abs(m_curSpeedY);
            sumSpeed = sax + say;
            if (sumSpeed < m_pagePanelSpeed - 0.001f) {
                //С�ڷ�ҳ��С�ٶ�
                auto perX = sax / sumSpeed;
                auto perY = say / sumSpeed;
                sumSpeed = m_pagePanelSpeed;
                sax = sumSpeed * perX;
                say = sumSpeed - sax;
            }
            if (m_curSpeedX > 0) {
                m_curSpeedX = sax;
            } else {
                m_curSpeedX = -sax;
            }
            if (m_curSpeedY > 0) {
                m_curSpeedY = say;
            } else {
                m_curSpeedY = -say;
            }
        }
        if (isPageChanged == false) {
            createTimer();
        }
    } else {
        appendDrawPoi(m_curSpeedX * dt, m_curSpeedY * dt);
        auto wb = m_damping * m_damping;
        m_curSpeedX *= wb;
        m_curSpeedY *= wb;
        createTimer();
    }
}

void ssui::ScrollView::createTimer() {
    Timer::createObject(this, (Timer::TimerTriggerFunc)&Self::speedUpdate);
    return;
}

void ssui::ScrollView::clearTimer() {
    Timer::clearTimer(this);
}

void ssui::ScrollView::debugString(string& outString) {
    if (m_drawDx == 0 && m_drawDy == 0) {
        return;
    }
    outString.append("\n[SrollView]");
    outString.append(string("\ndrawDx:\t") + util::itoa_c8s(m_drawDx) + "\tdrawDy:\t" + util::itoa_c8s(m_drawDy) + "\t");

    outString.append("\n<selfAabb>");
    m_selfAabb.debugString(outString);
    outString.append("\n<childAabb>");
    m_childAabb.debugString(outString);
}

void ssui::ScrollView::refreshTouchComp() {
    refreshSelfAabb();
    refreshChildAabb();
    bool isOverArea = false;
    if (m_childAabb.width() > m_selfAabb.width() + 1) {
        isOverArea = true;
    } else if (m_childAabb.height() > m_selfAabb.height() + 1) {
        isOverArea = true;
    }
    m_isTouchComp = isOverArea;
}
