#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class InputBox : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(InputBox);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(InputBox, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
public:
    inline Self& assign(const Self& other) {
        Base::assign(other);
        return *this;
    }
    virtual void onEvent(SSUIEvent& event) override;
public:
    virtual bool isTouchComponent() const override;
public:
    void dealWstrBeforeInput();
#pragma endregion
};

_SSUINamespaceEnd
