#include "GeometryManager.h"
#include "GeometryRect.h"
#include "GeometryPoly.h"
#include "GeometryUnionPoly.h"

using namespace ssui;

PolyImage GeometryManager::s_tmpPolyImageA;
Vector3<ft> GeometryManager::s_pTmpPolyBuff[2][200];
VertexPosColorTex GeometryManager::s_pTmpPolyImageBuff[2][200];

void ssui::GeometryManager::getPolyFromCircle(Poly& poly, const Point<ft>& center, float radius) {
    poly.clear();

    const int slice = 30;
    f32 perAngle = 360.0f / slice;
    vec3 c(center.m_x, center.m_y, 0.f);
    for (s32 i = 0; i != slice + 1; ++i) {
        f32 angle = perAngle * i;
        vec3 pos(radius * math::cos(angle), radius * math::sin(angle), 0.f);
        pos += c;

        poly.push_back(pos);
    }
}

void ssui::GeometryManager::getSector(GeometryUnionPoly* pGeo, const Point<ft>& center, float radius, float bAngle, float eAngle) {
    if (pGeo == nullptr) {
        return;
    }
    pGeo->m_arrPoly.clear();
    Poly poly;
    const int slice = 36;
    f32 perAngle = 360.0f / slice;
    f32 angle = bAngle;
    vec3 c(center.m_x, center.m_y, 0.f);
    for (s32 i = 1; i != slice + 1 && angle < eAngle; ++i) {
        vec3 pos(radius * math::cos(angle), radius * math::sin(angle), 0.f);
        pos += c;
        poly.push_back(pos);
        angle = bAngle + perAngle * i;
    }
    vec3 pos(radius * math::cos(eAngle), radius * math::sin(eAngle), 0.f);
    pos += c;
    poly.push_back(pos);
    auto dAngle = eAngle - bAngle;
    Poly tmpPoly;
    if (poly.size() >= 19) {
        if (Math::equal(dAngle, 180.f, 0.5f) && poly.size() == 19) {
            tmpPoly = poly;
            pGeo->m_arrPoly.push_back(tmpPoly);
        } else {
            for (int i = 0; i < 19; i++) {
                tmpPoly.push_back(poly[i]);
            }
            tmpPoly.push_back(c);
            pGeo->m_arrPoly.push_back(tmpPoly);
            if (poly.size() > 19) {
                tmpPoly.clear();
                for (int i = 18; i < poly.size(); i++) {
                    tmpPoly.push_back(poly[i]);
                }
                tmpPoly.push_back(c);
                pGeo->m_arrPoly.push_back(tmpPoly);
            }
        }
    } else {
        poly.push_back(c);
        pGeo->m_arrPoly.push_back(poly);
    }
}


void ssui::GeometryManager::getPolyFromRoundedRectangle(Poly& poly, const Point<ft>& center, float radius, float cornerRadius) {
    poly.clear();
    const int slice = 6;
    f32 perAngle = 90.0f / slice;
    vec3 c(center.m_x, center.m_y, 0.f);
    f32 subRadius = radius - cornerRadius;
    poly.push_back(vec3(center.m_x - subRadius, center.m_y - radius, 0));
    poly.push_back(vec3(center.m_x + subRadius, center.m_y - radius, 0));
    vec3 subCenter = vec3(center.m_x+subRadius, center.m_y-subRadius, 0);
    for (s32 i = 0; i != slice + 1; ++i) {
        f32 angle =270+ perAngle * i;
        vec3 pos(cornerRadius * math::cos(angle), cornerRadius * math::sin(angle), 0.f);
        pos += subCenter;
        poly.push_back(pos);
    }
    poly.push_back(vec3(center.m_x + radius, center.m_y - subRadius, 0));
    poly.push_back(vec3(center.m_x + radius, center.m_y + subRadius, 0));
    subCenter = vec3(center.m_x + subRadius, center.m_y + subRadius, 0);
    for (s32 i = 0; i != slice + 1; ++i) {
        f32 angle = perAngle * i;
        vec3 pos(cornerRadius * math::cos(angle), cornerRadius * math::sin(angle), 0.f);
        pos += subCenter;
        poly.push_back(pos);
    }
    poly.push_back(vec3(center.m_x + subRadius, center.m_y + radius, 0));
    poly.push_back(vec3(center.m_x - subRadius, center.m_y + radius, 0));
    subCenter = vec3(center.m_x - subRadius, center.m_y + subRadius, 0);
    for (s32 i = 0; i != slice + 1; ++i) {
        f32 angle = 90.0f + perAngle * i;
        vec3 pos(cornerRadius * math::cos(angle), cornerRadius * math::sin(angle), 0.f);
        pos += subCenter;
        poly.push_back(pos);
    }
    poly.push_back(vec3(center.m_x - radius, center.m_y + subRadius, 0));
    poly.push_back(vec3(center.m_x - radius, center.m_y - subRadius, 0));
    subCenter = vec3(center.m_x - subRadius, center.m_y - subRadius, 0);
    for (s32 i = 0; i != slice + 1; ++i) {
        f32 angle = 180.0f + perAngle * i;
        vec3 pos(cornerRadius * math::cos(angle), cornerRadius * math::sin(angle), 0.f);
        pos += subCenter;
        poly.push_back(pos);
    }
}


void ssui::GeometryManager::getPolyFromSixAngleRhombus(Poly& poly, const Point<ft>& center, float radius) {
    poly.clear();
    const int slice = 6;
    vec3 c(center.m_x, center.m_y, 0.f);
    f32 subRadius = radius*math::sin(60);
    poly.push_back(vec3(center.m_x, center.m_y - radius, 0));
    poly.push_back(vec3(center.m_x + subRadius, center.m_y - radius/2, 0));
    poly.push_back(vec3(center.m_x + subRadius, center.m_y + radius / 2, 0));
    poly.push_back(vec3(center.m_x, center.m_y + radius, 0));
    poly.push_back(vec3(center.m_x - subRadius, center.m_y + radius / 2, 0));
    poly.push_back(vec3(center.m_x - subRadius, center.m_y - radius / 2, 0));
    poly.push_back(vec3(center.m_x, center.m_y - radius, 0));
}

//�����ж�
bool GeometryManager::IsLineSegmentCross(const Vector3<ft>& pFirst1, const Vector3<ft>& pFirst2, const Vector3<ft>& pSecond1, const Vector3<ft>& pSecond2) {
    ft line1, line2;
    line1 = pFirst1.x * (pSecond1.y - pFirst2.y) +
        pFirst2.x * (pFirst1.y - pSecond1.y) +
        pSecond1.x * (pFirst2.y - pFirst1.y);
    line2 = pFirst1.x * (pSecond2.y - pFirst2.y) +
        pFirst2.x * (pFirst1.y - pSecond2.y) +
        pSecond2.x * (pFirst2.y - pFirst1.y);
    if (line1 * line2 >= 0 && !(math::equal(line1, 0.f, SSUI_DPH) && math::equal(line2, 0.f, SSUI_DPH))) {
        return false;
    }

    line1 = pSecond1.x * (pFirst1.y - pSecond2.y) +
        pSecond2.x * (pSecond1.y - pFirst1.y) +
        pFirst1.x * (pSecond2.y - pSecond1.y);
    line2 = pSecond1.x * (pFirst2.y - pSecond2.y) +
        pSecond2.x * (pSecond1.y - pFirst2.y) +
        pFirst2.x * (pSecond2.y - pSecond1.y);
    if (line1 * line2 >= 0 && !(math::equal(line1, 0.f, SSUI_DPH) && math::equal(line2, 0.f, SSUI_DPH))) {
        return false;
    }
    return true;
}
bool GeometryManager::GetCrossPointFromSeg(const Vector3<ft>& p1, const Vector3<ft>& p2, const Vector3<ft>& q1, const Vector3<ft>& q2, ft &x, ft &y) {
    if (IsRectCross(p1, p2, q1, q2)) {
        if (IsLineSegmentCross(p1, p2, q1, q2)) {
            //�󽻵�
            f64 tmpLeft, tmpRight;
            tmpLeft = (q2.x - q1.x) * (p1.y - p2.y) - (p2.x - p1.x) * (q1.y - q2.y);
            tmpRight = (p1.y - q1.y) * (p2.x - p1.x) * (q2.x - q1.x) + q1.x * (q2.y - q1.y) * (p2.x - p1.x) - p1.x * (p2.y - p1.y) * (q2.x - q1.x);
            if (math::equal(tmpLeft, 0.0, SSUI_DPH)) {
                return false;
            }
            x = tmpRight / tmpLeft;

            tmpLeft = (p1.x - p2.x) * (q2.y - q1.y) - (p2.y - p1.y) * (q1.x - q2.x);
            tmpRight = p2.y * (p1.x - p2.x) * (q2.y - q1.y) + (q2.x - p2.x) * (q2.y - q1.y) * (p1.y - p2.y) - q2.y * (q1.x - q2.x) * (p2.y - p1.y);
            if (math::equal(tmpLeft, 0.0, SSUI_DPH)) {
                return false;
            }
            y = tmpRight / tmpLeft;
            return true;
        }
    }
    return false;
}
bool GeometryManager::GetCrossPointFromLine(const Vector3<ft>& p1, const Vector3<ft>& p2, const Vector3<ft>& q1, const Vector3<ft>& q2, ft &x, ft &y) {
    //�󽻵�
    f64 tmpLeft, tmpRight;
    tmpLeft = (q2.x - q1.x) * (p1.y - p2.y) - (p2.x - p1.x) * (q1.y - q2.y);
    tmpRight = (p1.y - q1.y) * (p2.x - p1.x) * (q2.x - q1.x) + q1.x * (q2.y - q1.y) * (p2.x - p1.x) - p1.x * (p2.y - p1.y) * (q2.x - q1.x);
    if (math::equal(tmpLeft, 0.0, SSUI_DPH)) {
        return false;
    }
    x = tmpRight / tmpLeft;

    tmpLeft = (p1.x - p2.x) * (q2.y - q1.y) - (p2.y - p1.y) * (q1.x - q2.x);
    tmpRight = p2.y * (p1.x - p2.x) * (q2.y - q1.y) + (q2.x - p2.x) * (q2.y - q1.y) * (p1.y - p2.y) - q2.y * (q1.x - q2.x) * (p2.y - p1.y);
    if (math::equal(tmpLeft, 0.0, SSUI_DPH)) {
        return false;
    }
    y = tmpRight / tmpLeft;
    return true;
}
//����a���ڵ�b,����a�ڵ�b˳ʱ�뷽��,����true,���򷵻�false
bool GeometryManager::PointCmp(const Vector3<ft>& a, const Vector3<ft>& b, const Vector3<ft>& center) {
    if (a.x >= 0 && b.x < 0) {
        return true;
    }
    if (math::equal(a.x, 0.f, SSUI_DPH) && math::equal(b.x, 0.f, SSUI_DPH)) {
        return a.y > b.y;
    }
    //����OA������OB�Ĳ��
    ft det = (a.x - center.x) * (b.y - center.y) - (b.x - center.x) * (a.y - center.y);
    if (det < 0)
        return true;
    if (det > 0)
        return false;
    //����OA������OB���ߣ��Ծ����жϴ�С
    ft d1 = (a.x - center.x) * (a.x - center.x) + (a.y - center.y) * (a.y - center.y);
    ft d2 = (b.x - center.x) * (b.x - center.y) + (b.y - center.y) * (b.y - center.y);
    return d1 > d2;
}

void GeometryManager::ClockwiseSortPoints(const Poly& vPoints) {
    //��������
    Vector3<ft> center;
    ft x = 0, y = 0;
    for (int i = 0; i < vPoints.size(); i++) {
        x += vPoints[i].x;
        y += vPoints[i].y;
    }
    center.x = x / vPoints.size();
    center.y = y / vPoints.size();

    //ð������
    for (int i = 0; i < vPoints.size() - 1; i++) {
        for (int j = 0; j < vPoints.size() - i - 1; j++) {
            if (PointCmp(vPoints[j], vPoints[j + 1], center)) {
                Vector3<ft> tmp = vPoints[j];
                vPoints[j] = vPoints[j + 1];
                vPoints[j + 1] = tmp;
            }
        }
    }
}

bool GeometryManager::getPointIsInAabb(const ft x, const ft y, const Border& aabb) {
    if (x < aabb.m_left || y < aabb.m_top || x > aabb.m_right || y > aabb.m_bottom) {
        return false;
    } else {
        return true;
    }
}

bool GeometryManager::getPointIsInPoly(const ft x, const ft y, const Poly& poly) {
    if (poly.size() < 3) {
        return false;
    }
    auto ps = &poly.back();
    auto pe = poly.begin();
    if (getInsideFromSegAndPoint(vec3(x, y, 0), *ps, *pe) == false) {
        return false;
    }
    ps = poly.begin();
    pe++;
    for (; pe != poly.end(); ps++, pe++) {
        if (getInsideFromSegAndPoint(vec3(x, y, 0), *ps, *pe) == false) {
            return false;
        }
    }
    return true;
}

bool GeometryManager::getIntersectionFromPoly(Poly& retPoly, const Poly& polyA, const Poly& polyB) {
    if (polyA.size() < 3 || polyB.size() < 3) {
        return false;
    }
    //�㼯����
//     ClockwiseSortPoints(polyA);
//     ClockwiseSortPoints(polyB);

    bool flag = false;
    Poly::iterator pAs = &polyA.back();
    Poly::iterator pAe;
    Poly::iterator pBs;
    Poly::iterator pBe;
    int m = 0, k = polyB.size();
    for (auto& poi : polyB) {
        s_pTmpPolyBuff[0][m] = poi;
        m++;
    }
    int ti = 0;
    for (int i = 0; i < polyA.size(); i++) {
        ti = i % 2;
        pAe = &polyA[i];
        pBs = &s_pTmpPolyBuff[ti][k - 1];
        //0�ǲ��ɼ��࣬1�ǿɼ���
        flag = getInsideFromSegAndPoint(*pAs, *pAe, *pBs);
        int cj = k;
        k = 0;
        for (int j = 0; j < cj; j++) {
            pBe = &s_pTmpPolyBuff[ti][j];
            if (getInsideFromSegAndPoint(*pAs, *pAe, *pBe) == true) {
                if (flag == false && GetCrossPointFromLineFast(*pAs, *pAe, *pBs, *pBe, s_pTmpPolyBuff[!ti][k].x, s_pTmpPolyBuff[!ti][k].y)) {
                    //4
                    flag = true;
                    k++;
                    s_pTmpPolyBuff[!ti][k] = (*pBe);
                    k++;
                } else {
                    //1
                    s_pTmpPolyBuff[!ti][k] = (*pBe);
                    k++;
                }
            } else {
                if (flag == true && GetCrossPointFromLineFast(*pAs, *pAe, *pBs, *pBe, s_pTmpPolyBuff[!ti][k].x, s_pTmpPolyBuff[!ti][k].y)) {
                    //3
                    flag = false;
                    k++;
                } else {
                    //2
                }
            }
            pBs = pBe;
        }
        pAs = pAe;
        for (int n = 0; n < k; n++) {
            s_pTmpPolyBuff[ti][n] = s_pTmpPolyBuff[!ti][n];
        }
    }
    if (k < 3) {
        retPoly.clear();
        return false;
    }
    if (retPoly.empty()) {
        retPoly.push_back(s_pTmpPolyBuff[!ti][0]);
        for (int n = 1; n < k; n++) {
            if (((int)s_pTmpPolyBuff[!ti][n].x == (int)s_pTmpPolyBuff[!ti][n - 1].x && (int)s_pTmpPolyBuff[!ti][n].y == (int)s_pTmpPolyBuff[!ti][n - 1].y) ||
                ((int)s_pTmpPolyBuff[!ti][n].x == (int)s_pTmpPolyBuff[!ti][0].x && (int)s_pTmpPolyBuff[!ti][n].y == (int)s_pTmpPolyBuff[!ti][0].y)) {
                continue;
            }
            retPoly.push_back(s_pTmpPolyBuff[!ti][n]);
        }
    } else {
        auto itRet = retPoly.begin();
        bool isOver = false;
        if (itRet == retPoly.end()) {
            retPoly.push_back(s_pTmpPolyBuff[!ti][0]);
            isOver = true;
        } else {
            *itRet = s_pTmpPolyBuff[!ti][0];
            itRet++;
        }
        for (int n = 1; n < k; n++) {
            if (((int)s_pTmpPolyBuff[!ti][n].x == (int)s_pTmpPolyBuff[!ti][n - 1].x && (int)s_pTmpPolyBuff[!ti][n].y == (int)s_pTmpPolyBuff[!ti][n - 1].y) ||
                ((int)s_pTmpPolyBuff[!ti][n].x == (int)s_pTmpPolyBuff[!ti][0].x && (int)s_pTmpPolyBuff[!ti][n].y == (int)s_pTmpPolyBuff[!ti][0].y)) {
                continue;
            }
            if (isOver == true || itRet == retPoly.end()) {
                retPoly.push_back(s_pTmpPolyBuff[!ti][n]);
                isOver = true;
            } else {
                *itRet = s_pTmpPolyBuff[!ti][n];
                itRet++;
            }
        }
        if (isOver == false && itRet != retPoly.end()) {
            retPoly.erase(itRet, retPoly.end());
        }
    }
    if (retPoly.size() < 3) {
        return false;
    }
    //ClockwiseSortPoints(retPoly);

    return true;
}

Geometry* GeometryManager::getIntersectionGeometry(const Poly& polyA, const Poly& polyB) {
    Poly retPoly;
    if (getIntersectionFromPoly(retPoly, polyA, polyB)) {
        Border aabb;
        if (getBorderByPoly(aabb, retPoly)) {
            return GeometryRect::createObject(aabb);
        } else {
            return GeometryPoly::createObject(retPoly);
        }
    } else {
        return nullptr;
    }
}

Geometry* GeometryManager::getIntersectionGeometry(const Poly& polyA, const Geometry* pGeometryB) {
    if (pGeometryB == nullptr) {
        return nullptr;
    }
    Poly tmpPoly;
    const Poly* pPolyB = nullptr;
    if (pGeometryB->getNodeType() == NT_GeometryPoly) {
        pPolyB = &((GeometryPoly*)pGeometryB)->m_poly;
    } else if (pGeometryB->getNodeType() == NT_GeometryRect) {
        const auto& aabb = ((GeometryRect*)pGeometryB)->m_aabb;
        getPolyFromRect(tmpPoly, { aabb.m_left, aabb.m_top, aabb.m_right - aabb.m_left, aabb.m_bottom - aabb.m_top });
        pPolyB = &tmpPoly;
    }
    Poly retPoly;
    if (pPolyB != nullptr && getIntersectionFromPoly(retPoly, polyA, *pPolyB)) {
        Border aabb;
        if (getBorderByPoly(aabb, retPoly)) {
            return GeometryRect::createObject(aabb);
        } else {
            return GeometryPoly::createObject(retPoly);
        }
    } else {
        return nullptr;
    }
}

Geometry* GeometryManager::getIntersectionGeometry(const Geometry* pGeometryA, const Geometry* pGeometryB) {
    if (pGeometryA == nullptr || pGeometryB == nullptr) {
        return nullptr;
    }
    if (pGeometryA->getNodeType() == NT_GeometryPoly) {
        return getIntersectionGeometry(((GeometryPoly*)pGeometryA)->m_poly, pGeometryB);
    } else if (pGeometryA->getNodeType() == NT_GeometryRect) {
        if (pGeometryB->getNodeType() == NT_GeometryPoly) {
            return getIntersectionGeometry(((GeometryPoly*)pGeometryB)->m_poly, pGeometryA);
        } else if (pGeometryB->getNodeType() == NT_GeometryRect) {
            Border aabb;
            if (getIntersectionFromBorder(aabb, ((GeometryRect*)pGeometryA)->m_aabb, ((GeometryRect*)pGeometryB)->m_aabb)) {
                return GeometryRect::createObject(aabb);
            } else {
                return nullptr;
            }
        }
    }
    return nullptr;
}

bool GeometryManager::clipPolyImage(PolyImage& retPolyImage, const PolyImage& polyImageA, const Poly& polyB) {
    if (polyImageA.size() < 3 || polyB.size() < 3) {
        return false;
    }
    //�㼯����
    //     ClockwiseSortPoints(polyA);
    //     ClockwiseSortPoints(polyB);

    bool flag = false;
    PolyImage::iterator pAs = &polyImageA.back();
    PolyImage::iterator pAe;
    PolyImage::iterator pBs;
    PolyImage::iterator pBe;
    int m = 0, k = polyB.size();
    const auto colorData = polyImageA.back().color;
    const vec2 uvData = { 0.f, 0.f };
    for (auto& poi : polyB) {
        s_pTmpPolyImageBuff[0][m] = { poi, colorData, uvData };
        s_pTmpPolyImageBuff[1][m].color = colorData;
        m++;
    }
    for (; m < polyImageA.size() * 2; m++) {
        s_pTmpPolyImageBuff[0][m].color = colorData;
        s_pTmpPolyImageBuff[1][m].color = colorData;
    }

    int ti = 0;
    for (int i = 0; i < polyImageA.size(); i++) {
        ti = i % 2;
        pAe = &polyImageA[i];
        pBs = &s_pTmpPolyImageBuff[ti][k - 1];
        //0�ǲ��ɼ��࣬1�ǿɼ���
        flag = getInsideFromSegAndPoint(pAs->position, pAe->position, pBs->position);
        int cj = k;
        k = 0;
        for (int j = 0; j < cj; j++) {
            pBe = &s_pTmpPolyImageBuff[ti][j];
            if (getInsideFromSegAndPoint(pAs->position, pAe->position, pBe->position) == true) {
                if (flag == false && GetCrossPointFromLineFast(pAs->position, pAe->position, pBs->position, pBe->position,
                    s_pTmpPolyImageBuff[!ti][k].position.x, s_pTmpPolyImageBuff[!ti][k].position.y)) {
                    //4
                    flag = true;
                    k++;
                    s_pTmpPolyImageBuff[!ti][k] = (*pBe);
                    k++;
                } else {
                    //1
                    s_pTmpPolyImageBuff[!ti][k] = (*pBe);
                    k++;
                }
            } else {
                if (flag == true && GetCrossPointFromLineFast(pAs->position, pAe->position, pBs->position, pBe->position,
                    s_pTmpPolyImageBuff[!ti][k].position.x, s_pTmpPolyImageBuff[!ti][k].position.y)) {
                    //3
                    flag = false;
                    k++;
                } else {
                    //2
                }
            }
            pBs = pBe;
        }
        pAs = pAe;
        for (int n = 0; n < k; n++) {
            s_pTmpPolyImageBuff[ti][n] = s_pTmpPolyImageBuff[!ti][n];
        }
    }
    if (k < 3) {
        retPolyImage.clear();
        return false;
    }
    if (retPolyImage.empty()) {
        retPolyImage.push_back(s_pTmpPolyImageBuff[!ti][0]);
        for (int n = 1; n < k; n++) {
            if (((int)s_pTmpPolyImageBuff[!ti][n].position.x == (int)s_pTmpPolyImageBuff[!ti][n - 1].position.x &&
                (int)s_pTmpPolyImageBuff[!ti][n].position.y == (int)s_pTmpPolyImageBuff[!ti][n - 1].position.y) ||
                ((int)s_pTmpPolyImageBuff[!ti][n].position.x == (int)s_pTmpPolyImageBuff[!ti][0].position.x &&
                (int)s_pTmpPolyImageBuff[!ti][n].position.y == (int)s_pTmpPolyImageBuff[!ti][0].position.y)) {
                continue;
            }
            retPolyImage.push_back(s_pTmpPolyImageBuff[!ti][n]);
        }
    } else {
        auto itRet = retPolyImage.begin();
        bool isOver = false;
        if (itRet == retPolyImage.end()) {
            retPolyImage.push_back(s_pTmpPolyImageBuff[!ti][0]);
            isOver = true;
        } else {
            *itRet = s_pTmpPolyImageBuff[!ti][0];
            itRet++;
        }
        for (int n = 1; n < k; n++) {
            if (((int)s_pTmpPolyImageBuff[!ti][n].position.x == (int)s_pTmpPolyImageBuff[!ti][n - 1].position.x &&
                (int)s_pTmpPolyImageBuff[!ti][n].position.y == (int)s_pTmpPolyImageBuff[!ti][n - 1].position.y) ||
                ((int)s_pTmpPolyImageBuff[!ti][n].position.x == (int)s_pTmpPolyImageBuff[!ti][0].position.x &&
                (int)s_pTmpPolyImageBuff[!ti][n].position.y == (int)s_pTmpPolyImageBuff[!ti][0].position.y)) {
                continue;
            }
            if (isOver == true || itRet == retPolyImage.end()) {
                retPolyImage.push_back(s_pTmpPolyImageBuff[!ti][n]);
                isOver = true;
            } else {
                *itRet = s_pTmpPolyImageBuff[!ti][n];
                itRet++;
            }
        }
        if (isOver == false && itRet != retPolyImage.end()) {
            retPolyImage.erase(itRet, retPolyImage.end());
        }
    }
    if (retPolyImage.size() < 3) {
        return false;
    }
    //ClockwiseSortPoints(retPoly);
    assignPolyImageByPolyImage(retPolyImage, polyImageA);

    return true;
}

bool GeometryManager::clipPolyImage(PolyImage& retPolyImage, const Poly& polyClip) {
    if (retPolyImage.size() < 3 || polyClip.size() < 3) {
        return false;
    }
    s_tmpPolyImageA = retPolyImage;
    return clipPolyImage(retPolyImage, s_tmpPolyImageA, polyClip);
}

bool ssui::GeometryManager::clipPolyImage(PolyImage& retPolyImage, const Border& border) {
    static Border renderArea;
    if (GeometryManager::getBorderByPolyImage(renderArea, retPolyImage)) {
        if (renderArea <= border) {
            return true;
        }
        if (renderArea.cross(border)) {
            s_tmpPolyImageA = retPolyImage;
            getPolyFromBorder(retPolyImage, renderArea);
            assignPolyImageByPolyImage(retPolyImage, s_tmpPolyImageA);
            return true;
        } else {
            retPolyImage.clear();
            return false;
        }
    } else {
        Poly poly;
        getPolyFromBorder(poly, border);
        return clipPolyImage(retPolyImage, poly);
    }
}

void ssui::GeometryManager::transformPosition(PolyImage& poly, ft x, ft y) {
    for (auto& vpct : poly) {
        vpct.position.x += x;
        vpct.position.y += y;
    }
}

void ssui::GeometryManager::transformScale(PolyImage& poly, ft scaleX, ft scaleY, ft cx, ft cy) {

}

void ssui::GeometryManager::transformAngle(PolyImage& poly, ft angle, ft cx, ft cy) {

}
