#include "Engine.h"

#include "UIManager.h"
#include "NodeManager.h"
#include "DataManager.h"
#include "StringManager.h"
#include "DictionaryManager.h"
#include "UIScene.h"
#include "AppEngineWin.h"
#include "Control.h"
#include "ImageManager.h"
#include "Timer.h"
#include "NodeManager.h"
#include "ObjectAttrDef.hpp"

string UIManager::s_className = "UIManager";
UIManager* UIManager::s_pInstance = nullptr;
#ifdef _WIN32
HWND UIManager::s_hUe = null;
#endif
string UIManager::script_modName = "script/";
string UIManager::script_sourcePath = "script/";
HashMap<int, UIManager::JoyStickInfo*> UIManager::m_mapJoyStickInfo;
ArrayList<wstring> UIManager::arr_canNotInputWstr;
wstring UIManager::default_canNotInputWstr("`,\r,\n");
const s32 UIManager::RICHTEXT_FACE_MAX = 99;
LinkedHashMap<wstring, wstring> UIManager::s_replaceString[3];

void UIManager::setUISceneEnableMode(E_UI_Scene_Enable_Mode mode) {
    //    if (mode != UI_Scene_Enable_Mode) {
    UI_Scene_Enable_Mode = mode;
    for (auto scene : UIScene::s_arrScene) {
        scene->checkEnable();
    }
    //    }
}

E_UI_Scene_Enable_Mode UIManager::getUISceneEnableMode() {
    return UI_Scene_Enable_Mode;
}
ArrayList<string>& UIManager::getEnableWhiteList() {
    return enableWhiteList;
}
ArrayList<string>& UIManager::getEnableBlackList() {
    return enableBlackList;
}
void UIManager::changeUISceneEnableWhiteList(const string& uiname, b2 isAdd) {
    s32 index = enableWhiteList.where(uiname);
    if (isAdd && index == -1) {
        enableWhiteList.push_back(uiname);
    } else if (!isAdd && index != -1) {
        enableWhiteList.erase(enableWhiteList.begin() + index);
    }
    if (UI_Scene_Enable_Mode == E_UI_Scene_Enable_Whitelist) {
        auto bs = getUI(uiname);
        if (bs) {
            bs->checkEnable();
        }
    }
}

void UIManager::changeUISceneEnableBlackList(const string& uiname, b2 isAdd) {
    s32 index = enableBlackList.where(uiname);
    if (isAdd && index == -1) {
        enableBlackList.push_back(uiname);
    } else if (!isAdd && index != -1) {
        enableBlackList.erase(enableBlackList.begin() + index);
    }
    if (UI_Scene_Enable_Mode == E_UI_Scene_Enable_Blacklist) {
        auto bs = getUI(uiname);
        if (bs) {
            bs->checkEnable();
        }
    }
}

void UIManager::clearUISceneEnableWhiteList() {
    enableWhiteList.clear();
}

void UIManager::clearUISceneEnableBlackList() {
    enableBlackList.clear();
}

void UIManager::setDefaultCanNotInputWstr(const wstring& str) {
    default_canNotInputWstr = str;
    initCanNotInputWstrList();
}
void UIManager::initCanNotInputWstrList() {
    initCanNotInputWstring(default_canNotInputWstr);
}
void UIManager::initCanNotInputWstring(const wstring& str) {
    arr_canNotInputWstr.clear();
    util::split(str, ',', arr_canNotInputWstr);
}

void UIManager::initReplaceString() {
    wstring oldstring;
    wstring newstring;
    for (s32 i = RICHTEXT_FACE_MAX; i > 0; i--) {
        oldstring = "#";
        oldstring += util::itoa_s(i);
        newstring = "[Face";
        newstring += util::itoa_s(i);
        newstring += "s.0]";
        newstring += " [before]";
        s_replaceString[1].insert(oldstring, newstring);
    }
    for (s32 i = RICHTEXT_FACE_MAX; i > 0; i--) {
        oldstring = "#";
        oldstring += util::itoa_s(i);
        newstring = "[Face";
        newstring += util::itoa_s(i);
        newstring += ".0]";
        newstring += " [before]";
        s_replaceString[2].insert(oldstring, newstring);
    }
}

void UIManager::initialize() {
    if (s_pInstance == nullptr) {
        s_pInstance = new UIManager();
    }
    BoloVM::registerEnterClass(UIManager::getInstance(), UIManager::getInstance()->getClassName());
    UIManager::initScriptLib<UIManager>();
    clearJoyStickInfo();
    initCanNotInputWstrList();
    initReplaceString();
    if (getInstance()->isUeMode()) {
        LanguageManager::getInstance()->setLanguage(UIManager::getInstance()->m_curUeLanguage);
    }
}

void UIManager::destroy() {
    safe_delete(s_pInstance);
}

bool ssui::UIManager::isUeMode() const {
#ifdef WIN32
    if (AppEngineWin::ueHandle() != null) {
        return true;
    }
#endif
    return false;
}

void ssui::UIManager::update() {
    if (NodeManager::getInstance()->m_isReady == false) {
        NodeManager::initialize();
        DataManager::getInstance()->initSSUIFunc();
        float sx = (ft)Engine::screen().x;
        float sy = (ft)Engine::screen().y;
        m_screenScaleX = Graphics::screen().x / (ft)Engine::screen().x;
        m_screenScaleY = Graphics::screen().y / (ft)Engine::screen().y;
        if (isUeMode()) {
#ifdef WIN32
            COPYDATASTRUCT hwData;

            hwData.dwData = G2W2_HWND; //G2W2_HWND
            hwData.cbData = 0;
            hwData.lpData = AppEngineWin::coreHandle();
            SendMessage(AppEngineWin::ueHandle(), WM_COPYDATA, (WPARAM)AppEngineWin::coreHandle(), (LPARAM)&hwData);
            UIManager::sendNodeAttrData();
#endif
        }
    }
    Timer::updateTime(GameTime::getUseTimeStable());
    NodeManager::getInstance()->onDraw();
    NodeManager::getInstance()->onShow();
}

void UIManager::loadXmlConfig() {
    DataManager::getInstance()->loadXmlConfigFromTemplate();
}

ssui::UIManager::UIManager() {
    m_curUeLanguage = LanguageManager::getInstance()->mc_lang_default;
}

UIScene* UIManager::loadUI(const string& name, bool isFindFromUpdate) {
    auto pScene = UIScene::setFocus(name);
    if (pScene == nullptr) {
        return DataManager::getInstance()->loadUISceneFromTemplate(name, isFindFromUpdate);
    } else {
        pScene->setUIVisible(true);
        pScene->initScene();
        //pScene->onEvent(SSUIEvent::createSSUIEvent(ET_onSceneLoaded));
        return pScene;
    }
}

UIScene* UIManager::loadUI(const wstring& name, bool isFindFromUpdate) {
    auto pTmp = RPM::s_rpString.createObject();
    pTmp->clear();
    util::str2str(name, *pTmp);
    auto ret = loadUI(*pTmp, isFindFromUpdate);
    if (ret) {
        printlog("curScene = %s\n", pTmp->c_str());
    }
    else {
        printlog("scene = %s not found\n", pTmp->c_str());
    }
    RPM::s_rpString.releaseObject(pTmp, RPM::releaseString);
    return ret;
}

void UIManager::closeUI(const string& name) {
    UIScene::closeScene(name);
}

void UIManager::closeUI(const wstring& name) {
    auto pTmp = RPM::s_rpString.createObject();
    pTmp->clear();
    util::str2str(name, *pTmp);
    closeUI(*pTmp);
    RPM::s_rpString.releaseObject(pTmp, RPM::releaseString);
}

void UIManager::closeAllUI() {
    UIScene::closeAllScene();
}

void ssui::UIManager::regUserAttr(const string& className, const string& attrName) {
    m_mapUserAttrTriggerData[className.hashCode()][attrName.hashCode()] = string("UI_") + className + "_" + attrName;
}

UIScene* UIManager::getUI(const string& uiName) {
    for (auto scene : UIScene::s_arrScene) {
        if (scene->getName() == uiName) {
            return scene;
        }
    }
    return nullptr;
}
bool UIManager::existUI(const string& name) {
    return getUI(name);
}
Control* UIManager::getControl(const string& uiName, const string& ctrlName) {
    UIScene* scene = getUI(uiName);
    if (scene) {
        return scene->getControlWithId(ctrlName);
    }
    return nullptr;
}
void UIManager::setUIVisible(const string& uiName, bool isVis) {
    auto scene = getUI(uiName);
    if (scene) {
        scene->setUIVisible(isVis);
    }
}

void UIManager::setAllUIVisible(b2 isVis) {
    for (auto& pScene : UIScene::s_arrScene) {
        pScene->setUIVisible(isVis);
    }
}

void UIManager::checkAllUIWithWar(const string& uiName) {
    for (s32 i = 0; i < UIScene::s_arrScene.size(); i++) {
        auto* pScene = UIScene::s_arrScene[i];
        if (pScene->getName() == uiName) {
            pScene->setUIVisible(true);
        }else {
            closeUI(pScene->getName());
            i--;
        }
    }
}


void UIManager::drawImage(const Texture& tex, const vec4& rect, const vec4& clipRect, const Color & color) {
    auto nm = NodeManager::getInstance();
    nm->pushShow();
    nm->m_showCacheTexture = nullptr;
    nm->m_showCacheVpct.clear();
    Graphics::drawImage(tex, rect, clipRect, color);
}

void UIManager::clearJoyStickInfo() {
    for (auto it : m_mapJoyStickInfo) {
        if (it.second) {
            delete it.second;
        }
    }
    m_mapJoyStickInfo.clear();
}

void UIManager::addJoyStickInfo(s32 joystickId, ft angle, ft strength) {
    auto it = m_mapJoyStickInfo.find(joystickId);
    if (it != m_mapJoyStickInfo.end()) {
        if (it->second) {
            it->second->setJoyStickInfo(angle, strength);
        } else {
            JoyStickInfo* jsInfo = new JoyStickInfo(joystickId, angle, strength);
            m_mapJoyStickInfo[joystickId] = jsInfo;
        }
    } else {
        JoyStickInfo* jsInfo = new JoyStickInfo(joystickId, angle, strength);
        m_mapJoyStickInfo.insert(joystickId, jsInfo);
    }
}

ft UIManager::getJoyStickAngleById(s32 joystickId) {
    auto it = m_mapJoyStickInfo.find(joystickId);
    if (it != m_mapJoyStickInfo.end()) {
        if (it->second) {
            return it->second->getJoyStickAngle();
        }
    }
    return -1;
}
ft UIManager::getJoyStickStrengthById(s32 joystickId) {
    auto it = m_mapJoyStickInfo.find(joystickId);
    if (it != m_mapJoyStickInfo.end()) {
        if (it->second) {
            return it->second->getJoyStickStrength();
        }
    }
    return -1;
}

b2 UIManager::getUIVisible(const string& uiName) {
    auto scene = getUI(uiName);
    if (scene) {
        return scene->getUIVisible();
    }
    return false;
}

void UIManager::loadScriptInner(const string& name, const ArrayList<BoloVar>& args, bool inMod) {
    string header = script_modName;
    bool saveInMod = ResLoader::isResInMod();
    if (!inMod) {//��ʹ��mod�е���Դ��ʹ�ñ���ԭʼ��Դ
        header = script_sourcePath;
    }
    ResLoader::setResInMod(inMod);//������
    auto bolo = Bolo::get(header + name);
    bolo.gen();
    bolo.clearSource();
    bolo.execute(args);
    ResLoader::setResInMod(saveInMod);//�ٻ�ԭ
}

void UIManager::setScriptModName(const string& mod) {
    script_modName = mod;
}

void UIManager::setScriptSourcePath(const string& path) {
    script_sourcePath = path;
}

BoloVar bolo_ui_getCurUI(bolo_stack stack, void* self) {
    return bolo_create(stack, (BoloObject*)UIScene::getCurScene(), false);
}

BoloVar bolo_ui_loadUI(bolo_stack stack, void* self) {
    return bolo_create(stack, (BoloObject*)UIManager::getInstance()->loadUI(bolo_string(stack)), false);
}

BoloVar bolo_ui_closeUI(bolo_stack stack, void* self) {
    UIManager::getInstance()->closeUI(bolo_string(stack));
    return bolo_create(stack);
}

BoloVar bolo_ui_closeAllUI(bolo_stack stack, void* self) {
    UIManager::getInstance()->closeAllUI();
    return bolo_create(stack);
}

BoloVar bolo_ui_setUIVisible(bolo_stack stack, void* self) {
    string uiName = bolo_string(stack);
    int vis = bolo_int(stack);
    UIManager::getInstance()->setUIVisible(uiName, vis);
    return bolo_create(stack);
}

BoloVar bolo_ui_setAllUIVisible(bolo_stack stack, void* self) {
    s32 vis = bolo_int(stack);
    UIManager::getInstance()->setAllUIVisible(vis);
    return bolo_create(stack);
}

BoloVar bolo_ui_getUIVisible(bolo_stack stack, void* self) {
    string uiName = bolo_string(stack);
    return bolo_create(stack, UIManager::getInstance()->getUIVisible(uiName));
}

BoloVar bolo_ui_checkAllUIWithWar(bolo_stack stack, void* self) {
    string uiName = bolo_string(stack);
    UIManager::getInstance()->checkAllUIWithWar(uiName);
    return bolo_create(stack);
}

BoloVar bolo_ui_regUserAttr(bolo_stack stack, void* self) {
    UIManager::getInstance()->regUserAttr(bolo_string(stack), bolo_string(stack));
    return bolo_create(stack);
}
BoloVar bolo_ui_getUI(bolo_stack stack, void*) {
    return bolo_create(stack, UIManager::getInstance()->getUI(bolo_string(stack)), false);
}

BoloVar bolo_ui_existUI(bolo_stack stack, void*) {
    return bolo_create(stack, UIManager::getInstance()->existUI(bolo_string(stack)));
}
BoloVar bolo_ui_getControl(bolo_stack stack, void*) {
    string uiName = bolo_string(stack);
    string ctrlName = bolo_string(stack);
    return bolo_create(stack, (BoloObject*)UIManager::getInstance()->getControl(uiName, ctrlName), false);
}

BoloVar bolo_ui_getMemory(bolo_stack stack, void* self) {
    wstring key = bolo_wstring(stack);
    wstring st = UIScene::getMemory(key);
    return bolo_create(stack, st);
}

BoloVar bolo_ui_setMemory(bolo_stack stack, void* self) {
    wstring key = bolo_wstring(stack);
    wstring value = bolo_wstring(stack);
    UIScene::memory[key] = value;
    return bolo_create(stack);
}

BoloVar bolo_ui_getAuctionMemory(bolo_stack stack, void* self) {
    wstring key = bolo_wstring(stack);
    wstring st = UIScene::getAuctionMemory(key);
    return bolo_create(stack, st);
}

BoloVar bolo_ui_setAuctionMemory(bolo_stack stack, void* self) {
    wstring key = bolo_wstring(stack);
    wstring value = bolo_wstring(stack);
    UIScene::auctionMemory[key] = value;
    return bolo_create(stack);
}

BoloVar bolo_ui_clearAuctionMemory(bolo_stack stack, void* self) {
    UIScene::auctionMemory.clear();
    return bolo_create(stack);
}

BoloVar bolo_ui_getUIList(bolo_stack stack, void* self) {
    int size = UIScene::s_arrScene.size();
    BoloVar* vecs = stack->createArray(size);
    for (int i = 0; i < size; i++) {
        UIScene* tbus = UIScene::s_arrScene[i];
        vecs[i] = (bolo_create(stack, tbus->getName()));
    }
    return bolo_create(stack, vecs, size);
}

BoloVar bolo_ui_getCurEventX(bolo_stack stack, void* self) {
    int x = SSUIEvent::getLastTouchEvent().m_iData1;
    return bolo_create(stack, x);
}

BoloVar bolo_ui_getCurEventY(bolo_stack stack, void* self) {
    int y = SSUIEvent::getLastTouchEvent().m_iData2;
    return bolo_create(stack, y);
}

BoloVar bolo_ui_getScreenW(bolo_stack stack, void* self) {
    int w = Graphics::screen().x;
    return bolo_create(stack, w);
}

BoloVar bolo_ui_getScreenH(bolo_stack stack, void* self) {
    int h = Graphics::screen().y;
    return bolo_create(stack, h);
}

BoloVar bolo_ui_ui2screen(bolo_stack stack, void* self) {
    s32 x = bolo_int(stack);
    s32 y = bolo_int(stack);
    vec2i screenPos = Graphics::ui2screen(vec2i(x, y));
    BoloVar* vecs = stack->createArray(2);
    vecs[0] = (bolo_create(stack, screenPos.x));
    vecs[1] = (bolo_create(stack, screenPos.y));
    return bolo_create(stack, vecs, 2);
}

BoloVar bolo_ui_setSceneEnable(bolo_stack stack, void* self) {
    string uiName = bolo_string(stack);
    b2 isEnable = bolo_int(stack);
    UIScene* scene = UIManager::getInstance()->getUI(uiName);
    if (scene) {
        scene->setEnable(isEnable);
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_getSceneEnable(bolo_stack stack, void* self) {
    string uiName = bolo_string(stack);
    UIScene* scene = UIManager::getInstance()->getUI(uiName);
    b2 isEnable = true;
    if (scene) {
        isEnable = scene->isEnable();
    }
    return bolo_create(stack, isEnable);
}

BoloVar bolo_ui_setUISceneEnableMode(bolo_stack stack, void* self) {
    s32 mode = bolo_int(stack);
    UIManager::getInstance()->setUISceneEnableMode((E_UI_Scene_Enable_Mode)mode);
    return bolo_create(stack);
}

BoloVar bolo_ui_changeSceneEnableWhiteList(bolo_stack stack, void* self) {
    string name = bolo_string(stack);
    b2 isAdd = bolo_int(stack);
    UIManager::getInstance()->changeUISceneEnableWhiteList(name, isAdd);
    return bolo_create(stack);
}

BoloVar bolo_ui_clearSceneEnableWhiteList(bolo_stack stack, void* self) {
    UIManager::getInstance()->clearUISceneEnableWhiteList();
    return bolo_create(stack);
}

BoloVar bolo_ui_changeSceneEnableBlackList(bolo_stack stack, void* self) {
    string name = bolo_string(stack);
    b2 isAdd = bolo_int(stack);
    UIManager::getInstance()->changeUISceneEnableBlackList(name, isAdd);
    return bolo_create(stack);
}

BoloVar bolo_ui_clearSceneEnableBlackList(bolo_stack stack, void* self) {
    UIManager::getInstance()->clearUISceneEnableBlackList();
    return bolo_create(stack);
}

void UIManager::registerReflection(int id) {
    registerFunc(id, "getCurUI", bolo_ui_getCurUI, "(UIScene)getCurUI()"); ////
    registerFunc(id, "loadUI", bolo_ui_loadUI, "(UIScene*)loadUI(string name)");
    registerFunc(id, "closeUI", bolo_ui_closeUI, "(void)closeUI(string name)");
    registerFunc(id, "closeAllUI", bolo_ui_closeAllUI, "(void)closeAllUI()");
    registerFunc(id, "regUserAttr", bolo_ui_regUserAttr, "(void)regUserAttr(string className, string attrName)");
    registerFunc(id, "getUI", bolo_ui_getUI, "UIScene* getUI(string uiName)");
    registerFunc(id, "existUI", bolo_ui_existUI, "UIScene* getUI(string uiName)");
    registerFunc(id, "setUIVisible", bolo_ui_setUIVisible, "(void)setUIVisible(String name, bools v)");
    registerFunc(id, "setAllUIVisible", bolo_ui_setAllUIVisible, "(void)setALLUIVisible(String name, bools v)");
    registerFunc(id, "getUIVisible", bolo_ui_getUIVisible, "(bool)getUIVisible(String name)");
    registerFunc(id, "checkAllUIWithWar", bolo_ui_checkAllUIWithWar, "(void)checkAllUIWithWar()");
    registerFunc(id, "getControl", bolo_ui_getControl, "Control* getControl(string uiName, string ctrlName)");
    registerFunc(id, "getMemory", bolo_ui_getMemory, "(String)get memory(String key)");
    registerFunc(id, "setMemory", bolo_ui_setMemory, "(void)set memory(Stirng key,String value)");
    registerFunc(id, "getAuction", bolo_ui_getAuctionMemory, "(String)get auctionMemory(String key)");
    registerFunc(id, "setAuction", bolo_ui_setAuctionMemory, "(void)set auctionMemory(Stirng key,String value)");
    registerFunc(id, "clearAuction", bolo_ui_clearAuctionMemory, "(void)clear auctionMemory(void)");
    registerFunc(id, "getUIList", bolo_ui_getUIList, "(UIScene)getUIList()");
    registerFunc(id, "getCurEventX", bolo_ui_getCurEventX, "(int)bolo_ui_getCurEventX()");
    registerFunc(id, "getCurEventY", bolo_ui_getCurEventY, "(int)bolo_ui_getCurEventY()");
    registerFunc(id, "getScreenW", bolo_ui_getScreenW, "(int)bolo_ui_getScreenW()");
    registerFunc(id, "getScreenH", bolo_ui_getScreenH, "(int)bolo_ui_getScreenH()");
    registerFunc(id, "ui2screen", bolo_ui_ui2screen, "(vec2)bolo_ui_ui2screen(vec2)");

    registerFunc(id, "setSceneEnable", bolo_ui_setSceneEnable, "(void)setSceneEnable(String uiName, bool enable)");
    registerFunc(id, "getSceneEnable", bolo_ui_getSceneEnable, "(bool)getSceneEnable(String uiName)");

    registerFunc(id, "setUISceneEnableMode", bolo_ui_setUISceneEnableMode, "(void)setUISceneEnableMode(int mode)");
    //ui����������
    registerFunc(id, "changeSceneEnableWhiteList", bolo_ui_changeSceneEnableWhiteList, "(void)changeSceneEnableWhiteList(String name, bool enable)");
    registerFunc(id, "clearSceneEnableWhiteList", bolo_ui_clearSceneEnableWhiteList, "(void)clearSceneEnableWhiteList()");
    registerFunc(id, "changeSceneEnableBlackList", bolo_ui_changeSceneEnableBlackList, "(void)changeSceneEnableBlackList(String name, bool enable)");
    registerFunc(id, "clearSceneEnableBlackList", bolo_ui_clearSceneEnableBlackList, "(void)clearSceneEnableBlackList()");
}

void UIManager::dealCommand(const InputEvent& input) {
    int code = input.commandCode;
#ifdef _WIN32
    if (code == W2G2_NORMAL_DATA) {
        if (isUeMode()) {
            LanguageManager::getInstance()->setLanguage(m_curUeLanguage);
        }
        //LogPrintf("\r\n%s", 2, input.schars);
        DataManager::getInstance()->loadXmlFromMsgData(string(input.schars));
    } else if(code >= W2G2_UI_MIN && code <= W2G2_UI_MAX) {
        StringManager::getInstance()->m_tmpString.clear();
        StringManager::getInstance()->m_tmpWString.clear();
        StringManager::getInstance()->m_tmpWString = util::unicode2wstr((wstring::value_type*)input.chars);
        util::str2str(util::unicode2wstr((wstring::value_type*)input.chars), StringManager::getInstance()->m_tmpString);
        switch (code) {
        case W2G2_HWND:
            break;
        case W2G2_FILE_LOAD:
            loadUI(StringManager::getInstance()->m_tmpString);
            break;
        case W2G2_FILE_CLOSE:
            closeUI(StringManager::getInstance()->m_tmpString);
            break;
        case W2G2_ATTR_CHANGE:
            StringManager::getInstance()->m_arrTmpWSplit.clear();
            util::split(StringManager::getInstance()->m_tmpWString, ':', StringManager::getInstance()->m_arrTmpWSplit);
            if (StringManager::getInstance()->m_arrTmpWSplit.size() > 3) {
                for (auto curSub = StringManager::getInstance()->m_arrTmpWSplit.begin() + 3; curSub != StringManager::getInstance()->m_arrTmpWSplit.end(); curSub++) {
                    StringManager::getInstance()->m_arrTmpWSplit[2] += ':';
                    StringManager::getInstance()->m_arrTmpWSplit[2] += (*curSub);
                }
            }
            if (StringManager::getInstance()->m_arrTmpWSplit.size() >= 3) {
                setAttrValueBySsueId(util::aton_s(StringManager::getInstance()->m_arrTmpWSplit[0], 16), StringManager::getInstance()->m_arrTmpWSplit[1],
                    StringManager::getInstance()->m_arrTmpWSplit[2]);
            }
            break;
        case W2G2_PATH_SETTING:
            StringManager::getInstance()->m_arrTmpSplit.clear();
            util::split(StringManager::getInstance()->m_tmpString, '|', StringManager::getInstance()->m_arrTmpSplit);
            if (StringManager::getInstance()->m_arrTmpSplit.size() >= 3) {
                DataManager::getInstance()->resetProjPath(StringManager::getInstance()->m_arrTmpSplit[0]);
            }
            break;
        case W2G2_SELECT_UI:
            UIManager::selectCurSsueControl(StringManager::getInstance()->m_tmpWString);
            break;
        case W2G2_SHOW_OUTLINE:
            if (StringManager::getInstance()->m_tmpWString.empty() == false && StringManager::getInstance()->m_tmpWString.front() == 't') {
                m_isShowOutLine = true;
            } else {
                m_isShowOutLine = false;
            }
            break;
        case W2G2_SHOWBORDER:
            UIManager::showBorder(StringManager::getInstance()->m_tmpWString);
            break;
        case W2G2_VIEWSIZE:
            StringManager::getInstance()->m_arrTmpWSplit.clear();
            util::split(StringManager::getInstance()->m_tmpWString, ':', StringManager::getInstance()->m_arrTmpWSplit);
            if (StringManager::getInstance()->m_arrTmpWSplit.size() >= 5) {
                bool env;
                m_settingScreenX = util::atoi_s(StringManager::getInstance()->m_arrTmpWSplit[0]);
                m_settingScreenY = util::atoi_s(StringManager::getInstance()->m_arrTmpWSplit[1]);
                env = StringManager::getInstance()->m_arrTmpWSplit[2].front() == 't' ? true : false;
                m_settingScreenVx = util::atoi_s(StringManager::getInstance()->m_arrTmpWSplit[3]);
                m_settingScreenVy = util::atoi_s(StringManager::getInstance()->m_arrTmpWSplit[4]);
                //resize(m_settingScreenX, m_settingScreenY);
                Engine::setVirtualUISize(m_settingScreenVx, m_settingScreenVy);
                auto ui = Engine::uiScreen();
                Graphics::resize(ui);
                setViewSize({ m_settingScreenX, m_settingScreenY }, ui);
            }
            break;
        case W2G2_LANGUAGE:
            m_curUeLanguage = StringManager::getInstance()->m_tmpString;
            break;
        case W2G2_UI_MAX:
            break;
        default:
            break;
        }
    }
#endif
}

void ssui::UIManager::setViewSize(const vec2i& size, const vec2i& vsize) {
    m_settingScreenX = size.x;
    m_settingScreenY = size.y;
    m_settingScreenVx = vsize.x;
    m_settingScreenVy = vsize.y;
    resize(m_settingScreenX, m_settingScreenY);
}

void ssui::UIManager::resize(int w, int h) {
//    if (m_settingScreenVx != 0.f && m_settingScreenVy != 0.f) {
//        Engine::setVirtualUISize(m_settingScreenVx, m_settingScreenVy);
//    }
//    Engine::resize(w, h);
    m_screenScaleX = Graphics::screen().x / (ft)w;
    m_screenScaleY = Graphics::screen().y / (ft)h;
    for (auto& pScene : UIScene::s_arrScene) {
        if (pScene->m_pRootControl) {
            pScene->m_pRootControl->touchMeasureChanged();
        }
    }
}

s64 UIManager::getSsueNodeId(const ObjectBase* pNode) const {
    if (pNode != nullptr && !m_mapSsueNodeId.empty()) {
        const auto& pairNodeId = m_mapSsueNodeId.find((__ptr)pNode);
        if (pairNodeId != m_mapSsueNodeId.end()) {
            return pairNodeId->second;
        }
    }
    return 0;
}

ObjectBase* UIManager::getSsueNode(s64 id) const {
    const auto& pairIdNode = m_mapSsueIdNode.find(id);
    if (pairIdNode != m_mapSsueIdNode.end()) {
        return (ObjectBase*)pairIdNode->second;
    }
    return nullptr;
}

void UIManager::insertSsueNode(s64 id, ObjectBase* pNode) {
    const auto& pairIdNode = m_mapSsueIdNode.find(id);
    if (pairIdNode != m_mapSsueIdNode.end()) {
        m_mapSsueNodeId.erase(pairIdNode->second);
        m_mapSsueIdNode.erase(pairIdNode);
    }
    deleteSsueNode(pNode);
    if (id != 0 && pNode != nullptr) {
        m_mapSsueIdNode.insert(id, (__ptr)pNode);
        m_mapSsueNodeId.insert((__ptr)pNode, id);
    }
}

void UIManager::deleteSsueNode(ObjectBase* pNode) {
    if (pNode != nullptr && !m_mapSsueNodeId.empty()) {
        const auto& pairNodeId = m_mapSsueNodeId.find((__ptr)pNode);
        if (pairNodeId != m_mapSsueNodeId.end()) {
            m_mapSsueIdNode.erase(pairNodeId->second);
            m_mapSsueNodeId.erase(pairNodeId);
        }
    }
}

int UIManager::setAttrValueBySsueId(s64 id, const wstring& attrName, const wstring& attrValue) {
    auto pNode = getSsueNode(id);
    if (pNode == nullptr) {
        return -1;
    }
    return pNode->setAttrValue(attrName, attrValue);
}

int ssui::UIManager::loadCsvData(const wstring& csvData) {
    if (csvData.empty()) {
        return -1;
    }
    ArrayList<wstring>* tmpDataList = RPM::s_rpArrStringW.createObject();
    tmpDataList->clear();
    util::split(csvData, '\n', *tmpDataList);
    for (auto& csvRow : *tmpDataList) {
        if (csvRow.empty())
            continue;
        if (csvRow.back() == '\r') {
            csvRow.pop_back();
        }
    }
    auto itRow = tmpDataList->begin();
    string name_str = "";
    util::str2str(*itRow, name_str);
    auto pScene = getUI(name_str);
    if (pScene == nullptr) {
        RPM::s_rpArrStringW.releaseObject(tmpDataList, RPM::releaseArrStringW);
        return -2;
    }
    int beginTime = GameTime::getTime();
    if (UIScene::logCSV) {
        LOG("------------------- CSV Begin -------------------", UIScene::LogPriority);
        LOG(*itRow, UIScene::LogPriority);
    }
    ArrayList<Control*> cannotRemoveAddControl;
    for (++itRow; itRow != tmpDataList->end(); ++itRow) {
        pScene->parseCsvRow(*itRow, cannotRemoveAddControl);
    }
    pScene->onEvent(SSUIEvent::createSSUIEvent(ET_onCSVLoaded));
    int endTime = GameTime::getTime();
    if (UIScene::logCSV) {
        LOG("------ total time = %d ------\n", endTime - beginTime);
        LOG("------------------- CSV End -------------------", UIScene::LogPriority);
    }
    cannotRemoveAddControl.clear();
    RPM::s_rpArrStringW.releaseObject(tmpDataList, RPM::releaseArrStringW);
    return 0;
}

#ifdef _WIN32

void UIManager::sendUiCommand(int tag, const wstring& message) {
    if (s_hUe != null) {
        COPYDATASTRUCT hwData;
        hwData.dwData = tag; //G2W2_HWND
        hwData.cbData = (message.size() + 1) * sizeof(unichar);
        hwData.lpData = (PVOID)message.c_str();
        SendMessage(s_hUe, WM_COPYDATA, 0, (LPARAM)&hwData);
    }
}

void ssui::UIManager::sendNodeAttrData() {
    wstring initData;
    DataManager::getInstance()->getNodeInitData(initData);
    UIManager::sendUiCommand(G2W2_INIT_NODEDATA, initData);
    DataManager::getInstance()->getAttrInitData(initData);
    UIManager::sendUiCommand(G2W2_INIT_ATTRDATA, initData);
    DataManager::getInstance()->getLanguageSettingInitData(initData);
    UIManager::sendUiCommand(G2W2_INIT_LANGUAGE_LMAP, initData);
}

void UIManager::toNextSsueControl() {
    if (m_pArrSsueControl.empty()) {
        m_pCurSsueControl = nullptr;
        return;
    }
    if (m_pCurSsueControl == nullptr) {
        m_pCurSsueControl = m_pArrSsueControl.back();
        return;
    }
    for (auto itCtrl = &m_pArrSsueControl.back(); itCtrl != m_pArrSsueControl.begin() - 1; --itCtrl) {
        if (*itCtrl == m_pCurSsueControl) {
            --itCtrl;
            if (itCtrl != m_pArrSsueControl.begin() - 1) {
                m_pCurSsueControl = *itCtrl;
            } else {
                m_pCurSsueControl = m_pArrSsueControl.back();
            }
            return;
        }
    }
    m_pCurSsueControl = m_pArrSsueControl.back();
    return;
}

void UIManager::selectCurSsueControl(ft x, ft y) {
    if (s_hUe != null && !UIScene::s_arrScene.empty()) {
        m_pArrSsueControl.clear();
        if (UIScene::s_arrScene.back()->m_pRootControl != nullptr) {
            UIScene::s_arrScene.back()->m_pRootControl->refreshSsueControls(x, y);
            toNextSsueControl();
            if (m_pCurSsueControl != nullptr) {
                sendUiCommand(G2W2_SELECT_CONTROL, util::i64toa_s(m_pCurSsueControl->getSsueId(), 16));
            }
        }
    }
}

void UIManager::selectCurSsueControl(const wstring& ssueId) {
    auto id = util::aton_s(ssueId, 16);
    auto pObj = UIManager::getSsueNode(id);
    if (pObj != nullptr && pObj->is(NT_Control)) {
        m_pCurSsueControl = (Control*)pObj;
        StringManager::getInstance()->stringToWstring(m_pCurSsueControl->getSkinGroupOfCurSkin(), StringManager::getInstance()->m_tmpWString);
        sendUiCommand(G2W2_SELECT_CONTROL, util::i64toa_s(m_pCurSsueControl->getSsueId(), 16) + "!" + StringManager::getInstance()->m_tmpWString);
    } else {
        m_pCurSsueControl = nullptr;
    }
}

void ssui::UIManager::outScreen(int lv) const {
    LogPrintf("\n%d, %d, %d, %d", lv, Engine::screen().x, Engine::screen().y, Engine::uiScreen().x, Engine::uiScreen().y);
}

void ssui::UIManager::showBorder(const wstring& value) {
    if (value.front() == 't') {
        m_isShowBorder = true;
    } else {
        m_isShowBorder = false;
    }
}
#endif
void ssui::UIManager::disposeFunc(ObjectBase* pSelf) {
    Timer::clearTimer(pSelf);
}


