#pragma once
#include "ssuiBasic.h"
#include "Engine.h"
#include "Size.h"

_SSUINamespaceBegin

#define SUBIMAGE_UV(poi, tex) vec2(((poi).x / (tex).width()), ((poi).y / (tex).height()))
#define COLOR_V(color) (vec4((color).r, (color).g, (color).b, (color).a))

template <class T>
struct Segment{
    Vector3<T> m_s;
    Vector3<T> m_e;
};

class Geometry;
class GeometryUnionPoly;

//��Ҫ��ͼ�μ��㣬����ȡ����ν�����
class GeometryManager {
public:
    static inline int getScreenWidth() {
        return Graphics::screen().x;
    }
    static inline int getScreenHeight() {
        return Graphics::screen().y;
    }
public:
    static inline void sumBorderAndPoint(Border& aabb, const vec3& poi) {
        if (poi.x < aabb.m_left) {
            aabb.m_left = poi.x;
        } else if (poi.x > aabb.m_right) {
            aabb.m_right = poi.x;
        }
        if (poi.y < aabb.m_top) {
            aabb.m_top = poi.y;
        } else if (poi.y > aabb.m_bottom) {
            aabb.m_bottom = poi.y;
        }
    }
    static inline void sumPointAndBorder(vec2& poi, const Border& aabb, u8 dir = DDR_LT) {
        if ((dir & 0x03) == DR_T || ((dir & 0x30) >> 4) == DR_T) {
            // �ϵ���
            if (poi.y < aabb.m_bottom) {
                poi.y = aabb.m_bottom;
            }
        }else if ((dir & 0x03) == DR_B || ((dir & 0x30) >> 4) == DR_B) {
            // �µ���
            if (poi.y < -aabb.m_top) {
                poi.y = -aabb.m_top;
            }
        }
        if ((dir & 0x03) == DR_L || ((dir & 0x30) >> 4) == DR_L) {
            // ����
            if (poi.x < aabb.m_right) {
                poi.x = aabb.m_right;
            }
        } else if ((dir & 0x03) == DR_R || ((dir & 0x30) >> 4) == DR_R) {
            // �ҵ���
            if (poi.x < -aabb.m_left) {
                poi.x = -aabb.m_left;
            }
        }
    }
    static inline void sumPointAndPolyImage(vec2& poi, const PolyImage& polyImage) {
        for (auto& vpct : polyImage) {
            if (poi.x < vpct.position.x) {
                poi.x = vpct.position.x;
            }
            if (poi.y < vpct.position.y) {
                poi.y = vpct.position.y;
            }
        }
    }
    static inline void getBorderFromRectAndTransform(Border& aabb, const Rect<ft>& rect, const mat4& trans) {
        vec3 poi = {rect.m_x, rect.m_y, 0.f};
        poi.trans(trans);
        aabb = {poi.x, poi.y, poi.x, poi.y};

        poi = {rect.m_x, rect.m_y + rect.m_h, 0.f};
        poi.trans(trans);
        sumBorderAndPoint(aabb, poi);

        poi = {rect.m_x + rect.m_w, rect.m_y + rect.m_h, 0.f};
        poi.trans(trans);
        sumBorderAndPoint(aabb, poi);

        poi = {rect.m_x + rect.m_w, rect.m_y, 0.f};
        poi.trans(trans);
        sumBorderAndPoint(aabb, poi);
    }
    static inline void getBorderFromSizeAndTransform(Border& aabb, const Size& size, const mat4& trans) {
        vec3 poi = {0.f, 0.f, 0.f};
        poi.trans(trans);
        aabb = {poi.x, poi.y, poi.x, poi.y};

        poi = {0.f, size.m_h, 0.f};
        poi.trans(trans);
        sumBorderAndPoint(aabb, poi);

        poi = {size.m_w, size.m_h, 0.f};
        poi.trans(trans);
        sumBorderAndPoint(aabb, poi);

        poi = {size.m_w, 0.f, 0.f};
        poi.trans(trans);
        sumBorderAndPoint(aabb, poi);
    }
    static inline void getRectFromSize(Rect<ft>& rect, const Size& size) {
        rect = {0.f, 0.f, size.m_w, size.m_h};
    }
    static inline void getRectFromSizeAndTransform(Rect<ft>& rect, const Size& size, const mat4& trans) {
        vec3 poi = {0.f, 0.f, 0.f};
        poi.trans(trans);
        rect.m_x = poi.x;
        rect.m_y = poi.y;

        poi = {size.m_w, size.m_h, 0.f};
        poi.trans(trans);
        rect.m_w = poi.x - rect.m_x;
        rect.m_h = poi.y - rect.m_y;
    }
    static inline void getPolyFromSize(Poly& poly, const Size& size) {
        poly.clear();
        poly.push_back({0.f, 0.f, 0.f});
        poly.push_back({size.m_w, 0.f, 0.f});
        poly.push_back({size.m_w, size.m_h, 0.f});
        poly.push_back({0.f, size.m_h, 0.f});
    }
    static inline void getPolyImageFromSize(PolyImage& polyImage, const Size& size, const vec4& color) {
        polyImage.clear();
        polyImage.push_back(VertexPosColorTex({0.f, 0.f, 0.f}, color, {0, 0}));
        polyImage.push_back(VertexPosColorTex({size.m_w, 0.f, 0.f}, color, {0, 0}));
        polyImage.push_back(VertexPosColorTex({size.m_w, size.m_h, 0.f}, color, {0, 0}));
        polyImage.push_back(VertexPosColorTex({0.f, size.m_h, 0.f}, color, {0, 0}));
    }
    static inline void getPolyFromRect(Poly& poly, const Rect<ft>& rect) {
        poly.clear();
        poly.push_back({rect.m_x, rect.m_y, 0.f});
        poly.push_back({rect.m_x + rect.m_w, rect.m_y, 0.f});
        poly.push_back({rect.m_x + rect.m_w, rect.m_y + rect.m_h, 0.f});
        poly.push_back({rect.m_x, rect.m_y + rect.m_h, 0.f});
    }
    static void getPolyFromCircle(Poly& poly, const Point<ft>& center, float radius);
    static void getPolyFromRoundedRectangle(Poly& poly, const Point<ft>& center, float radius, float cornerRadius);
    static void getPolyFromSixAngleRhombus(Poly& poly, const Point<ft>& center, float radius);

    static void getSector(GeometryUnionPoly* pGeo, const Point<ft>& center, float radius, float bAngle, float eAngle);
    static inline void getPolyFromBorder(Poly& poly, const Border& aabb) {
        poly.clear();
        poly.push_back({aabb.m_left, aabb.m_top, 0.f});
        poly.push_back({aabb.m_right, aabb.m_top, 0.f});
        poly.push_back({aabb.m_right, aabb.m_bottom, 0.f});
        poly.push_back({aabb.m_left, aabb.m_bottom, 0.f});
    }
    static inline void getPolyFromBorder(PolyImage& poly, const Border& aabb) {
        poly.clear();
        poly.push_back(Vpct_t({ aabb.m_left, aabb.m_top, 0.f }, {}, {}));
        poly.push_back(Vpct_t({ aabb.m_right, aabb.m_top, 0.f }, {}, {}));
        poly.push_back(Vpct_t({ aabb.m_right, aabb.m_bottom, 0.f }, {}, {}));
        poly.push_back(Vpct_t({ aabb.m_left, aabb.m_bottom, 0.f }, {}, {}));
    }
    static inline void getPolyFromSizeAndTransform(Poly& poly, const Size& size, const mat4& trans) {
        auto psz = poly.size();
        if (psz >= 4) {
            poly[0] = {0.f, 0.f, 0.f};
            poly[0].trans(trans);
            poly[1] = {size.m_w, 0.f, 0.f};
            poly[1].trans(trans);
            poly[2] = {size.m_w, size.m_h, 0.f};
            poly[2].trans(trans);
            poly[3] = {0.f, size.m_h, 0.f};
            poly[3].trans(trans);
            if (psz > 4) {
                poly.erase(poly.begin() + 4, poly.end());
            }
        } else {
            poly.clear();
            poly.push_back({0.f, 0.f, 0.f});
            poly.back().trans(trans);
            poly.push_back({size.m_w, 0.f, 0.f});
            poly.back().trans(trans);
            poly.push_back({size.m_w, size.m_h, 0.f});
            poly.back().trans(trans);
            poly.push_back({0.f, size.m_h, 0.f});
            poly.back().trans(trans);
        }
    }
    static inline void getPolyFromRectAndTransform(Poly& poly, const Rect<ft>& rect, const mat4& trans) {
        auto psz = poly.size();
        if (psz >= 4) {
            poly[0] = {rect.m_x, rect.m_y, 0.f};
            poly[0].trans(trans);
            poly[1] = {rect.m_x + rect.m_w, rect.m_y, 0.f};
            poly[1].trans(trans);
            poly[2] = {rect.m_x + rect.m_w, rect.m_y + rect.m_h, 0.f};
            poly[2].trans(trans);
            poly[3] = {rect.m_x, rect.m_y + rect.m_h, 0.f};
            poly[3].trans(trans);
            if (psz > 4) {
                poly.erase(poly.begin() + 4, poly.end());
            }
        } else {
            poly.clear();
            poly.push_back({rect.m_x, rect.m_y, 0.f});
            poly.back().trans(trans);
            poly.push_back({rect.m_x + rect.m_w, rect.m_y, 0.f});
            poly.back().trans(trans);
            poly.push_back({rect.m_x + rect.m_w, rect.m_y + rect.m_h, 0.f});
            poly.back().trans(trans);
            poly.push_back({rect.m_x, rect.m_y + rect.m_h, 0.f});
            poly.back().trans(trans);
        }
    }
    static inline void getPolyFromTransform(Poly& poly, const mat4& trans) {
        for (auto& poi : poly) {
            poi.trans(trans);
        }
    }
    static inline void getPolyFromTransform(PolyImage& polyImage, const mat4& trans) {
        for (auto& vp : polyImage) {
            vp.position.trans(trans);
        }
    }
    static inline void getBorderFromPolyImage(Border& aabb, const PolyImage& polyImage) {
        if (polyImage.empty()) {
            return;
        }
        aabb = {polyImage[0].position.x, polyImage[0].position.y, polyImage[0].position.x, polyImage[0].position.y};
        for (int i = 1; i < polyImage.size(); i++) {
            if (polyImage[i].position.x < aabb.m_left) {
                aabb.m_left = polyImage[i].position.x;
            } else if (polyImage[i].position.x > aabb.m_right) {
                aabb.m_right = polyImage[i].position.x;
            }
            if (polyImage[i].position.y < aabb.m_top) {
                aabb.m_top = polyImage[i].position.y;
            } else if (polyImage[i].position.y > aabb.m_bottom) {
                aabb.m_bottom = polyImage[i].position.y;
            }
        }
    }
    static inline void getRightFromPolyImage(ft& right, const PolyImage& polyImage) {
        right = 0;
        if (polyImage.empty()) {
            return;
        }
        for (auto& poi : polyImage) {
            if (poi.position.x > right) {
                right = poi.position.x;
            }
        }
    }
    static inline void getRightFromPolyImageGroup(ft& right, const ArrayList<PolyImage>& arrPolyImage) {
        right = 0;
        if (arrPolyImage.empty()) {
            return;
        }
        for (auto& polyImage : arrPolyImage) {
            for (auto& poi : polyImage) {
                if (poi.position.x > right) {
                    right = poi.position.x;
                }
            }
        }
    }
    static inline void getSizeFromPolyImage(Size& size, const PolyImage& polyImage) {
        if (polyImage.empty()) {
            return;
        }
        Border aabb;
        getBorderFromPolyImage(aabb, polyImage);
        size.m_w = aabb.m_right;
        size.m_h = aabb.m_bottom;
    }
    static inline void getSizeFromPolyImage2(Size& size, const PolyImage& polyImage) {
        if (polyImage.empty()) {
            return;
        }
        Border aabb;
        getBorderFromPolyImage(aabb, polyImage);
        size.m_w = aabb.m_right - aabb.m_left;
        size.m_h = aabb.m_bottom - aabb.m_top;
    }

    //�ų�ʵ��
    static inline bool IsRectCross(const Vector3<ft> &p1, const Vector3<ft> &p2, const Vector3<ft> &q1, const Vector3<ft> &q2) {
        b2 ret = math::minimum(p1.x, p2.x) <= math::maximum(q1.x, q2.x) &&
            math::minimum(q1.x, q2.x) <= math::maximum(p1.x, p2.x) &&
            math::minimum(p1.y, p2.y) <= math::maximum(q1.y, q2.y) &&
            math::minimum(q1.y, q2.y) <= math::maximum(p1.y, p2.y);
        return ret;
    }
    /*
    �����1�������1������P��
    �����2�����0�����㣻
    �����3������߶�SP��ü��ߵ�1������I��
    �����4������߶�SP��ü��ߵ�1������I��1���յ�P��
    ��0ʱ��poi�ڱ߽����ڲ�(�ɼ�)����>0ʱ��poi�ڱ߽������(���ɼ�)��
    */
    static inline bool getInsideFromSegAndPoint(const Vector3<ft>& segStart, const Vector3<ft>& segEnd, const Vector3<ft>& poi) {
        return ((segEnd.x - segStart.x) * (poi.y - segStart.y) - (segEnd.y - segStart.y) * (poi.x - segStart.x)) > 0 ? true : false;
    }
    static bool IsLineSegmentCross(const Vector3<ft>& pFirst1, const Vector3<ft>& pFirst2, const Vector3<ft>& pSecond1, const Vector3<ft>& pSecond2);
    static bool GetCrossPointFromSeg(const Vector3<ft>& p1, const Vector3<ft>& p2, const Vector3<ft>& q1, const Vector3<ft>& q2, ft &x, ft &y);
    static bool GetCrossPointFromLine(const Vector3<ft>& p1, const Vector3<ft>& p2, const Vector3<ft>& q1, const Vector3<ft>& q2, ft &x, ft &y);
    inline static bool GetCrossPointFromLineFast(const Vector3<ft>& p1, const Vector3<ft>& p2, const Vector3<ft>& q1, const Vector3<ft>& q2, ft &x, ft &y) {
//�󽻵�
//         f64 tmpLeft, tmpRight;
//         tmpLeft = (q2.x - q1.x) * (p1.y - p2.y) - (p2.x - p1.x) * (q1.y - q2.y);
//         tmpRight = (p1.y - q1.y) * (p2.x - p1.x) * (q2.x - q1.x) + q1.x * (q2.y - q1.y) * (p2.x - p1.x) - p1.x * (p2.y - p1.y) * (q2.x - q1.x);
//         x = tmpRight / tmpLeft;
// 
//         tmpLeft = (p1.x - p2.x) * (q2.y - q1.y) - (p2.y - p1.y) * (q1.x - q2.x);
//         tmpRight = p2.y * (p1.x - p2.x) * (q2.y - q1.y) + (q2.x - p2.x) * (q2.y - q1.y) * (p1.y - p2.y) - q2.y * (q1.x - q2.x) * (p2.y - p1.y);
//         y = tmpRight / tmpLeft;
// 
//         return true;
        f64 tmpLeft, tmpRight, t1, t2;
        t1 = (p2.x - p1.x) * (q1.y - q2.y);
        t2 = (q2.x - q1.x) * (p1.y - p2.y);
        tmpLeft = t2 - t1;
        tmpRight = (p1.y - q1.y) * (p2.x - p1.x) * (q2.x - q1.x) - q1.x * t1 + p1.x * t2;
        x = tmpRight / tmpLeft;

        tmpLeft = -tmpLeft;
        tmpRight = (q2.x - p2.x) * (q2.y - q1.y) * (p1.y - p2.y) + p2.y * t1 - q2.y * t2;
        y = tmpRight / tmpLeft;

        return true;
    }
    //����a���ڵ�b,����a�ڵ�b˳ʱ�뷽��,����true,���򷵻�false
    static bool PointCmp(const Vector3<ft>& a, const Vector3<ft>& b, const Vector3<ft>& center);
    static void ClockwiseSortPoints(const Poly& vPoints);
    static bool getPointIsInAabb(const ft x, const ft y, const Border& aabb);
    static bool getPointIsInPoly(const ft x, const ft y, const Poly& poly);
    /*
        http://blog.csdn.net/johnny710vip/article/details/6963452
        <Sutherland-Hodgman�㷨>
    */
    static bool getIntersectionFromPoly(Poly& retPoly, const Poly& polyA, const Poly& polyB);
    static Geometry* getIntersectionGeometry(const Poly& polyA, const Poly& polyB);
    static Geometry* getIntersectionGeometry(const Poly& polyA, const Geometry* pGeometryB);
    static Geometry* getIntersectionGeometry(const Geometry* pGeometryA, const Geometry* pGeometryB);
    static PolyImage s_tmpPolyImageA;

    static Vector3<ft> s_pTmpPolyBuff[2][200];
    static VertexPosColorTex s_pTmpPolyImageBuff[2][200];
    static bool clipPolyImage(PolyImage& retPolyImage, const PolyImage& polyImageA, const Poly& polyB);
    static bool clipPolyImage(PolyImage& retPolyImage, const Poly& polyClip);
    static bool clipPolyImage(PolyImage& retPolyImage, const Border& border);
    static inline bool getIntersectionFromBorder(Border& retAabb, const Border& aabb1, const Border& aabb2) {
        if (aabb1.m_right < aabb2.m_left || aabb2.m_right < aabb1.m_left || aabb1.m_bottom < aabb2.m_top || aabb2.m_bottom < aabb1.m_top) {
            retAabb.clear();
            return false;
        }
        retAabb.m_left = math::maximum(aabb1.m_left, aabb2.m_left);
        retAabb.m_right = math::minimum(aabb1.m_right, aabb2.m_right);
        retAabb.m_top = math::maximum(aabb1.m_top, aabb2.m_top);
        retAabb.m_bottom = math::minimum(aabb1.m_bottom, aabb2.m_bottom);
        return true;
    }
public:
    using vec2f = Vector2<f64>;
    static inline f64 dot(const vec2f& v0, const vec2f& v1) {
        return v0.x * v1.x + v0.y * v1.y;
    }
    static inline vec2f toVec2f(const vec2& v) {
        return vec2f(f64(v.x), f64(v.y));
    }
    static inline bool isPointInTriangle(vec2f& uv, const vec2& p, const vec2& t1, const vec2& t2, const vec2& t3) {
        // Compute vectors
        vec2f v0 = toVec2f(t3 - t1);
        vec2f v1 = toVec2f(t2 - t1);
        vec2f v2 = toVec2f(p - t1);
        // Compute dot products
        f64 dot00 = dot(v0, v0);
        f64 dot01 = dot(v0, v1);
        f64 dot02 = dot(v0, v2);
        f64 dot11 = dot(v1, v1);
        f64 dot12 = dot(v1, v2);
        // Compute barycentric coordinates
        f64 invDenom = 1.0f / (dot00 * dot11 - dot01 * dot01);
        uv.x = (dot11 * dot02 - dot01 * dot12) * invDenom;
        uv.y = (dot00 * dot12 - dot01 * dot02) * invDenom;
        // Check if point is in triangle
        return (uv.x >= -0.001) && (uv.y >= -0.001) && (uv.x + uv.y <= 1.001);
    }
    static inline bool assignVpByPolyImage(VertexPosColorTex& vp, const PolyImage& polyImage) {
        vec2f uvPerData;
        for (int i = 2; i < polyImage.size(); i++) {
            if (isPointInTriangle(uvPerData, {vp.position.x, vp.position.y}, {polyImage[0].position.x, polyImage[0].position.y},
                {polyImage[i - 1].position.x, polyImage[i - 1].position.y}, {polyImage[i].position.x, polyImage[i].position.y})) {
                vp.texCoord = polyImage[i - 1].texCoord - polyImage[0].texCoord;
                SSUIMath::getMulti(vp.texCoord, uvPerData.y);
                auto tmp = polyImage[i].texCoord - polyImage[0].texCoord;
                SSUIMath::getMulti(tmp, uvPerData.x);
                vp.texCoord = vp.texCoord + tmp;
                //vp.texCoord.x >>= 1;
                //vp.texCoord.y >>= 1;
                vp.texCoord += polyImage[0].texCoord;
                vp.color = ((polyImage[i - 1].color - polyImage[0].color) * uvPerData.y +
                    (polyImage[i].color - polyImage[0].color) * uvPerData.x) * 0.5f + polyImage[0].color;
                return true;
            }
        }
        return false;
    }
    static inline bool assignPolyImageByPolyImage(VertexPosColorTex arrDst[], int size, const PolyImage& src) {
        bool ret = true;
        for (int i = 0; i < size; i++) {
            ret = (ret && assignVpByPolyImage(arrDst[i], src));
        }
        return ret;
    }
    static inline bool assignPolyImageByPolyImage(PolyImage& dst, const PolyImage& src) {
        bool ret = true;
        for (auto& vpct : dst) {
            ret = (ret && assignVpByPolyImage(vpct, src));
        }
        return ret;
    }
    static inline bool refreshPolyImageByAreaChanged(PolyImage& polyImage, const Border& srcRect, const Border& newRect) {
        if (polyImage.size() != 4) {
            return false;
        }
        VertexPosColorTex tmpPolyImage[4];
        tmpPolyImage[0].position = {newRect.m_left, newRect.m_top};
        tmpPolyImage[1].position = {newRect.m_right, newRect.m_top};
        tmpPolyImage[2].position = {newRect.m_right, newRect.m_bottom};
        tmpPolyImage[3].position = {newRect.m_left, newRect.m_bottom};
        assignPolyImageByPolyImage(tmpPolyImage, 4, polyImage);
        polyImage[0] = tmpPolyImage[0];
        polyImage[1] = tmpPolyImage[1];
        polyImage[2] = tmpPolyImage[2];
        polyImage[3] = tmpPolyImage[3];
        return true;
    }
    static inline bool movePolyImageByAreaChanged(PolyImage& polyImage, const Border& newRect) {
        if (polyImage.size() != 4) {
            return false;
        }
        polyImage[0].position = {newRect.m_left, newRect.m_top};
        polyImage[1].position = {newRect.m_right, newRect.m_top};
        polyImage[2].position = {newRect.m_right, newRect.m_bottom};
        polyImage[3].position = {newRect.m_left, newRect.m_bottom};
        return true;
    }
public:
    static inline bool getBorderByPoly(Border& aabb, const Poly& poly) {
        if (poly.size() != 4) {
            return false;
        }
        if (poly[0].x == poly[1].x && poly[1].y == poly[2].y &&
            poly[2].x == poly[3].x && poly[3].y == poly[0].y) {
            if (poly[0].x < poly[2].x) {
                aabb.m_left = poly[0].x;
                aabb.m_right = poly[2].x;
            } else {
                aabb.m_left = poly[2].x;
                aabb.m_right = poly[0].x;
            }
            if (poly[1].y < poly[3].y) {
                aabb.m_top = poly[1].y;
                aabb.m_bottom = poly[3].y;
            } else {
                aabb.m_top = poly[3].y;
                aabb.m_bottom = poly[1].y;
            }
        } else if (poly[0].y == poly[1].y && poly[1].x == poly[2].x &&
            poly[2].y == poly[3].y && poly[3].x == poly[0].x) {
            if (poly[1].x < poly[3].x) {
                aabb.m_left = poly[1].x;
                aabb.m_right = poly[3].x;
            } else {
                aabb.m_left = poly[3].x;
                aabb.m_right = poly[1].x;
            }
            if (poly[0].y < poly[2].y) {
                aabb.m_top = poly[0].y;
                aabb.m_bottom = poly[2].y;
            } else {
                aabb.m_top = poly[2].y;
                aabb.m_bottom = poly[0].y;
            }
        } else {
            return false;
        }
        return true;
    }
    static inline bool getBorderByPolyImage(Border& aabb, const PolyImage& polyImage) {
        do {
            if (polyImage.size() != 4) {
                break;
            }
            u8 tw = 0xff;
            if (polyImage[0].position.x == polyImage[1].position.x && polyImage[1].position.y == polyImage[2].position.y &&
                polyImage[2].position.x == polyImage[3].position.x && polyImage[3].position.y == polyImage[0].position.y) {
                if (polyImage[0].position.x < polyImage[2].position.x) {
                    aabb.m_left = polyImage[0].position.x;
                    aabb.m_right = polyImage[2].position.x;
                    tw &= 3;
                } else {
                    aabb.m_left = polyImage[2].position.x;;
                    aabb.m_right = polyImage[0].position.x;
                    tw &= 12;
                }
                if (polyImage[1].position.y < polyImage[3].position.y) {
                    aabb.m_top = polyImage[1].position.y;
                    aabb.m_bottom = polyImage[3].position.y;
                    tw &= 6;
                } else {
                    aabb.m_top = polyImage[3].position.y;
                    aabb.m_bottom = polyImage[1].position.y;
                    tw &= 9;
                }
            } else if (polyImage[0].position.y == polyImage[1].position.y && polyImage[1].position.x == polyImage[2].position.x &&
                polyImage[2].position.y == polyImage[3].position.y && polyImage[3].position.x == polyImage[0].position.x) {
                if (polyImage[1].position.x < polyImage[3].position.x) {
                    aabb.m_left = polyImage[1].position.x;
                    aabb.m_right = polyImage[3].position.x;
                    tw &= 6;
                } else {
                    aabb.m_left = polyImage[3].position.x;
                    aabb.m_right = polyImage[1].position.x;
                    tw &= 9;
                }
                if (polyImage[0].position.y < polyImage[2].position.y) {
                    aabb.m_top = polyImage[0].position.y;
                    aabb.m_bottom = polyImage[2].position.y;
                    tw &= 3;
                } else {
                    aabb.m_top = polyImage[2].position.y;
                    aabb.m_bottom = polyImage[0].position.y;
                    tw &= 12;
                }
            } else {
                break;
            }
            if (tw & 1) {
                return true;
            }
            if (tw & 2) {
                auto tmpData = polyImage[0];
                polyImage[0] = polyImage[1];
                polyImage[1] = polyImage[2];
                polyImage[2] = polyImage[3];
                polyImage[3] = tmpData;
            } else if (tw & 4) {
                auto tmpData = polyImage[0];
                polyImage[0] = polyImage[2];
                polyImage[2] = tmpData;
                tmpData = polyImage[1];
                polyImage[1] = polyImage[3];
                polyImage[3] = tmpData;
            } else {
                auto tmpData = polyImage[0];
                polyImage[0] = polyImage[3];
                polyImage[3] = polyImage[2];
                polyImage[2] = polyImage[1];
                polyImage[1] = tmpData;
            }
            return true;
        } while (false);
        if (!polyImage.empty()) {
            aabb.m_left = polyImage.front().position.x;
            aabb.m_top = polyImage.front().position.y;
            aabb.m_right = polyImage.front().position.x;
            aabb.m_bottom = polyImage.front().position.y;
            for (auto it = polyImage.begin() + 1; it != polyImage.end(); ++it) {
                aabb.m_left = math::minimum(aabb.m_left, it->position.x);
                aabb.m_top = math::minimum(aabb.m_top, it->position.y);
                aabb.m_right = math::maximum(aabb.m_right, it->position.x);
                aabb.m_bottom = math::maximum(aabb.m_bottom, it->position.y);
            }
        }
        return false;
    }
    static inline bool getIsRectByPolyImageAndRank(Border& aabb, const PolyImage& polyImage) {
        if (polyImage.size() != 4) {
            return false;
        }
        u8 tw = 0xff;
        if (polyImage[0].position.x == polyImage[1].position.x && polyImage[1].position.y == polyImage[2].position.y &&
            polyImage[2].position.x == polyImage[3].position.x && polyImage[3].position.y == polyImage[0].position.y) {
            if (polyImage[0].position.x < polyImage[2].position.x) {
                aabb.m_left = polyImage[0].position.x;
                aabb.m_right = polyImage[2].position.x;
                tw &= 3;
            } else {
                aabb.m_left = polyImage[2].position.x;;
                aabb.m_right = polyImage[0].position.x;
                tw &= 12;
            }
            if (polyImage[1].position.y < polyImage[3].position.y) {
                aabb.m_top = polyImage[1].position.y;
                aabb.m_bottom = polyImage[3].position.y;
                tw &= 6;
            } else {
                aabb.m_top = polyImage[3].position.y;
                aabb.m_bottom = polyImage[1].position.y;
                tw &= 9;
            }
        } else if (polyImage[0].position.y == polyImage[1].position.y && polyImage[1].position.x == polyImage[2].position.x &&
            polyImage[2].position.y == polyImage[3].position.y && polyImage[3].position.x == polyImage[0].position.x) {
            if (polyImage[1].position.x < polyImage[3].position.x) {
                aabb.m_left = polyImage[1].position.x;
                aabb.m_bottom = polyImage[3].position.x;
                tw &= 6;
            } else {
                aabb.m_left = polyImage[3].position.x;
                aabb.m_bottom = polyImage[1].position.x;
                tw &= 9;
            }
            if (polyImage[0].position.y < polyImage[2].position.y) {
                aabb.m_top = polyImage[0].position.y;
                aabb.m_bottom = polyImage[2].position.y;
                tw &= 3;
            } else {
                aabb.m_top = polyImage[2].position.y;
                aabb.m_bottom = polyImage[0].position.y;
                tw &= 12;
            }
        } else {
            return false;
        }
        if (tw & 1) {
            return true;
        }
        if (tw & 2) {
            auto tmpData = polyImage[0];
            polyImage[0] = polyImage[1];
            polyImage[1] = polyImage[2];
            polyImage[2] = polyImage[3];
            polyImage[3] = tmpData;
        } else if (tw & 4) {
            auto tmpData = polyImage[0];
            polyImage[0] = polyImage[2];
            polyImage[2] = tmpData;
            tmpData = polyImage[1];
            polyImage[1] = polyImage[3];
            polyImage[3] = tmpData;
        } else {
            auto tmpData = polyImage[0];
            polyImage[0] = polyImage[3];
            polyImage[3] = polyImage[2];
            polyImage[2] = polyImage[1];
            polyImage[1] = tmpData;
        }
        return true;
    }
    //PolyImage's transform
    static void transformPosition(PolyImage& poly, ft x, ft y);
    static void transformScale(PolyImage& poly, ft scaleX, ft scaleY, ft cx, ft cy);
    static void transformAngle(PolyImage& poly, ft angle, ft cx, ft cy);
};

_SSUINamespaceEnd
