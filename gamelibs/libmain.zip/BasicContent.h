#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Skin;
class BasicContent : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(BasicContent);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(BasicContent, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    Skin* m_pSkin = nullptr;
    string mt_skinName;
    ArrayList<string> m_beforeSkins;
    //���Բ���ɾ
    wstring* mt_pTextValue = nullptr;
    wstring mt_textCache;
    wstring mt_textKey;
#pragma endregion

#pragma region "����"
public:
    BasicContent& assign(const BasicContent& other);
    virtual void onPrepareData() override;

#pragma region "Skin"
public:
    const string& getSkinName() const;
    void setSkinName(const string& value);
public:
    Skin* getSkin() const;
    void setSkin(Skin* value);
    int getSkinKey() const;
    const string& getSkinGroupOfCurSkin() const;
    void addBeforeSkinName(const string& skinName);
    const string& getBeforeSkinName(const string& value) const;
#pragma endregion

#pragma region "Text, Input"
public:
    const wstring& getText() const;
    void setText(const wstring& value);
    const wstring& getTextKey() const;
    void setTextKey(const wstring& value);
public:
    virtual void onShowTextChangedFunc();
    void dataTextChangedFunc();
    void setTextWithChar(const wstring::value_type& value);
    void appendDataText(const wstring& value);
    void appendDataText(u16 character);
    void backspaceDataText();
    const wstring* getShowText() const;
    wstring* showText();
#pragma endregion
#pragma endregion
};

_SSUINamespaceEnd
