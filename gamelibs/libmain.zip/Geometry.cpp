#include "Geometry.h"
#include "GeometryManager.h"
#include "GeometryRect.h"
#include "GeometryPoly.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Geometry, 0, 0);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(Geometry)
NODETYPE_COMMON_PART_DEFINITION_END

Geometry* Geometry::createObject(const Poly& poly) {
    Border aabb;
    if (GeometryManager::getBorderByPoly(aabb, poly)) {
        return GeometryRect::createObject(aabb);
    } else {
        return GeometryPoly::createObject(poly);
    }
}
