#include "SkinGroup.h"
#include "UIScene.h"
#include "ImageManager.h"
#include "DataInfoNode.h"
#include "DataInfoAttr.h"

HashMap<strHash, SkinGroup*> SkinGroup::s_mapSkinGroup;
HashMap<strHash, SkinGroup*> SkinGroup::s_mapUsingSkinGroup;
HashMap<strHash, UITexture*> SkinGroup::s_mapQuoteTexture;

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(SkinGroup, 200, 500)
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("name", Name, SkinGroup, STR);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(SkinGroup)
    NBSCRIPT_ATTR_REGISTER("name", Name, SkinGroup, STR);
NODETYPE_COMMON_PART_DEFINITION_END

SkinGroup* SkinGroup::createSkinGroup(const string& sceneName, DataInfoNode& data) {
    auto pSkinGroup = SkinGroup::createSkinGroup(sceneName);
    pSkinGroup->setData(data);
    return pSkinGroup;
}

void SkinGroup::addQuoteTexture(const string& imageName) {
    const auto& pairTexture = s_mapQuoteTexture.find(imageName.hashCode());
    if (pairTexture == s_mapQuoteTexture.end()) {
        s_mapQuoteTexture.insert(imageName.hashCode(), ImageManager::getUITexture(imageName));
    }
}

void SkinGroup::setName(const string& value) {
    if (mt_name != value) {
        if (!mt_name.empty()) {
            auto oldKey = mt_name.hashCode();
            auto pairOld = s_mapSkinGroup.find(oldKey);
            if (pairOld != s_mapSkinGroup.end()) {
                s_mapSkinGroup.erase(oldKey);
            }
        }
        auto newKey = value.hashCode();
        auto pairNew = s_mapSkinGroup.find(newKey);
        if (pairNew != s_mapSkinGroup.end()) {
            for (auto& pScene : UIScene::s_arrScene) {
                pScene->TriggerEvent(ET_SkinGroupReplace, pairNew->second, this);
            }
            pairNew->second->releaseObject();
            s_mapSkinGroup.erase(newKey);
        }
        s_mapSkinGroup.insert(newKey, this);
        mt_name = value;
    }
}

int SkinGroup::addDataChild(DataInfoNode& childData) {
    int ret = Base::addDataChild(childData);
    if (ret < 0) {
        if (ObjectBase::is(childData.m_objType, NT_Skin)) {
            addSkin((Skin*)ObjectBase::createObject(childData));
            ret = NT_Skin;
        } else if (childData.m_objType == NT_UITexture) {
            for (auto& pAttrInfo : childData.m_arrAttr) {
                if (pAttrInfo->m_attrType == AT_UITexture_Name) {
                    auto pName = pAttrInfo->m_pStrData;
                    if (pName != nullptr && !pName->empty()) {
                        addQuoteTexture(*pName);
                    }
                    break;
                }
            }
            ret = NT_UITexture;
        }
    }
    return ret;
}
