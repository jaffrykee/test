#include "ShapeGroup.h"

#include "DataHeaders.h"

wstring ShapeGroup::s_tmpSlotCmdData;
wstring ShapeGroup::s_tmpStateCmdData;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ShapeGroup, 20000, 30000);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("slot", Slot, ShapeGroup, S32, s_tmpSlotCmdData, true);
    NODEBASE_ATTR_REGISTER("state", State, ShapeGroup, S32, s_tmpStateCmdData, true);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ShapeGroup)
    NBSCRIPT_ATTR_REGISTER("slot", Slot, ShapeGroup, S32);
    NBSCRIPT_ATTR_REGISTER("state", State, ShapeGroup, S32);
NODETYPE_COMMON_PART_DEFINITION_END
