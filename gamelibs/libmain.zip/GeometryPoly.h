#pragma once
#include "Geometry.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class RenderCacheImage;
class GeometryPoly : public Geometry {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(GeometryPoly);
protected:
    inline virtual void createSelf() override {}
    inline virtual void disposeSelf() override {}
    NODETYPE_COMMON_PART_DECLARATION_END(GeometryPoly, Geometry);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
public:
    static GeometryPoly* createObject(const Poly& poly);
#pragma endregion

#pragma region "��Ա"
public:
    Poly m_poly;
#pragma endregion

#pragma region "����"
public:
    GeometryPoly& assign(const GeometryPoly& other);
    virtual bool isIn(ft x, ft y) override;
    virtual void appendOutline(Poly& poly) override;
    virtual void getCenter(ft& cx, ft& cy) const override;
    virtual void getBorder(Border& aabb) const override;
    virtual void transformPosition(ft x, ft y) override;

#pragma endregion
};

_SSUINamespaceEnd
