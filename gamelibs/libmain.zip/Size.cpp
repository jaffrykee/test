#include "Size.h"
#include "Border.h"

void ssui::Size::getSumAggregate(ssui::Size& ret, const ssui::Size& sizeA, const ssui::Size& sizeB) {
    ret = { 0.f, 0.f };
    ret.m_w = sizeA.m_w > sizeB.m_w ? sizeA.m_w : sizeB.m_w;
    ret.m_h = sizeA.m_h > sizeB.m_h ? sizeA.m_h : sizeB.m_h;
}

ssui::Size::Size(ft w, ft h) : m_w(w), m_h(h) {

}

ssui::Size::Size(const Border& aabb) {
    m_w = aabb.m_right - aabb.m_left;
    m_h = aabb.m_bottom - aabb.m_top;
}

bool ssui::Size::operator==(const ssui::Size& other) const {
    if (m_w == other.m_w && m_h == other.m_h) {
        return true;
    } else {
        return false;
    }
}

bool ssui::Size::operator!=(const ssui::Size& other) const {
    if (m_w != other.m_w || m_h != other.m_h) {
        return true;
    } else {
        return false;
    }
}

void ssui::Size::sumAggregate(const ssui::Size& size, const int& retCalInitArea) {
    if ((retCalInitArea & 1) && size.m_w > m_w) {
        m_w = size.m_w;
    }
    if ((retCalInitArea & 2) && size.m_h > m_h) {
        m_h = size.m_h;
    }
}
