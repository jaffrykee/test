#pragma once
#include "Geometry.h"
#include "GeometryRect.h"
#include "GeometryPoly.h"
#include "GeometryUnionPoly.h"
