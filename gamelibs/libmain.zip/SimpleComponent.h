#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class SimpleComponent : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(SimpleComponent);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(SimpleComponent, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    ArrayList<Control*> m_container;
    bool m_isReady = false;
#pragma endregion

#pragma region "����"
public:
    Self& assign(const Self& other);
    virtual ArrayList<Control*>& container() override final;
    virtual const ArrayList<SlotType_e>& getSlotList() const override;
    virtual ParentAreaType_e getParentAreaType() const;
#pragma endregion
};

using Block = SimpleComponent;

_SSUINamespaceEnd
