#pragma once
#include "ssuiBasic.h"
#include "Controller.h"
#include "Engine.h"

using namespace ssui;
using namespace ss2;

_SSUINamespaceBegin

class UIComponent;
class UIController : public IController {
public:
    static ArrayList<UIComponent*> s_arrPressOwner;
public:
    HashSet<InputEvent> activeInput;

public:
    UIController();
    virtual bool execEvent(const InputEvent& input) override;
    virtual void reset() override;

public:
    void init();
    void update();
};

_SSUINamespaceEnd
