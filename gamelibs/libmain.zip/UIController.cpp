#include "UIController.h"
#include "NodeManager.h"
#include "DataManager.h"
#include "UIScene.h"
#include "Control.h"
#include "UIManager.h"
#include "InputBox.h"
#ifdef _WIN32
#include "AppEngineWin.h"
#endif // _WIN32

ArrayList<UIComponent*> UIController::s_arrPressOwner;

UIController::UIController() {
    reset();
}

bool UIController::execEvent(const InputEvent& input) {
    switch (input.type) {
    case InputEvent::text:
    {
        if (UIManager::getInstance()->m_pCurInputBox) {
            UIManager::getInstance()->m_pCurInputBox->TriggerEvent(input.chars, input.length);
            return true;
        }
        break;
    }
    break;
    case InputEvent::character:
    {
        if (UIManager::getInstance()->m_pCurInputBox) {
            UIManager::getInstance()->m_pCurInputBox->TriggerEvent(ET_Char, input.charValue, 0);
            return true;
        }
        break;
    }
    break;
    case InputEvent::uiCommand:
    {
        UIManager::getInstance()->dealCommand(input);
        break;
    }
    break;
    case InputEvent::languageChanged:
    {
        NodeManager::getInstance()->onLanguageThemeChanged();
        break;
    }
        break;
    default:
        break;
    }
    switch (input.key) {
    case InputKey::mouseDoubleLeft:
    case InputKey::mouseLeft:
    {
        int x = input.pointx * UIManager::getInstance()->m_screenScaleX;
        int y = input.pointy * UIManager::getInstance()->m_screenScaleY;
        switch (input.type) {
        case InputEvent::press:
        {
            if (UIManager::getInstance()->isUeMode()) {
                #ifdef _WIN32
                UIManager::getInstance()->selectCurSsueControl(x, y);
#endif
            }
            UIManager::getInstance()->m_pCurInputBox = nullptr; 
            auto& uiEvent = SSUIEvent::createSSUIEvent(ET_Press, x, y);
            b2 ownEvent = false;
            b2 handled = false;
            for(auto pScene = UIScene::s_arrScene.end() - 1; pScene != UIScene::s_arrScene.begin() - 1; --pScene){
                if (!(*pScene)->getIsNonEvent() && (*pScene)->m_pRootControl != nullptr && (*pScene)->m_pRootControl->isIn(x, y)) {
                    (*pScene)->m_pRootControl->onEvent(uiEvent);
                    ownEvent = (*pScene)->getDataIsOwnEvent();
                    handled = uiEvent.m_blockHandle || uiEvent.m_blockScript;
                    if (uiEvent.m_blockHandle || ownEvent) {
                        if (!uiEvent.m_nextUI) {
                            UIScene::setCurScene(*pScene);
                            break;
                        }
                    }
                }
//                 if (pScene->isIn(input.pointx, input.pointy)) {
//                     pScene->onEvent(event);
//                     if (!event.m_triggerStatusChange && !event.m_triggerScript) {
//                         break;
//                     }
//                 }
            }
            bool re = uiEvent.m_blockHandle || handled;
            return handled;
        }
        break;
        case InputEvent::release:
        {
            auto& eventRelease = SSUIEvent::createSSUIEvent(ET_Release, x, y);
            auto& eventClick = SSUIEvent::createSSUIEvent(ET_Click, x, y);
            //Event eventLostFocus(Event::ET_LostFocus, .x, .y);
            bool isTrigger = false;
            for (auto pFrame = s_arrPressOwner.begin(); pFrame != s_arrPressOwner.end(); pFrame = s_arrPressOwner.begin()) {
                (*pFrame)->onEvent(eventRelease);
                if ((*pFrame)->isIn(x, y)) {
                    (*pFrame)->onEvent(eventClick);
                    isTrigger = true;
                }
                s_arrPressOwner.erase(pFrame);
            }
            if (isTrigger) {
                return true;
            }
        }
        break;
        case InputEvent::drag:
        {
            auto& eventDrag = SSUIEvent::createSSUIEvent(ET_Drag, x, y);
            bool isTrigger = false;
            for (auto& pFrame : s_arrPressOwner) {
                pFrame->onEvent(eventDrag);
                isTrigger = true;
//                 if (pFrame->isIn(x, y)) {
//                     pFrame->onEvent(eventDrag);
//                 }
            }
            if (isTrigger && eventDrag.m_enDragged) {
                return true;
            }
        }
        break;
        default:
            break;
        }
        if (UIScene::s_arrScene.size() > 0) {
            auto pScene = UIScene::getCurScene();
            if (pScene && !pScene->getIsNonEvent() && pScene->m_pRootControl != nullptr && pScene->m_pRootControl->isIn(x, y)
                && pScene->m_pRootControl->checkCanEvent()) {
                if (pScene->getDataIsOwnEvent()) {
                    return true;
                }
            }
            return false;
        }
    }
    break;
//     case InputKey::mouseDoubleRight:
//     {
// //         NodeManager::getInstance()->createFast();
// //         DataManager::getInstance()->initSSUIFunc();
//     }
//     break;
//     case InputKey::mouseRight:
    case InputKey::mouseMiddle:
    {
        switch (input.type) {
        case InputEvent::press:
            break;
        case InputEvent::release:
            if (UIManager::getInstance()->isUeMode()) {
                NodeManager::getInstance()->showObjectCount();
            }
            break;
        case InputEvent::drag:
            for (var& c : activeInput) {
                switch (c.key) {
                case InputKey::mouseRight:
                {
                    vec2i dir = input.point() - c.point();
                    c.setPoint(input.pointx, input.pointy);
                    break;
                }
                case InputKey::mouseMiddle:
                {
                    vec2i dir = input.point() - c.point();
                    c.setPoint(input.pointx, input.pointy);
                    vec2i move(-dir.x, dir.y);
                    break;
                }
                }
            }
            break;
        }
        if (UIScene::s_arrScene.size() > 0) {
            auto pScene = UIScene::getCurScene();
            if (pScene && !pScene->getIsNonEvent() && pScene->m_pRootControl != nullptr 
                && pScene->m_pRootControl->checkCanEvent()) {
                if (pScene->getDataIsOwnEvent()) {
                    return true;
                }
            }
            return false;
        }
    }
    break;
    case 'W':
    case 'S':
    case 'A':
    case 'D':
    case InputKey::up:
    case InputKey::down:
    case InputKey::left:
    case InputKey::right:
    case InputKey::wheel:
    case InputKey::alt:
        if (UIManager::getInstance()->m_pCurInputBox) {
            return true;
        }
//         if (isKeyHold(InputKey::control)) {
//             return false;
//         }
        if (input.type == InputEvent::press) {
        } else {
        }
        break;
    case 'F':
#ifdef _WIN32
        if (isKeyHold(InputKey::control)) {
            NodeManager::getInstance()->showObjectCount();
        }
#endif
        break;
    default: 
        if (UIManager::getInstance()->m_pCurInputBox) {
            return true;
        }
        break;
    }
    return false;
}

void UIController::reset() {
    activeInput.clear();
}

void UIController::init() {
}

void UIController::update() {
}
