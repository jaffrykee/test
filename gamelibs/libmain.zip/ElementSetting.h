#pragma once
#include "ObjectBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class NodeTypeSetting;
class ElementSetting : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ElementSetting);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(ElementSetting, ObjectBase);

#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
    static wstring s_tmpAttrName;
    static wstring s_tmpAttrValue;
#pragma endregion

#pragma region "��̬����"
    static ElementSetting* createObject(NameSpaceSetting* pNameSpace, const wstring& name, NodeType_e objType, CCIT_e ccit = CCIT_NULL);
    static const wstring& getAttrTypeWstringFromCode(int code);
#pragma endregion

#pragma region "��Ա"
    //ElementSettingType_e m_type;
    NameSpaceSetting* m_pParent = nullptr;
    NodeType_e m_objType;
    wstring m_name;
    LinkedHashMap<wstrHash, ElementSetting*> m_lmapChildNode;
    LinkedHashSet<int> m_lhsAttrClass;

    //<inc>
//     HashMap<wstrHash, ElementSetting*> m_mapComponentNode;
//     LinkedHashMap<wstrHash, AttrType_e> m_lmapAttr;
//     ArrayList<NodeType_e> m_arrCompType;
#pragma endregion

#pragma region "����"
    inline void addChild(ElementSetting* pNode) {
        m_lmapChildNode.insert(pNode->m_name.hashCode(), pNode);
    }
    void addChild(const wstring& childName);
    inline ElementSetting& assign(const ElementSetting& other) {
        Base::assign(other);
        //��Ӧ�õ��á�
        assert(false);
        m_objType = other.m_objType;
        m_name = other.m_name;
        for (auto& pairChildNode : other.m_lmapChildNode) {
            m_lmapChildNode.insert(pairChildNode.first, (ElementSetting*)pairChildNode.second->createCopy());
        }
        m_lhsAttrClass = other.m_lhsAttrClass;
        return *this;
    }
    void initAttrClass(NodeType_e nt);
    virtual DataInfoNode* parseXml(XmlParser& parser);
#pragma endregion
};

_SSUINamespaceEnd
