#include "ChildItem.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ChildItem, 0, 0);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ChildItem)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::ChildItem::createSelf() {

}

void ssui::ChildItem::disposeSelf() {

}

#pragma region "���Է���"
#pragma endregion

ssui::ChildItem& ssui::ChildItem::assign(const ChildItem& other) {
    Base::assign(other);
    return *this;
}
