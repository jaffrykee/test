#pragma once
#include "ObjectBase.h"
#include "Size.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class UITexture;
class UIImageBase : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UIImageBase)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(UIImageBase, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
protected:
    UITexture* mt_pTexture = nullptr;
public:
    inline UITexture* getTexture() const {
        return mt_pTexture;
    }
    void setTexture(UITexture* value) {
        mt_pTexture = value;
    }
private:
    strHash mt_key = 0;
public:
    inline int getKey() const {
        return mt_key;
    }
    inline void setKey(int value) {
        mt_key = value;
    }
    inline const string& getName() const {
        return StringManager::getInstance()->mc_strNullDef;
    }
    inline void setName(const string& value) {
        mt_key = value.hashCode();
    }
#pragma endregion

#pragma region "����"
public:
    inline UIImageBase& assign(const UIImageBase& other) {
        Base::assign(other);
        return *this;
    }
    inline virtual void getPolyImageFromSize(PolyImage& polyImage, const Size& size, const vec4& color) {

    }
#pragma endregion
};

_SSUINamespaceEnd
