#include "ProgressSlider.h"
#include "Control.h"
#include "MeasureData.h"
#include "Geometry.h"
#include "Progress.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ProgressSlider, 0, 0);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("enableProgSlider", EnableProgSlider, ProgressSlider, B2);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ProgressSlider)
NBSCRIPT_ATTR_REGISTER("enableProgSlider", EnableProgSlider, ProgressSlider, B2);
NODETYPE_COMMON_PART_DEFINITION_END

bool ssui::ProgressSlider::getEnableProgSlider() const {
    return enableProgSlider;
}

void ssui::ProgressSlider::setEnableProgSlider(bool value) {
    enableProgSlider = value;
}

ssui::ProgressSlider& ssui::ProgressSlider::assign(const ProgressSlider& other) {
    Base::assign(other);
    return *this;
}

void ssui::ProgressSlider::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    if (enableProgSlider == false) {
        return;
    }
    switch (event.m_type) {
        case ET_Press:
        {
            m_isDragged = false;
            event.m_blockAnimation = true;
            m_lastX = event.m_iData1;
            m_lastY = event.m_iData2;
            m_pressX = m_lastX;
            m_pressY = m_lastY;
            if (isInSlider(m_pressX, m_pressY) == false) {
                static float cx, cy;
                if (getCenter(cx, cy)) {
                    dragSlider(m_pressX - cx, m_pressY - cy);
                } else {
                    auto& pGeo = getHost()->getInnerMeasure().m_pTransGeo;
                    if (pGeo != nullptr) {
                        Border aabb;
                        pGeo->getBorder(aabb);
                        dragSlider(m_pressX - aabb.m_left - m_drawDx, m_pressY - aabb.m_top - m_drawDy);
                    }
                }
            }
            getHost()->setDataSlotIsPressed(SLOT_progSlider, true);
            getHost()->setEventType(event, PT_BlockStatusChange);
        }
        break;
        case ET_Drag:
        {
//             if (getHost()->getDataIsVisible() == false || getHost()->getDataIsEnable() == false ||
//                 getHost()->isIn(event.m_iData1, event.m_iData2) == false) {
//                 m_isDragged = true;
//                 getHost()->setDataSlotIsPressed(SLOT_progSlider, false);
//                 return;
//             }
            if (event.m_iData1 < m_pressX - s_clickTolerance || event.m_iData2 < m_pressY - s_clickTolerance ||
                event.m_iData1 > m_pressX + s_clickTolerance || event.m_iData2 > m_pressY + s_clickTolerance) {
                m_isDragged = true;
            }
            m_curX = event.m_iData1;
            m_curY = event.m_iData2;
            dragSlider(m_curX - m_lastX, m_curY - m_lastY);
            m_lastX = m_curX;
            m_lastY = m_curY;
            event.m_blockStatusChange = true;
            event.m_blockAnimation = true;
            event.m_enDragged = true;
            getHost()->setEventType(event, PT_BlockStatusChange);
        }
        break;
        case ET_Release:
        {
            m_curX = event.m_iData1;
            m_curY = event.m_iData2;
            m_pressX = -1;
            m_pressY = -1;
            getHost()->setDataSlotIsPressed(SLOT_progSlider, false);
//             if (getHost()->getDataIsVisible() == false || getHost()->getDataIsEnable() == false ||
//                 getHost()->isIn(event.m_iData1, event.m_iData2) == false || getHost()->getEventNodeGroup() == nullptr) {
//                 setCanTriggerScript(false);
//                 return;
//             }
            event.m_blockAnimation = true;
            getHost()->setEventType(event, PT_BlockStatusChange);
        }
        break;
        case ET_Click:
        {
            if (m_isDragged) {
                return;
            }
            if (getHost()->getDataIsVisible() == false || getHost()->getDataIsEnable() == false ||
                getHost()->isIn(event.m_iData1, event.m_iData2) == false) {
                setCanTriggerScript(false);
                return;
            }
            getHost()->setDataIsBlink(false);
            event.m_blockAnimation = true;
            getHost()->setEventType(event, PT_BlockStatusChange);
        }
        break;
        default:
        {

        }
        break;
    }
    Base::onEventScript(event);
}

ssui::ParentAreaType_e ssui::ProgressSlider::getParentAreaType() const {
    return PAT_inner;
}

void ssui::ProgressSlider::onTransform(unsigned char drawStep) {
    auto pProg = (Progress*)getHost()->getComponent(NT_Progress);
    if (pProg) {
        float per = pProg->getValuePercent();
        auto& area = getHost()->getInnerMeasure().m_srcArea;
        switch (pProg->m_direction) {
            case ssui::PROG_DRC_lr:
            case ssui::PROG_DRC_rl:
            {
                auto w = area.width();
                auto pw = per * w;
                m_drawDx = pw;
                m_drawDy = 0.f;
            }
            break;
            case ssui::PROG_DRC_tb:
            case ssui::PROG_DRC_bt:
            {
                auto h = area.height();
                auto ph = per * h;
                m_drawDx = 0.f;
                m_drawDy = ph;
            }
            break;
            default:
                break;
        }
        for (auto& pChild : *this) {
            applyTransformToSelfChildGrandChildAndSoOn(pChild, m_drawDx, m_drawDy);
        }
    }
}

bool ssui::ProgressSlider::isTouchComponent() const {
    return true;
}

const gstl::ArrayList<ssui::SlotType_e>& ssui::ProgressSlider::getSlotList() const {
    return getSlotListDef(SLOT_progSlider);
}

bool ssui::ProgressSlider::isIn(ft x, ft y) const {
    if (Base::isIn(x, y)) {
        return true;
    } else {
        if (getHost()->isEnableClip() == false) {
            return isInSlider(x, y);
        }
    }
    return false;
}

bool ssui::ProgressSlider::isInSlider(ft x, ft y) const {
    for (auto& pChild : getContainer()) {
        auto& pGeo = pChild->getSelfMeasure().m_pTransGeo;
        if (pGeo != nullptr && pGeo->isIn(x, y)) {
            return true;
        }
    }
    return false;
}

bool ssui::ProgressSlider::getBorder(Border& aabb) const {
    aabb.clear();
    static Border tmpAabb;
    bool isTouch = false;
    for (auto& pChild : getContainer()) {
        auto& pGeo = pChild->getSelfMeasure().m_pTransGeo;
        if (pGeo != nullptr) {
            if (isTouch == false) {
                pGeo->getBorder(aabb);
                isTouch = true;
            } else {
                pGeo->getBorder(tmpAabb);
                aabb |= tmpAabb;
            }
        }
    }
    return isTouch;
}

bool ssui::ProgressSlider::getCenter(ft& cx, ft& cy) const {
    static Border aabb;
    if (getBorder(aabb)) {
        aabb.getCenter(cx, cy);
        return true;
    }
    return false;
}

bool ssui::ProgressSlider::dragSlider(s16 dx, s16 dy) {
    auto pProg = (Progress*)getHost()->getComponent(NT_Progress);
    if (pProg) {
        pProg->dragSlider(dx, dy);
        return true;
    }
    return false;
}
