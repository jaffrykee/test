#pragma once
#include "ToggleButton.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class RadioButton : public ToggleButton {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(RadioButton)
protected:
    inline virtual void createSelf() override {
        setRadioIdFunc(StringManager::getInstance()->mc_strNullDef);
    }
    inline virtual void disposeSelf() override {
        removeFromCurRadio();
    }
    NODETYPE_COMMON_PART_DECLARATION_END(RadioButton, ToggleButton);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static HashMap<string, HashSet<RadioButton*>> s_mapRadio;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    HashMap<string, HashSet<RadioButton*>>::iterator mt_pairRadio = nullptr;
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    void setRadioIdFunc(const string& value) {
        removeFromCurRadio();
        const auto& pairRadio = s_mapRadio.find(value);
        if (pairRadio != s_mapRadio.end()) {
            mt_pairRadio = pairRadio;
            auto it = mt_pairRadio->second.find(this);
            if (it == mt_pairRadio->second.end()) {
                mt_pairRadio->second.insert(this);
            }
        } else {
            const auto& pairNew = s_mapRadio.insert(value, HashSet<Self*>());
            mt_pairRadio = pairNew;
            mt_pairRadio->second.insert(this);
        }
    }
    inline const string& getRadioId() const {
        return (mt_pairRadio == nullptr) ? StringManager::getInstance()->mc_strNullDef : mt_pairRadio->first;
    }
    void setRadioId(const string& value);

#pragma endregion

public:
    inline virtual void assignInitNode() {
        Base::create();
    }
    inline RadioButton& assign(const RadioButton& other) {
        Base::assign(other);
        setRadioId(other.getRadioId());
        return *this;
    }
    virtual void onEvent(SSUIEvent& event) override;
    inline void removeFromCurRadio() {
        if (mt_pairRadio != nullptr) {
            mt_pairRadio->second.erase(this);
            if (mt_pairRadio->second.empty() == true) {
                s_mapRadio.erase(mt_pairRadio);
            }
            mt_pairRadio = nullptr;
        }
    }
    virtual void onSelect() override;
    void checkOtherRadioButton();
#pragma endregion
};

_SSUINamespaceEnd
