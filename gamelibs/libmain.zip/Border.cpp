#include "Border.h"

const Border Border::s_null;
ssui::StaticCache<Border, BORDER_CACHE_WB> Border::s_cache;

Border& Border::createStaticCache() {
    auto& border = s_cache.nextData();
    border.clear();
    return border;
}

Border& Border::createStaticCache(ft left, ft top, ft right, ft bottom) {
    auto& border = s_cache.nextData();
    border.m_left = left;
    border.m_top = top;
    border.m_right = right;
    border.m_bottom = bottom;
    return border;
}

ssui::Border::Border() {

}

ssui::Border::Border(ft left, ft top, ft right, ft bottom) : m_left(left), m_top(top), m_right(right), m_bottom(bottom) {

}

bool Border::operator==(const Border& other) const {
    if (m_left == other.m_left && m_top == other.m_top && m_right == other.m_right && m_bottom == other.m_bottom) {
        return true;
    } else {
        return false;
    }
}

bool Border::operator!=(const Border& other) const {
    if (m_left != other.m_left || m_top != other.m_top || m_right != other.m_right || m_bottom != other.m_bottom) {
        return true;
    } else {
        return false;
    }
}

const Border& Border::operator|=(const Border& other) {
    if (m_left > other.m_left) {
        m_left = other.m_left;
    }
    if (m_right < other.m_right) {
        m_right = other.m_right;
    }
    if (m_top > other.m_top) {
        m_top = other.m_top;
    }
    if (m_bottom < other.m_bottom) {
        m_bottom = other.m_bottom;
    }
    return *this;
}

const Border& Border::operator+=(const vec2& other) {
    m_left += other.x;
    m_top += other.y;
    m_right += other.x;
    m_bottom += other.y;
    return *this;
}

bool Border::operator<=(const Border& other) const {
    if (m_left >= other.m_left && m_right <= other.m_right && m_top >= other.m_top && m_bottom <= other.m_bottom) {
        return true;
    } else {
        return false;
    }
}

bool Border::cross(const Border& other) {
    if (m_right < other.m_left || other.m_right < m_left || m_bottom < other.m_top || other.m_bottom < m_top) {
        clear();
        return false;
    }
    m_left = math::maximum(m_left, other.m_left);
    m_right = math::minimum(m_right, other.m_right);
    m_top = math::maximum(m_top, other.m_top);
    m_bottom = math::minimum(m_bottom, other.m_bottom);
    return true;
}

void Border::clear() {
    m_left = 0;
    m_top = 0;
    m_right = 0;
    m_bottom = 0;
}

void Border::outString(int lv /*= 3*/) const {
    LogPrintf("\nl: %f,\tt: %f,\tr: %f,\tb: %f", lv, m_left, m_top, m_right, m_bottom);
}

ssui::ft Border::width() const {
    return m_right - m_left;
}

ssui::ft Border::height() const {
    return m_bottom - m_top;
}

gstl::vec2 Border::center() const {
    return{ (m_left + m_right) * 0.5f, (m_top + m_bottom) * 0.5f };
}

void Border::getCenter(ft& cx, ft& cy) {
    cx = (m_left + m_right) * 0.5f;
    cy = (m_top + m_bottom) * 0.5f;
}

void ssui::Border::debugString(string& outString) {
    outString.append("\nBorder:\n\t");
    outString.append(string("l: ") + util::ftoa_c8s(m_left) + ",\tt: " + util::ftoa_c8s(m_top) +
        ",\tr: " + util::ftoa_c8s(m_right) + ",\tb: " + util::ftoa_c8s(m_bottom));
}
