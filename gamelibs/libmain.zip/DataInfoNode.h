#pragma once
#include "ObjectBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class DataInfoAttr;
class DataInfoNode : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(DataInfoNode);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(DataInfoNode, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
public:
    static DataInfoNode* createObject(const wstring& nsName, const wstring& esName);
#pragma endregion

#pragma region "��Ա"
public:
    ArrayList<DataInfoNode*> m_arrNode;
    ArrayList<DataInfoAttr*> m_arrAttr;
    NodeType_e m_objType = NT_MAX;
#pragma endregion

#pragma region "����"
public:
    inline void addNode(DataInfoNode* pNode) {
        m_arrNode.push_back(pNode);
    }
    inline void addAttr(DataInfoAttr* pAttr) {
        m_arrAttr.push_back(pAttr);
    }
    DataInfoNode& assign(const DataInfoNode& other);
#pragma endregion
};

_SSUINamespaceEnd
