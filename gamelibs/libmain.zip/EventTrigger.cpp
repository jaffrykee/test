#include "EventTrigger.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(EventTrigger, 0, 0);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(EventTrigger)
NODETYPE_COMMON_PART_DEFINITION_END
