#pragma once
#include "ButtonBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Button : public ButtonBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(Button)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(Button, ButtonBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
public:
    inline Button& assign(const Button& other) {
        Base::assign(other);
        return *this;
    }
    virtual void onEvent(SSUIEvent& event) override;
#pragma endregion
};

_SSUINamespaceEnd
