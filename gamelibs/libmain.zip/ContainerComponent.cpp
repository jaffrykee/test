#include "ContainerComponent.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ContainerComponent, 500, 2000);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ContainerComponent)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::ContainerComponent::disposeSelf() {
    for (auto& pChild : m_container) {
        pChild->releaseObject();
    }
    m_container.clear();
}

ContainerComponent& ssui::ContainerComponent::assign(const ContainerComponent& other) {
    Base::assign(other);
    return *this;
}

bool ssui::ContainerComponent::isContainerComponent() const {
    return true;
}

ArrayList<Control*>& ContainerComponent::container() {
    return m_container;
}

const ArrayList<SlotType_e>& ssui::ContainerComponent::getSlotList() const {
    return getSlotListDef(SLOT_container);
}

void ContainerComponent::onPrepareData() {

}
