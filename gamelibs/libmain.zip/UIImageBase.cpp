#include "UIImageBase.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UIImageBase, 0, 0);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("key", Key, UIImageBase, S32);
    NODEBASE_ATTR_REGISTER("name", Name, UIImageBase, STR);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UIImageBase)
    NBSCRIPT_ATTR_REGISTER("key", Key, UIImageBase, S32);
    NBSCRIPT_ATTR_REGISTER("name", Name, UIImageBase, STR);
NODETYPE_COMMON_PART_DEFINITION_END
