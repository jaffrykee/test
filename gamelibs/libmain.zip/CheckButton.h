#pragma once
#include "ToggleButton.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class CheckButton : public ToggleButton {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(CheckButton)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(CheckButton, ToggleButton);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
public:
    inline CheckButton& assign(const CheckButton& other) {
        Base::assign(other);
        return *this;
    }
    virtual void onEvent(SSUIEvent& event) override;
#pragma endregion
};

_SSUINamespaceEnd
