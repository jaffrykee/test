#pragma once
#include "ObjectBase.h"
#include "UIKeySubject.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class UIXmlConfig : public ObjectBase {
public:
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UIXmlConfig);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
        for (auto& pairKeySubject : m_mapKeySubject) {
			pairKeySubject.second->releaseObject();
        }
		m_mapKeySubject.clear();
    }
    NODETYPE_COMMON_PART_DECLARATION_END(UIXmlConfig, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
   HashMap<string, UIKeySubject*> m_mapKeySubject;
#pragma endregion

#pragma region "����"
public:
    inline UIXmlConfig& assign(const UIXmlConfig& other) {
        Base::assign(other);
        return *this;
    }
	void loadXmlConfigInfo();
    virtual int addDataChild(DataInfoNode& childData) override;
public:
    void addKeySubject(UIKeySubject* pKeySubject);
#pragma endregion
};

_SSUINamespaceEnd
