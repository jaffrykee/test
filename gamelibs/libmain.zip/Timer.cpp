#include "Timer.h"

#include "DataHeaders.h"

gstl::SortedMap<unsigned long long, Timer*> ssui::Timer::s_smapTimer;
gstl::HashMap<ObjectBase*, gstl::SortedSet<unsigned long long>> ssui::Timer::s_mapTimerKeyList;
gstl::ArrayList<Timer*> ssui::Timer::s_arrWaitingCreateCache;
gstl::ArrayList<ObjectBase*> ssui::Timer::s_arrWaitingClearCache;
bool ssui::Timer::s_isCreateLock = false;;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Timer, 50, 100);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(Timer)
NODETYPE_COMMON_PART_DEFINITION_END
