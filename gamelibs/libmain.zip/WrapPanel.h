#pragma once
#include "StackPanel.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class WrapPanel : public StackPanel {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(WrapPanel);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(WrapPanel, StackPanel);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    //һ���м��У��У�
    s16 m_drawLineCount = 0;
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    virtual void setDataDirection(int value) override;
public:
    int getDrawLineCount() const;
    //�Ƿ��Ⱥ�������
    virtual bool getIsHorizontal() const override;
    //�Ƿ������ٺᡣ
    virtual bool getIsVertical() const override;
    virtual bool getIsLeft() const override;
    virtual bool getIsTop() const override;
#pragma endregion
public:
    WrapPanel& assign(const WrapPanel& other);
public:
    //virtual bool onDrawChildren(unsigned char drawStep, bool isReDraw) override;
    virtual void onPrepareData() override;
    virtual void onTransformChildren(unsigned char drawStep) override;
#pragma endregion
};

_SSUINamespaceEnd
