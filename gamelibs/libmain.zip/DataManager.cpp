#ifdef _WIN32
#include <io.h>
#else
#include <sys/uio.h>
#endif
#include "DataManager.h"
#include "ResLoader.h"
#include "SSUILib.h"
#include "ObjectHeaders.h"

static string sFileName;
static string sFileData;
string DataManager::s_className = "DataManager";
DataManager* DataManager::s_pInstance = nullptr;

void DataManager::registerReflection(int id) {
    //registerFunc(id, "loadUI", bolo_ui_loadUI, "(UIScene*)loadUI(string name)");
}

void DataManager::regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
    const NodeType_e& nodeType, boloClassGetFuncB2 getFunc, boloClassSetFuncB2 setFunc, const wstring& subType, bool isEnum) {
    m_arrAttrSetting[attrType] = AttrSetting::createObject(attrType, attrName, dataType, nodeType, getFunc, setFunc, subType, isEnum);
    regNodeAttrs(nodeType, attrType);
}

void DataManager::regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
    const NodeType_e& nodeType, boloClassGetFuncS32 getFunc, boloClassSetFuncS32 setFunc, const wstring& subType, bool isEnum) {
    m_arrAttrSetting[attrType] = AttrSetting::createObject(attrType, attrName, dataType, nodeType, getFunc, setFunc, subType, isEnum);
    regNodeAttrs(nodeType, attrType);
}

void DataManager::regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
    const NodeType_e& nodeType, boloClassGetFuncU32 getFunc, boloClassSetFuncU32 setFunc, const wstring& subType, bool isEnum) {
    m_arrAttrSetting[attrType] = AttrSetting::createObject(attrType, attrName, dataType, nodeType, getFunc, setFunc, subType, isEnum);
    regNodeAttrs(nodeType, attrType);
}

void DataManager::regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
    const NodeType_e& nodeType, boloClassGetFuncF32 getFunc, boloClassSetFuncF32 setFunc, const wstring& subType, bool isEnum) {
    m_arrAttrSetting[attrType] = AttrSetting::createObject(attrType, attrName, dataType, nodeType, getFunc, setFunc, subType, isEnum);
    regNodeAttrs(nodeType, attrType);
}

void DataManager::regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
    const NodeType_e& nodeType, boloClassGetFuncS64 getFunc, boloClassSetFuncS64 setFunc, const wstring& subType, bool isEnum) {
    m_arrAttrSetting[attrType] = AttrSetting::createObject(attrType, attrName, dataType, nodeType, getFunc, setFunc, subType, isEnum);
    regNodeAttrs(nodeType, attrType);
}

void DataManager::regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
    const NodeType_e& nodeType, boloClassGetFuncString getFunc, boloClassSetFuncString setFunc, const wstring& subType, bool isEnum) {
    m_arrAttrSetting[attrType] = AttrSetting::createObject(attrType, attrName, dataType, nodeType, getFunc, setFunc, subType, isEnum);
    regNodeAttrs(nodeType, attrType);
}

void DataManager::regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
    const NodeType_e& nodeType, boloClassGetFuncWString getFunc, boloClassSetFuncWString setFunc, const wstring& subType, bool isEnum) {
    m_arrAttrSetting[attrType] = AttrSetting::createObject(attrType, attrName, dataType, nodeType, getFunc, setFunc, subType, isEnum);
    regNodeAttrs(nodeType, attrType);
}

void DataManager::initCcitData() {
    auto pSsui = getSSUINameSpace();
    auto pEssui = pSsui->m_lmapElementSetting[StringManager::getInstance()->mc_wstrSSUI.hashCode()];
    ElementSetting* pEs;

    CCIT_DEF(Label, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_MAX);
    CCIT_DEF(Button, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_Button, NT_MAX);
    CCIT_DEF(Radio, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_RadioButton, NT_MAX);
    CCIT_DEF(Check, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_CheckButton, NT_MAX);
    CCIT_DEF(SkillButton, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_SkillButton, NT_MAX);
    CCIT_DEF(InputBox, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_InputBox, NT_MAX);
    CCIT_DEF(TextFlow, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_TextFlow, NT_ScrollView, NT_MAX);
    CCIT_DEF(Progress, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_Progress, NT_ProgressSlider, NT_MAX);
    CCIT_DEF(VirtualJoystick, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_VirtualJoystick, NT_MAX);
    CCIT_DEF(TimeBlock, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_TimeContent, NT_Block, NT_MAX);
	CCIT_DEF(UIDrawModel, NT_BasicMeasure, NT_BasicContent, NT_Block, NT_UIDrawModel, NT_MAX);
    CCIT_DEF(ImageShape, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_ImageShape, NT_MAX);
    CCIT_DEF(TextShape, NT_TextShape, NT_BasicMeasure, NT_BasicTransform, NT_BasicContent, NT_MAX);
    //CCIT_DEF(TextShape, NT_BasicMeasure, NT_BasicClip, NT_BasicContent, NT_TextShape, NT_MAX); 
    CCIT_DEF(ParticleShape, NT_BasicMeasure, NT_BasicTransform, NT_BasicContent, NT_ParticleShape, NT_MAX); 
    
    CCIT_DEF(Panel, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_Panel, NT_ScrollView, NT_MAX);
    CCIT_DEF(StackPanel, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_StackPanel, NT_ScrollView, NT_MAX);
    CCIT_DEF(SlicedPanel, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_SlicedPanel, NT_MAX);

    //======================================
    CCIT_DEF(Para, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Para, NT_MAX);
    CCIT_DEF(FlowElement, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_FlowElement, NT_MAX);
    CCIT_DEF(Grid, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_Grid, NT_ScrollView, NT_MAX);
    CCIT_DEF(WrapPanel, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_WrapPanel, NT_ScrollView, NT_MAX);
    CCIT_DEF(AutoGrid, NT_BasicMeasure, NT_BasicTransform, NT_BasicClip, NT_BasicContent, NT_Block, NT_AutoGrid, NT_ScrollView, NT_MAX);

    for (const auto& ccit : m_ccitData) {
        bool isContainer = false;
        for (auto& ntComp : ccit.m_data) {
            if (ObjectBase::is(ntComp, NodeType_e::NT_UIComponent) &&
                ((UIComponent*)ObjectBase::getInitNode(ntComp))->isContainerComponent()) {
                isContainer = true;
                break;
            }
        }
        if (isContainer) {
            for (const auto& ccitChild : m_ccitData) {
                ccit.m_pEs->addChild(ccitChild.m_pEs);
            }
            ccit.m_pEs->addChild(getSSUINameSpace()->m_lmapElementSetting[StringManager::getInstance()->mc_wstrControl.hashCode()]);
        }
        ccit.m_pEs->addChild(getSSUINameSpace()->m_lmapElementSetting[StringManager::getInstance()->mc_wstrEventNodeBase.hashCode()]);
        getSSUINameSpace()->m_lmapElementSetting[StringManager::getInstance()->mc_wstrControl.hashCode()]->addChild(ccit.m_pEs);
    }
}

const std::bitset<NT_MAX>& DataManager::getNodeInheritData(NodeType_e nt) {
    return m_arrNodeTypeSetting[nt]->m_inheritData;
}

ObjectBase* DataManager::getInitNode(NodeType_e nodeType) {
    return m_arrNodeTypeSetting[nodeType]->m_pInitNode;
}

void DataManager::getAttrInitData(wstring& initData) {
    //SSUI! Control@[attrData] ! Button@[attrData] ! ...
    //Control @ color$int$ # visible$bool$true # ...
    initData = StringManager::getInstance()->mc_wstrSSUI;
    for (auto& pNts : m_arrNodeTypeSetting) {
        const auto& lmapAs = pNts->m_lmapAttrSetting;
        if (lmapAs.empty() == false) {
            initData += "!";
            initData += pNts->m_name;
            initData += "@";
            for (const auto& pairAs : lmapAs) {
                initData += pairAs.second->m_attrName;
                if (pairAs.second->m_isEnum == true) {
                    initData += "$enum$";
                    initData += "$";
                } else {
                    switch (pairAs.second->m_dataType) {
                    case AttrDataType_e::ADT_B2:
                        initData += "$bool$";
                        bool value;
                        if (pairAs.second->getDefaultValueB2(value)) {
                            initData += value ? "true" : "false";
                        }
                        initData += "$";
                        break;
                    default:
                        initData += "$int$";
                        initData += "$";
                        break;
                    }
                }
                initData += ((pairAs.second->m_pSubType) ? (*pairAs.second->m_pSubType) : (DictionaryManager::getInstance()->m_arrAttrSubType[AST_halfNormal]));
                initData += "#";
            }
            initData.pop_back();
        }
    }
}

void DataManager::getNodeInitData(wstring& initData) {
    //SSUI! Panel@[childData]@[attrData] ! Label@[childData]@[attrData] ~ ...
    // Panel @ Panel#Label#Button#Event @ Control#Block#Panel
    initData.clear();
    wstring rootName = "SSUI";
    wstring childData, attrData;

    for (const auto& pairNs : m_lmapNameSpaceSetting) {
        const auto& pNs = pairNs.second;
        initData += pNs->m_name;
        for (const auto& pairEs : pNs->m_lmapElementSetting) {
            const auto& pEs = pairEs.second;
            initData += '!';
            initData += pEs->m_name;
            initData += "@";
            if (!pEs->m_lmapChildNode.empty()) {
                auto pairChildData = pEs->m_lmapChildNode.begin();
                initData += pairChildData->second->m_name;
                pairChildData++;
                for (; pairChildData != pEs->m_lmapChildNode.end(); pairChildData++) {
                    initData += "#";
                    initData += pairChildData->second->m_name;
                }
            }
            initData += "@";
            if (!pEs->m_lhsAttrClass.empty()) {
                for (const auto& nt : pEs->m_lhsAttrClass) {
                    initData += m_arrNodeTypeSetting[nt]->m_name;
                    initData += "#";
                }
                initData.pop_back();
            }
        }
        initData += "~";
    }
    initData.pop_back();
}


void ssui::DataManager::getLanguageSettingInitData(wstring& initData) {
    initData.clear();
    //wstring tmpWStr;
    for (auto& pairLang : LanguageManager::getInstance()->m_lmapLang) {
//         tmpWStr.clear();
//         util::str2str(pairLang.first, tmpWStr);
        initData += pairLang.first.c_str();
        initData += "~";
    }
    initData.pop_back();
}

ssui::NameSpaceSetting* ssui::DataManager::getSSUIImageNameSpace() {
    return m_lmapNameSpaceSetting[StringManager::getInstance()->mc_wstrSSUIImage.hashCode()];
}

void ssui::DataManager::getCcitName(string& ccitName, CCIT_e ccit) {
    auto pEs = DataManager::getInstance()->m_ccitData[ccit].m_pEs;
    if (pEs == nullptr) {
        return;
    }
    StringManager::getInstance()->wstringToString(pEs->m_name, ccitName);
}

ssui::NameSpaceSetting* ssui::DataManager::getSSUINameSpace() {
    return m_lmapNameSpaceSetting[StringManager::getInstance()->mc_wstrSSUI.hashCode()];
}

void DataManager::initialize() {
    auto pSelf = getInstance();
    for (auto& pAs : pSelf->m_arrAttrSetting) {
        if (pAs != nullptr) {
            pSelf->m_mapAttrSetting.insert(pAs->m_attrName.hashCode(), pAs);
        }
    }
    auto pSsui = NameSpaceSetting::createObject(StringManager::getInstance()->mc_wstrSSUI, &NameSpaceSetting::parseSSUIXml);
    auto pUt = NameSpaceSetting::createObject(StringManager::getInstance()->mc_wstrSSUIImage, &NameSpaceSetting::parseUITextureXml);
    auto pXml = NameSpaceSetting::createObject(StringManager::getInstance()->mc_wstrUIXmlConfig, &NameSpaceSetting::parseXmlConfigXml);
    ElementSetting::createObject(pSsui, StringManager::getInstance()->mc_wstrSSUI, NT_UIScene);
    ElementSetting::createObject(pSsui, StringManager::getInstance()->mc_wstrControl, NT_Control);
    ElementSetting::createObject(pSsui, StringManager::getInstance()->mc_wstrSkinGroup, NT_SkinGroup);
    ElementSetting::createObject(pSsui, StringManager::getInstance()->mc_wstrUITexture, NT_UITexture);
    ElementSetting::createObject(pSsui, StringManager::getInstance()->mc_wstrSkin, NT_Skin);
    ElementSetting::createObject(pSsui, StringManager::getInstance()->mc_wstrShapeGroup, NT_ShapeGroup);
    ElementSetting::createObject(pSsui, StringManager::getInstance()->mc_wstrEventNodeBase, NT_EventNodeBase);
    ElementSetting::createObject(pSsui, StringManager::getInstance()->mc_wstrEventScript, NT_EventScript);
    ElementSetting::createObject(pUt, StringManager::getInstance()->mc_wstrSSUIImage, NT_UITexture);
    ElementSetting::createObject(pUt, StringManager::getInstance()->mc_wstrUIImageRect, NT_UIImageRect);
    ElementSetting::createObject(pUt, StringManager::getInstance()->mc_wstrUIImagePoly, NT_UIImagePoly);

    ElementSetting::createObject(pXml, StringManager::getInstance()->mc_wstrUIXmlConfig, NT_UIXmlConfig);
    ElementSetting::createObject(pXml, StringManager::getInstance()->mc_wstrUIKeySubject, NT_UIKeySubject);
    //createObject("Script", NNNNN_Script, NT_Panel);
    for (auto& pair : pSelf->m_mapNodeTypeSetting) {
        //<inc>
        //ElementSetting::createObject(wstring("_") + pair.first, 0x8000 | (int)(pair.second), pair.second->m_nodeType);
    }
    pSelf->initCcitData();
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrSSUI, StringManager::getInstance()->mc_wstrControl);

    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrSSUI, StringManager::getInstance()->mc_wstrControl);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrSSUI, StringManager::getInstance()->mc_wstrSkinGroup);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrSSUI, StringManager::getInstance()->mc_wstrSkin);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrSSUI, StringManager::getInstance()->mc_wstrUITexture);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrSSUI, StringManager::getInstance()->mc_wstrEventNodeBase);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrControl, StringManager::getInstance()->mc_wstrControl);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrControl, StringManager::getInstance()->mc_wstrEventNodeBase);

    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrEventNodeBase, StringManager::getInstance()->mc_wstrEventScript);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrSkin, StringManager::getInstance()->mc_wstrShapeGroup);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrShapeGroup, StringManager::getInstance()->mc_wstrImageShape);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrShapeGroup, StringManager::getInstance()->mc_wstrTextShape);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrShapeGroup, StringManager::getInstance()->mc_wstrParticleShape);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrShapeGroup, StringManager::getInstance()->mc_wstrSlicedPanel);
    pSsui->addEsToEs(StringManager::getInstance()->mc_wstrSlicedPanel, StringManager::getInstance()->mc_wstrImageShape);

    pUt->addEsToEs(StringManager::getInstance()->mc_wstrSSUIImage, StringManager::getInstance()->mc_wstrUIImageRect);
    pUt->addEsToEs(StringManager::getInstance()->mc_wstrSSUIImage, StringManager::getInstance()->mc_wstrUIImagePoly);

    pXml->addEsToEs(StringManager::getInstance()->mc_wstrUIXmlConfig, StringManager::getInstance()->mc_wstrUIKeySubject);
}

void DataManager::destroy() {
    auto pSelf = getInstance();
    for (auto& ccit : pSelf->m_ccitData) {
        ccit.m_data.clear();
    }
    pSelf->m_lmapCcit.clear();
    for (auto& pairNs : pSelf->m_lmapNameSpaceSetting) {
        pairNs.second->releaseObject();
    }
    pSelf->m_lmapNameSpaceSetting.clear();
    for (auto& pCs : pSelf->m_arrNodeTypeSetting) {
        pCs->releaseObject();
    }
    pSelf->clearCache();
}

void DataManager::clearCache() {
    for (auto& pair : m_mapSceneTemplate) {
        pair.second->releaseObject();
    }
    m_mapSceneTemplate.clear();
    for (auto& pair : m_mapImageTemplate) {
        pair.second->releaseObject();
    }
    m_mapImageTemplate.clear();
    if (m_xmlConfigTemplate) {
        m_xmlConfigTemplate->releaseObject();
    }
}

void DataManager::loadXmlFromBuff(const string& fileName, const c8* pData, int size) {
    wstring rootName;
    iobuf bisData(pData, size == -1 ? strlen(pData) : size);
    XmlParser parser;
    parser.setInput(bisData);
    parser.next();
    parser.getName(rootName);

    const auto& pairNs = m_lmapNameSpaceSetting.find(rootName.hashCode());
    if (pairNs != m_lmapNameSpaceSetting.end()) {
        const auto& pNs = pairNs->second;
        pNs->parseXml(fileName, parser);
    }

    parser.require(END_TAG, StringManager::getInstance()->mc_wstrNullDef, rootName);
    parser.next();
    parser.require(END_DOCUMENT, "", NULLSTRING);
    bisData.close();
}

void DataManager::loadXmlFromString(const string& fileName, const string& strData) {
    loadXmlFromBuff(fileName, strData.c_str());
}

void ssui::DataManager::loadXmlFromQuoteSkinGroup(const string& fileName) {
    string t_fileName = fileName;
    if (ResLoader::isResInMod()) {
        t_fileName = util::lowcase(fileName);
    }
    const auto& pairScene = m_mapSceneTemplate.find(t_fileName);
    if (pairScene != m_mapSceneTemplate.end()) {
        auto pDataInfo = pairScene->second;
        if (pDataInfo != nullptr) {
            for (const auto& pNode : pDataInfo->m_arrNode) {
                if (pNode->m_objType == NT_SkinGroup) {
                    for (const auto& pAttr : pNode->m_arrAttr) {
                        if (pAttr != nullptr && pAttr->m_attrType == AT_SkinGroup_Name && pAttr->m_pStrData != nullptr) {
                            const string& skinGroupName = *pAttr->m_pStrData;
                            DataManager::loadXmlFromFile(skinGroupName, ImageManager::getSkinPath(), false);
                            DataManager::loadSkinGroupFromTemplate(skinGroupName);
                        }
                    }
                }
            }
        }
    }
    SkinGroup::refreshAllCurSkin();
}

void ssui::DataManager::reloadAllUITexture() {
    ArrayList<string> arrFiles;
    //./images/
    getFiles(arrFiles, ResLoader::getResourcePath() + ImageManager::getFreePath() + ImageManager::getImagePath(), "*.xml", false);
    for (auto& fileName : arrFiles) {
        DataManager::loadXmlFromFile(fileName, ImageManager::getImagePath(), false);
    }
    for (auto& fileName : arrFiles) {
        DataManager::loadUITextureFromTemplate(fileName);
    }
    arrFiles.clear();
}

void DataManager::loadXmlFromMsgData(const string& msgData) {
    sFileName.clear();
    sFileData.clear();
    auto iSplit = msgData.find_first_of("~", 0);
    sFileName = msgData.substr(0, iSplit);
    sFileData = msgData.substr(iSplit + 1, msgData.length() - iSplit - 1);
    //<inc>
    if (UIManager::getInstance()->isUeMode() == false) {
        preReadData();
        loadXmlFromString(sFileName, sFileData);
    } else {
#ifndef _DEBUG
        reloadAllUITexture();
#endif
        loadXmlFromString(sFileName, sFileData);
        loadXmlFromQuoteSkinGroup(sFileName);
    }
    UIManager::getInstance()->closeAllUI();
    if (UIManager::getInstance()->isUeMode() == false) {
        DataManager::getInstance()->loadSkinGroupFromTemplate(sFileName);
        DataManager::getInstance()->loadUISceneFromTemplate(sFileName);
    } else {
        DataManager::getInstance()->loadUISceneFromTemplate(sFileName, false);
    }
}

void DataManager::loadXmlFromFile(const string& fileName, const string& exPack, bool isInMod) {
    const string& packageName = isInMod ? "" : (ImageManager::getArtistPath() + ImageManager::getFreePath());
    int size = 0;
    c8* data = ResLoader::loadFile(packageName + exPack + fileName, size);
    if (!data) {
        printlog("name = %s is not exist!\n", fileName.c_str());
    } else {
        loadXmlFromBuff(fileName, data, size);
        delete[] data;
    }
}

UIScene* DataManager::loadUISceneFromTemplate(const string& fileName, bool isFindFromUpdate) {
    string t_fileName = fileName;
    if (ResLoader::isResInMod()) {
        t_fileName = util::lowcase(fileName);
    }
    const auto& pairTemplate = m_mapSceneTemplate.find(t_fileName);
    UIScene* pNew = nullptr;
    if (pairTemplate != m_mapSceneTemplate.end()) {
        pNew = UIScene::createScene(fileName, *pairTemplate->second);
    } else if (isFindFromUpdate == true) {
        preReadUIFileData(fileName);
        const auto& pairTemplate2 = m_mapSceneTemplate.find(t_fileName);
        if (pairTemplate2 != m_mapSceneTemplate.end()) {
            pNew = UIScene::createScene(fileName, *pairTemplate2->second);
        }
    }
    if (pNew != nullptr && pNew->is(NT_UIScene)) {
        pNew->initScene();
        pNew->onEvent(SSUIEvent::createSSUIEvent(ET_onSceneLoaded));
        return (UIScene*)pNew;
    }
    return nullptr;
}

SkinGroup* DataManager::loadSkinGroupFromTemplate(const string& fileName) {
    string t_fileName = fileName;
    if (ResLoader::isResInMod()) {
        t_fileName = util::lowcase(fileName);
    }
    const auto& pairTemplate = m_mapSceneTemplate.find(t_fileName);
    if (pairTemplate != m_mapSceneTemplate.end()) {
        return SkinGroup::createSkinGroup(fileName, *pairTemplate->second);
    }
    return nullptr;
}

UITexture* DataManager::loadUITextureFromTemplate(const string& fileName) {
    string t_fileName = fileName;
    if (ResLoader::isResInMod()) {
        t_fileName = util::lowcase(fileName);
    }
    const auto& pairTemplate = m_mapImageTemplate.find(t_fileName);
    if (pairTemplate != m_mapImageTemplate.end()) {
        //StringManager::getInstance()->mtringToWstring(fileName, m_tmpFileName);
        m_tmpArrSplit.clear();
        util::split(fileName, '.', m_tmpArrSplit);
        if (!m_tmpArrSplit.empty() && !m_tmpArrSplit.front().empty()) {
            return UITexture::createUITexture(m_tmpArrSplit.front(), *pairTemplate->second);
        }
    }
    return nullptr;
}

void DataManager::loadXmlConfigFromTemplate() {
    if (!m_xmlConfigTemplate)
        return;
    refreshBagItemXmlList.clear();
    canMoveRoleXmlList.clear();
    xmlNoneventConfig.clear();
    xmlPriorityConfig.clear();
    currencyXmlList.clear();
    canShowFloatXmlList.clear();
    const auto& pXmlConf = (UIXmlConfig*)ObjectBase::createObject(*m_xmlConfigTemplate);
    if (pXmlConf) {
        pXmlConf->loadXmlConfigInfo();
    }
}

void DataManager::getFiles(ArrayList<string>& arrFiles, const string& path, const string& fix, bool isIterative) {
#ifdef _WIN32
    //�ļ����
    size_t hFile = 0;
    //�ļ���Ϣ
    struct _finddata_t fileinfo;
    string p = path;
    if ((hFile = _findfirst(p.append(fix).c_str(), &fileinfo)) != -1) {
        do {
            //�����Ŀ¼,����֮
            //�������,�����б�
            if ((fileinfo.attrib & _A_SUBDIR)) {
                if (isIterative && strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0) {
                    getFiles(arrFiles, p.append("\\").append(fileinfo.name), fix, isIterative);
                }
            } else {
                arrFiles.push_back(fileinfo.name);
            }
        } while (_findnext(hFile, &fileinfo) == 0);
        _findclose(hFile);
    }
#endif
}

void DataManager::initSSUIFunc() {
    preReadData();
    //DataManager::loadUISceneFromTemplate("a.sui");
}

void DataManager::preReadData() {
    if (ResLoader::isResInMod()) {
        HashSet<string> files;
        ResLoader::listFile("ui", files, "*.xml");
        for (auto& fileName : files) {
            DataManager::loadXmlFromFile(fileName, "ui/", true);
        }
        for (auto& fileName : files) {
            DataManager::loadUITextureFromTemplate(fileName);
        }
        for (auto& fileName : files) {
            DataManager::loadSkinGroupFromTemplate(fileName);
        }
        files.clear();
        ResLoader::listFile("images", files, "*.xml");
        for (auto& fileName : files) {
            DataManager::loadXmlFromFile(fileName, "images/", true);
        }
        for (auto& fileName : files) {
            DataManager::loadUITextureFromTemplate(fileName);
        }
    } else {
        ArrayList<string> arrFiles;

        ImageManager::setFreePath("./ui/");
        //./
        getFiles(arrFiles, ResLoader::getResourcePath() + ImageManager::getFreePath(), "*.xml", false);
        for (auto& fileName : arrFiles) {
            DataManager::loadXmlFromFile(fileName, "", false);
        }
        for (auto& fileName : arrFiles) {
            DataManager::loadUITextureFromTemplate(fileName);
        }
        arrFiles.clear();

        //./images/
        getFiles(arrFiles, ResLoader::getResourcePath() + ImageManager::getFreePath() + ImageManager::getImagePath(), "*.xml", false);
        for (auto& fileName : arrFiles) {
            DataManager::loadXmlFromFile(fileName, ImageManager::getImagePath(), false);
        }
        for (auto& fileName : arrFiles) {
            DataManager::loadUITextureFromTemplate(fileName);
        }
        arrFiles.clear();

        //./skin/
        getFiles(arrFiles, ResLoader::getResourcePath() + ImageManager::getFreePath() + ImageManager::getSkinPath(), "*.xml", false);
        for (auto& fileName : arrFiles) {
            DataManager::loadXmlFromFile(fileName, ImageManager::getSkinPath(), false);
        }
        for (auto& fileName : arrFiles) {
            DataManager::loadSkinGroupFromTemplate(fileName);
        }
        arrFiles.clear();

        //./
        getFiles(arrFiles, ResLoader::getResourcePath() + ImageManager::getFreePath(), "*.xml", false);
//         for (auto& fileName : arrFiles) {
//             DataManager::loadXmlFromFile(fileName, "", false);
//         }
        //֮ǰ�Ѿ��ȹ�
        for (auto& fileName : arrFiles) {
            DataManager::loadSkinGroupFromTemplate(fileName);
        }
        arrFiles.clear();
    }
    loadXmlConfigFromTemplate();
    SkinGroup::refreshAllCurSkin();
}

void ssui::DataManager::preReadUIFileData(const string& fileName, const string& folder) {
    DataManager::loadXmlFromFile(fileName, folder, false);
    DataManager::loadSkinGroupFromTemplate(fileName);
}

void DataManager::resetProjPath(const string& artistPath) {
    ResLoader::initResourcePath(artistPath);
    NodeManager::getInstance()->createFast();
    preReadData();
}
