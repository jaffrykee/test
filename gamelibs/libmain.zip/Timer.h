#pragma once
#include "ObjectBase.h"
#include "GameTime.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Timer : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(Timer);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(Timer, ObjectBase);
#pragma region "��������"
public:
    typedef void(ObjectBase::*TimerTriggerFunc)(u32);
#pragma endregion

#pragma region "��̬��Ա"
public:
    static SortedMap<unsigned long long, Timer*> s_smapTimer;
    //����ֻ��Control��������Լ�Timer��
    static HashMap<ObjectBase*, SortedSet<unsigned long long>> s_mapTimerKeyList;
    static ArrayList<Timer*> s_arrWaitingCreateCache;
    static ArrayList<ObjectBase*> s_arrWaitingClearCache;
    static bool s_isCreateLock;
#pragma endregion

#pragma region "��̬����"
public:
    inline static void putFunc(Timer* pTimer) {
        auto key = pTimer->getKey();
        s_smapTimer.insert(key, pTimer);
        auto pairTimerKey = s_mapTimerKeyList.find(pTimer->m_pSelf);
        if (pairTimerKey == s_mapTimerKeyList.end()) {
            pairTimerKey = s_mapTimerKeyList.insert(pTimer->m_pSelf, SortedSet<unsigned long long>());
        }
        pairTimerKey->second.insert(key);
    }
    inline static Timer* createObject(ObjectBase* pSelf, TimerTriggerFunc trigger, u32 time = 1) {
        auto pTimer = Self::createObject();
        pTimer->m_pSelf = pSelf;
        pTimer->m_triggerFunc = trigger;
        pTimer->m_triggerTime = GameTime::getUseTimeStable() + time;
        if (s_isCreateLock == false) {
            putFunc(pTimer);
        } else {
            s_arrWaitingCreateCache.push_back(pTimer);
        }
        if (time > 500) {
            LogPrintf("Timer:\t%d", 7, time);
        }
        return pTimer;
    }
    inline static void printAllTimer(const string& tag) {
        LogPrintf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!%s", 7, tag.c_str());
        for (const auto& pair : s_smapTimer) {
            LogPrintf("key:\t%lld\tvalue:%lld\t", 7, pair.first, (__ptr)pair.second);
        }
        LogPrintf("============================%s", 7, tag.c_str());
    }
    inline static void deleteFromTimerKeyList(Timer* pTimer) {
        auto pairTimerKeyList = s_mapTimerKeyList.find(pTimer->m_pSelf);
        if (pairTimerKeyList != s_mapTimerKeyList.end()) {
            pairTimerKeyList->second.erase(pTimer->getKey());
            if (pairTimerKeyList->second.empty()) {
                s_mapTimerKeyList.erase(pairTimerKeyList);
            }
        }
    }
    inline static int updateTime(u32 curTime) {
        if (s_smapTimer.empty()) {
            return 0;
        }
        s_isCreateLock = true;
        int count = 0;
        auto pairTimer = s_smapTimer.begin();
        for (; pairTimer != s_smapTimer.end(); pairTimer = s_smapTimer.begin()) {
            u32 rowTime = pairTimer->first >> 32;
            if (rowTime > curTime) {
                break;
            }
            const auto& curTimer = pairTimer->second;
            ((curTimer->m_pSelf)->*(curTimer->m_triggerFunc))(rowTime);

            deleteFromTimerKeyList(curTimer);
            curTimer->releaseObject();
            s_smapTimer.erase(pairTimer);
        }
        s_isCreateLock = false;
        for (auto& pObj : s_arrWaitingClearCache) {
            clearTimer(pObj);
            for (auto itwn = s_arrWaitingCreateCache.begin(); itwn != s_arrWaitingCreateCache.end(); ++itwn) {
                if ((*itwn)->m_pSelf == pObj) {
                    s_arrWaitingCreateCache.erase(itwn);
                    --itwn;
                }
            }
        }
        for (auto& pTimer : s_arrWaitingCreateCache) {
            putFunc(pTimer);
        }
        s_arrWaitingCreateCache.clear();
        s_arrWaitingClearCache.clear();
        return count;
    }
    inline static void clearTimer(ObjectBase* pSelf) {
        if (s_isCreateLock == false) {
            auto pairTimerKeyList = Timer::s_mapTimerKeyList.find(pSelf);
            if (pairTimerKeyList != Timer::s_mapTimerKeyList.end()) {
                for (const auto& key : pairTimerKeyList->second) {
                    Timer::s_smapTimer[key]->releaseObject();
                    Timer::s_smapTimer.erase(key);
                }
                Timer::s_mapTimerKeyList.erase(pairTimerKeyList);
            }
        } else {
            s_arrWaitingClearCache.push_back(pSelf);
        }
    }
#pragma endregion

#pragma region "��Ա"
public:
    ObjectBase* m_pSelf = nullptr;
    TimerTriggerFunc m_triggerFunc = nullptr;
    u32 m_triggerTime = UINT_MAX;
#pragma endregion

#pragma region "����"
public:
    inline Timer& assign(const Timer& other) {
        Base::assign(other);
        return *this;
    }
    inline unsigned long long getKey() {
        return (((unsigned long long)m_triggerTime) << 32) + (((unsigned long long)m_pSelf) & UINT_MAX);
    }
#pragma endregion
};

_SSUINamespaceEnd
