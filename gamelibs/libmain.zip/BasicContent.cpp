#include "BasicContent.h"
#include "UIScene.h"
#include "Control.h"
#include "InputBox.h"
#include "EventNodeGroup.h"
#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(BasicContent, CONTROL_RESPOOLINIT, CONTROL_RESPOOLLIMIT);
#pragma region "����ע��"
NODETYPE_COMMON_PART_DEFINITION_MID(BasicContent)
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_END

void BasicContent::disposeSelf() {
}

BasicContent& BasicContent::assign(const BasicContent& other) {
    Base::assign(other);
    mt_textCache = other.mt_textCache;
    mt_pTextValue = other.mt_pTextValue == &other.mt_textCache ? &mt_textCache : other.mt_pTextValue;
    mt_textKey = other.mt_textKey;
    setSkinName(other.getSkinName());
    return *this;
}

void ssui::BasicContent::onPrepareData() {
    if (getScene() != nullptr) {
        m_pSkin = getScene()->getSkinTemplate(getSkinName().hashCode());
        //setSkin(getScene()->getSkinTemplate(getSkinName().hashCode()));
    }
}

#pragma region "Skin"
const gstl::string& BasicContent::getSkinName() const {
    return mt_skinName;
}

void BasicContent::setSkinName(const string& value) {
    if (getScene() != nullptr) {
        if (!value.empty()) {
            setSkin(getScene()->getSkinTemplate(value.hashCode()));
        } else {
            setSkin(nullptr);
        }
    }
    mt_skinName = value;
    touchPrepareDataChanged();
}

Skin* BasicContent::getSkin() const {
    return m_pSkin;
}

void BasicContent::setSkin(Skin* value) {
    m_pSkin = value;
    touchPrepareDataChanged();
}

int BasicContent::getSkinKey() const {
    return mt_skinName.hashCode();
}

const gstl::string& BasicContent::getSkinGroupOfCurSkin() const {
    if (m_pSkin != nullptr && m_pSkin->m_pRow != nullptr && m_pSkin->m_pRow->m_pSkinGroup != nullptr) {
        return m_pSkin->m_pRow->m_pSkinGroup->getName();
    }
    return StringManager::getInstance()->mc_strNullDef;
}

void BasicContent::addBeforeSkinName(const string& skinName) {
    m_beforeSkins.push_back(skinName);
}
const string& BasicContent::getBeforeSkinName(const string& value) const {
    for (auto it = m_beforeSkins.end() - 1; it != m_beforeSkins.begin() - 1; it--) {
        if ((*it) != value) {
            return (*it);
        }
    }
    return StringManager::getInstance()->mc_strNullDef;
}
#pragma endregion

#pragma region "Text, Input"
const gstl::wstring& BasicContent::getText() const {
    if (mt_pTextValue == nullptr) {
        return StringManager::getInstance()->mc_wstrNullDef;
    } else {
        return *mt_pTextValue;
    }
}

void BasicContent::setText(const wstring& value) {
    mt_textCache = value;
    dataTextChangedFunc();
}

const gstl::wstring& BasicContent::getTextKey() const {
    return mt_textKey;
}

void BasicContent::setTextKey(const wstring& value) {
    mt_textKey = value;
    if (value.empty()) {
        mt_pTextValue = nullptr;
    } else {
//         string a = util::wstr2utf(value);
//         printf("\n key = %s",a.c_str());
        mt_pTextValue = LanguageManager::getInstance()->getWordPtr(value);
//         if (mt_pTextValue) {
//             string b = util::wstr2utf(*mt_pTextValue);
//             printf("\n value = %s",b.c_str());
//         }
        
    }
    mt_textCache.clear();
    if (mt_pTextValue == nullptr) {
        if (LanguageManager::getInstance()->getLanguage() == LanguageManager::getInstance()->mc_lang_default) {
            mt_textCache = value;
            mt_pTextValue = &mt_textCache;
        }
    }
    onShowTextChangedFunc();
}

void BasicContent::onShowTextChangedFunc() {
    if (getHost()) { 
        getHost()->TriggerEvent(ET_TextChanged, nullptr, nullptr);
    }
    if (getHost() != nullptr && getHost()->m_isAutoFrameData != 0) {
        touchMeasureChanged();
    } else {
        touchRenderChanged();
    }
}

void BasicContent::dataTextChangedFunc() {
    mt_pTextValue = &mt_textCache;
    onShowTextChangedFunc();
}

void BasicContent::setTextWithChar(const wstring::value_type& value) {
    mt_textCache.clear();
    mt_textCache.push_back(value);
    dataTextChangedFunc();
}

void BasicContent::appendDataText(const wstring& value) {
    mt_textCache.append(value);
    dataTextChangedFunc();
}

void BasicContent::appendDataText(u16 character) {
    mt_textCache.append(character);
    dataTextChangedFunc();
}

void BasicContent::backspaceDataText() {
    if (mt_textCache.size() > 0) {
        mt_textCache.pop_back();
        dataTextChangedFunc();
    }
}

const gstl::wstring* BasicContent::getShowText() const {
    return &(getText());
}

gstl::wstring* BasicContent::showText() {
    return mt_pTextValue;
}
#pragma endregion
