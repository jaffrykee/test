#include "DataInfoAttr.h"
#include "DataManager.h"
#include "AttrSetting.h"

string DataInfoAttr::s_tmpParseStr;

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(DataInfoAttr, 500000, 1000000);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(DataInfoAttr)
NODETYPE_COMMON_PART_DEFINITION_END

DataInfoAttr* DataInfoAttr::createObject(AttrType_e attrType, const wstring& wstrValue) {
    auto dataType = DataManager::getInstance()->m_arrAttrSetting[(size_t)attrType]->m_dataType;
    switch (dataType) {
    case AttrDataType_e::ADT_B2:
    {
        return createObject(attrType, wstrValue == StringManager::getInstance()->mc_wstrTrueDef ? true : false);
    }
    break;
    case AttrDataType_e::ADT_S32:
    {
        return createObject(attrType, util::atoi_s(wstrValue));
    }
    break;
    case AttrDataType_e::ADT_U32:
    {
        return createObject(attrType, (u32)util::aton_s(wstrValue, 10));
    }
    break;
    case AttrDataType_e::ADT_F32:
    {
        StringManager::wstringToString(wstrValue, s_tmpParseStr);
        return createObject(attrType, util::atof_s(s_tmpParseStr));
    }
    break;
    case AttrDataType_e::ADT_S64:
    {
        return createObject(attrType, (s64)util::aton_s(wstrValue, 10));
    }
    break;
    case AttrDataType_e::ADT_HU32:
    {
        return createObject(attrType, (u32)util::aton_s(wstrValue, 16));
    }
    break;
    case AttrDataType_e::ADT_HS64:
    {
        return createObject(attrType, (s64)util::aton_s(wstrValue, 16));
    }
    break;
    case AttrDataType_e::ADT_STR:
    {
        string* pStr = new string();
        StringManager::wstringToString(wstrValue, *pStr);
        return createObject(attrType, pStr);
    }
    break;
    case AttrDataType_e::ADT_WSTR:
    {
        return createObject(attrType, new wstring(wstrValue));
    }
    break;
    default:
        break;
    }
    return nullptr;
}
