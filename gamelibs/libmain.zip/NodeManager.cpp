#include "NodeManager.h"
#include "ObjectHeaders.h"
#include "ImageManager.h"
#include "AttrSetting.h"
#include "Json.h"
#include "GeometryManager.h"

string NodeManager::s_className = "NodeManager";
NodeManager* NodeManager::s_pInstance = nullptr;

void NodeManager::initialize() {
    BoloVM::registerEnterClass(NodeManager::getInstance(), NodeManager::getInstance()->getClassName());
    NodeManager::initScriptLib<NodeManager>();
    //NT_(.*),[/ A-Za-z:]*
    //$1::initialize();
    ObjectBase::initialize();
    Control::initialize();
    UIScene::initialize();

    UIComponent::initialize();
    BasicClip::initialize();
    BasicContent::initialize();
    BasicMeasure::initialize();
    BasicTransform::initialize();
    //Shape
    ImageShape::initialize();
    TextShape::initialize();
    ParticleShape::initialize();
    //IDrawComponent
    SimpleComponent::initialize();
    TimeContent::initialize();
    ScrollView::initialize();
    Progress::initialize();
    ProgressSlider::initialize();
    Blink::initialize();
    FlowElement::initialize();
    VirtualJoystick::initialize();
	UIDrawModel::initialize();
    //IContainerComponent
    ContainerComponent::initialize();
    Grid::initialize();
    StackPanel::initialize();
    WrapPanel::initialize();
    Para::initialize();
    AutoGrid::initialize();
    TextFlow::initialize();
    SlicedPanel::initialize();
    ImagePackage::initialize();
    //ChildItem
    ChildItem::initialize();
    GridItem::initialize();
    //IEventComponent
    ButtonBase::initialize();
    Button::initialize();
    ToggleButton::initialize();
    CheckButton::initialize();
    RadioButton::initialize();
    SkillButton::initialize();
    InputBox::initialize();

    EventNodeBase::initialize();
    EventTrigger::initialize();
    EventScript::initialize();
    EventNodeGroup::initialize();
    Timer::initialize();

    SkinGroup::initialize();
    SkinRow::initialize();
    Skin::initialize();
    ShapeGroup::initialize();

    NodeTypeSetting::initialize();
    NameSpaceSetting::initialize();
    ElementSetting::initialize();
    AttrSetting::initialize();
    DataInfoNode::initialize();
    DataInfoAttr::initialize();

    UITexture::initialize();
    UIImageBase::initialize();
    UIImageRect::initialize();
    UIImagePoly::initialize();

    MeasureData::initialize();
    Geometry::initialize();
    GeometryPoly::initialize();
    GeometryRect::initialize();
    GeometryUnionPoly::initialize();

    UIXmlConfig::initialize();
    UIKeySubject::initialize();

    DataManager::initialize();
    ImageManager::initialize();
    StringManager::initialize();
    UIManager::initialize();
    if (UIManager::getInstance()->isUeMode()) {
        UIScene::setMemory("USE_SSUI", "true");
    }

    NodeManager::getInstance()->m_isReady = true;
}

void NodeManager::destroy() {
    getInstance()->m_isReady = false;

    //initialize
    //destroy
    ObjectBase::destroy();
    Control::destroy();
    UIScene::destroy();

    UIComponent::destroy();
    BasicClip::destroy();
    BasicContent::destroy();
    BasicMeasure::destroy();
    ImageShape::destroy();
    TextShape::destroy();
    ParticleShape::destroy();
    //IDrawComponent
    SimpleComponent::destroy();
    TimeContent::destroy();
    ScrollView::destroy();
    Progress::destroy();
    ProgressSlider::destroy();
    Blink::destroy();
    FlowElement::destroy();
    VirtualJoystick::destroy();
    UIDrawModel::destroy();
    //IContainerComponent
    ContainerComponent::destroy();
    Grid::destroy();
    StackPanel::destroy();
    WrapPanel::destroy();
    Para::destroy();
    AutoGrid::destroy();
    TextFlow::destroy();
    SlicedPanel::destroy();
    ImagePackage::destroy();
    //ChildItem
    ChildItem::destroy();
    GridItem::destroy();
    //IEventComponent
    ButtonBase::destroy();
    Button::destroy();
    ToggleButton::destroy();
    CheckButton::destroy();
    RadioButton::destroy();
    SkillButton::destroy();
    InputBox::destroy();

    EventNodeBase::destroy();
    EventTrigger::destroy();
    EventScript::destroy();
    EventNodeGroup::destroy();
    Timer::destroy();

    SkinGroup::destroy();
    SkinRow::destroy();
    Skin::destroy();
    ShapeGroup::destroy();

    NodeTypeSetting::destroy();
    NameSpaceSetting::destroy();
    ElementSetting::destroy();
    AttrSetting::destroy();
    DataInfoNode::destroy();
    DataInfoAttr::destroy();

    UITexture::destroy();
    UIImageBase::destroy();
    UIImageRect::destroy();
    UIImagePoly::destroy();

    MeasureData::destroy();
    Geometry::destroy();
    GeometryPoly::destroy();
    GeometryRect::destroy();
    GeometryUnionPoly::destroy();

    UIXmlConfig::destroy();
    UIKeySubject::destroy();

    DataManager::destroy();
    ImageManager::destroy();
    UIManager::destroy();
    safe_delete(s_pInstance);
}

void NodeManager::registerReflection(int id) {
    //registerFunc(id, "loadUI", bolo_ui_loadUI, "(UIScene*)loadUI(string name)");
}

void NodeManager::createFast() {
    UIScene::closeAllScene();
    SkinGroup::clearCache();
    DataManager::getInstance()->clearCache();
    ImageManager::initialize();
}

void NodeManager::onDraw() {
    UIScene::updateUIIsDraw();
    for (auto& pScene : UIScene::s_arrScene) {
        if (pScene->m_pRootControl) {
            pScene->m_pRootControl->onDraw(1);
        }
    }
}

void NodeManager::onShow() {
    m_showCacheVpct.clear();
    m_showCacheTexture = nullptr;
    m_lastGrayValue = 0.0f;
    if (UIManager::getInstance()->isUeMode()) {
#ifdef _WIN32
        m_curOutLine.clear();
        if (UIManager::getInstance()->m_pCurSsueControl != nullptr && UIManager::getInstance()->m_isShowOutLine) {
            UIManager::getInstance()->m_pCurSsueControl->appendOutline(m_curOutLine);
        }
        m_curBackArea.clear();
        m_curBackArea.push_back(vec3(0.f, 0.f, 0.f));
        m_curBackArea.push_back(vec3(Graphics::screen().x, 0.f, 0.f));
        m_curBackArea.push_back(vec3(Graphics::screen().x, Graphics::screen().y, 0.f));
        m_curBackArea.push_back(vec3(0.f, 0.f, 0.f));
        m_curBackArea.push_back(vec3(Graphics::screen().x, Graphics::screen().y, 0.f));
        m_curBackArea.push_back(vec3(0.f, Graphics::screen().y, 0.f));
        Graphics::drawGraphic(m_curBackArea, m_backColor, RenderMode::triangles);
#endif
    }
    for (auto& pScene : UIScene::s_arrScene) {
        if (pScene->m_pRootControl) {
            pScene->m_pRootControl->onShow();
        }
    }
    pushShow();
    if (UIManager::getInstance()->isUeMode()) {
#ifdef _WIN32
        m_allBorder.clear();
        if (UIManager::getInstance()->m_isShowBorder == true) {
            for (auto& pScene : UIScene::s_arrScene) {
                if (pScene->m_pRootControl != nullptr) {
                    pScene->m_pRootControl->appendOutlineForeach(m_allBorder);
                }
            }
            if (!m_allBorder.empty()) {
                for (auto& poly : m_allBorder) {
                    poly.reverse(poly.begin(), poly.end());
                    Graphics::drawGraphic(poly, m_borderColor, RenderMode::lineLoop, m_borderWidth);
                }
            }
        }
        if (!m_curOutLine.empty()) {
            m_curOutLine.reverse(m_curOutLine.begin(), m_curOutLine.end());
            Graphics::drawGraphic(m_curOutLine, m_outLineColor, RenderMode::lineLoop, m_outLineWidth);
        }
#endif
    }
    m_showCacheVpct.clear();
    m_showCacheTexture = nullptr;
    m_lastGrayValue = 0.0f;
}

void ssui::NodeManager::pushShow() {
    if (m_showCacheTexture == nullptr || m_showCacheTexture.getIsLoadingReady() == false || m_showCacheVpct.empty()) {
        return;
    }
    auto model = Graphics::getMesh();
    auto pSource = model->mesh().source();
    auto pUiMesh = (UIMesh*)pSource;
    pUiMesh->setVertexSize(m_showCacheVpct.size());
    int vi = 0;
    if (UIManager::getInstance()->m_isImageSnapToPixel == true) {
        for (auto vpct : m_showCacheVpct) {
            vpct.position.x = Math::round(vpct.position.x);
            vpct.position.y = Math::round(vpct.position.y);
            pUiMesh->setVertex(vi, vpct.position);
            pUiMesh->setColor(vi, vpct.color);
            //pUiMesh->setUV(vi, { vpct.texCoord.x, 1 - vpct.texCoord.y });
            pUiMesh->setUV(vi, { vpct.texCoord.x, vpct.texCoord.y });
            vi++;
        }
    } else {
        for (auto vpct : m_showCacheVpct) {
            pUiMesh->setVertex(vi, vpct.position);
            pUiMesh->setColor(vi, vpct.color);
            //pUiMesh->setUV(vi, { vpct.texCoord.x, 1 - vpct.texCoord.y });
            pUiMesh->setUV(vi, { vpct.texCoord.x, vpct.texCoord.y });
            vi++;
        }
    }
    Graphics::setGrayLevel(m_lastGrayValue);
//    printf("%d texturename = %s\n",m_showCacheTexture.source()->status,m_showCacheTexture.source()->name().c_str());
//    if (m_showCacheTexture.source()->status!=ss2::TextureSource::needGen) {
//        printf("this is needgen %d texturename = %s \n",m_showCacheTexture.source()->status,m_showCacheTexture.source()->name().c_str());
//    }
    Graphics::drawImage(m_showCacheTexture, model);
    Graphics::setGrayLevel(0.0f);
}

void NodeManager::showObjectCount() {
    int tmpSize, tmpCount, tmpMem, tmpRpCount, tmpRpMem, tmpTrueCount, tmpTrueMem;
    string tmpOutMem, tmpOutRpMem, tmpOutTrueMem;
    int totalCount = 0, totalMem = 0, totalRpCount = 0, totalRpMem = 0, totalTrueCount = 0, totalTrueMem = 0;
    LogPrintf("=============================================================================", 1);
    LogPrintf("===============================showObjectCount===============================", 1);
    LogPrintf("=============================================================================", 1);
    LogPrintf("size\tcount\tmem\trpCount\trpMem\ttCount\ttMem\tname\t", 1);
    for (auto& pairTestData : m_mapClassTestData) {
        tmpSize = (*pairTestData.second.m_pFuncGetSizeObject)();
        tmpCount = (*pairTestData.second.m_pFuncGetCountObject)();
        tmpMem = tmpCount * tmpSize;
        StringManager::getMemStringFromByteNum(tmpOutMem, tmpMem);
        tmpRpCount = (*pairTestData.second.m_pFuncGetResPoolCount)();
        tmpRpMem = tmpRpCount * tmpSize;
        StringManager::getMemStringFromByteNum(tmpOutRpMem, tmpRpMem);
        tmpTrueCount = tmpCount > tmpRpCount ? tmpCount : tmpRpCount;
        tmpTrueMem = tmpMem > tmpRpMem ? tmpMem : tmpRpMem;
        StringManager::getMemStringFromByteNum(tmpOutTrueMem, tmpTrueMem);
        if (tmpCount != 0 || tmpRpCount != 0) {
            //printlog("%8d\t%s\n", tmpCount, pairTestData.first.c_str());
            LogPrintf("%d\t%d\t%s\t%d\t%s\t%d\t%s\t%s", 1, tmpSize, tmpCount, tmpOutMem.c_str(),
                tmpRpCount, tmpOutRpMem.c_str(), tmpTrueCount, tmpOutTrueMem.c_str(), pairTestData.first.c_str());
            totalCount += tmpCount;
            totalMem += tmpMem;
            totalRpCount += tmpRpCount;
            totalRpMem += tmpRpMem;
            totalTrueCount += tmpTrueCount;
            totalTrueMem += tmpTrueMem;
        }
    }
    StringManager::getMemStringFromByteNum(tmpOutMem, totalMem);
    StringManager::getMemStringFromByteNum(tmpOutRpMem, totalRpMem);
    StringManager::getMemStringFromByteNum(tmpOutTrueMem, totalTrueMem);
    LogPrintf("\t%d\t%s\t%d\t%s\t%d\t%s\t<Total>", 1, totalCount, tmpOutMem.c_str(), totalRpCount, tmpOutRpMem.c_str(),
        totalTrueCount, tmpOutTrueMem.c_str());
}

void NodeManager::setTheme(const string& value) {
    if (m_curTheme != value) {
        onLanguageThemeChanged();
    }
}

void NodeManager::onLanguageThemeChanged() {
    SkinGroup::refreshAllCurSkin();
    for (auto& pScene : UIScene::s_arrScene) {
        pScene->TriggerEvent(ET_LanguageThemeChanged, nullptr, nullptr);
    }
}
