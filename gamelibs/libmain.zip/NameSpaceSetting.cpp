#include "NameSpaceSetting.h"
#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(NameSpaceSetting, 5, 15);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(NameSpaceSetting)
NODETYPE_COMMON_PART_DEFINITION_END

void NameSpaceSetting::disposeSelf() {
    for (const auto& pairEs : m_lmapElementSetting) {
        pairEs.second->releaseObject();
    }
    m_lmapElementSetting.clear();
}

void ssui::NameSpaceSetting::parseXmlConfigXml(const string& fileName, XmlParser& parser) {
    const auto& pairEs = m_lmapElementSetting.find(m_name.hashCode());
    if (pairEs != m_lmapElementSetting.end()) {
        const auto& pEs = pairEs->second;
        auto pInfoNode = pEs->parseXml(parser);
        if (DataManager::getInstance()->m_xmlConfigTemplate) {
            DataManager::getInstance()->m_xmlConfigTemplate->releaseObject();
        }
        DataManager::getInstance()->m_xmlConfigTemplate = pInfoNode;
    }
}

void ssui::NameSpaceSetting::parseUITextureXml(const string& fileName, XmlParser& parser) {
    const auto& pairEs = m_lmapElementSetting.find(m_name.hashCode());
    if (pairEs != m_lmapElementSetting.end()) {
        const auto& pEs = pairEs->second;
        auto pInfoNode = pEs->parseXml(parser);
        auto& mapIt = DataManager::getInstance()->m_mapImageTemplate;
        const auto& pairIt = mapIt.find(fileName);
        if (pairIt != mapIt.end()) {
            pairIt->second->releaseObject();
            pairIt->second = pInfoNode;
        } else {
            mapIt.insert(fileName, pInfoNode);
        }
    }
}

void ssui::NameSpaceSetting::parseSSUIXml(const string& fileName, XmlParser& parser) {
    const auto& pairEs = m_lmapElementSetting.find(m_name.hashCode());
    if (pairEs != m_lmapElementSetting.end()) {
        const auto& pEs = pairEs->second;
        auto pInfoNode = pEs->parseXml(parser);
        auto& mapSt = DataManager::getInstance()->m_mapSceneTemplate;
        const auto& pairSt = mapSt.find(fileName);
        if (pairSt != mapSt.end()) {
            pairSt->second->releaseObject();
            pairSt->second = pInfoNode;
        } else {
            mapSt.insert(fileName, pInfoNode);
        }
    }
}

void ssui::NameSpaceSetting::addEsToEs(const wstring& parent, const wstring& child) {
    m_lmapElementSetting[parent.hashCode()]->addChild(m_lmapElementSetting[child.hashCode()]);
}

void ssui::NameSpaceSetting::addElementSetting(ElementSetting* pXe) {
    m_lmapElementSetting.insert(pXe->m_name.hashCode(), pXe);
}
