#include "BasicTransform.h"
#include "Control.h"
#include "GeometryManager.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(BasicTransform, CONTROL_RESPOOLINIT, CONTROL_RESPOOLLIMIT);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("upSideDown", UpSideDown, BasicTransform, B2);
NODEBASE_ATTR_REGISTER("mirror", Mirror, BasicTransform, B2);
NODEBASE_ATTR_REGISTER("alpha", Alpha, BasicTransform, F32);
NODEBASE_ATTR_REGISTER("radian", Radian, BasicTransform, S32);
NODEBASE_ATTR_REGISTER("scaleX", ScaleX, BasicTransform, S32);
NODEBASE_ATTR_REGISTER("scaleY", ScaleY, BasicTransform, S32);
NODEBASE_ATTR_REGISTER("offsetX", OffsetX, BasicTransform, S32);
NODEBASE_ATTR_REGISTER("offsetY", OffsetY, BasicTransform, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(BasicTransform)
NBSCRIPT_ATTR_REGISTER("upSideDown", UpSideDown, BasicTransform, B2);
NBSCRIPT_ATTR_REGISTER("mirror", Mirror, BasicTransform, B2);
NBSCRIPT_ATTR_REGISTER("alpha", Alpha, BasicTransform, F32);
NBSCRIPT_ATTR_REGISTER("radian", Radian, BasicTransform, S32);
NBSCRIPT_ATTR_REGISTER("scaleX", ScaleX, BasicTransform, S32);
NBSCRIPT_ATTR_REGISTER("scaleY", ScaleY, BasicTransform, S32);
NBSCRIPT_ATTR_REGISTER("offsetX", OffsetX, BasicTransform, S32);
NBSCRIPT_ATTR_REGISTER("offsetY", OffsetY, BasicTransform, S32);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(BasicTransform, Alpha, ft)
UIComponent_ControlAttr_Def(BasicTransform, UpSideDown, bool)
UIComponent_ControlAttr_Def(BasicTransform, Mirror, bool)
UIComponent_ControlAttr_Def(BasicTransform, Radian, ft)
UIComponent_ControlAttr_Def(BasicTransform, ScaleX, ft)
UIComponent_ControlAttr_Def(BasicTransform, ScaleY, ft)
UIComponent_ControlAttr_Def(BasicTransform, OffsetX, ft)
UIComponent_ControlAttr_Def(BasicTransform, OffsetY, ft)
#pragma endregion

float ssui::BasicTransform::getAlpha() const {
    return mt_alpha;
}

void ssui::BasicTransform::setAlpha(float value) {
    if (!math::equal(mt_alpha, value)) {
        mt_alpha = value;
        getHost()->touchRenderChanged();
    }
    m_isSetting = true;
}

b2 ssui::BasicTransform::getUpSideDown() const {
    return mt_upSideDown;
}

void ssui::BasicTransform::setUpSideDown(b2 value) {
    if (mt_upSideDown != value) {
        mt_upSideDown = value;
        getHost()->touchRenderChanged();
    }
    m_isSetting = true;
}

b2 ssui::BasicTransform::getMirror() const {
    return mt_mirror;
}

void ssui::BasicTransform::setMirror(b2 value) {
    if (mt_mirror != value) {
        mt_mirror = value;
        getHost()->touchRenderChanged();
    }
    m_isSetting = true;
}

s32 ssui::BasicTransform::getRadian() const {
    return mt_radian;
}

void ssui::BasicTransform::setRadian(s32 value) {
    if (mt_radian != value) {
        mt_radian = value;
        getHost()->touchRenderChanged();
    }
    m_isSetting = true;
}

s32 ssui::BasicTransform::getScaleX() const {
    return mt_scaleX;
}
void ssui::BasicTransform::setScaleX(s32 value) {
    if (mt_scaleX != value) {
        mt_scaleX = value;
        getHost()->touchRenderChanged();
    }
    m_isSetting = true;
}

s32 ssui::BasicTransform::getScaleY() const {
    return mt_scaleY;
}
void ssui::BasicTransform::setScaleY(s32 value) {
    if (mt_scaleY != value) {
        mt_scaleY = value;
        getHost()->touchRenderChanged();
    }
    m_isSetting = true;
}

s32 ssui::BasicTransform::getOffsetX() const {
    return mt_offsetX;
}
void ssui::BasicTransform::setOffsetX(s32 value) {
    if (mt_offsetX != value) {
        mt_offsetX = value;
        getHost()->touchRenderChanged();
    }
    m_isSetting = true;
}

s32 ssui::BasicTransform::getOffsetY() const {
    return mt_offsetY;
}
void ssui::BasicTransform::setOffsetY(s32 value) {
    if (mt_offsetY != value) {
        mt_offsetY = value;
        getHost()->touchRenderChanged();
    }
    m_isSetting = true;
}

void ssui::BasicTransform::disposeSelf() {
}

BasicTransform& ssui::BasicTransform::assign(const BasicTransform& other) {
    Base::assign(other);
    mt_upSideDown = other.mt_upSideDown;
    mt_mirror = other.mt_mirror;
    mt_alpha = other.mt_alpha;
    mt_radian = other.mt_radian;
    mt_scaleX = other.mt_scaleX;
    mt_scaleY = other.mt_scaleY;
    mt_offsetY = other.mt_offsetY;
    mt_offsetY = other.mt_offsetY;
    m_isSetting = other.m_isSetting;
    return *this;
}

void ssui::BasicTransform::applyTransform(Control* control, s32 offsetX, s32 offsetY, s32 scaleX, s32 scaleY, s32 radian, f32 alpha) {
    ft cx, cy;
    control->getCenter(cx, cy);

    //const Border& border = control->getParentArea();
    //ft width = border.width();
    //ft height = border.height();

    ft fixedCX = cx + offsetX;
    ft fixedCY = cy + offsetY;

    applyChildTransformPolyImage(control, fixedCX, fixedCY, SSUIMath::restorePct(scaleX), SSUIMath::restorePct(scaleY), (ft)radian, alpha);
}

void ssui::BasicTransform::onTransform(unsigned char drawStep) {
    if (!getHost() || m_isSetting == false) {
        return;
    }

    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
        auto& e = *it;
        if (e.size() == 4) {
            if (mt_upSideDown) {
                algo::swap(e[0].texCoord.y, e[2].texCoord.y);
                algo::swap(e[1].texCoord.y, e[3].texCoord.y);
            }

            if (mt_mirror) {
                algo::swap(e[0].texCoord.x, e[2].texCoord.x);
                algo::swap(e[1].texCoord.x, e[3].texCoord.x);
            }
        }
    }

    applyTransform(getHost(), getOffsetX(), getOffsetY(), getScaleX(), getScaleY(), getRadian(), getAlpha());
}

void ssui::BasicTransform::applyTransformToPosterity(Control* pPosterity) {
    //auto& parentArea = getHost()->getParentArea();
    //auto x = parentArea.m_left;
    //auto y = parentArea.m_top;
    //if (math::equalZero(x, 0.01f) && math::equalZero(y, 0.01f)) {
    //    return;
    //}

    if (getScaleX() != 1.0)
    {
        int k = 0;
    }
//    applyTransform(pPosterity, getOffsetX(), getOffsetY(), getScaleX(), getScaleY(), getRadian());

    //ft offsetX = pPosterity->getBasicTransform()->getOffsetX();
    //ft offsetY = pPosterity->getBasicTransform()->getOffsetY();
    //ft scaleX = pPosterity->getBasicTransform()->getScaleX();
    //ft scaleY = pPosterity->getBasicTransform()->getScaleY();
    //ft radian = pPosterity->getBasicTransform()->getRadian();
    //applyTransform(pPosterity, offsetX, offsetY, scaleX, scaleY, radian);
}

void ssui::BasicTransform::onRender(unsigned char drawStep) {

}
