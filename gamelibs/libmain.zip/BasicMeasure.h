#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class MeasureData;
class BasicMeasure : public UIComponent {
//    friend class BasicMeasure;
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(BasicMeasure);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(BasicMeasure, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
protected:
    //Absolute
    ft m_ax = 0.f;
    ft m_ay = 0.f;
    ft m_aw = 0.f;
    ft m_ah = 0.f;
    //Relative
    union {
        struct {
            pct m_rx;
            pct m_ry;
            pct m_rw;
            pct m_rh;
        };
        unsigned long long m_relativeData = 0;
    };
    //AutoSize
    union {
        struct {
            bool m_isAutoWidth : 1;
            bool m_isAutoHeight : 1;
        };
        unsigned char m_isAuto = 0;
    };
    //AbsoluteCheck
    union {
        struct {
            u16 m_minAw;
            u16 m_minAh;
        };
        unsigned int m_absoluteMinCheckData = 0;
    };
    union {
        struct {
            u16 m_maxAw;
            u16 m_maxAh;
        };
        unsigned int m_absoluteMaxCheckData = UINT_MAX;
    };
    //RelativeCheck
    union {
        struct {
            pct m_minRw;
            pct m_minRh;
        };
        unsigned long long m_relativeMinCheckData = 0;
    };
    union {
        struct {
            pct m_maxRw;
            pct m_maxRh;
        };
        unsigned long long m_relativeMaxCheckData = UINT_MAX;
    };
    //Anchor
    union {
        struct {
            pct m_anchorRx;
            pct m_anchorRy;
        };
        unsigned int m_anchorData = 0;
    };
    //AbsoluteMargin
    union {
        struct {
            s16 m_aml;
            s16 m_amt;
            s16 m_amr;
            s16 m_amb;
        };
        unsigned long long m_absoluteMarginData = 0;
    };
    //RelativeMargin
    //̫���ӣ���֧��
//     union {
//         struct {
//             pct m_rml;
//             pct m_rmt;
//             pct m_rmr;
//             pct m_rmb;
//         };
//         unsigned long long m_relativeMarginData = 0;
//     };
    //AbsolutePadding
    union {
        struct {
            s16 m_apl;
            s16 m_apt;
            s16 m_apr;
            s16 m_apb;
        };
        unsigned long long m_absolutePaddingData = 0;
    };
    //RelativePadding
    //̫���ӣ���֧��
//     union {
//         struct {
//             pct m_rpl;
//             pct m_rpt;
//             pct m_rpr;
//             pct m_rpb;
//         };
//         unsigned long long m_relativePaddingData = 0;
//     };
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    //Absolute
    ft getAx() const;
    void setAx(ft value);
    ft getAy() const;
    void setAy(ft value);
    ft getAw() const;
    void setAw(ft value);
    ft getAh() const;
    void setAh(ft value);
    //Relative
    int getRx() const;
    void setRx(int value);
    int getRy() const;
    void setRy(int value);
    int getRw() const;
    void setRw(int value);
    int getRh() const;
    void setRh(int value);
    //AutoSize
    bool getIsAutoWidth() const;
    void setIsAutoWidth(bool value);
    bool getIsAutoHeight() const;
    void setIsAutoHeight(bool value);
    //AbsoluteCheck
    int getMinAw() const;
    void setMinAw(int value);
    int getMinAh() const;
    void setMinAh(int value);
    int getMaxAw() const;
    void setMaxAw(int value);
    int getMaxAh() const;
    void setMaxAh(int value);
    //RelativeCheck
    int getMinRw() const;
    void setMinRw(int value);
    int getMinRh() const;
    void setMinRh(int value);
    int getMaxRw() const;
    void setMaxRw(int value);
    int getMaxRh() const;
    void setMaxRh(int value);
    //Anchor
    int getAnchorRx() const;
    void setAnchorRx(int value);
    int getAnchorRy() const;
    void setAnchorRy(int value);
    //AbsoluteMargin
    int getAbsoluteMarginLeft() const;
    void setAbsoluteMarginLeft(int value);
    int getAbsoluteMarginTop() const;
    void setAbsoluteMarginTop(int value);
    int getAbsoluteMarginRight() const;
    void setAbsoluteMarginRight(int value);
    int getAbsoluteMarginBottom() const;
    void setAbsoluteMarginBottom(int value);
    //AbsolutePadding
    int getAbsolutePaddingLeft() const;
    void setAbsolutePaddingLeft(int value);
    int getAbsolutePaddingTop() const;
    void setAbsolutePaddingTop(int value);
    int getAbsolutePaddingRight() const;
    void setAbsolutePaddingRight(int value);
    int getAbsolutePaddingBottom() const;
    void setAbsolutePaddingBottom(int value);
#pragma endregion "���Է���"
public:
    bool isAbsoluteCheckDataChanged();
    bool isRelativeCheckDataChanged();
public:
    BasicMeasure& assign(const BasicMeasure& other);
    virtual void onPrepareData() override;
    virtual void onMeasure(unsigned char drawStep) override;
    virtual void onTransform(unsigned char drawStep) override;
    virtual void applyTransformToPosterity(Control* pPosterity) override;
#pragma endregion
};

_SSUINamespaceEnd
