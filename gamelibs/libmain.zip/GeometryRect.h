#pragma once
#include "Geometry.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class RenderCacheImage;
class GeometryRect : public Geometry {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(GeometryRect);
protected:
    inline virtual void createSelf() override {}
    inline virtual void disposeSelf() override {}
    NODETYPE_COMMON_PART_DECLARATION_END(GeometryRect, Geometry);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
public:
    static GeometryRect* createObject(const Border& aabb);
#pragma endregion

#pragma region "��Ա"
public:
    Border m_aabb;
#pragma endregion

#pragma region "����"
public:
    GeometryRect& assign(const GeometryRect& other);
    virtual bool isIn(ft x, ft y) override;
    virtual void appendOutline(Poly& poly) override;
    virtual void getCenter(ft& cx, ft& cy) const override;
    virtual void getBorder(Border& aabb) const override;
    virtual void transformPosition(ft x, ft y) override;
#pragma endregion
};

_SSUINamespaceEnd
