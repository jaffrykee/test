#pragma once
#include "ObjectBase.h"
#include "SkinGroup.h"
#include "SkinRow.h"
#include "ShapeGroup.h"
#include "TextShape.h"
#include "DataInfoNode.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class EventNodeGroup;
class UIScene : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UIScene);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(UIScene, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static HashMap<wstring, wstring> memory;
    static HashMap<wstring, wstring> auctionMemory;

    static ArrayList<UIScene*> s_arrScene;
    static UIScene* s_curUIScene;
    static b2 isChangeCurScene;
    static int LogPriority;
    static bool logCSV;
    static bool s_isParsing;
public:
    static string Public_loaded_script;              //����ui����ʱ����ִ�еĽű�
    static string Public_closed_script;             //����ui�ر�ʱ����ִ�еĽű�
#pragma endregion

#pragma region "��̬����"
public:
    static UIScene* createScene(const string& name);
    static UIScene* createScene(const string& name, DataInfoNode& data);

    static b2 setCurScene(UIScene* bus);
    static void rankScenes(ArrayList<UIScene*>& scns);
    static void updateCurScene();
    static b2 getIsChangeCurScene();
    static void setIsChangeCurScene(b2 is);
    static void updateUIIsDraw();
    static UIScene* getCurScene();
    static void closeScene(const string& name);
    static void closeAllScene();
    static void destroyFunc();
    static UIScene* setFocus(const string& name);

    static wstring getMemory(const wstring& key);
    static void setMemory(const wstring& key, const wstring& value);
    static wstring getAuctionMemory(const wstring& key);
#pragma endregion

#pragma region "��Ա"
public:
    string mt_name;
    //�ڵ�id������
    HashMap<strHash, Control*> m_mapIdNode;
    Control* m_pRootControl = nullptr;
protected:
    SkinGroup* m_pSelfSkinGroup = nullptr;
    HashMap<int, int> m_mapSkinGroup;
public:
    s32 m_priority = 50;
    b2 m_nonEvent = false;
    string m_curImportUIName = "";
    HashMap<string, string> m_mapImportUIName;

    b2 m_canClose = true;
    b2 m_closeWhenCheck = true;
    b2 m_isFloatUI = false;
    b2 m_canBeMaskByDraw = true;
    b2 m_canEnableMaskByDraw = true;
    b2 m_canEnableMaskByDrawForce = false;
    b2 m_isOwnEvent = true;
    b2 m_isEnable = true;    //�ڰ�����ʹ��
    b2 m_visible = true;
    b2 m_isCanBeCurScene = true;
private:
    EventNodeGroup* mt_pDataEventGroup = nullptr;
#pragma endregion

#pragma region "����"
public:
    bool getIsVisible() const {
        return m_visible;
    }
    void setDataIsVisible(bool value) {
        m_visible = value;
    }
public:
    const string& getName() const;
public:
    void initScene();
    void setEnable(b2 _enable);
    b2 isEnable();
    b2 checkEnable();

    SkinGroup* getSelfSkinGroup() const;
    TextShape* getStringBoardDataFromSkin(const string& value);
    Skin* getSkinTemplate(int key) const;
    void setSelfSkinGroup(SkinGroup* pValue);
    int addSkinGroupQuote(const string& skinGroupName);

    void loadImportXml(const string& xmlName);
    void deleteImportXml(const string& xmlName);
    void deleteAllImportXml();

    void setCurImportUIName(const string& value);
    const string& getCurImportUIName() const;

    void setUIVisible(b2 isVis);
    void setRootCtrlVisible(b2 isVis);
    b2 getUIVisible();

    s32 getPriority() const;
    void setPriority(s32 pri);
    b2 getIsNonEvent() const;
    void setIsNonEvent(b2 is);

    b2 getDataCanClose() const;
    void setDataCanClose(b2 value);

    b2 getDataIsCloseWhenCheck() const;
    void setDataIsCloseWhenCheck(b2 value);

    b2 getDataIsFloatUI() const;
    void setDataIsFloatUI(b2 value);

    b2 getDataCanBeMask() const;
    void setDataCanBeMask(b2 value);

    b2 getDataCanEnableMask() const;
    void setDataCanEnableMask(b2 value);

    b2 getDataCanEnableMaskForce() const;
    void setDataCanEnableMaskForce(b2 value);

    b2 getDataIsOwnEvent() const;
    void setDataIsOwnEvent(b2 value);

    b2 getDataIsCanBeCurScene() const;
    void setDataIsCanBeCurScene(b2 value);
public:
    UIScene& assign(const UIScene& other);
    virtual void onEvent(SSUIEvent& event) override;
public:
    virtual int addDataChild(DataInfoNode& childData) override;
    void setRootControl(Control* pCtrl);
    void addImportControl(Control* pCtrl);
    void setOtherData();
    Control* getControlWithId(const string& id);
    Control* getControlWithIdW(const wstring& id);
    Control* copyAndAddToWithId(const string& id,const string& copyID, const string& parentID);
    Control* copyAndAddToFunc(const string& nId, Control* copyAim, Control* addToParent, UIScene* addToScene, bool isCheckId = true);
    void updateCopyID(Control* con);
    void updateCopyControlID(Control* con, const string& copyid);
public:
    int parseCsvRow(const wstring& csvRow, ArrayList<Control*>& cannotRemoveAddControl);
    int parseCsvWordList(Control *& ctrl, ArrayList<wstring>* pWordList, ArrayList<Control*>& cannotRemoveAddControl);
    int getRowIndexByAttrType(const wstring& csvRow, CsvAttrType_e type);
    wstring CSVtoLogStr(ArrayList<wstring>* pWordList);
public:
    EventNodeGroup* getEventNodeGroup() const;
    void setControlScript(EventType_e type, const wstring& scriptStr, bool isClear);
    void setControlScript(const string& type, const wstring& scriptStr, bool isClear);
#pragma endregion
public:
    virtual void debugString(string& outString) override;
};

_SSUINamespaceEnd
