#pragma once
#include "SimpleComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class FlowElement : public SimpleComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(FlowElement);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(FlowElement, SimpleComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    u8 m_curSlot = 0xff;
    u8 m_curState = 0xff;
    b2 m_isTouchComp = false;
    s32 m_lineNo = -1;    //�ڵڼ���
#pragma endregion

#pragma region "����"
public:
    Self& assign(const Self& other);
    virtual const ArrayList<SlotType_e>& getSlotList() const override;
public:
    void setLineNo(s32 value);
    s32 getLineNo() const;
    void setIsTouchComponent(b2 value);
    virtual bool isTouchComponent() const;
    virtual void onEvent(SSUIEvent& event) override;
#pragma endregion
};

_SSUINamespaceEnd
