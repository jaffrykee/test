#pragma once
#include "ObjectBase.h"
#include "UIManager.h"
#include "Bolo.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class EventTrigger : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(EventTrigger);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(EventTrigger, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
public:
    inline EventTrigger& assign(const EventTrigger& other) {
        Base::assign(other);
        return *this;
    }
    inline virtual void onTrigger(ObjectBase* pObj) {
    }
#pragma endregion
};

_SSUINamespaceEnd
