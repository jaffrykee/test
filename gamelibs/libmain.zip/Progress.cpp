#include "Progress.h"
#include "Control.h"
#include "GeometryManager.h"
#include "GeometryRect.h"
#include "GeometryPoly.h"
#include "GeometryUnionPoly.h"
#include "Timer.h"
#include "UIScene.h"
#include "BasicClip.h"
#include "ProgressSlider.h"

#include "DataHeaders.h"

gstl::wstring ssui::Progress::s_tmpProgressDirectionCmdData;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Progress, 50, 100);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("minValue", MinValue, Progress, F32);
NODEBASE_ATTR_REGISTER("maxValue", MaxValue, Progress, F32);
NODEBASE_ATTR_REGISTER("curValue", CurValue, Progress, F32);
NODEBASE_ATTR_REGISTER("progDirection", ProgressDirection, Progress, S32, s_tmpProgressDirectionCmdData, true);
NODEBASE_ATTR_REGISTER("changedRate", ChangedRate, Progress, F32);
NODEBASE_ATTR_REGISTER("changedSpeed", ChangedSpeed, Progress, F32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(Progress)
NBSCRIPT_ATTR_REGISTER("minValue", MinValue, Progress, F32);
NBSCRIPT_ATTR_REGISTER("maxValue", MaxValue, Progress, F32);
NBSCRIPT_ATTR_REGISTER("curValue", CurValue, Progress, F32);
NBSCRIPT_ATTR_REGISTER("progDirection", ProgressDirection, Progress, S32);
NBSCRIPT_ATTR_REGISTER("changedRate", ChangedRate, Progress, F32);
NBSCRIPT_ATTR_REGISTER("changedSpeed", ChangedSpeed, Progress, F32);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(Progress, MinValue, ft)
UIComponent_ControlAttr_Def(Progress, MaxValue, ft)
UIComponent_ControlAttr_Def(Progress, CurValue, ft)
UIComponent_ControlAttr_Def(Progress, ProgressDirection, int)
UIComponent_ControlAttr_Def(Progress, ChangedRate, ft)
UIComponent_ControlAttr_Def(Progress, ChangedSpeed, ft)
#pragma endregion

void ssui::Progress::createSelf() {
}

void ssui::Progress::disposeSelf() {
}

float ssui::Progress::getMinValue() const {
    return m_minValue;
}

void ssui::Progress::setMinValue(float value) {
    m_minValue = value;
    if (UIScene::s_isParsing == false) {
        rebuild();
    }
}

float ssui::Progress::getMaxValue() const {
    return m_maxValue;
}

void ssui::Progress::setMaxValue(float value) {
    m_maxValue = value;
    if (UIScene::s_isParsing == false) {
        rebuild();
    }
}

float ssui::Progress::getCurValue() const {
    return m_curValue;
}

void ssui::Progress::setCurValue(float value) {
    m_curValue = value;
    if (UIScene::s_isParsing == true) {
        m_showValue = m_curValue;
    } else {
        rebuild();
    }
}

int ssui::Progress::getProgressDirection() const {
    return m_direction;
}

void ssui::Progress::setProgressDirection(int value) {
    m_direction = (ProgressDirection_e)value;
    if (UIScene::s_isParsing == false) {
        rebuild();
    }
}

float ssui::Progress::getChangedRate() const {
    return m_changedRate;
}

void ssui::Progress::setChangedRate(float value) {
    m_changedRate = value;
    if (UIScene::s_isParsing == false) {
        rebuild();
    }
}

float ssui::Progress::getChangedSpeed() const {
    return m_changedSpeed;
}

void ssui::Progress::setChangedSpeed(float value) {
    m_changedSpeed = value;
    if (UIScene::s_isParsing == false) {
        rebuild();
    }
}

Progress& ssui::Progress::assign(const Self& other) {
    Base::assign(other);
    m_minValue = other.m_minValue;
    m_maxValue = other.m_maxValue;
    m_curValue = other.m_curValue;
    m_showValue = m_curValue;
    m_direction = other.m_direction;
    m_changedSpeed = other.m_changedSpeed;
    m_changedRate = other.m_changedRate;
    if (getHost()) {
        getHost()->touchRenderChanged();
    }
    return *this;
}

ssui::ParentAreaType_e ssui::Progress::getParentAreaType() const {
    return PAT_inner;
}

const ArrayList<SlotType_e>& ssui::Progress::getSlotList() const {
    return getSlotListDef(SLOT_progFill);
}

void ssui::Progress::onPrepareData() {
    Base::onPrepareData();
    rebuild();
}

void ssui::Progress::onRender(unsigned char drawStep) {
    Base::onRender(drawStep);
    auto& area = getHost()->getInnerMeasure().m_srcArea;
    switch (m_direction) {
        case ssui::PROG_DRC_lr:
        case ssui::PROG_DRC_rl:
        {
            m_lastAreaLen = area.width();
        }
        break;
        case ssui::PROG_DRC_tb:
        case ssui::PROG_DRC_bt:
        {
            m_lastAreaLen = area.height();
        }
        break;
        default:
            break;
    }
}

void ssui::Progress::onClip(unsigned char drawStep) {
    if (m_isRect) {
        m_clipArea = getHost()->getInnerMeasure().m_srcArea;
        float per = getValuePercent();
        switch (m_direction) {
            case ssui::PROG_DRC_lr:
            {
                auto w = m_clipArea.width();
                auto pw = per * w;
                m_clipArea.m_right = m_clipArea.m_left + pw;
            }
            break;
            case ssui::PROG_DRC_rl:
            {
                auto w = m_clipArea.width();
                auto pw = per * w;
                m_clipArea.m_left = m_clipArea.m_right - pw;
            }
            break;
            case ssui::PROG_DRC_tb:
            {
                auto h = m_clipArea.height();
                auto ph = per * h;
                m_clipArea.m_bottom = m_clipArea.m_top + ph;
            }
            break;
            case ssui::PROG_DRC_bt:
            {
                auto h = m_clipArea.height();
                auto ph = per * h;
                m_clipArea.m_top = m_clipArea.m_bottom - ph;
            }
            break;
            default:
                break;
        }
        for (auto& pChild : *this) {
            applyClipToSelfChildGrandChildAndSoOn(pChild, m_clipArea);
        }
    }
}

void ssui::Progress::applyClipToPosterity(Control* pPosterity) {
    if (m_isRect && pPosterity != getHost()) {
        applyClipToSelfChildGrandChildAndSoOn(pPosterity, m_clipArea);
    }
}

bool ssui::Progress::isTouchComponent() const {
    return true;
}

float ssui::Progress::getValuePercent() const {
    float per = (m_showValue - m_minValue) / (m_maxValue - m_minValue);
    if (per > 1) {
        per = 1;
    } else if (per < 0) {
        per = 0;
    }
    return per;
}

void ssui::Progress::setCurPercent(float value) {
    if (value > 1) {
        value = 1;
    } else if (value < 0) {
        value = 0;
    }
    m_curValue = value * (m_maxValue - m_minValue) + m_minValue;
    m_showValue = m_curValue;
    getHost()->touchRenderChanged();
}

void ssui::Progress::dragSlider(s16 x, s16 y) {
    auto pSlider = (ProgressSlider*)getHost()->getComponent(NT_ProgressSlider);
    if (pSlider == nullptr) {
        return;
    }
    float per0 = (m_showValue - m_minValue) / (m_maxValue - m_minValue);
    auto lastPer = getValuePercent();
    switch (m_direction) {
        case ssui::PROG_DRC_lr:
        {
            float dPer = x / m_lastAreaLen;
            auto curPer = lastPer + dPer;
            setCurPercent(curPer);
        }
        break;
        case ssui::PROG_DRC_rl:
        {
            float dPer = x / m_lastAreaLen;
            auto curPer = lastPer - dPer;
            setCurPercent(curPer);
        }
        break;
        case ssui::PROG_DRC_tb:
        {
            float dPer = y / m_lastAreaLen;
            auto curPer = lastPer + dPer;
            setCurPercent(curPer);
        }
        break;
        case ssui::PROG_DRC_bt:
        {
            float dPer = y / m_lastAreaLen;
            auto curPer = lastPer - dPer;
            setCurPercent(curPer);
        }
        break;
        default:
            break;
    }
}

ssui::ft ssui::Progress::getDValue(u32 dTime) {
    if (m_changedSpeed > 0) {
        //�̶�value
        return dTime * 0.001f * m_changedSpeed;
    } else {
        //����value
        auto sumValue = m_maxValue - m_minValue;
        if (sumValue > 0) {
            return sumValue * (dTime * 0.001f * m_changedRate);
        } else {
            return 0;
        }
    }
}

void ssui::Progress::createTimer() {
    Timer::createObject(this, (Timer::TimerTriggerFunc)&Self::timerTrigger);
    return;
}

void ssui::Progress::timerTrigger(u32 targerTime) {
    rebuild();
}

void ssui::Progress::correctValidity() {
    if (m_curValue > m_maxValue) {
        m_curValue = m_maxValue;
    } else if (m_curValue < m_minValue) {
        m_curValue = m_minValue;
    }
    if (m_showValue > m_maxValue) {
        m_showValue = m_maxValue;
    } else if (m_showValue < m_minValue) {
        m_showValue = m_minValue;
    }
}

void ssui::Progress::rebuild() {
    if (getHost() == nullptr || m_maxValue == m_minValue) {
        return;
    }
    correctValidity();
    u32 dTime = 0;
    auto nowTime = GameTime::getUseTimeStable();
    if (m_lastTime == 0) {
        dTime = 0;
    } else {
        dTime = nowTime - m_lastTime;
        if (dTime <= 0) {
            dTime = 1;
        }
    }
    m_lastTime = nowTime;

    if (dTime > 0) {
        auto dValue = getDValue(dTime);
        if (m_showValue < m_curValue) {
            m_showValue += dValue;
            if (m_showValue >= m_curValue) {
                //�Ѿ��ﵽ��
                m_showValue = m_curValue;
            }
        } else {
            m_showValue -= dValue;
            if (m_showValue <= m_curValue) {
                //�Ѿ��ﵽ��
                m_showValue = m_curValue;
            }
        }
    }
    if (Math::equal(m_showValue, m_curValue) == false) {
        createTimer();
    } else {
        m_lastTime = 0;
    }
    m_isRect = false;
    switch (m_direction) {
        case ssui::PROG_DRC_lr:
        case ssui::PROG_DRC_rl:
        case ssui::PROG_DRC_tb:
        case ssui::PROG_DRC_bt:
        {
            m_isRect = true;
            touchRenderChanged();
        }
        break;
        case ssui::PROG_DRC_cw:
        case ssui::PROG_DRC_antiCw:
        {
            float per = (m_showValue - m_minValue) / (m_maxValue - m_minValue);
            if (per > 1) {
                per = 1;
            } else if (per < 0) {
                per = 0;
            }
            auto clipComp = getHost()->getBasicClip();
            if (clipComp) {
                float bAngle = clipComp->getClipBeginAngle();
                auto dAngle = 360.f * per;
                if (m_direction == PROG_DRC_cw) {
                    clipComp->setClipEndAngle(bAngle + dAngle);
                } else {
                    clipComp->setClipEndAngle(bAngle - dAngle + 360.f);
                }
            }
        }
        break;
        default:
            break;
    }
}

void ssui::Progress::debugString(string& outString) {
    outString.append("\n[Progress]");
    outString.append(string("\nshowValue: ") + util::ftoa_c8s(m_showValue));
    outString.append(string("\ncurValue: ") + util::ftoa_c8s(m_curValue));
}
