#include "DataInfoNode.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(DataInfoNode, 50000, 100000);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(DataInfoNode)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::DataInfoNode::disposeSelf() {
    for (auto& pNode : m_arrNode) {
        pNode->releaseObject();
    }
    for (auto& pAttr : m_arrAttr) {
        pAttr->releaseObject();
    }
    m_arrNode.clear();
    m_arrAttr.clear();
}

DataInfoNode* DataInfoNode::createObject(const wstring& nsName, const wstring& esName) {
    const auto& lmapNs = DataManager::getInstance()->m_lmapNameSpaceSetting;
    const auto& pairNs = lmapNs.find(nsName.hashCode());
    if (pairNs != lmapNs.end()) {
        const auto& pNs = pairNs->second;
        const auto& lmapEs = pNs->m_lmapElementSetting;
        const auto& pairEs = lmapEs.find(esName.hashCode());
        if (pairEs != lmapEs.end()) {
            const auto& pEs = pairEs->second;
            auto pNodeInfo = createObject();
            pNodeInfo->m_objType = pEs->m_objType;
            const auto& lmapCcit = DataManager::getInstance()->m_lmapCcit;
            const auto& pairCcit = lmapCcit.find(esName.hashCode());
            if (pairCcit != lmapCcit.end()) {
                pNodeInfo->addAttr(DataInfoAttr::createObject(AT_Control_DataCcit, pairCcit->second->m_id));
            }
            return pNodeInfo;
        }
    }
    return nullptr;
}

ssui::DataInfoNode& ssui::DataInfoNode::assign(const DataInfoNode& other) {
    Base::assign(other);
    for (auto& child : other.m_arrNode) {
        m_arrNode.push_back((DataInfoNode*)child->createCopy());
    }
    for (auto& attr : other.m_arrAttr) {
        m_arrAttr.push_back((DataInfoAttr*)attr->createCopy());
    }
    m_objType = other.m_objType;
    return *this;
}
