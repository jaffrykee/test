#include "TextShape.h"
#include "Control.h"
#include "Para.h"
#include "FlowElement.h"
#include "DataHeaders.h"

Tpid_t ssui::TextShape::s_tmpArrTpid[256];
gstl::wstring ssui::TextShape::s_tmpFontNames;
wstring TextShape::s_tmpTextDirectionAttrList;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(TextShape, 200, 1000);
#pragma region "����ע��"
if (s_tmpFontNames == "") {
    ArrayList<string> names = Graphics::getFontNames();
    for (int i = 0; i < names.size(); i++) {
        if (i != 0)
            s_tmpFontNames += "%";

        s_tmpFontNames += util::u32toa_s(i);
        s_tmpFontNames += '^';
        s_tmpFontNames += util::utf2wstr(names[i]);
    }
}
s_tmpTextDirectionAttrList.clear();
s_tmpTextDirectionAttrList += "0";
s_tmpTextDirectionAttrList += '^';
s_tmpTextDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpTextDirectionAttrList += '%';
s_tmpTextDirectionAttrList += "1";
s_tmpTextDirectionAttrList += '^';
s_tmpTextDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpTextDirectionAttrList += '%';
s_tmpTextDirectionAttrList += "2";
s_tmpTextDirectionAttrList += '^';
s_tmpTextDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpTextDirectionAttrList += '%';
s_tmpTextDirectionAttrList += "3";
s_tmpTextDirectionAttrList += '^';
s_tmpTextDirectionAttrList += util::utf2wstr(string(u8"����"));
NODEBASE_ATTR_REGISTER("fontDataUnderLine", DataUnderLine, TextShape, B2);
NODEBASE_ATTR_REGISTER("fontDataDeleteLine", DataDeleteLine, TextShape, B2);
NODEBASE_ATTR_REGISTER("fontDataEnableLightFont", DataEnableLightFont, TextShape, B2);
NODEBASE_ATTR_REGISTER("fontDataEnableBorderFont", DataEnableBorderFont, TextShape, B2);
NODEBASE_ATTR_REGISTER("fontDataEnableShadowFont", DataEnableShadowFont, TextShape, B2);
NODEBASE_ATTR_REGISTER("font", DataFont, TextShape, S32, s_tmpFontNames, true);
NODEBASE_ATTR_REGISTER("fontSize", DataFontSize, TextShape, S32);
NODEBASE_ATTR_REGISTER("textDirection", TextDirection, TextShape, S32, s_tmpTextDirectionAttrList, true);
NODEBASE_ATTR_REGISTER("textSpacing", TextSpacing, TextShape, S32);
NODEBASE_ATTR_REGISTER("colorUp", DataColorUp, TextShape, HU32);
NODEBASE_ATTR_REGISTER("colorDown", DataColorDown, TextShape, HU32);
// border
NODEBASE_ATTR_REGISTER("fontDataExSizeBorder", DataExSizeBorder, TextShape, F32);
NODEBASE_ATTR_REGISTER("fontColorBorder", DataColorBorder, TextShape, HU32);
// shadow
NODEBASE_ATTR_REGISTER("fontDataExSizeShadow", DataExSizeShadow, TextShape, F32);
NODEBASE_ATTR_REGISTER("fontDataAngleShadow", DataAngleShadow, TextShape, F32);
NODEBASE_ATTR_REGISTER("fontColorShadow", DataColorShadow, TextShape, HU32);
// Light
NODEBASE_ATTR_REGISTER("fontDataExSizeLight", DataExSizeLight, TextShape, F32);
NODEBASE_ATTR_REGISTER("fontDataLightWeight", DataLightWeight, TextShape, F32);
NODEBASE_ATTR_REGISTER("fontColorLight", DataColorLight, TextShape, HU32);
// Underline
NODEBASE_ATTR_REGISTER("fontColorUnderLine", DataColorUnderLine, TextShape, HU32);
NODEBASE_ATTR_REGISTER("fontDataUnderLineWidth", DataUnderLineWidth, TextShape, F32);
NODEBASE_ATTR_REGISTER("fontDataUnderLineOffsetY", DataUnderLineOffsetY, TextShape, F32);
// Deleteline
NODEBASE_ATTR_REGISTER("fontColorDeleteLine", DataColorDeleteLine, TextShape, HU32);
NODEBASE_ATTR_REGISTER("fontDataDeleteLineWidth", DataDeleteLineWidth, TextShape, F32);
NODEBASE_ATTR_REGISTER("fontDataDeleteLineOffsetY", DataDeleteLineOffsetY, TextShape, F32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(TextShape)
NBSCRIPT_ATTR_REGISTER("fontDataUnderLine", DataUnderLine, TextShape, B2);
NBSCRIPT_ATTR_REGISTER("fontDataDeleteLine", DataDeleteLine, TextShape, B2);
NBSCRIPT_ATTR_REGISTER("fontDataEnableLightFont", DataEnableLightFont, TextShape, B2);
NBSCRIPT_ATTR_REGISTER("fontDataEnableBorderFont", DataEnableBorderFont, TextShape, B2);
NBSCRIPT_ATTR_REGISTER("fontDataEnableShadowFont", DataEnableShadowFont, TextShape, B2);
NBSCRIPT_ATTR_REGISTER("font", DataFont, TextShape, S32);
NBSCRIPT_ATTR_REGISTER("fontSize", DataFontSize, TextShape, S32);
NBSCRIPT_ATTR_REGISTER("textDirection", TextDirection, TextShape, S32);
NBSCRIPT_ATTR_REGISTER("textSpacing", TextSpacing, TextShape, S32);
NBSCRIPT_ATTR_REGISTER("colorUp", DataColorUp, TextShape, HU32);
NBSCRIPT_ATTR_REGISTER("colorDown", DataColorDown, TextShape, HU32);
// border
NBSCRIPT_ATTR_REGISTER("fontDataExSizeBorder", DataExSizeBorder, TextShape, F32);
NBSCRIPT_ATTR_REGISTER("fontColorBorder", DataColorBorder, TextShape, HU32);
// shadow
NBSCRIPT_ATTR_REGISTER("fontDataExSizeShadow", DataExSizeShadow, TextShape, F32);
NBSCRIPT_ATTR_REGISTER("fontDataAngleShadow", DataAngleShadow, TextShape, F32);
NBSCRIPT_ATTR_REGISTER("fontColorShadow", DataColorShadow, TextShape, HU32);
// Light
NBSCRIPT_ATTR_REGISTER("fontDataExSizeLight", DataExSizeLight, TextShape, F32);
NBSCRIPT_ATTR_REGISTER("fontDataLightWeight", DataLightWeight, TextShape, F32);
NBSCRIPT_ATTR_REGISTER("fontColorLight", DataColorLight, TextShape, HU32);
// Underline
NBSCRIPT_ATTR_REGISTER("fontColorUnderLine", DataColorUnderLine, TextShape, HU32);
NBSCRIPT_ATTR_REGISTER("fontDataUnderLineWidth", DataUnderLineWidth, TextShape, F32);
NBSCRIPT_ATTR_REGISTER("fontDataUnderLineOffsetY", DataUnderLineOffsetY, TextShape, F32);
// Deleteline
NBSCRIPT_ATTR_REGISTER("fontColorDeleteLine", DataColorDeleteLine, TextShape, HU32);
NBSCRIPT_ATTR_REGISTER("fontDataDeleteLineWidth", DataDeleteLineWidth, TextShape, F32);
NBSCRIPT_ATTR_REGISTER("fontDataDeleteLineOffsetY", DataDeleteLineOffsetY, TextShape, F32);
NODETYPE_COMMON_PART_DEFINITION_END

TextShape& ssui::TextShape::assign(const TextShape& other) {
    Base::assign(other);
    return *this;
}

int ssui::TextShape::getDataFont() const {
    return mt_dataFont;
}

void ssui::TextShape::setDataFont(int value) {
    if (mt_dataFont != value) {
        mt_dataFont = value;
        touchRenderChanged();
    }
}

int ssui::TextShape::getDataFontSize() const {
    return mt_dataFontSize;
}

void ssui::TextShape::setDataFontSize(int value) {
    if (mt_dataFontSize != value) {
        mt_dataFontSize = value;
        touchRenderChanged();
    }
}

int ssui::TextShape::getTextDirection() const {
    return (int)mt_textDirection;
}

void ssui::TextShape::setTextDirection(int value) {
    mt_textDirection = (FontDir)value;
    touchRenderChanged();
}

int ssui::TextShape::getTextSpacing() const {
    return mt_textSpacing;
}

void ssui::TextShape::setTextSpacing(int value) {
    mt_textSpacing = value;
    touchRenderChanged();
}

gstl::u32 ssui::TextShape::getDataColorUp() const {
    return mt_dataColorUp.getARGB();
}

void ssui::TextShape::setDataColorUp(u32 value) {
    SSUIMath::setColorFromArgb(mt_dataColorUp, value);
    touchRenderChanged();
}

gstl::u32 ssui::TextShape::getDataColorDown() const {
    return mt_dataColorDown.getARGB();
}

void ssui::TextShape::setDataColorDown(u32 value) {
    SSUIMath::setColorFromArgb(mt_dataColorDown, value);
    touchRenderChanged();
}

gstl::u32 ssui::TextShape::getDataColorBorder() const {
    return mt_colorBorder.getARGB();
}

void ssui::TextShape::setDataColorBorder(u32 value) {
    SSUIMath::setColorFromArgb(mt_colorBorder, value);
    getHost()->touchRenderChanged();
}

gstl::u32 ssui::TextShape::getDataColorShadow() const {
    return mt_colorShadow.getARGB();
}

void ssui::TextShape::setDataColorShadow(u32 value) {
    SSUIMath::setColorFromArgb(mt_colorShadow, value);
    getHost()->touchRenderChanged();
}

gstl::u32 ssui::TextShape::getDataColorLight() const {
    return mt_colorLight.getARGB();
}

void ssui::TextShape::setDataColorLight(u32 value) {
    SSUIMath::setColorFromArgb(mt_colorLight, value);
    getHost()->touchRenderChanged();
}

gstl::u32 ssui::TextShape::getDataColorUnderLine() const {
    return mt_colorUnderLine.getARGB();
}

void ssui::TextShape::setDataColorUnderLine(u32 value) {
    SSUIMath::setColorFromArgb(mt_colorUnderLine, value);
    getHost()->touchRenderChanged();
}

gstl::u32 ssui::TextShape::getDataColorDeleteLine() const {
    return mt_colorDeleteLine.getARGB();
}

void ssui::TextShape::setDataColorDeleteLine(u32 value) {
    SSUIMath::setColorFromArgb(mt_colorDeleteLine, value);
    getHost()->touchRenderChanged();
}

gstl::f32 ssui::TextShape::getDataLightWeight() const {
    return mt_LightWeight;
}

void ssui::TextShape::setDataLightWeight(f32 value) {
    if (mt_LightWeight != value) {
        mt_LightWeight = value;
        getHost()->touchRenderChanged();
    }
}

gstl::f32 ssui::TextShape::getDataExSizeBorder() const {
    return mt_exSizeBorder;
}

void ssui::TextShape::setDataExSizeBorder(f32 value) {
    if (mt_exSizeBorder != value) {
        mt_exSizeBorder = value;
        getHost()->touchRenderChanged();
    }
}

gstl::f32 ssui::TextShape::getDataExSizeShadow() const {
    return mt_exSizeShadow;
}

void ssui::TextShape::setDataExSizeShadow(f32 value) {
    if (mt_exSizeShadow != value) {
        mt_exSizeShadow = value;
        getHost()->touchRenderChanged();
    }
}

gstl::f32 ssui::TextShape::getDataExSizeLight() const {
    return mt_exSizeLight;
}

void ssui::TextShape::setDataExSizeLight(f32 value) {
    if (mt_exSizeLight != value) {
        mt_exSizeLight = value;
        getHost()->touchRenderChanged();
    }
}

gstl::f32 ssui::TextShape::getDataAngleShadow() const {
    return mt_angleShadow;
}

void ssui::TextShape::setDataAngleShadow(f32 value) {
    if (mt_angleShadow != value) {
        mt_angleShadow = value;
        getHost()->touchRenderChanged();
    }
}

gstl::f32 ssui::TextShape::getDataUnderLineOffsetY() const {
    return mt_underLineOffsetY;
}

void ssui::TextShape::setDataUnderLineOffsetY(f32 value) {
    if (mt_underLineOffsetY != value) {
        mt_underLineOffsetY = value;
        getHost()->touchRenderChanged();
    }
}

gstl::f32 ssui::TextShape::getDataDeleteLineOffsetY() const {
    return mt_deleteLineOffsetY;
}

void ssui::TextShape::setDataDeleteLineOffsetY(f32 value) {
    if (mt_deleteLineOffsetY != value) {
        mt_deleteLineOffsetY = value;
        getHost()->touchRenderChanged();
    }
}

gstl::f32 ssui::TextShape::getDataDeleteLineWidth() const {
    return mt_deleteLineWidth;
}

void ssui::TextShape::setDataDeleteLineWidth(f32 value) {
    if (mt_deleteLineWidth != value) {
        mt_deleteLineWidth = value;
        getHost()->touchRenderChanged();
    }
}

b2 ssui::TextShape::getDataUnderLine() const {
    return mt_underLine;
}

void ssui::TextShape::setDataUnderLine(b2 value) {
    if (mt_underLine != value) {
        mt_underLine = value;
        getHost()->touchRenderChanged();
    }
}

gstl::f32 ssui::TextShape::getDataUnderLineWidth() const {
    return mt_underLineWidth;
}

void ssui::TextShape::setDataUnderLineWidth(f32 value) {
    if (mt_underLineWidth != value) {
        mt_underLineWidth = value;
        getHost()->touchRenderChanged();
    }
}

b2 ssui::TextShape::getDataDeleteLine() const {
    return mt_DeleteLine;
}

void ssui::TextShape::setDataDeleteLine(b2 value) {
    if (mt_DeleteLine != value) {
        mt_DeleteLine = value;
        getHost()->touchRenderChanged();
    }
}

b2 ssui::TextShape::getDataEnableLightFont() const {
    return mt_enableLightFont;
}

void ssui::TextShape::setDataEnableLightFont(b2 value) {
    if (mt_enableLightFont != value) {
        mt_enableLightFont = value;
        getHost()->touchRenderChanged();
    }
}

b2 ssui::TextShape::getDataEnableBorderFont() const {
    return mt_enableBorderFont;
}

void ssui::TextShape::setDataEnableBorderFont(b2 value) {
    if (mt_enableBorderFont != value) {
        mt_enableBorderFont = value;
        getHost()->touchRenderChanged();
    }
}

b2 ssui::TextShape::getDataEnableShadowFont() const {
    return mt_enableShadowFont;
}

void ssui::TextShape::setDataEnableShadowFont(b2 value) {
    if (mt_enableShadowFont != value) {
        mt_enableShadowFont = value;
        getHost()->touchRenderChanged();
    }
}

const wstring& ssui::TextShape::getShowText() {
    auto pCurHost = getHost();
ReStart:
    if (pCurHost == nullptr) {
        return StringManager::getInstance()->mc_wstrNullDef;
    }
    if (pCurHost->getText().empty()) {
        pCurHost = pCurHost->getParent();
        goto ReStart;
    } else {
        return pCurHost->getText();
    }
}
void TextShape::getTextMinAndMaxPos(vec3& minPos, vec3& maxPos) const {
    getMinAndMaxPos(minPos, maxPos);
    auto parentCtrl = getHost()->getParent();
    if (parentCtrl && parentCtrl->getDataCcit() == CCIT_FlowElement) {
        auto pFlowComp = (FlowElement*)parentCtrl->getComponentByClass(NT_FlowElement);
        auto pComp = parentCtrl->getParentComponent();
        if (pComp && pComp->is(NT_Para) && pFlowComp) {
            static_cast<Para*>(pComp)->getMinAndMaxPos(pFlowComp->getLineNo(),minPos, maxPos);
            return;
        }
    }
}
void TextShape::getMinAndMaxPos(vec3& minPos, vec3& maxPos) const {
    if (getHost()->m_arrRender.size() == 0)
        return;

    const PolyImage& polyImage = getHost()->m_arrRender[0];
    if (polyImage.size() < 4)
        return;

    minPos = polyImage[0].position;
    maxPos = polyImage[0].position;

    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
        for (VertexPosColorTex& e : *it) {
            minPos.x = math::minimum(e.position.x, minPos.x);
            minPos.y = math::minimum(e.position.y, minPos.y);
            maxPos.x = math::maximum(e.position.x, maxPos.x);
            maxPos.y = math::maximum(e.position.y, maxPos.y);
        }
    }
}

void TextShape::fillRect(const vec2& start, const vec2& end, float width, const Color& color) {
    vec2 pos;
    pos.x = start.x;
    pos.y = start.y - width / 2.0f;

    float _width = end.x - start.x + 1;
    float _height = width;

    ArrayList<vec3>list;
    list.push_back(vec3(pos.x, pos.y, .0f));
    list.push_back(vec3(pos.x + _width, pos.y, .0f));
    list.push_back(vec3(pos.x + _width, pos.y + _height, .0f));
    list.push_back(vec3(pos.x, pos.y + _height, .0f));
    Graphics::drawGraphic(list, color, RenderMode::triangleFan);
}

void TextShape::drawDeleteLine() {
    if (getHost()->m_arrRender.size() == 0)
        return;

    const PolyImage& polyImage = getHost()->m_arrRender[0];
    if (polyImage.size() < 4)
        return;

    vec3 minPos, maxPos;
    getTextMinAndMaxPos(minPos, maxPos);

    vec2 start;
    start.x = minPos.x;
    start.y = (maxPos.y + minPos.y) / 2;
    vec2 end;
    end.x = maxPos.x;
    end.y = start.y;

    start.y += getDataDeleteLineOffsetY();
    end.y += getDataDeleteLineOffsetY();

    fillRect(start, end, getDataDeleteLineWidth(), mt_colorDeleteLine);
}

void TextShape::drawUnderLine() {
    if (getHost()->m_arrRender.size() == 0)
        return;
    const PolyImage& polyImage = getHost()->m_arrRender[0];
    if (polyImage.size() < 4)
        return;

    vec3 minPos, maxPos;
    getTextMinAndMaxPos(minPos, maxPos);

    vec2 start;
    start.x = minPos.x;
    start.y = maxPos.y;
    vec2 end;
    end.x = maxPos.x;
    end.y = start.y;

    start.y += getDataUnderLineOffsetY();
    end.y += getDataUnderLineOffsetY();

    fillRect(start, end, getDataUnderLineWidth(), mt_colorUnderLine);
}

void TextShape::onMeasure(unsigned char drawStep) {
    if (getHost()->m_isAutoFrameData) {
        getHost()->initRender();
        onRender(drawStep);
    }
}

void ssui::TextShape::renderString(const wstring& text, const Font& font, const Color& upColor, const Color& downColor) {
    getHost()->m_texture = Graphics::createString(s_tmpArrTpid, text, font, upColor, downColor);
    if (getHost()->m_texture) {
        for (int i = 0, size = text.size(); i < size; i++) {
            auto& render = getHost()->nextRender();
            render[0] = s_tmpArrTpid[i].m_vpct[0];
            render[1] = s_tmpArrTpid[i].m_vpct[1];
            render[2] = s_tmpArrTpid[i].m_vpct[2];
            render[3] = s_tmpArrTpid[i].m_vpct[3];
        }
    }
}

void ssui::TextShape::onRender(unsigned char drawStep) {
    CheckHidden();
    //releaseSrcDrawNodeList();
    const auto& text = getShowText();
    if (text.empty()) {
        return;
    }

    ft maxBorderSize = 0;
    b2 useNormalOnly = true;
    if (getDataEnableShadowFont() || getDataEnableBorderFont() || getDataEnableLightFont()) {
        maxBorderSize = math::maximum(maxBorderSize, mt_exSizeBorder);
        maxBorderSize = math::maximum(maxBorderSize, mt_exSizeLight);
        maxBorderSize = math::maximum(maxBorderSize, mt_exSizeShadow);
        useNormalOnly = false;
    }

    if (getDataEnableLightFont()) {
        Font font = toFontInfo(FontStyle::light);
        font.isHaveNormal = false;
        font.offsetX = maxBorderSize - mt_exSizeLight;
        font.offsetY = font.offsetX;
        if (getHost()->getParentComponent() && getHost()->getParentComponent()->is(NT_FlowElement)) {
            font.isText = true;
        }
        renderString(text, font, font.borderColor, font.borderColor);
    }

    if (getDataEnableShadowFont()) { 
        Font font = toFontInfo(FontStyle::shadow);
        font.isHaveNormal = false;
        font.offsetX = maxBorderSize - mt_exSizeShadow;
        font.offsetY = font.offsetX;
        if (getHost()->getParentComponent() && getHost()->getParentComponent()->is(NT_FlowElement)) {
            font.isText = true;
        }
        renderString(text, font, font.borderColor, font.borderColor);
    }

    if (getDataEnableBorderFont()) {
        Font font = toFontInfo(FontStyle::border);
        font.isHaveNormal = false;
        font.offsetX = maxBorderSize - mt_exSizeBorder;
        font.offsetY = font.offsetX;
        if (getHost()->getParentComponent() && getHost()->getParentComponent()->is(NT_FlowElement)) {
            font.isText = true;
        }
        renderString(text, font, font.borderColor, font.borderColor);
    }

    Font font;
    if (useNormalOnly) {
        font = toFontInfo(FontStyle::normal);
    } else {
        font = toFontInfo(FontStyle::border);
        font.exSize = maxBorderSize;
    }
    if (getHost()->getParentComponent() && getHost()->getParentComponent()->is(NT_FlowElement)) {
        font.isText = true;
    }
    font.isHaveNormal = true;
    font.offsetX = 0;
    font.offsetY = 0;
    renderString(text, font, mt_dataColorUp, mt_dataColorDown);
}

void ssui::TextShape::onShow() {
    if (getHost() == nullptr) {
        return;
    }

    for (int i = 0; i < getHost()->m_arrRender.size(); i++) {
        auto& render = getHost()->m_arrRender[i];
        if (getHost()->m_texture != nullptr && render.size() > 3) {
            auto nm = NodeManager::getInstance();
            auto& showCache = nm->m_showCacheVpct;
            if (getHost()->m_texture != nm->m_showCacheTexture) {
                float lastGrayValue = nm->m_lastGrayValue;
                nm->m_lastGrayValue = 0.0f;
                nm->pushShow();
                nm->m_showCacheTexture = getHost()->m_texture;
                showCache.clear();
                nm->m_lastGrayValue = lastGrayValue;
            }
            auto itBegin = render.begin();
            auto it1 = itBegin + 1;
            auto it2 = itBegin + 2;
            for (; it2 != render.end(); ++it1, ++it2) {
                //��������˳ʱ�뻹����ʱ�룿
                showCache.push_back(*itBegin);
                showCache.push_back(*it2);
                showCache.push_back(*it1);
            }
        }

        auto nm = NodeManager::getInstance();
        auto& showCache = nm->m_showCacheVpct;
        if (showCache.size() != 0 && i == getHost()->m_arrRender.size() - 1) {
            float lastGrayValue = nm->m_lastGrayValue;
            nm->m_lastGrayValue = 0.0f;
            nm->pushShow();
            nm->m_showCacheTexture = getHost()->m_texture;
            nm->m_lastGrayValue = lastGrayValue;
            showCache.clear();
        }
    }

    if (getDataUnderLine())
        drawUnderLine();

    if (getDataDeleteLine())
        drawDeleteLine();
}

Font TextShape::toFontInfo(FontStyle style) const {
    Font font;
    font.index = getDataFont();
    font.size = getDataFontSize();
    font.style = style;
    font.spacing = mt_textSpacing;
    font.dir = mt_textDirection;

    switch (style) {
        case FontStyle::border:
            font.exSize = mt_exSizeBorder;
            font.borderColor = mt_colorBorder;
            break;

        case FontStyle::light:
            font.exSize = mt_exSizeLight;
            font.exWeight = mt_LightWeight;
            font.borderColor = mt_colorLight;
            break;

        case FontStyle::shadow:
            font.exSize = mt_exSizeShadow;
            font.exAngle = mt_angleShadow;
            font.borderColor = mt_colorShadow;
            break;
    }

    return font;
}
