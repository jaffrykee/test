#pragma once
#include "SimpleComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Progress : public SimpleComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(Progress);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(Progress, SimpleComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
    static wstring s_tmpProgressDirectionCmdData;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    float m_minValue = 0;
    float m_maxValue = 100;
    float m_curValue = 100;
    ProgressDirection_e m_direction = PROG_DRC_lr;
    //�仯���ʣ�ÿ��仯�����ֵ������
    float m_changedRate = 100;
    //�仯�ٶȣ�ÿ��仯�Ĺ̶�value�������ֵ����0����ʹ�ø�ֵ������m_changedRate��
    float m_changedSpeed = 0;
    float m_lastAreaLen = 0;
public:
    float m_showValue = 100;
    u32 m_lastTime = 0;
public:
    Border m_clipArea;
    bool m_isRect = true;
#pragma endregion

#pragma region "����"
public:
    float getMinValue() const;
    void setMinValue(float value);
    float getMaxValue() const;
    void setMaxValue(float value);
    float getCurValue() const;
    void setCurValue(float value);
    int getProgressDirection() const;
    void setProgressDirection(int value);
    float getChangedRate() const;
    void setChangedRate(float value);
    float getChangedSpeed() const;
    void setChangedSpeed(float value);
public:
    Self& assign(const Self& other);
public:
    virtual ParentAreaType_e getParentAreaType() const;
    virtual const ArrayList<SlotType_e>& getSlotList() const override;
    virtual void onPrepareData() override;
    virtual void onRender(unsigned char drawStep) override;
    virtual void onClip(unsigned char drawStep) override;
    virtual void applyClipToPosterity(Control* pPosterity) override;
    virtual bool isTouchComponent() const override;
public:
    float getValuePercent() const;
    void setCurPercent(float value);
    void dragSlider(s16 x, s16 y);
    ft getDValue(u32 dTime);
    void createTimer();
    void timerTrigger(u32 targerTime);
public:
    void correctValidity();
    void rebuild();
public:
    virtual void debugString(string& outString) override;
#pragma endregion
};

_SSUINamespaceEnd
