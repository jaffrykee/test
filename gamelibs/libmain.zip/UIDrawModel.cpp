#include "UIDrawModel.h"
#include "Control.h"
#include "DataHeaders.h"
#include "BasicMeasure.h"
#include "ParticleShape.h"
#include "BasicContent.h"
#include "GameTime.h"
#include "UIScene.h"
#include "UIManager.h"

HashMap<string, wstring> ssui::UIDrawModel::s_createObjectMap;
ArrayList<u32> ssui::UIDrawModel::s_deleteObjectArr;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UIDrawModel, 0, 0);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("modelScaleX", ModelScaleX, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelScaleY", ModelScaleY, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelScaleZ", ModelScaleZ, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelAngleX", ModelAngleX, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelAngleY", ModelAngleY, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelAngleZ", ModelAngleZ, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelOffsetX", ModelOffsetX, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelOffsetY", ModelOffsetY, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelOffsetZ", ModelOffsetZ, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("modelBackPrefab", ModelBackPrefab, UIDrawModel, STR);
NODEBASE_ATTR_REGISTER("backScaleX", BackScaleX, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backScaleY", BackScaleY, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backScaleZ", BackScaleZ, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backAngleX", BackAngleX, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backAngleY", BackAngleY, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backAngleZ", BackAngleZ, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backOffsetX", BackOffsetX, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backOffsetY", BackOffsetY, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backOffsetZ", BackOffsetZ, UIDrawModel, F32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UIDrawModel)
NBSCRIPT_ATTR_REGISTER("modelScaleX", ModelScaleX, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelScaleY", ModelScaleY, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelScaleZ", ModelScaleZ, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelAngleX", ModelAngleX, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelAngleY", ModelAngleY, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelAngleZ", ModelAngleZ, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelOffsetX", ModelOffsetX, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelOffsetY", ModelOffsetY, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelOffsetZ", ModelOffsetZ, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelBackPrefab", ModelBackPrefab, UIDrawModel, STR);
NODEBASE_ATTR_REGISTER("backScaleX", BackScaleX, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backScaleY", BackScaleY, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backScaleZ", BackScaleZ, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backAngleX", BackAngleX, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backAngleY", BackAngleY, UIDrawModel, F32);
NODEBASE_ATTR_REGISTER("backAngleZ", BackAngleZ, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("backOffsetX", BackOffsetX, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("backOffsetY", BackOffsetY, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("backOffsetZ", BackOffsetZ, UIDrawModel, F32);
NBSCRIPT_ATTR_REGISTER("modelScaleAndAngle", ModelScaleAndAngle, UIDrawModel, STR);
NBSCRIPT_ATTR_REGISTER("modelScaleStr", ModelScaleStr, Control, STR);
NBSCRIPT_ATTR_REGISTER("modelAngleStr", ModelAngleStr, Control, STR);
NBSCRIPT_ATTR_REGISTER("modelOffset", ModelOffset, UIDrawModel, STR);
NBSCRIPT_ATTR_REGISTER("modelId", ModelId, UIDrawModel, U32);
NODETYPE_COMMON_PART_DEFINITION_END
#pragma region "control����ע��"
UIComponent_ControlAttr_Def_STR(UIDrawModel, ModelBackPrefab, string)
UIComponent_ControlAttr_Def_STR(UIDrawModel, ModelScaleAndAngle, string)
UIComponent_ControlAttr_Def_STR(UIDrawModel, ModelScaleStr, string);
UIComponent_ControlAttr_Def_STR(UIDrawModel, ModelAngleStr, string);
UIComponent_ControlAttr_Def_STR(UIDrawModel, ModelOffset, string)
UIComponent_ControlAttr_Def(UIDrawModel, ModelId, u32)
#pragma endregion

void ssui::UIDrawModel::createSelf() {
}
void ssui::UIDrawModel::disposeSelf() {
    if (m_modelId != 0) {
        s_deleteObjectArr.push_back(m_modelId);
    }else if (m_modelEntity) {
        m_modelEntity.destroy();
    }
    if (m_backEntity) {
        m_backEntity.destroy();
        m_backEntity = null;
    }
    m_modelId = 0;
    m_modelEntity = null;
}

void ssui::UIDrawModel::setModelId(u32 value) {
    m_modelId = value;
}
u32 ssui::UIDrawModel::getModelId() const {
    return m_modelId;
}

Entity ssui::UIDrawModel::getModelEntity() const {
    return m_modelEntity;
}
void ssui::UIDrawModel::setModelEntity(Entity value, b2 isDestroy) {
    if (m_modelEntity && isDestroy) {
        m_modelEntity.destroy();
        m_modelEntity = null;
    }
    if (!m_modelEntity) {
        m_modelEntity = value;
        //m_innerScale = m_modelEntity.transform()->scale();
        //m_innerRotation = m_modelEntity.transform()->rotationEuler();
        onRefreshChange();
    }
}

ft ssui::UIDrawModel::getModelScaleX() const {
	return m_modelScaleX;
}
void ssui::UIDrawModel::setModelScaleX(ft value) {
    if (m_modelScaleX != value) {
        m_modelScaleX = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getModelScaleY() const {
	return m_modelScaleY;
}
void ssui::UIDrawModel::setModelScaleY(ft value) {
    if (m_modelScaleY != value) {
        m_modelScaleY = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getModelScaleZ() const {
	return m_modelScaleZ;
}
void ssui::UIDrawModel::setModelScaleZ(ft value) {
    if (m_modelScaleZ != value) {
        m_modelScaleZ = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getModelAngleX() const {
	return m_modelAngleX;
}
void ssui::UIDrawModel::setModelAngleX(ft value) {
    if (m_modelAngleX != value) {
        m_modelAngleX = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getModelAngleY() const {
	return m_modelAngleY;
}
void ssui::UIDrawModel::setModelAngleY(ft value) {
    if (m_modelAngleY != value) {
        m_modelAngleY = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getModelAngleZ() const {
	return m_modelAngleZ;
}
void ssui::UIDrawModel::setModelAngleZ(ft value) {
    if (m_modelAngleZ != value) {
        m_modelAngleZ = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getModelOffsetX() const {
    return m_modelOffsetX;
}
void ssui::UIDrawModel::setModelOffsetX(ft value) {
    if (m_modelOffsetX != value) {
        m_modelOffsetX = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getModelOffsetY() const {
    return m_modelOffsetY;
}
void ssui::UIDrawModel::setModelOffsetY(ft value) {
    if (m_modelOffsetY != value) {
        m_modelOffsetY = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getModelOffsetZ() const {
    return m_modelOffsetZ;
}
void ssui::UIDrawModel::setModelOffsetZ(ft value) {
    if (m_modelOffsetZ != value) {
        m_modelOffsetZ = value;
        onRefreshChange();
    }
}
const string& ssui::UIDrawModel::getModelBackPrefab() const {
    return m_modelBackPrefab;
}
void ssui::UIDrawModel::setModelBackPrefab(const string& value) {
    if (m_modelBackPrefab != value) {
        m_modelBackPrefab = value;
        if (m_backEntity) {
            m_backEntity.destroy();
            m_backEntity = null;
        }
        static string head = "prefab/";
        Prefab p = Prefab::get(head + m_modelBackPrefab);
        m_backEntity = p.gen();
        m_backInnerScale = m_backEntity.transform()->scale();
        m_backInnerRotation = m_backEntity.transform()->rotationEuler();
        m_backInnerWorldPosition = m_backEntity.transform()->worldPosition();
    }
}
ft ssui::UIDrawModel::getBackScaleX() const {
    return m_backScaleX;
}
void ssui::UIDrawModel::setBackScaleX(ft value) {
    if (m_backScaleX != value) {
        m_backScaleX = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getBackScaleY() const {
    return m_backScaleY;
}
void ssui::UIDrawModel::setBackScaleY(ft value) {
    if (m_backScaleY != value) {
        m_backScaleY = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getBackScaleZ() const {
    return m_backScaleZ;
}
void ssui::UIDrawModel::setBackScaleZ(ft value) {
    if (m_backScaleZ != value) {
        m_backScaleZ = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getBackAngleX() const {
    return m_backAngleX;
}
void ssui::UIDrawModel::setBackAngleX(ft value) {
    if (m_backAngleX != value) {
        m_backAngleX = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getBackAngleY() const {
    return m_backAngleY;
}
void ssui::UIDrawModel::setBackAngleY(ft value) {
    if (m_backAngleY != value) {
        m_backAngleY = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getBackAngleZ() const {
    return m_backAngleZ;
}
void ssui::UIDrawModel::setBackAngleZ(ft value) {
    if (m_backAngleZ != value) {
        m_backAngleZ = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getBackOffsetX() const {
    return m_backOffsetX;
}
void ssui::UIDrawModel::setBackOffsetX(ft value) {
    if (m_backOffsetX != value) {
        m_backOffsetX = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getBackOffsetY() const {
    return m_backOffsetY;
}
void ssui::UIDrawModel::setBackOffsetY(ft value) {
    if (m_backOffsetY != value) {
        m_backOffsetY = value;
        onRefreshChange();
    }
}
ft ssui::UIDrawModel::getBackOffsetZ() const {
    return m_backOffsetZ;
}
void ssui::UIDrawModel::setBackOffsetZ(ft value) {
    if (m_backOffsetZ != value) {
        m_backOffsetZ = value;
        onRefreshChange();
    }
}

const string& ssui::UIDrawModel::getModelScaleAndAngle() const {
    return m_scaleAndAngle;
}
void ssui::UIDrawModel::setModelScaleAndAngle(const string& value) {
    m_scaleAndAngle = value;
    ArrayList<string> t_strs;
    util::split(value, ':', t_strs);
    if (t_strs.size() >= 1) {
        m_modelScaleStr = t_strs[0];
        ArrayList<string> t_tmps;
        util::split(t_strs[0], ',', t_tmps);
        if (t_tmps.size() >= 3) {
            setModelScaleX(util::atof_s(t_tmps[0]));
            setModelScaleY(util::atof_s(t_tmps[1]));
            setModelScaleZ(util::atof_s(t_tmps[2]));
        }
        t_tmps.clear();
        if (t_strs.size() >= 2) {
            m_modelAngleStr = t_strs[1];
            util::split(t_strs[1], ',', t_tmps);
            if (t_tmps.size() >= 3) {
                setModelAngleX(util::atof_s(t_tmps[0]));
                setModelAngleY(util::atof_s(t_tmps[1]));
                setModelAngleZ(util::atof_s(t_tmps[2]));
            }
        }
    }
}
const string& ssui::UIDrawModel::getModelScaleStr() const {
    return m_modelScaleStr;
}
void ssui::UIDrawModel::setModelScaleStr(const string& value) {
    m_modelScaleStr = value;
    ArrayList<string> t_tmps;
    util::split(value, ',', t_tmps);
    if (t_tmps.size() >= 3) {
        setModelScaleX(util::atof_s(t_tmps[0]));
        setModelScaleY(util::atof_s(t_tmps[1]));
        setModelScaleZ(util::atof_s(t_tmps[2]));
    }
}
const string& ssui::UIDrawModel::getModelAngleStr() const {
    return m_modelAngleStr;
}
void ssui::UIDrawModel::setModelAngleStr(const string& value) {
    m_modelAngleStr = value;
    ArrayList<string> t_tmps;
    util::split(value, ',', t_tmps);
    if (t_tmps.size() >= 3) {
        setModelAngleX(util::atof_s(t_tmps[0]));
        setModelAngleY(util::atof_s(t_tmps[1]));
        setModelAngleZ(util::atof_s(t_tmps[2]));
    }
}

const string& ssui::UIDrawModel::getModelOffset() const {
    return m_offsetStr;
}
void ssui::UIDrawModel::setModelOffset(const string& value) {
    m_offsetStr = value;
    ArrayList<string> t_strs;
    util::split(value, ':', t_strs);
    if (t_strs.size() >= 1) {
        ArrayList<string> t_tmps;
        util::split(t_strs[0], ',', t_tmps);
        if (t_tmps.size() >= 3) {
            setModelOffsetX(util::atof_s(t_tmps[0]));
            setModelOffsetY(util::atof_s(t_tmps[1]));
            setModelOffsetZ(util::atof_s(t_tmps[2]));
        }
    }
}

void ssui::UIDrawModel::onRefreshChange() {
    mt_isRefresh = true;
}

ssui::UIDrawModel& ssui::UIDrawModel::assign(const ssui::UIDrawModel& other) {
    m_modelScaleX = other.m_modelScaleX;
    m_modelScaleY = other.m_modelScaleY;
    m_modelScaleZ = other.m_modelScaleZ;
    m_modelAngleX = other.m_modelAngleX;
    m_modelAngleY = other.m_modelAngleY;
    m_modelAngleZ = other.m_modelAngleZ;
    m_modelOffsetX = other.m_modelOffsetX;
    m_modelOffsetY = other.m_modelOffsetY;
    m_modelOffsetZ = other.m_modelOffsetZ;
    Base::assign(other);
    return *this;
}

void ssui::UIDrawModel::onShow() {
    if (UIManager::getInstance()->isUeMode() == false) {
        if (getHost() == nullptr) {
            return;
        }
        auto pText = getHost()->enableBasicContent()->getShowText();
        if (pText == nullptr || (*pText).empty()) {
            return;
        }
        if ( m_modelEntity) {
            NodeManager::getInstance()->pushShow();
            if (mt_isRefresh) {
                vec3 scale(getModelScaleX(), getModelScaleY(), getModelScaleZ());
                vec3 transAngle(getModelAngleX(), getModelAngleY(), getModelAngleZ());

                m_modelEntity.transform()->setPositionInheriable(false);
                m_modelEntity.transform()->setScaleInheriable(false);
                m_modelEntity.transform()->setRotationInheriable(false);
                m_modelEntity.transform()->setScale(scale * m_innerScale);
                m_modelEntity.transform()->setRotation(quat(transAngle + m_innerRotation));
                m_modelEntity.transform()->setPosition(vec3(getModelOffsetX(), getModelOffsetY(), getModelOffsetZ()));
                if (m_backEntity != null) {
                    vec3 backScale(getBackScaleX(), getBackScaleY(), getBackScaleZ());
                    vec3 backAngle(getBackAngleX(), getBackAngleY(), getBackAngleZ());
                    vec3 backOffset(getBackOffsetX(), getBackOffsetY(), getBackOffsetZ());
                    m_modelEntity.attach(m_backEntity.root());
                    m_backEntity.transform()->setScale(vec3(backScale * m_backInnerScale));
                    m_backEntity.transform()->setRotation(quat(backAngle + m_backInnerRotation));
                    m_backEntity.transform()->setWorldPosition(backOffset + m_innerWorldPosition);
                    m_backEntity.play();
                }
                else {
                    m_modelEntity.play();
                }
                mt_isRefresh = false;
            }
            vec2i pos1 = Graphics::ui2screen(vec2i(getSelfDrawX(), getSelfDrawY()));
            vec2i pos2 = Graphics::ui2screen(vec2i(getSelfWidth(), getSelfHeight()));
            m_modelRect.set(pos1.x, pos1.y, pos2.x, pos2.y);

            f32 timef = GameTime::getTimeDeltaConstf();
            if (m_backEntity) {
                m_backEntity.apply([timef](Entity e) {
                    e.value()->update(timef); });
                Graphics::draw3D(m_modelRect, m_backEntity);
            }else {
                m_modelEntity.apply([timef](Entity e) {
                    e.value()->update(timef); });
                Graphics::draw3D(m_modelRect, m_modelEntity);
            }
        }
        if(m_modelInfo != *pText){
            m_modelInfo = *pText;
            string key = getHost()->getScene()->getName();
            key += "|";
            key += getHost()->getId();
            s_createObjectMap.insert(key, m_modelInfo);
        }
    } else {
        if (getHost() == nullptr) {
            return;
        }
        if (m_backEntity) {
            NodeManager::getInstance()->pushShow();
            if (mt_isRefresh) {
                vec3 backScale(getBackScaleX(), getBackScaleY(), getBackScaleZ());
                vec3 backAngle(getBackAngleX(), getBackAngleY(), getBackAngleZ());
                vec3 backOffset(getBackOffsetX(), getBackOffsetY(), getBackOffsetZ());
                m_backEntity.transform()->setScale(vec3(backScale * m_backInnerScale));
                m_backEntity.transform()->setRotation(quat(backAngle + m_backInnerRotation));
                m_backEntity.transform()->setWorldPosition(backOffset + m_innerWorldPosition);
                m_backEntity.play();
            }
            vec2i pos1 = Graphics::ui2screen(vec2i(getSelfDrawX(), getSelfDrawY()));
            vec2i pos2 = Graphics::ui2screen(vec2i(getSelfWidth(), getSelfHeight()));
            m_modelRect.set(pos1.x, pos1.y, pos2.x, pos2.y);

            f32 timef = GameTime::getTimeDeltaConstf();
            m_backEntity.apply([timef](Entity e) {
                e.value()->update(timef); });
            Graphics::draw3D(m_modelRect, m_backEntity);
        }
    }
}

bool ssui::UIDrawModel::isTouchComponent() const {
    return true;
}

void UIDrawModel::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    default:
    {

    }
    break;
    }
    Base::onEventScript(event);
}
