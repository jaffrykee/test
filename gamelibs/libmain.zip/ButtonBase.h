#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ButtonBase : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ButtonBase);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(ButtonBase, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    s16 m_px = -1;
    s16 m_py = -1;
    bool m_isDragged = false;
#pragma endregion

#pragma region "����"
public:
    inline Self& assign(const Self& other) {
        Base::assign(other);
        return *this;
    }
    virtual void onEvent(SSUIEvent& event) override;
public:
    virtual bool isTouchComponent() const override;
#pragma endregion
};

_SSUINamespaceEnd
