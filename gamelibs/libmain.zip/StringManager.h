#pragma once
#include "ssuiBasic.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

//һ����̬��
class StringManager {
#pragma region "��̬��Ա"
public:
    static string s_className;
    static StringManager* s_pInstance;
#pragma endregion

#pragma region "��̬����"
public:
    inline static StringManager* getInstance() {
        if (s_pInstance == nullptr) {
            s_pInstance = new StringManager();
        }
        return s_pInstance;
    }
    static void initialize();
    static void destroy();
    static void registerReflection(int id);

    template<typename TypeIn, typename TypeOut, size_t Count>
    inline static void RegisterWordRow(TypeIn(&arr)[Count], HashMap<TypeIn, int>& map, TypeOut outStr) {
        int i = 0;
        outStr.clear();
        for (const auto& rowName : arr) {
            map.insert(rowName, i);
            i++;
            outStr += TypeOut(rowName.c_str());
            outStr += '%';
        }
        outStr.pop_back();
    }
    template<typename TypeIn, size_t Count>
    inline static void RegisterWordRow(TypeIn(&arr)[Count], HashMap<TypeIn, int>& map) {
        int i = 0;
        for (const auto& rowName : arr) {
            map.insert(rowName, i);
            i++;
        }
    }
#pragma endregion

#pragma region "��Ա"
public:
    const string mc_strNullDef = "";
    const wstring mc_wstrNullDef = "";
    const string mc_strTrueDef = "true";
    const wstring mc_wstrTrueDef = "true";
    const string mc_strFalseDef = "false";
    const wstring mc_wstrFalseDef = "false";
    const string mc_strDefault = "default";
    const wstring mc_wstrDefault = "default";
    const string mc_strLinkSkin = "linkSkin";
    const wstring mc_wstrLinkSkin = "linkSkin";
    const string mc_strBefore = "before";
    const wstring mc_wstrBefore = "before";

    const string mc_strdisable = "disable";
    const wstring mc_wstrdisable = "disable";

    const wstring mc_wstrBoloUI = "BoloUI";
    const int mc_wstrKeyBoloUI = StringManager::mc_wstrBoloUI.hashCode();
    const wstring mc_wstrSSUI = "SSUI";
    const wstring mc_wstrSSUIImage = "SSUIImage";
    const int mc_wstrKeySSUI = StringManager::mc_wstrSSUI.hashCode();
    const string mc_strBoloObject = "BoloObject";
    const wstring mc_wstrBoloObject = "BoloObject";

    const wstring mc_wstrControl = "Control";
    const wstring mc_wstrSkinGroup = "SkinGroup";
    const wstring mc_wstrUITexture = "UITexture";
    const wstring mc_wstrEventNodeBase = "EventNodeBase";
    const wstring mc_wstrEventScript = "EventScript";
    const wstring mc_wstrSkin = "Skin";
    const wstring mc_wstrShapeGroup = "ShapeGroup";
    const wstring mc_wstrImageShape = "ImageShape";
    const wstring mc_wstrTextShape = "TextShape";
    const wstring mc_wstrParticleShape = "ParticleShape";
    const wstring mc_wstrSlicedPanel = "SlicedPanel";
    const wstring mc_wstrStringManager = "StringManager";
    const wstring mc_wstrUIImageRect = "UIImageRect";
    const wstring mc_wstrUIImagePoly = "UIImagePoly";

    const wstring mc_wstrUIXmlConfig = "UIXmlConfig";
    const wstring mc_wstrUIKeySubject = "UIKeySubject";

    const string mc_strUiDataPackage = "ui/";
    const string mc_strScriptPath = "script/";

    HashMap<int, wstring> m_mapAttrSetting;
    HashSet<string> m_hsThemeName;
    ArrayList<string> m_arrTmpSplit;
    ArrayList<wstring> m_arrTmpWSplit;

    const u16 mc_wcOpenBrace = '{';
    const u16 mc_wcCloseBrace = '}';
    const u16 mc_wcOpenBracket = '[';
    const u16 mc_wcCloseBracket = ']';
    const u16 mc_wcOpenParentheses = '(';
    const u16 mc_wcCloseParentheses = ')';
    const u16 mc_wcPeriod = '.';
    const u16 mc_wcTextFlowEnter = '`';
    const u16 mc_wcTextFlowScript = '@';
    const u16 mc_wcSkinSep = ';';
    const u16 mc_wcPasswordChar = '*';

    const int mc_wstrCodePanel = wstring("Panel").hashCode();
    const int mc_wstrCodeLabel = wstring("Label").hashCode();
    const int mc_wstrCodeButton = wstring("Button").hashCode();

    const string mc_strUITextureFileSuffix = ".xml";

    string m_tmpString;
    wstring m_tmpWString;
#pragma endregion

#pragma region "����"
public:
    StringManager();
public:
    inline static void getMemStringFromByteNum(string& memString, int byteNum) {
        if (byteNum > 1024 * 1024) {
            memString = util::itoa_c8s(byteNum / (1024 * 1024)) + " MB";
        } else if (byteNum > 1024) {
            memString = util::itoa_c8s(byteNum / 1024) + " KB";
        } else {
            memString = util::itoa_c8s(byteNum);
        }
    }
    inline static void wstringToString(const wstring& src, string& dst) {
        dst.clear();
        util::str2str(src, dst);
    }
    inline static void stringToWstring(const string& src, wstring& dst) {
        dst.clear();
        util::str2str(src, dst);
    }
    inline static bool getBoolValue(const wstring& wstr) {
        return (wstr.front() == 't') ? true : false;
    }
    static void appendStrings(string& dstStr, const string& append, int count);
#pragma endregion
};

_SSUINamespaceEnd
