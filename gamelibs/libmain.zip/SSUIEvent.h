#pragma once
#include <stdlib.h>
#include "ssuiBasic.h"
#include "StaticCache.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

#define UIEVENT_CACHE_WB        10

class SSUIEvent {
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static StaticCache<SSUIEvent, UIEVENT_CACHE_WB> s_cache;
    static SSUIEvent s_null;
#pragma endregion

#pragma region "��̬����"
    inline static SSUIEvent& createSSUIEvent(EventType_e type) {
        SSUIEvent& uiEvent = SSUIEvent::s_cache.nextData();
        uiEvent.resetValue();
        uiEvent.m_type = type;
        return uiEvent;
    }
    inline static SSUIEvent& createSSUIEvent(EventType_e type, int value1, int value2, u16 extType = 0) {
        SSUIEvent& uiEvent = SSUIEvent::s_cache.nextData();
        uiEvent.resetValue();
        uiEvent.m_type = type;
        uiEvent.m_iData1 = value1;
        uiEvent.m_iData2 = value2;
        uiEvent.m_extType = extType;
        return uiEvent;
    }
    inline static SSUIEvent& createSSUIEvent(EventType_e type, f32 value1, f32 value2, u16 extType = 0) {
        SSUIEvent& uiEvent = SSUIEvent::s_cache.nextData();
        uiEvent.resetValue();
        uiEvent.m_type = type;
        uiEvent.m_fData1 = value1;
        uiEvent.m_fData2 = value2;
        uiEvent.m_extType = extType;
        return uiEvent;
    }
    inline static SSUIEvent& createSSUIEvent(EventType_e type, void* value1, void* value2, u16 extType = 0) {
        SSUIEvent& uiEvent = SSUIEvent::s_cache.nextData();
        uiEvent.resetValue();
        uiEvent.m_type = type;
        uiEvent.m_pData1 = value1;
        uiEvent.m_pData2 = value2;
        uiEvent.m_extType = extType;
        return uiEvent;
    }
    inline static SSUIEvent& createSSUIEvent(wstring::value_type* pText, int len, u16 extType = 0) {
        SSUIEvent& uiEvent = SSUIEvent::s_cache.nextData();
        uiEvent.resetValue();
        uiEvent.m_type = ET_Text;
        uiEvent.m_pData1 = pText;
        uiEvent.m_iData2 = len;
        uiEvent.m_extType = extType;
        return uiEvent;
    }
    inline static SSUIEvent& getLastTouchEvent() {
        for (int di = 0; di < (1 << UIEVENT_CACHE_WB); di++) {
            auto& uiEvent = s_cache.dData(-di);
            if (uiEvent.m_type == ET_Drag || uiEvent.m_type == ET_Click || uiEvent.m_type == ET_Press || uiEvent.m_type == ET_Release) {
                return uiEvent;
            }
        }
        return s_null;
    }
#pragma endregion

#pragma region "��Ա"
public:
    //��ֵ��
    union {
        int m_iData1;
        f32 m_fData1;
        void* m_pData1;
        __ptr m_data1 = 0;
    };
    //��ֵ��
    union {
        int m_iData2;
        f32 m_fData2;
        void* m_pData2;
        __ptr m_data2 = 0;
    };
    u16 m_extType = 0;
    EventType_e m_type = ET_Null;
    union {
        struct {
            bool m_blockScript : 1;
            bool m_blockStatusChange : 1;
            bool m_blockAnimation : 1;
            bool m_enDragged : 1;
            bool m_blockHandle : 1;
            bool m_nextUI : 1;
            bool mt_em6 : 1;
            bool mt_em7 : 1;
        };
        unsigned char mt_statusInitData = 0;
    };
#pragma endregion

#pragma region "����"
	inline bool isBlockHandle() const {
		return m_blockHandle;
	}
    inline bool isBlockAll() const {
		return false;
//         return m_type == ET_Drag && mt_statusInitData == (1 << 0) + (1 << 1) + (1 << 2) + (1 << 3)
// 			|| mt_statusInitData == (1 << 1) + (1 << 2) + (1 << 3);
    }
    inline bool isSendNext() const {
        return (m_blockStatusChange == false);
    }
    inline void resetValue() {
        mt_statusInitData = 0;
        m_extType = 0;
    }
#pragma endregion
};

//__declspec(selectany) ssui::SSUIEvent SSUIEvent::st_cache;

_SSUINamespaceEnd
