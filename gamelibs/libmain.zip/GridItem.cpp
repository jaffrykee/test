#include "GridItem.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(GridItem, 300, 1000);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("columnIndex", ColumnIndex, GridItem, S32);
NODEBASE_ATTR_REGISTER("columnSpan", ColumnSpan, GridItem, S32);
NODEBASE_ATTR_REGISTER("rowIndex", RowIndex, GridItem, S32);
NODEBASE_ATTR_REGISTER("rowSpan", RowSpan, GridItem, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(GridItem)
NBSCRIPT_ATTR_REGISTER("columnIndex", ColumnIndex, GridItem, S32);
NBSCRIPT_ATTR_REGISTER("columnSpan", ColumnSpan, GridItem, S32);
NBSCRIPT_ATTR_REGISTER("rowIndex", RowIndex, GridItem, S32);
NBSCRIPT_ATTR_REGISTER("rowSpan", RowSpan, GridItem, S32);
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::GridItem::createSelf() {

}

void ssui::GridItem::disposeSelf() {

}

#pragma region "���Է���"
int ssui::GridItem::getColumnIndex() const {
    return getHost() ? getHost()->getExpansionAttrS32(AT_GridItem_ColumnIndex) : 0;
}

void ssui::GridItem::setColumnIndex(int value) {
    if (getHost()) {
        getHost()->setExpansionAttr(AT_GridItem_ColumnIndex, value);
    }
}

int ssui::GridItem::getColumnSpan() const {
    return getHost() ? getHost()->getExpansionAttrS32(AT_GridItem_ColumnSpan) : 0;
}

void ssui::GridItem::setColumnSpan(int value) {
    if (getHost()) {
        getHost()->setExpansionAttr(AT_GridItem_ColumnSpan, value);
    }
}

int ssui::GridItem::getRowIndex() const {
    return getHost() ? getHost()->getExpansionAttrS32(AT_GridItem_RowIndex) : 0;
}

void ssui::GridItem::setRowIndex(int value) {
    if (getHost()) {
        getHost()->setExpansionAttr(AT_GridItem_RowIndex, value);
    }
}

int ssui::GridItem::getRowSpan() const {
    return getHost() ? getHost()->getExpansionAttrS32(AT_GridItem_RowSpan) : 0;
}

void ssui::GridItem::setRowSpan(int value) {
    if (getHost()) {
        getHost()->setExpansionAttr(AT_GridItem_RowSpan, value);
    }
}
#pragma endregion

ssui::GridItem& ssui::GridItem::assign(const GridItem& other) {
    Base::assign(other);
    return *this;
}

void GridItem::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    default:
    {

    }
    break;
    }
    Base::onEventScript(event);
}
