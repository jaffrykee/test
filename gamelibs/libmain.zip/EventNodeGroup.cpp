#include "EventNodeGroup.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(EventNodeGroup, 100, 500);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(EventNodeGroup)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::EventNodeGroup::setScript(const string& type, const wstring& scriptStr, bool isClear /*= true*/) {
    if (type.length()) {
        if (scriptStr.length()) {
            auto eventNode = EventNodeBase::createObject();
            if (eventNode) {
                eventNode->setEventName(type);
                if (isClear) {
                    eraseEventNodeByEventType((EventType_e)eventNode->getEventType());
                }
                auto eventScript = EventScript::createObject();
                if (eventScript) {
                    eventScript->setScriptData(scriptStr);
                    eventNode->m_eventTriggers.push_back(eventScript);
                    addEventNode(eventNode);
                }
            }
        } else {
            EventType_e eventType = ET_MAX;
            const auto& pairEvent = DictionaryManager::getInstance()->m_mapEventType.find(type);
            if (pairEvent != DictionaryManager::getInstance()->m_mapEventType.end()) {
                eventType = (EventType_e)pairEvent->second;
            }
            eraseEventNodeByEventType(eventType);
        }
    }
}
