#include "Grid.h"
#include "Control.h"
#include "GridItem.h"
#include "UIManager.h"
#include "GeometryManager.h"
#include "Geometry.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Grid, 0, 0);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("cw0", Cw0, Grid, S32);
NODEBASE_ATTR_REGISTER("cw1", Cw1, Grid, S32);
NODEBASE_ATTR_REGISTER("cw2", Cw2, Grid, S32);
NODEBASE_ATTR_REGISTER("cw3", Cw3, Grid, S32);
NODEBASE_ATTR_REGISTER("cw4", Cw4, Grid, S32);
NODEBASE_ATTR_REGISTER("cw5", Cw5, Grid, S32);
NODEBASE_ATTR_REGISTER("cw6", Cw6, Grid, S32);
NODEBASE_ATTR_REGISTER("cw7", Cw7, Grid, S32);
NODEBASE_ATTR_REGISTER("rh0", Rh0, Grid, S32);
NODEBASE_ATTR_REGISTER("rh1", Rh1, Grid, S32);
NODEBASE_ATTR_REGISTER("rh2", Rh2, Grid, S32);
NODEBASE_ATTR_REGISTER("rh3", Rh3, Grid, S32);
NODEBASE_ATTR_REGISTER("rh4", Rh4, Grid, S32);
NODEBASE_ATTR_REGISTER("rh5", Rh5, Grid, S32);
NODEBASE_ATTR_REGISTER("rh6", Rh6, Grid, S32);
NODEBASE_ATTR_REGISTER("rh7", Rh7, Grid, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(Grid)
NBSCRIPT_ATTR_REGISTER("cw0", Cw0, Grid, S32);
NBSCRIPT_ATTR_REGISTER("cw1", Cw1, Grid, S32);
NBSCRIPT_ATTR_REGISTER("cw2", Cw2, Grid, S32);
NBSCRIPT_ATTR_REGISTER("cw3", Cw3, Grid, S32);
NBSCRIPT_ATTR_REGISTER("cw4", Cw4, Grid, S32);
NBSCRIPT_ATTR_REGISTER("cw5", Cw5, Grid, S32);
NBSCRIPT_ATTR_REGISTER("cw6", Cw6, Grid, S32);
NBSCRIPT_ATTR_REGISTER("cw7", Cw7, Grid, S32);
NBSCRIPT_ATTR_REGISTER("rh0", Rh0, Grid, S32);
NBSCRIPT_ATTR_REGISTER("rh1", Rh1, Grid, S32);
NBSCRIPT_ATTR_REGISTER("rh2", Rh2, Grid, S32);
NBSCRIPT_ATTR_REGISTER("rh3", Rh3, Grid, S32);
NBSCRIPT_ATTR_REGISTER("rh4", Rh4, Grid, S32);
NBSCRIPT_ATTR_REGISTER("rh5", Rh5, Grid, S32);
NBSCRIPT_ATTR_REGISTER("rh6", Rh6, Grid, S32);
NBSCRIPT_ATTR_REGISTER("rh7", Rh7, Grid, S32);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "���Է���"
int ssui::Grid::getColumnWidth(int index) const {
    if (index >= GRID_INDEXMAX) {
        //throw
        return 0;
    } else {
        return m_cw[index];
    }
}

void ssui::Grid::setColumnWidth(int index, int value) {
    if (index >= GRID_INDEXMAX) {
        //throw
    } else {
        getHost()->touchPrepareDataChanged();
        m_cw[index] = value;
    }
}

int ssui::Grid::getRowHeight(int index) const {
    if (index >= GRID_INDEXMAX) {
        //throw
        return 0;
    } else {
        return m_rh[index];
    }
}

void ssui::Grid::setRowHeight(int index, int value) {
    if (index >= GRID_INDEXMAX) {
        //throw
    } else {
        getHost()->touchPrepareDataChanged();
        m_rh[index] = value;
    }
}

int ssui::Grid::getCw0() const {
    return m_cw[0];
}

void ssui::Grid::setCw0(int value) {
    m_cw[0] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getCw1() const {
    return m_cw[1];
}

void ssui::Grid::setCw1(int value) {
    m_cw[1] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getCw2() const {
    return m_cw[2];
}

void ssui::Grid::setCw2(int value) {
    m_cw[2] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getCw3() const {
    return m_cw[3];
}

void ssui::Grid::setCw3(int value) {
    m_cw[3] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getCw4() const {
    return m_cw[4];
}

void ssui::Grid::setCw4(int value) {
    m_cw[4] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getCw5() const {
    return m_cw[5];
}

void ssui::Grid::setCw5(int value) {
    m_cw[5] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getCw6() const {
    return m_cw[6];
}

void ssui::Grid::setCw6(int value) {
    m_cw[6] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getCw7() const {
    return m_cw[7];
}

void ssui::Grid::setCw7(int value) {
    m_cw[7] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getRh0() const {
    return m_rh[0];
}

void ssui::Grid::setRh0(int value) {
    m_rh[0] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getRh1() const {
    return m_rh[1];
}

void ssui::Grid::setRh1(int value) {
    m_rh[1] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getRh2() const {
    return m_rh[2];
}

void ssui::Grid::setRh2(int value) {
    m_rh[2] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getRh3() const {
    return m_rh[3];
}

void ssui::Grid::setRh3(int value) {
    m_rh[3] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getRh4() const {
    return m_rh[4];
}

void ssui::Grid::setRh4(int value) {
    m_rh[4] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getRh5() const {
    return m_rh[5];
}

void ssui::Grid::setRh5(int value) {
    m_rh[5] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getRh6() const {
    return m_rh[6];
}

void ssui::Grid::setRh6(int value) {
    m_rh[6] = value;
    getHost()->touchPrepareDataChanged();
}

int ssui::Grid::getRh7() const {
    return m_rh[7];
}

void ssui::Grid::setRh7(int value) {
    m_rh[7] = value;
    getHost()->touchPrepareDataChanged();
}
#pragma endregion

ssui::Grid& ssui::Grid::assign(const Grid& other) {
    Base::assign(other);
    return *this;
}

void ssui::Grid::getItemArea(Border& area, int columnIndex, int columnSpan, int rowIndex, int rowSpan) const {
    if (columnSpan <= 0) {
        columnSpan = 1;
    }
    if (rowSpan <= 0) {
        rowSpan = 1;
    }
    if (columnIndex >= GRID_INDEXMAX) {
        columnIndex = GRID_INDEXMAX - 1;
    }
    if (rowIndex >= GRID_INDEXMAX) {
        rowIndex = GRID_INDEXMAX - 1;
    }
    area.clear();
    u16 widthStarCount = 0;
    u16 heightStarCount = 0;
    for (int ri = 0; ri < rowIndex; ri++) {
        if (m_rh[ri] < 0) {
            heightStarCount += (-m_rh[ri]);
        } else {
            area.m_top += m_rh[ri];
        }
    }
    for (int ci = 0; ci < columnIndex; ci++) {
        if (m_cw[ci] < 0) {
            widthStarCount += (-m_cw[ci]);
        } else {
            area.m_left += m_cw[ci];
        }
    }
    if (widthStarCount != 0) {
        area.m_left += widthStarCount * m_starWidth;
        widthStarCount = 0;
    }
    if (heightStarCount != 0) {
        area.m_top += heightStarCount * m_starHeight;
        heightStarCount = 0;
    }
    area.m_bottom = area.m_top;
    area.m_right = area.m_left;
    for (int ci = 0; ci < columnSpan; ci++) {
        if (m_cw[columnIndex + ci] < 0) {
            widthStarCount += (-m_cw[columnIndex + ci]);
        } else {
            area.m_right += m_cw[columnIndex + ci];
        }
    }
    for (int ri = 0; ri < rowSpan; ri++) {
        if (m_rh[rowIndex + ri] < 0) {
            heightStarCount += (-m_rh[rowIndex + ri]);
        } else {
            area.m_bottom += m_rh[rowIndex + ri];
        }
    }
    if (widthStarCount != 0) {
        area.m_right += widthStarCount * m_starWidth;
        widthStarCount = 0;
    }
    if (heightStarCount != 0) {
        area.m_bottom += heightStarCount * m_starHeight;
        heightStarCount = 0;
    }
}

void ssui::Grid::getItemArea(Border& area, GridItem* pItem) const {
    getItemArea(area, pItem->getColumnIndex(), pItem->getColumnSpan(), pItem->getRowIndex(), pItem->getRowSpan());
}

const ssui::Border& ssui::Grid::getChildArea(const Control* pChild) const {
    //auto i = m_container.where(const_cast<Control*>(pChild));
    auto pItem = (GridItem*)pChild->getComponent(NT_GridItem);
    if (pItem) {
        auto& childArea = Border::createStaticCache();
        getItemArea(childArea, pItem);
        return childArea;
    } else {
        return Base::getChildArea(pChild);
    }
}

void ssui::Grid::onPrepareData() {
    if (getHost() == nullptr) {
        return;
    }
    if (getHost()->m_isAutoFrameData) {
        getHost()->m_measureReadyMinimumTimes = 1;
    }
}

bool ssui::Grid::onDrawChildren(unsigned char drawStep, bool isReDraw) {
    if (container().empty()) {
        return true;
    }
    refreshStarSize();
    bool isPosterityReady = true;
    if (isReDraw == false) {
        for (auto& pChild : *this) {
            if (pChild->isDrawReady() == false) {
                isReDraw = true;
                break;
            }
        }
    }
    if (isReDraw) {
        for (auto& pChild : *this) {
            pChild->assignAllDrawChanged();
            pChild->onDraw(drawStep);
        }
        onTransformChildren(drawStep);
    } else {
        for (auto& pChild : *this) {
            pChild->onDraw(drawStep);
        }
    }
    for (auto& pChild : *this) {
        if (pChild->isDrawReady() == false || pChild->m_isPosterityReady == false) {
            isPosterityReady = false;
            break;
        }
    }
    return isPosterityReady;
}

int ssui::Grid::addChild(Control* pChild) {
    auto ret = Base::addChild(pChild);
    pChild->releaseComponentByClass(NT_ChildItem);
    pChild->addComponent(GridItem::createObject());
    return ret;
}

void ssui::Grid::refreshStarSize() {
    const auto& selfArea = getHost()->getSelfMeasure().m_srcArea;
    auto width = selfArea.width();
    auto height = selfArea.height();
    m_sumWidthStarCount = 0;
    m_sumHeightStarCount = 0;
    for (auto curWidth : m_cw) {
        if (curWidth < 0) {
            if (curWidth == -100) {
                m_isAutoWidth = true;
            } else {
                m_sumWidthStarCount += (-curWidth);
            }
        } else {
            width -= curWidth;
        }
    }
    for (auto curHeight : m_rh) {
        if (curHeight < 0) {
            if (curHeight == -100) {
                m_isAutoHeight = true;
            } else {
                m_sumHeightStarCount += (-curHeight);
            }
        } else {
            height -= curHeight;
        }
    }
    m_starWidth = width / m_sumWidthStarCount;
    m_starHeight = height / m_sumHeightStarCount;
}

// void ssui::Grid::updateAutoSize(int columnIndex, int rowIndex) {
//     //AutoSize
//     if (m_isAutoData != 0) {
//         Border tmpCurChildAabb;
//         vec2 sumSelfRb;
//         for (auto& pComp : *getHost()) {
//             for (auto& pChild : *pComp) {
//                 auto pGeo = pChild->getOuterMeasure().m_pTransGeo;
//                 if (pGeo) {
//                     pGeo->getBorder(tmpCurChildAabb);
//                     //Ĭ����չ�������ҷ����·���
//                     GeometryManager::sumPointAndBorder(sumSelfRb, tmpCurChildAabb, pChild->mMeasureDir);
//                 } else {
//                     //Ĭ����չ�������ҷ����·���
//                     GeometryManager::sumPointAndBorder(sumSelfRb, pChild->getOuterMeasure().m_srcArea);
//                 }
//             }
//         }
//         for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
//             GeometryManager::sumPointAndPolyImage(sumSelfRb, *it);
//         }
//         if (m_isAutoWidth) {
//             auto cw = right - left;
//             if (sumSelfRb.x > cw) {
//                 right += sumSelfRb.x - cw;
//             }
//         }
//         if (m_isAutoHeight) {
//             auto ch = bottom - top;
//             if (sumSelfRb.y > ch) {
//                 bottom += sumSelfRb.y - ch;
//             }
//         }
//     }
// }
