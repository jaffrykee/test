#pragma once
#include "SimpleComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class UIDrawModel : public SimpleComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UIDrawModel)
protected:
	virtual void createSelf() override;
	virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(UIDrawModel, SimpleComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static HashMap<string, wstring> s_createObjectMap;
    static ArrayList<u32> s_deleteObjectArr;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    string m_modelScaleStr = "1.f,1.f,1.f";
    string m_modelAngleStr = "0,0,0";
    string m_scaleAndAngle = "1.f,1.f,1.f:0,0,0";
    string m_offsetStr = "";
	f32 m_modelScaleX = 1.f;
	f32 m_modelScaleY = 1.f;
	f32 m_modelScaleZ = 1.f;
	f32 m_modelAngleX = 0.f;
	f32 m_modelAngleY = 0.f;
	f32 m_modelAngleZ = 0.f;
    f32 m_modelOffsetX = 0.f;
    f32 m_modelOffsetY = 0.f;
    f32 m_modelOffsetZ = 0.f;
    string m_modelBackPrefab = "";

    f32 m_backScaleX = 1.f;
    f32 m_backScaleY = 1.f;
    f32 m_backScaleZ = 1.f;
    f32 m_backAngleX = 0.f;
    f32 m_backAngleY = 0.f;
    f32 m_backAngleZ = 0.f;
    f32 m_backOffsetX = 0.f;
    f32 m_backOffsetY = 0.f;
    f32 m_backOffsetZ = 0.f;

    Entity m_backEntity = null;
    Entity m_modelEntity = null;
    b2 mt_isRefresh = false;
    vec3 m_innerScale = vec3(1.0f, 1.0f, 1.0f);
    vec3 m_innerRotation = vec3::zero;
    vec3 m_innerWorldPosition = vec3::zero;

    vec3 m_backInnerScale = vec3(1.0f, 1.0f, 1.0f);
    vec3 m_backInnerRotation = vec3::zero;
    vec3 m_backInnerWorldPosition = vec3::zero;
    vec4 m_modelRect = vec4::zero;
    u32 m_modelId = 0;
    wstring m_modelInfo = "";
#pragma endregion
#pragma region "���Է���"
public:
    void setModelId(u32 value);
    u32 getModelId() const;
    void setModelEntity(Entity value, b2 isDestroy);
    Entity getModelEntity() const;

	ft getModelScaleX() const;
	void setModelScaleX(ft value);
	ft getModelScaleY() const;
	void setModelScaleY(ft value);
	ft getModelScaleZ() const;
	void setModelScaleZ(ft value);
	ft getModelAngleX() const;
	void setModelAngleX(ft value);
	ft getModelAngleY() const;
	void setModelAngleY(ft value);
	ft getModelAngleZ() const;
	void setModelAngleZ(ft value);

    ft getModelOffsetX() const;
    void setModelOffsetX(ft value);
    ft getModelOffsetY() const;
    void setModelOffsetY(ft value);
    ft getModelOffsetZ() const;
    void setModelOffsetZ(ft value);
    const string& getModelBackPrefab() const;
    void setModelBackPrefab(const string& value);
    
    ft getBackScaleX() const;
    void setBackScaleX(ft value);
    ft getBackScaleY() const;
    void setBackScaleY(ft value);
    ft getBackScaleZ() const;
    void setBackScaleZ(ft value);
    ft getBackAngleX() const;
    void setBackAngleX(ft value);
    ft getBackAngleY() const;
    void setBackAngleY(ft value);
    ft getBackAngleZ() const;
    void setBackAngleZ(ft value);
    ft getBackOffsetX() const;
    void setBackOffsetX(ft value);
    ft getBackOffsetY() const;
    void setBackOffsetY(ft value);
    ft getBackOffsetZ() const;
    void setBackOffsetZ(ft value);

    const string& getModelScaleAndAngle() const;
    void setModelScaleAndAngle(const string& value);
    const string& getModelScaleStr() const;
    void setModelScaleStr(const string& value);
    const string& getModelAngleStr() const;
    void setModelAngleStr(const string& value);
    const string& getModelOffset() const;
    void setModelOffset(const string& value);
#pragma endregion
#pragma region "����"
public:
    void onRefreshChange();
    UIDrawModel& assign(const UIDrawModel& other);
public:
    virtual bool isTouchComponent() const override;
    virtual void onEvent(SSUIEvent& event) override;
public:
    virtual void onShow() override;
#pragma endregion
};

_SSUINamespaceEnd
