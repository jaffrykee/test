#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ChildItem : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ChildItem)
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(ChildItem, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
#pragma endregion
public:
    ChildItem& assign(const ChildItem& other);
#pragma endregion
};

_SSUINamespaceEnd
