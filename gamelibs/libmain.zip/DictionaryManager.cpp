#include "DictionaryManager.h"
#include "NodeManager.h"
#include "EventNodeBase.h"
#include "ShapeGroup.h"
#include "TimeContent.h"
#include "TextShape.h"
#include "Progress.h"
#include "BasicClip.h"

string DictionaryManager::s_className = "DictionaryManager";
DictionaryManager* DictionaryManager::s_pInstance = nullptr;

void DictionaryManager::initialize() {
    //ET_([a-zA-Z]*);
    //"$1";
}

void DictionaryManager::destroy() {

}

void DictionaryManager::registerReflection(int id) {

}

ssui::DictionaryManager::DictionaryManager() {
    WordRowRegisterW(EventType, ET_, Null)
    //Touch
    WordRowRegisterW(EventType, ET_, Press)
    WordRowRegisterW(EventType, ET_, Release)
    WordRowRegisterW(EventType, ET_, Drag)
    WordRowRegisterW(EventType, ET_, Click)
    WordRowRegisterW(EventType, ET_, LostFocus)
    WordRowRegisterW(EventType, ET_, Select)
    WordRowRegisterW(EventType, ET_, Unselect)
    //Normal
    WordRowRegisterW(EventType, ET_, Timer)
    WordRowRegisterW(EventType, ET_, AddChildNotYet)
    WordRowRegisterW(EventType, ET_, RemoveChildNotYet)
    WordRowRegisterW(EventType, ET_, ReleaseChildrenNotYet)
    WordRowRegisterW(EventType, ET_, AddChildDone)
    WordRowRegisterW(EventType, ET_, RemoveChildDone)
    WordRowRegisterW(EventType, ET_, ReleaseChildrenDone)
    WordRowRegisterW(EventType, ET_, AddComponentDone)
    //Attr
    WordRowRegisterW(EventType, ET_, AttrValueChanged)
    WordRowRegisterW(EventType, ET_, SceneChanged)
    WordRowRegisterW(EventType, ET_, TextChanged)
    WordRowRegisterW(EventType, ET_, VisibleChanged)
    WordRowRegisterW(EventType, ET_, EnableChanged)
    WordRowRegisterW(EventType, ET_, CommandChanged)
    //Draw
    WordRowRegisterW(EventType, ET_, LanguageThemeChanged)
    WordRowRegisterW(EventType, ET_, SkinGroupReplace)
        
    //Input & System
    WordRowRegisterW(EventType, ET_, Text)
    WordRowRegisterW(EventType, ET_, Char)
    WordRowRegisterW(EventType, ET_, Command)

    //Scene
    WordRowRegisterW(EventType, ET_, onSceneLoaded)
    WordRowRegisterW(EventType, ET_, onSceneClose)

    //CSV
    WordRowRegisterW(EventType, ET_, onCSVLoaded)
    WordRowRegisterW(EventType, ET_, onCSVAddItem)
	WordRowRegisterW(EventType, ET_, ItemChange)

    //TimeBlock
    WordRowRegisterW(EventType, ET_, CountDown)
    WordRowRegisterW(EventType, ET_, CountTimeOut)

    //WordRowRegisterW(EventType, ET_, MAX)
    RegisterWordRow<string, wstring, ET_MAX>(m_arrEventType, m_mapEventType, EventNodeBase::s_tmpEventList);

    WordRowRegisterW(AttrSubType, AST_, halfNormal)
    WordRowRegisterW(AttrSubType, AST_, normal)
    WordRowRegisterW(AttrSubType, AST_, allBool)
    RegisterWordRow<wstring, AST_MAX>(m_arrAttrSubType, m_mapAttrSubType);
    
    WordRowRegisterW(SlotType, SLOT_, body)
    WordRowRegisterW(SlotType, SLOT_, text)
    WordRowRegisterW(SlotType, SLOT_, scroll)
    WordRowRegisterW(SlotType, SLOT_, progFill)
    WordRowRegisterW(SlotType, SLOT_, progEmpty)
    WordRowRegisterW(SlotType, SLOT_, hSliderBack)
    WordRowRegisterW(SlotType, SLOT_, hSliderBody)
    WordRowRegisterW(SlotType, SLOT_, vSliderBack)
    WordRowRegisterW(SlotType, SLOT_, vSliderBody)
    WordRowRegisterW(SlotType, SLOT_, vJoystick)
    WordRowRegisterW(SlotType, SLOT_, blink)
    WordRowRegisterW(SlotType, SLOT_, container)
    WordRowRegisterW(SlotType, SLOT_, null)
    WordRowRegisterW(SlotType, SLOT_, progSlider)
    WordRowRegisterW(SlotType, SLOT_, tips)
    RegisterWordRowWithNumValue<string, wstring, SLOT_MAX>(m_arrSlotType, m_mapSlotType, ShapeGroup::s_tmpSlotCmdData);

    WordRowRegisterW(StateValue, STATE_, normal)
    WordRowRegisterW(StateValue, STATE_, pressed)
    WordRowRegisterW(StateValue, STATE_, disable)
    WordRowRegisterW(StateValue, STATE_, disable_pressed_x)
    WordRowRegisterW(StateValue, STATE_, selected)
    WordRowRegisterW(StateValue, STATE_, selected_pressed)
    WordRowRegisterW(StateValue, STATE_, selected_disable)
    WordRowRegisterW(StateValue, STATE_, selected_disable_pressed_x)
    RegisterWordRowWithNumValue<string, wstring, STATE_MAX>(m_arrStateValue, m_mapStateValue, ShapeGroup::s_tmpStateCmdData);

    //CsvAttr
    WordRowRegisterW(CsvAttrType, CAT_, Text)
    WordRowRegisterW(CsvAttrType, CAT_, Skin)
    WordRowRegisterW(CsvAttrType, CAT_, Visible)
    WordRowRegisterW(CsvAttrType, CAT_, IsEnable)
    WordRowRegisterW(CsvAttrType, CAT_, Id)
    WordRowRegisterW(CsvAttrType, CAT_, Value1)
    WordRowRegisterW(CsvAttrType, CAT_, Value2)
    WordRowRegisterW(CsvAttrType, CAT_, CsvData)
    WordRowRegisterW(CsvAttrType, CAT_, Blink)
	WordRowRegisterW(CsvAttrType, CAT_, Command)
    WordRowRegisterW(CsvAttrType, CAT_, BindId)
    RegisterWordRow<string, CAT_MAX>(m_arrCsvAttrType, m_mapCsvAttrType);

    //TimeContent
    WordRowRegisterW(TimeOrder, TO_, Positive)
    WordRowRegisterW(TimeOrder, TO_, CountDown)
    RegisterWordRowWithNumValue<string, wstring, TO_MAX>(m_arrTimeOrder, m_mapTimeOrder, TimeContent::s_tmpTimeOrderCmdData);
    WordRowRegisterW(TimeType, TimeDigit_, MSEC)
    WordRowRegisterW(TimeType, TimeDigit_, SEC)
    WordRowRegisterW(TimeType, TimeDigit_, MIN)
    WordRowRegisterW(TimeType, TimeDigit_, HOUR)
    WordRowRegisterW(TimeType, TimeDigit_, DAY)
    RegisterWordRowWithNumValue<string, wstring, TimeDigit_MAX>(m_arrTimeType, m_mapTimeType, TimeContent::s_tmpTimeTypeCmdData);
    //BasicClip
    WordRowRegisterW(ClipType, ClipType_, none)
    WordRowRegisterW(ClipType, ClipType_, circle)
    WordRowRegisterW(ClipType, ClipType_, roundedRectangle)
    WordRowRegisterW(ClipType, ClipType_, sixAngleRhombus)
    WordRowRegisterW(ClipType, ClipType_, custom)
    RegisterWordRowWithNumValue<string, wstring, ClipType_max>(m_arrClipType, m_mapClipType, BasicClip::s_tmpClipTypeCmdData);
    //ProgressDirection
    WordRowRegisterW(ProgressDirection, PROG_DRC_, lr)
    WordRowRegisterW(ProgressDirection, PROG_DRC_, rl)
    WordRowRegisterW(ProgressDirection, PROG_DRC_, tb)
    WordRowRegisterW(ProgressDirection, PROG_DRC_, bt)
    WordRowRegisterW(ProgressDirection, PROG_DRC_, cw)
    WordRowRegisterW(ProgressDirection, PROG_DRC_, antiCw)
    RegisterWordRowWithNumValue<string, wstring, SLOT_MAX>(m_arrProgressDirection, m_mapProgressDirection, Progress::s_tmpProgressDirectionCmdData);
}
