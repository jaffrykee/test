#pragma once
#include "ObjectBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class NodeTypeSetting;
class NameSpaceSetting : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(NameSpaceSetting);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(NameSpaceSetting, ObjectBase);

#pragma region "��������"
    typedef void (NameSpaceSetting::*ParseXmlFunc_t)(const string& fileName, XmlParser& parser);
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
    inline static NameSpaceSetting* createObject(const wstring& name, ParseXmlFunc_t pParseFunc) {
        auto pSelf = Self::createObject();
        pSelf->m_name = name;
        pSelf->m_pParseFunc = pParseFunc;
        DataManager::getInstance()->m_lmapNameSpaceSetting.insert(name.hashCode(), pSelf);
        return pSelf;
    }
#pragma endregion

#pragma region "��Ա"
    wstring m_name;
    //��¼������ElementSetting
    LinkedHashMap<wstrHash, ElementSetting*> m_lmapElementSetting;
    ParseXmlFunc_t m_pParseFunc = nullptr;
#pragma endregion

#pragma region "����"
    inline NameSpaceSetting& assign(const NameSpaceSetting& other) {
        Base::assign(other);
        //��Ӧ�õ��á�
        assert(false);
        for (auto& pairEs : m_lmapElementSetting) {
            m_lmapElementSetting.insert(pairEs.first, pairEs.second);
        }
        m_name = other.m_name;
        return *this;
    }
    void addElementSetting(ElementSetting* pXe);
    void addEsToEs(const wstring& parent, const wstring& child);
#pragma region "����"
    void parseSSUIXml(const string& fileName, XmlParser& parser);
    void parseUITextureXml(const string& fileName, XmlParser& parser);
    void parseXmlConfigXml(const string& fileName, XmlParser& parser);
    inline void parseXml(const string& fileName, XmlParser& parser) {
        if (m_pParseFunc != nullptr) {
            (this->*m_pParseFunc)(fileName, parser);
        }
    }
#pragma endregion
#pragma endregion
};

_SSUINamespaceEnd
