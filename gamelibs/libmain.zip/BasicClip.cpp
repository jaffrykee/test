#include "BasicClip.h"
#include "Control.h"
#include "GeometryManager.h"
#include "GeometryUnionPoly.h"

#include "DataHeaders.h"

gstl::wstring ssui::BasicClip::s_tmpClipTypeCmdData;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(BasicClip, CONTROL_RESPOOLINIT, CONTROL_RESPOOLLIMIT);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("isEnableClip", IsEnableClip, BasicClip, B2);
NODEBASE_ATTR_REGISTER("clipType", ClipType, BasicClip, S32, s_tmpClipTypeCmdData, true);
NODEBASE_ATTR_REGISTER("clipRoundedRadius", ClipRoundedRadius, BasicClip, S32);
NODEBASE_ATTR_REGISTER("clipCircleOffsestX", ClipCircleOffsestX, BasicClip, S32);
NODEBASE_ATTR_REGISTER("clipCircleOffsestY", ClipCircleOffsestY, BasicClip, S32);
NODEBASE_ATTR_REGISTER("clipBeginAngle", ClipBeginAngle, BasicClip, S32);
NODEBASE_ATTR_REGISTER("clipEndAngle", ClipEndAngle, BasicClip, S32);
NODEBASE_ATTR_REGISTER("clipCircleRadius", ClipCircleRadius, BasicClip, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(BasicClip)
NBSCRIPT_ATTR_REGISTER("isEnableClip", IsEnableClip, BasicClip, B2);
NBSCRIPT_ATTR_REGISTER("clipType", ClipType, BasicClip, S32);
NBSCRIPT_ATTR_REGISTER("clipRoundedRadius", ClipRoundedRadius, BasicClip, S32);
NBSCRIPT_ATTR_REGISTER("clipCircleRadius", ClipCircleRadius, BasicClip, S32);
NBSCRIPT_ATTR_REGISTER("clipCircleOffsestX", ClipCircleOffsestX, BasicClip, S32);
NBSCRIPT_ATTR_REGISTER("clipCircleOffsestY", ClipCircleOffsestY, BasicClip, S32);
NBSCRIPT_ATTR_REGISTER("clipBeginAngle", ClipBeginAngle, BasicClip, S32);
NBSCRIPT_ATTR_REGISTER("clipEndAngle", ClipEndAngle, BasicClip, S32);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(BasicClip, IsEnableClip, bool)
UIComponent_ControlAttr_Def(BasicClip, ClipType, int)
UIComponent_ControlAttr_Def(BasicClip, ClipRoundedRadius, int)
UIComponent_ControlAttr_Def(BasicClip, ClipCircleRadius, int)
UIComponent_ControlAttr_Def(BasicClip, ClipCircleOffsestX, int)
UIComponent_ControlAttr_Def(BasicClip, ClipCircleOffsestY, int)
UIComponent_ControlAttr_Def(BasicClip, ClipBeginAngle, int)
UIComponent_ControlAttr_Def(BasicClip, ClipEndAngle, int)
#pragma endregion
void ssui::BasicClip::disposeSelf() {
}

bool ssui::BasicClip::getIsEnableClip() const {
    return m_isEnableClip;
}

void ssui::BasicClip::setIsEnableClip(bool value) {
    m_isEnableClip = value;
    getHost()->touchRenderChanged();
}

int ssui::BasicClip::getClipType() const {
    return (int)m_clipType;
}

void ssui::BasicClip::setClipType(int value) {
    m_clipType = (E_ClipType)value;
    getHost()->touchRenderChanged();
}

int ssui::BasicClip::getClipCircleRadius() const {
    return m_clipCircleRadius;
}

void ssui::BasicClip::setClipCircleRadius(int value) {
    m_clipCircleRadius = value;
    getHost()->touchRenderChanged();
}

int ssui::BasicClip::getClipCircleOffsestX() const {
    return m_clipCircleOffsetX;
}

void ssui::BasicClip::setClipCircleOffsestX(int value) {
    m_clipCircleOffsetX = value;
    getHost()->touchRenderChanged();
}

int ssui::BasicClip::getClipCircleOffsestY() const {
    return m_clipCircleOffsetY;
}

void ssui::BasicClip::setClipCircleOffsestY(int value) {
    m_clipCircleOffsetY = value;
    getHost()->touchRenderChanged();
}

int ssui::BasicClip::getClipBeginAngle() const {
    return  m_clipBeginAngle;
}

void ssui::BasicClip::setClipBeginAngle(int value) {
    m_clipBeginAngle = value;
    getHost()->touchRenderChanged();
}

int ssui::BasicClip::getClipEndAngle() const {
    return m_clipEndAngle;
}

void ssui::BasicClip::setClipEndAngle(int value) {
    m_clipEndAngle = value;
    getHost()->touchRenderChanged();
}

BasicClip& ssui::BasicClip::assign(const BasicClip& other) {
    Base::assign(other);
    return *this;
}

void ssui::BasicClip::onClip(unsigned char drawStep) {
    if (getHost() == nullptr || m_isEnableClip == false) {
        return;
    }
    switch (m_clipType) {
        case ssui::ClipType_circle:
        {    // Բ��
            clipCircle();
            break;
        }
        case ssui::ClipType_roundedRectangle:
        { // Բ�Ǿ���
            clipRoundedRectangle();
            break;
        }
        case ssui::ClipType_sixAngleRhombus:
        { // ��������
            clipSixAngleRhombus();
            break;
        }
        case ssui::ClipType_custom:
        { // �Զ���
            clipCustom();
            break;
        }
        default:
        {
            clipDefault();
            break;
        }
    }
}

void ssui::BasicClip::applyClipToPosterity(Control* pPosterity) {
    if (m_isEnableClip == true) {
        applyClipToSelfChildGrandChildAndSoOn(pPosterity, getHost()->getParentArea());
    }
}

int ssui::BasicClip::getClipRoundedRadius() const {
    return m_clipRoundedRadius;
}

void ssui::BasicClip::setClipRoundedRadius(int value) {
    m_clipRoundedRadius = value;
}

void ssui::BasicClip::clipDefault() {
    Border renderArea;
    const auto& selfArea = getHost()->getSelfMeasure().m_srcArea;
    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
        GeometryManager::clipPolyImage(*it, selfArea);
    }
    for (auto& pComp : *getHost()) {
        for (auto& pChild : *pComp) {
            applyClipToSelfChildGrandChildAndSoOn(pChild, pChild->getParentArea());
        }
    }
}

void ssui::BasicClip::clipCircle() {
    //         for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
    //             GeometryManager::clipPolyImage(render, selfArea);
    //         }
    ft cx, cy;
    getHost()->getCenter(cx, cy);
    cx += (ft)m_clipCircleOffsetX;
    cy += (ft)m_clipCircleOffsetY;

    ft radius = (ft)m_clipCircleRadius;
    Point<ft> center = { cx, cy };

    ft dAngle = m_clipEndAngle - m_clipBeginAngle;
    if (dAngle > 359.5f) {
        Poly poly;
        //Բ���и�����
        GeometryManager::getPolyFromCircle(poly, center, radius);
        for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
            GeometryManager::clipPolyImage(*it, poly);
        }
        for (auto& pComp : *getHost()) {
            for (auto& pChild : *pComp) {
                applyClipToSelfChildGrandChildAndSoOn(pChild, poly);
            }
        }
    } else {
        static ArrayList<Poly> sArrClipPoly;
        sArrClipPoly.clear();
        Border aabb = getHost()->measure().m_srcArea;
        auto pGeoUnion = GeometryUnionPoly::createObject(sArrClipPoly);
        GeometryManager::getSector(pGeoUnion, center, m_clipCircleRadius, m_clipBeginAngle, m_clipEndAngle);
        pGeoUnion->refreshNull();
        //<inc>
        //             for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
        //                 GeometryManager::clipPolyImage(render, pGeoUnion);
        //             }
        for (auto& pComp : *getHost()) {
            for (auto& pChild : *pComp) {
                applyClipToSelfChildGrandChildAndSoOn(pChild, pGeoUnion);
            }
        }
    }
}

void ssui::BasicClip::clipRoundedRectangle() {
    Poly poly;
    ft cx, cy;
    getHost()->getCenter(cx, cy);
    cx += (ft)m_clipCircleOffsetX;
    cy += (ft)m_clipCircleOffsetY;
    ft radius = (ft)m_clipCircleRadius;
    Point<ft> center = { cx, cy };
    //Բ���и�����
    GeometryManager::getPolyFromRoundedRectangle(poly, center, radius, (ft)m_clipRoundedRadius);
    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
        GeometryManager::clipPolyImage(*it, poly);
    }
    for (auto& pComp : *getHost()) {
        for (auto& pChild : *pComp) {
            applyClipToSelfChildGrandChildAndSoOn(pChild, poly);
        }
    }
}

void ssui::BasicClip::clipSixAngleRhombus() {
    Poly poly;
    ft cx, cy;
    getHost()->getCenter(cx, cy);
    cx += (ft)m_clipCircleOffsetX;
    cy += (ft)m_clipCircleOffsetY;
    ft radius = (ft)m_clipCircleRadius;
    Point<ft> center = { cx, cy };
    //Բ���и�����
    GeometryManager::getPolyFromSixAngleRhombus(poly, center, radius);
    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
        GeometryManager::clipPolyImage(*it, poly);
    }
    for (auto& pComp : *getHost()) {
        for (auto& pChild : *pComp) {
            applyClipToSelfChildGrandChildAndSoOn(pChild, poly);
        }
    }
}

void ssui::BasicClip::clipCustom() {

}


