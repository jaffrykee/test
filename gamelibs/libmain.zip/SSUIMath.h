#pragma once
#include "SSUIPublic.h"

using namespace ss2;
using namespace gstl;

_SSUINamespaceBegin

class SSUIMath {
public:
    static ft restorePct(pct value);
    static bool getAttrBitValue(int attr, int bit);
    static void enableAttrBitValue(int& attr, int bit);
    static void disableAttrBitValue(int& attr, int bit);
    static void setAttrBitValue(int& attr, int bit, bool value);

    static bool getAttrBitValue(u8 attr, int bit);
    static void enableAttrBitValue(u8& attr, int bit);
    static void disableAttrBitValue(u8& attr, int bit);
    static void setAttrBitValue(u8& attr, int bit, bool value);

    static void getMulti(vec2& poi, f32 per);
    static void setColorFromArgb(Color& color, u32 value);
    static void assignPosition(mat4& mat, const ft x, const ft y, const ft z = 0.f);
    static void outMatPoi(const mat4& mat, const int lv = 3);
    static void sumPosition(mat4& mat, const ft x, const ft y, const ft z = 0.f);
    static bool getAttrGroupValue(const u32& attrGroup, int ag);
    static bool getAttrGroupValue(const u16& attrGroup, int ag);
    static bool getAttrGroupValue(const u8& attrGroup, int ag);
    static void enableAttrGroupValue(u32& attrGroup, int ag);
    static void enableAttrGroupValue(u16& attrGroup, int ag);
    static void enableAttrGroupValue(u8& attrGroup, int ag);
    static void disableAttrGroupValue(u32& attrGroup, int ag);
    static void disableAttrGroupValue(u16& attrGroup, int ag);
    static void disableAttrGroupValue(u8& attrGroup, int ag);
    static void setAttrGroupValue(u32& attrGroup, int ag, bool value);
    static void setAttrGroupValue(u16& attrGroup, int ag, bool value);
    static void setAttrGroupValue(u8& attrGroup, int ag, bool value);
    static void getMixColor(Color& ret, const Color& src, const Color& dst, MixColorRule_e mcr = MCR_Alpha);
    static void getMixColor(Color& src, const Color& dst, MixColorRule_e mcr = MCR_Alpha);
    static ft getDistance(ft ax, ft ay, ft bx, ft by);
    static ft ssAngleToCounterClockAngle(ft ssAngle);
    static void getCounterClockJoyStickValue(ft& angle, ft& strength, ft cx, ft cy, ft x, ft y, ft r);
    static void assignWithCheck(u16& dst, const s64& value);
    static void assignWithCheck(u8& dst, const s64& value);
    static void assignWithCheck(u32& dst, const s64& value);
};

_SSUINamespaceEnd
