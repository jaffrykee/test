#pragma once
#include "ObjectBase.h"
#include "LanguageManager.h"
#include "ResPool.h"
#include "ResPoolManager.h"
#include "DataManager.h"
#include "MeasureData.h"
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Skin;
class UIScene;
class EventNodeBase;
class UIComponent;
class BasicMeasure;
class BasicClip;
class BasicContent;
class BasicTransform;
class DataInfoAttr;
class Control : public ObjectBase {
    friend class UIScene;
public:
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(Control);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(Control, ObjectBase);
#pragma region "��������"
    enum StaticComponent_e {
        SC_BasicMeasure = 0,
        SC_BasicClip,
        SC_BasicContent,
        SC_MAX,
    };
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
public:
    static Control* createObject(const ArrayList<NodeType_e>& compInfo);
    static Control* createObject(NodeType_e compInfo[], int count);
    static Control* createObject(int ccit);
#pragma endregion

#pragma region "��Ա"
    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<DEV

public:
    ArrayList<UIComponent*> m_components;
    UIComponent* m_pParentComponent = nullptr;
    UIComponent* m_pChildrenComponent = nullptr;
public:
//     BasicMeasure* m_measureComponent = nullptr;
//     BasicTransform* m_transformComponent = nullptr;
    BasicClip* m_clipComponent = nullptr;
    BasicContent* m_contentComponent = nullptr;
public:
    HashMap<int, DataInfoAttr*> m_mapExpansionAttr;
public:
    MeasureData* m_pOuterMeasure = nullptr;
    MeasureData* m_pMeasure = nullptr;
    MeasureData* m_pInnerMeasure = nullptr;
    Texture m_texture;
    int m_curRenderCount = 0;
    ArrayList<PolyImage> m_arrRender;
public:
    union {
        struct {
            CCIT_e mt_dataCcit;// = CCIT_Panel
//Draw
            union {
                struct {
                    bool m_isPrepareDataReady : 1;
                    bool m_isMeasureReady : 1;
                    bool m_isRenderReady : 1;
                };
                unsigned char m_isDrawReady : 3;
            };
            //�ڱ�֡��Control������Render�׶Σ����ؼ�������ǵ�onChildrenTransformSuf���ܴ���δ�����ı任��
            bool m_isDidRender : 1;
            //���ؼ�����ready���ܽ�measure��״̬��Ϊready�����������
            bool m_isMustParentReady : 1;
            //Draw
            //Ϊtrueʱ���ܴ���DrawReady�ļ�����
            bool m_isLockDrawTouch : 1;
            //�������Ƿ񶼻����ˡ�
            bool m_isPosterityReady : 1;
            //ÿ���ӿؼ��������ٻ���һ�β��ܽ�measure��״̬��Ϊready���磺����Ӧ
            //bool m_isMustEachChildDrawAtLeastOnce : 1;
//PrepareData
            //WrapPanel + autoSizeΪ1��
            unsigned char m_measureReadyMinimumTimes : 2;
            union {
                struct {
                    bool m_isAutoWidthFrame : 1;
                    bool m_isAutoHeightFrame : 1;
                };
                unsigned char m_isAutoFrameData : 2;
            };
//             union {
//                 struct {
//                     bool m_isStaticWidthAndHaveRelativeChildX : 1;
//                     bool m_isStaticHeightAndHaveRelativeChildY : 1;
//                 };
//             };
//Normal
            bool mt_isEnableInput : 1;
            bool mt_isBlink : 1;
            bool mt_isCopyAdd : 1;      //�Ƿ���copyAndAddToFunc���ӵ�
            bool mt_isHidden : 1;
            bool m_isSkin : 1;
            bool m_isRefreshScrollStateReady : 1;
            unsigned char m_drawStep : 2;   //��ǰ�Ļ��ƴ�����

            bool m_isOwnEvent : 1;
            bool m_canTransHandle : 1;
            bool m_canTransScript : 1;
            bool m_nextUIevent : 1;
        };
        unsigned long long m_drawInitData = 0;
    };
	u8 mMeasureDir = DDR_LT; // �ؼ�����ڸ��ڵ����չ�����෴����
public:
    string* mt_pId = nullptr;
    UIScene* mt_pScene = nullptr;
    string sourceID = "";
public:
    SlotState m_arrSlotState[SLOT_MAX];
private:
    EventNodeGroup* mt_pDataEventGroup = nullptr;
    wstring* mt_pCsvData = nullptr;
    wstring* mt_pCommand = nullptr;   //�洢��������ֵ����
    string mt_selectBindingControlId;

    //mergeEx
private:
    string mt_importUIName = "";
#pragma endregion

#pragma region "����"

#pragma region "������Է���"
#pragma region "BasicMeasure"
public:
    //Absolute
    ft getAx() const;
    void setAx(ft value);
    ft getAy() const;
    void setAy(ft value);
    ft getAw() const;
    void setAw(ft value);
    ft getAh() const;
    void setAh(ft value);
    //Relative
    int getRx() const;
    void setRx(int value);
    int getRy() const;
    void setRy(int value);
    int getRw() const;
    void setRw(int value);
    int getRh() const;
    void setRh(int value);
    //AutoSize
    bool getIsAutoWidth() const;
    void setIsAutoWidth(bool value);
    bool getIsAutoHeight() const;
    void setIsAutoHeight(bool value);
    //AbsoluteCheck
    int getMinAw() const;
    void setMinAw(int value);
    int getMinAh() const;
    void setMinAh(int value);
    int getMaxAw() const;
    void setMaxAw(int value);
    int getMaxAh() const;
    void setMaxAh(int value);
    //RelativeCheck
    int getMinRw() const;
    void setMinRw(int value);
    int getMinRh() const;
    void setMinRh(int value);
    int getMaxRw() const;
    void setMaxRw(int value);
    int getMaxRh() const;
    void setMaxRh(int value);
    //Anchor
    int getAnchorRx() const;
    void setAnchorRx(int value);
    int getAnchorRy() const;
    void setAnchorRy(int value);
    //AbsoluteMargin
    int getAbsoluteMarginLeft() const;
    void setAbsoluteMarginLeft(int value);
    int getAbsoluteMarginTop() const;
    void setAbsoluteMarginTop(int value);
    int getAbsoluteMarginRight() const;
    void setAbsoluteMarginRight(int value);
    int getAbsoluteMarginBottom() const;
    void setAbsoluteMarginBottom(int value);
    //AbsolutePadding
    int getAbsolutePaddingLeft() const;
    void setAbsolutePaddingLeft(int value);
    int getAbsolutePaddingTop() const;
    void setAbsolutePaddingTop(int value);
    int getAbsolutePaddingRight() const;
    void setAbsolutePaddingRight(int value);
    int getAbsolutePaddingBottom() const;
    void setAbsolutePaddingBottom(int value);
#pragma endregion
#pragma region "BasicClip"
    bool getIsEnableClip() const;
    void setIsEnableClip(bool value);
    int getClipType() const;
    void setClipType(int value);
    int getClipRoundedRadius()const;
    void setClipRoundedRadius(int value);
    int getClipCircleRadius() const;
    void setClipCircleRadius(int value);
    int getClipCircleOffsestX() const;
    void setClipCircleOffsestX(int value);
    int getClipCircleOffsestY() const;
    void setClipCircleOffsestY(int value);
    int getClipBeginAngle() const;
    void setClipBeginAngle(int value);
    int getClipEndAngle() const;
    void setClipEndAngle(int value);
#pragma endregion
#pragma region "BasicTransform"
    float getAlpha() const;
    void setAlpha(float value);
    b2 getUpSideDown() const;
    void setUpSideDown(b2 value);
    b2 getMirror() const;
    void setMirror(b2 value);

    f32 getRadian() const;
    void setRadian(f32 value);
    f32 getScaleX() const;
    void setScaleX(f32 value);
    f32 getScaleY() const;
    void setScaleY(f32 value);
    f32 getOffsetX() const;
    void setOffsetX(f32 value);
    f32 getOffsetY() const;
    void setOffsetY(f32 value);
#pragma endregion
#pragma region "RadioButton"
    const string& getRadioId() const;
    void setRadioId(const string& value);
#pragma endregion
#pragma region "SkillButton"
    s32 getCdTime() const;
    void setCdTime(s32 value);
    s32 getRemainTime() const;
    void setRemainTime(s32 value);
    int getSkillButtonDirection() const;
    void setSkillButtonDirection(int value);
#pragma endregion
#pragma region "ScrollView"
    f32 getDamping() const;
    void setDamping(f32 value);
    f32 getStack() const;
    void setStack(f32 value);
    f32 getMinSpeed() const;
    void setMinSpeed(f32 value);
    f32 getPagePanelSpeed() const;
    void setPagePanelSpeed(f32 value);
    bool getIsPagePanel() const;
    void setIsPagePanel(bool value);
#pragma endregion  
#pragma region "Progress"
    float getMinValue() const;
    void setMinValue(float value);
    float getMaxValue() const;
    void setMaxValue(float value);
    float getCurValue() const;
    void setCurValue(float value);
    int getProgressDirection() const;
    void setProgressDirection(int value);
    float getChangedRate() const;
    void setChangedRate(float value);
    float getChangedSpeed() const;
    void setChangedSpeed(float value);
#pragma endregion  
#pragma region "VirtualJoystick"
    int getJoystickId() const;
    void setJoystickId(int value);
    int getJoystickR() const;
    void setJoystickR(int value);
#pragma endregion
#pragma region "TimeContent"
    const wstring& getTimePattern() const;
    void setTimePattern(const wstring& value);
    int getTimeOrder() const;
    void setTimeOrder(int value);
    int getTimeType() const;
    void setTimeType(int value);
    int getDataDays() const;
    void setDataDays(int value);
    int getDataHours() const;
    void setDataHours(int value);
    int getDataMinutes() const;
    void setDataMinutes(int value);
    int getDataSeconds() const;
    void setDataSeconds(int value);
    int getDataMSs() const;
    void setDataMSs(int value);

    s64 getTimeOut() const;
    void setTimeOut(s64 value);
    s64 getCurTime() const;
    void setCurTime(s64 value);
    bool getIsStart() const;
    void setIsStart(bool value);

    b2 getFullDisplayNumber() const;
    void setFullDisplayNumber(b2 value);
    b2 getHideLastUnitText() const;
    void setHideLastUnitText(b2 value);
    s32 getMaxDisplaySectionNumber() const;
    void setMaxDisplaySectionNumber(s32 value);
#pragma endregion
#pragma region "StackPanel"
    BoloObject* getSelectControlObject() const;
    void setSelectControlObject(BoloObject* value);
    ft getDataRowSpacing() const;
    void setDataRowSpacing(ft value);
    ft getDataColumnSpacing() const;
    void setDataColumnSpacing(ft value);
    int getDataDirection() const;
    virtual void setDataDirection(int value);
#pragma endregion
#pragma region "TextFlow"
    ft getTextAx() const;
    void setTextAx(ft value);
    ft getTextAy() const;
    void setTextAy(ft value);
    int getTextRx() const;
    void setTextRx(int value);
    int getTextRy() const;
    void setTextRy(int value);
    int getTextAnchorRx() const;
    void setTextAnchorRx(int value);
    int getTextAnchorRy() const;
    void setTextAnchorRy(int value);
    void setTextTips(const wstring& tipsText);
    const wstring& getTextTips() const;
    s32 getCurConvertIndex() const;
    void setCurConvertIndex(s32 value);
    const string& getLinkSkin() const;
    void setLinkSkin(const string& value);
    b2 getIsPassword() const;
    void setIsPassword(b2 value);
    b2 getIsSingleLine() const;
    void setIsSingleLine(b2 value);
#pragma endregion
#pragma region "DrawModel"
    const string& getModelBackPrefab() const;
    void setModelBackPrefab(const string& value);
    const string& getModelScaleAndAngle() const;
    void setModelScaleAndAngle(const string& value);
    const string& getModelScaleStr() const;
    void setModelScaleStr(const string& value);
    const string& getModelAngleStr() const;
    void setModelAngleStr(const string& value);
    const string& getModelOffset() const;
    void setModelOffset(const string& value);
    void setModelId(u32 value);
    u32 getModelId() const;
#pragma endregion
#pragma endregion

public:
    Control& assign(const Control& other);
    virtual int addDataChild(DataInfoNode& childData) override;
    virtual void onEvent(SSUIEvent& event) override;
	virtual void onEventEnd(SSUIEvent& event);
	void setEventType(SSUIEvent& event, const s32 type);
    b2 checkCanEvent();
public:
    DataInfoAttr* getExpansionAttr(AttrType_e attrIndex);
    int getExpansionAttrS32(AttrType_e attrIndex);
    void setExpansionAttr(DataInfoAttr* pAttrInfo);
    void setExpansionAttr(AttrType_e attrIndex, int value);
public:
    void pushRender(const PolyImage& render);
    PolyImage& nextRender();
    void swap(ArrayList<PolyImage>& renderCache);

#pragma region "Parent, Components(ccit), Children"
public:
    UIComponent* getParentComponent() const;
    Control* getParent() const;
    BoloObject* getParentObject() const;
    void setParentObject(BoloObject* value);
    void setParent(Control* value);
public:
    UIComponent** begin() const;
    UIComponent** end() const;
    void addComponent(UIComponent* pComp);
    BasicContent* enableBasicContent();
    void disableBasicContent();
    void releaseAllComponents();
    bool releaseComponent(UIComponent* pComp);
    bool releaseComponentByClass(NodeType_e nodeType);
    bool releaseComponentByType(NodeType_e nodeType);
    UIComponent* getComponent(NodeType_e nodeType) const;
    UIComponent* getComponentByClass(NodeType_e nodeType) const;
    BasicMeasure* getBasicMeasure() const;
    BasicClip* getBasicClip() const;
    bool isEnableClip() const;
    BasicContent* getBasicContent() const;
    BasicTransform* getBasicTransform( ) const;
    void setChildrenComponent(UIComponent* pCtnComp);
    int getDataCcit() const;
    void setDataCcit(int value);
public:
    const ArrayList<Control*>& getChildren() const;
    ArrayList<Control*>& children();
    void addChild(Control* pChild, UIComponent* pParentComp);
    void addChild(Control* pChild);
    void removeChildFunc(Control** ppChild, bool isRelease);
    void removeChild(Control* pChild);
    virtual void deleteAllAddChild();
    virtual void deleteAddChild(Control* pChild);
    virtual void deleteAddChildWithID(const string& name);
    virtual void deleteImportChild(const string& name);
    virtual void deleteAllImportChild();
    void releaseChildren();
    void releaseChildrenClass(NodeType_e nodeType);
    void deleteChild(Control* pChild);
public:
    int getAddControlCount();
    int getVControlCount();
    Control* getVControlWithIndex(int index);
    Control* getControlWithIndex(int index);
    int getControlIndexWithID(const string& id);
    int getVControlIndexWithID(const string& id);
    bool setControlIndex(Control* ctrl, int index);
#pragma endregion

#pragma region "Draw"
public:
    void touchPrepareDataChanged();
    void touchMeasureChanged();
    void touchRenderChanged();
    void touchPosterityChanged();
    void onDrawChanged();
    bool isDrawReady();
    void assignAllDrawChanged();
    void touchAllChildrenDrawChanged();
    void assignAllDrawReady();
public:
    ParentAreaType_e getParentAreaType() const;
    const Border& getParentArea() const;
    MeasureData& measure();
    const MeasureData& getSelfMeasure() const;
    const MeasureData& getOuterMeasure() const;
    const MeasureData& getInnerMeasure() const;
    const MeasureData& getMeasure(ParentAreaType_e pat) const;
    bool isHaveOuterMeasure() const;
    bool isHaveInnerMeasure() const;
public:
    //����������Եȡ�
    bool isWaitingParentMeasureReady() const;
public:
    void onDraw(unsigned char drawStep);
    bool onDrawComponents(unsigned char drawStep, bool isReDraw);
    //��Ҫ����Ϊ�л�״̬�����µ��ӽڵ�任��׼�����Լ������ȷ�����ԡ�
    void initPrepareData();
    void onPrepareData();
    void initMeasure();
    //drawStep�ǻ��ƵĽ׶Σ��������Գ���autoSizeΪĿ�ĵĵ�0�׶Σ��������Ѿ������autoSize�����������autoSize�ĵ�1�׶Ρ�
    //times������Ϊ��û����ȫ׼����ʱ����Ҫ���»���selfControl��onMeasureʱ�򣬽��е��ڼ���selfControl��onMeasure�ˡ�
    void onMeasure(unsigned char drawStep, int times = 0);
    void initRender();
    void onRender(unsigned char drawStep);
    void onTransformAndClipPosterityByParentArea(Control* pPosterity);
    void onShow();
public:
    void refreshScrollState();
public:
    //�ɼ�������ֵ��
    bool getRealVisible() const;
    bool getDataIsVisible() const;
    void setDataIsVisible(bool value);
    void onDataVisibleChangedFunc();
    ft getDrawX() const;
    ft getDrawY() const;
    ft getDrawWidth() const;
    ft getDrawHeight() const;
#pragma endregion

#pragma region "transform"
public:
    void transformPosition(ft x, ft y);
#pragma endregion

#pragma region "Id, Scene"
public:
    const string& getId() const;
    void setId(const string& value);
    void setIdJustData(const string& value);

    UIScene* getScene() const;
    BoloObject* getSceneObject() const;
    void setScene(UIScene* pScene);
#pragma endregion

#pragma region "event"
public:
	b2 getIsOwnEvent() const;
	void setIsOwnEvent(b2 value);
	b2 getCanTransHandle() const;
	void setCanTransHandle(b2 value);
	b2 getCanTransScript() const;
	void setCanTransScript(b2 value);
    b2 getNextUIEvent() const;
    void setNextUIEvent(b2 value);
#pragma endregion

#pragma region "Skin, Text, Input"
public:
    const string& getSkinName() const;
    void setSkinName(const string& value);
    const string& getBeforeSkinName(const string& value) const;
    void addBeforeSkinName(const string& value);
public:
    const wstring& getText() const;
    void setText(const wstring& value);
    const wstring& getTextKey() const;
    void setTextKey(const wstring& value);
public:
    bool getIsInput() const;
    void setIsInput(bool value);
public:
    Skin* getSkin() const;
    const string& getSkinGroupOfCurSkin() const;
#pragma endregion

#pragma region "Slot, State"
public:
    SlotState getDataSlotState(SlotType_e slot) const;
    bool getDataIsEnable() const;
    void setDataIsEnable(bool value);
    bool getDataSlotIsEnable(SlotType_e slot) const;
    void setDataSlotIsEnable(SlotType_e slot, bool value);

    bool getDataIsPressed() const;
    void setDataIsPressed(bool value);
    bool getDataSlotIsPressed(SlotType_e slot) const;
    void setDataSlotIsPressed(SlotType_e slot, bool value);

    bool getDataIsSelected() const;
    void setDataIsSelected(bool value);
    void setDataIsSelectedNonScript(bool value);
    bool getDataSlotIsSelected(SlotType_e slot) const;
    void setDataSlotIsSelected(SlotType_e slot, bool value);
    void setSelectBindingControlId(const string& value);

    bool getDataIsBlink() const;
    void setDataIsBlink(bool value);
#pragma endregion

#pragma region "Event, Script, Csv"
public:
    EventNodeGroup* getEventNodeGroup() const;
    void setControlScript(EventType_e type, const wstring& scriptStr, bool isClear = true);
    void setControlScript(const string& type, const wstring& scriptStr, bool isClear = true);
    inline const string& getParentId( ) const {
        if ( getParent( ) ) {
            return getParent( )->getId( );
        }
        else {
            return StringManager::getInstance( )->mc_strNullDef;
        }
    }
    bool getIsCopyAdd() const;
    void setIsCopyAdd(bool value);
    void setsourceID(const string& sourceID);
    string getsourceID();
    const string& getImportUIName() const;
    void setImportUIName(const string& value);
public:
    const wstring& getDataCsvData() const;
    void setDataCsvData(const wstring& value);
    const wstring& getDataCommand() const;
    void setDataCommand(const wstring& value);
    int parseCsvValue1(const wstring& data);
    int parseCsvValue2(const wstring& data);
    int parseCsvWordList(ArrayList<wstring>* pWordList);
    void parseCommand(const wstring& value);
    void parseDataCSvData(const wstring& value);
public:
    bool isIn(ft x, ft y) const;
    bool isIn(ft x, ft y, ParentAreaType_e pat) const;
#pragma endregion

#pragma region "UI�༭��"
    void refreshSsueControls(ft x, ft y);
    void appendOutline(Poly& poly) const;
    void appendOutlineForeach(ArrayList<Poly>& arrPoly) const;
    void getOutline(Poly& poly) const;
    void getCenter(ft& cx, ft& cy);
#pragma endregion

public:
    virtual void debugString(string& outString) override;
    virtual void treeString( string& outString, int step ) override;

#pragma endregion
};

_SSUINamespaceEnd
