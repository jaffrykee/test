#pragma once
#include "StackPanel.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class AutoGrid : public StackPanel {
public:
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(AutoGrid);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(AutoGrid, StackPanel);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    //������
    s8 mt_dataGridCount = 1;

public:
    //�и�
    ArrayList<RowHy> m_drawRowHy;
    //�п�
    ArrayList<ColumnWx> m_drawColumnWx;

private:
    s16 m_drawRowCount = 0;
    s16 m_drawColumnCount = 0;

#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    inline int getDataGridCount() const {
        return mt_dataGridCount;
    }
    inline void setDataGridCount(int value) {
        if (value <= 0) {
            value = 1;
        }
        if (mt_dataGridCount != value) {
            mt_dataGridCount = value;
            getHost()->touchMeasureChanged();
        }
    }
    inline virtual void setDataDirection(int value) override {
        if (value <= 0) {
            //DDR_LT/DR_T
            value = 1;
        }
        if (mt_dataDirection != value) {
            mt_dataDirection = value;
            getHost()->touchMeasureChanged();
        }
    }
public:
    inline int getDrawRowCount() const {
        return m_drawRowCount;
    }
    inline int getDrawColumnCount() const {
        return m_drawColumnCount;
    }
#pragma endregion

public:
    inline AutoGrid& assign(const AutoGrid& other) {
        Base::assign(other);
        return *this;
    }
    //�Ƿ��Ⱥ�������
    inline virtual bool getIsHorizontal() const override {
        return getDataDirection() & 0x01;
    }
    //�Ƿ������ٺᡣ
    inline virtual bool getIsVertical() const override {
        return !getIsHorizontal();
    }
    inline virtual bool getIsLeft() const override {
        //��λΪ0���ߵ�λΪ0��
        return ((!(getDataDirection() & 0xf0)) || (!(getDataDirection() & 0x0f)));
    }
    inline virtual bool getIsTop() const override {
        //��λΪ1���ߵ�λΪ1��
        return ((getDataDirection() & 0xf0) == 0x10) || ((getDataDirection() & 0x0f) == 0x01);
    }
    void refreshChildSizeCache();

#pragma region "��˽��"
private:
    inline void getHorizontalNextRowAndColumn(int& curRow, int& curColumn, b2& rowChanged, b2& colChanged) {
        curColumn++;
        colChanged = true;
        if (!(curColumn = curColumn % mt_dataGridCount)) {
            curRow++;
            rowChanged = true;
        } else {
            rowChanged = false;
        }
    }
    inline void getVerticalNextRowAndColumn(int& curRow, int& curColumn, b2& rowChanged, b2& colChanged) {
        curRow++;
        rowChanged = true;
        if (!(curRow = curRow % mt_dataGridCount)) {
            curColumn++;
            colChanged = true;
        } else {
            colChanged = false;
        }
    }
    inline void refreshRowAndColumnXY() {
        if (getIsLeft()) {
            for (int i = 1; i < m_drawColumnCount && i < m_drawColumnWx.size(); i++) {
                m_drawColumnWx[i].m_x += (m_drawColumnWx[i - 1].m_x + m_drawColumnWx[i - 1].m_w + getDataColumnSpacing());
            }
        } else {
            for (int i = m_drawColumnCount - 2; i >= 0; i--) {
                if ((i + 1) < m_drawColumnWx.size()) {
                    m_drawColumnWx[i].m_x += (m_drawColumnWx[i + 1].m_x + m_drawColumnWx[i + 1].m_w + getDataColumnSpacing());
                }
            }
        }
        if (getIsTop()) {
            for (int i = 1; i < m_drawRowCount && i < m_drawRowHy.size(); i++) {
                m_drawRowHy[i].m_y += (m_drawRowHy[i - 1].m_y + m_drawRowHy[i - 1].m_h + getDataRowSpacing());
            }
        } else {
            for (int i = m_drawRowCount - 2; i >= 0; i--) {
                if ((i + 1) < m_drawRowHy.size()) {
                    m_drawRowHy[i].m_y += (m_drawRowHy[i + 1].m_y + m_drawRowHy[i + 1].m_h + getDataRowSpacing());
                }
            }
        }
    }
#pragma endregion

#pragma endregion
};

_SSUINamespaceEnd
