#pragma once
#include "ObjectBase.h"
#include "MeasureData.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ShapeBase;
class Control;
class AreaBase;
class EventNodeGroup;
class Control;
class DataInfoNode;
class Skin;
class UIComponent : public ObjectBase {
    friend class Control;
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UIComponent);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(UIComponent, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static ArrayList<Control*> s_nullContainer;
    static const ArrayList<SlotType_e> sc_nullSlotList;
private:
    static ArrayList<SlotType_e> s_arrSlotList[SLOT_MAX];
public:
    static s16 s_clickTolerance;
#pragma endregion

#pragma region "��̬����"
public:
    static const ArrayList<SlotType_e>& getSlotListDef(SlotType_e slot);
#pragma endregion

#pragma region "��Ա"
private:
    Control* m_pHost = nullptr;
    b2 m_canTriggerScript = true;
    b2 m_isTriggerScript = false;
#pragma endregion

#pragma region "����"
public:
    UIComponent& assign(const UIComponent& other);
    virtual void onEvent(SSUIEvent& event) override;
    virtual b2 onEventScript(SSUIEvent& event) ;
    virtual b2 canTriggerScript();
    virtual void setCanTriggerScript(b2 value);
    b2 getIsTriggerScript() const;
    virtual int addDataChild(DataInfoNode& childData) override;

    Control* getHost() const;
    void setHost(Control* pHost);
    bool isEnableContainer();
    const ArrayList<Control*>& getContainer() const;
    virtual ArrayList<Control*>& container();
    Control** begin();
    Control** end();
    virtual int addChild(Control* pChild);
    void releaseChildren();
    virtual ParentAreaType_e getParentAreaType() const;
    virtual const MeasureData& getSelfMeasure() const;
    virtual const MeasureData& getOuterMeasure() const;
    virtual const MeasureData& getInnerMeasure() const;
    virtual const MeasureData& getMeasure(ParentAreaType_e pat) const;
    virtual const Border& getChildArea(const Control* pChild) const;
    //�������ǲ��ǿ�����Ϊ�ӽڵ�����������������ݵ�������
    virtual bool isContainerComponent() const;
    virtual bool isTouchComponent() const;

    ft getSelfDrawX() const;
    ft getSelfDrawY() const;
    ft getSelfWidth() const;
    ft getSelfHeight() const;
public:
    virtual const ArrayList<SlotType_e>& getSlotList() const;
    virtual EventNodeGroup* getEventNodeGroup() const;
public:
    void touchPrepareDataChanged();
    void touchMeasureChanged();
    void touchRenderChanged();
    UIScene* getScene();
    virtual bool isIn(ft x, ft y) const;
public:
    //virtual void isChild
public:
    virtual bool onDrawChildren(unsigned char drawStep, bool isReDraw);
    virtual void onChildrenTransformSuf(unsigned char drawStep, bool isReDraw) {}
    virtual void onTransformChildren(unsigned char drawStep) {}
    virtual void onPrepareData();
    virtual void onChildPrepareData() {}
    virtual void onMeasure(unsigned char drawStep) {}
    virtual void onRender(unsigned char drawStep) {}
    virtual void onTransform(unsigned char drawStep) {}
    virtual void onClip(unsigned char drawStep) {}
    virtual void applyClipToPosterity(Control* pPosterity) {}
    virtual void applyTransformToPosterity(Control* pPosterity) {}
    virtual void onShow();
    virtual void onSelect() {};    //select true֮����
public:
    SlotState getDrawState(SlotType_e slot) const;
    void addSlotChildren(Skin* pSkin, SlotType_e slot);
public:
    //public func
    void applyTransformToSelfChildGrandChildAndSoOn(Control* pSelf, ft x, ft y);
    void applyClipToSelfChildGrandChildAndSoOn(Control* pSelf, const Border& rect);
    void applyClipToSelfChildGrandChildAndSoOn(Control* pSelf, const Poly& polyClip);
    void applyClipToSelfChildGrandChildAndSoOn(Control* pSelf, const Geometry* pGeo);
    void applyChildTransformPolyImage(Control* pSelf, ft cX, ft cY, ft scaleX, ft scaleY, ft radian, ft alpha);
    virtual void treeString(string& outString, int step) override;
};

_SSUINamespaceEnd
