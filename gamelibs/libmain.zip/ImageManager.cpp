#include "ImageManager.h"
//#include "TextureManager.h"

HashMap<strHash, UITexture*> ImageManager::s_mapTexture;
HashMap<strHash, UITexture*> ImageManager::s_mapUsingTexture;
string ImageManager::st_artistPath;
string ImageManager::st_freePath;
string ImageManager::st_imagePath = "images/";
string ImageManager::st_skinPath = "skin/";
string ImageManager::st_imageOffsetPath;
//bool ImageManager::s_isInMod = false;

void ImageManager::useTexture(Texture& tex, const string& imageName, const bool isFromMod, const string& imagePath, const string& extension) {
    if (isFromMod) {
        //string iName = string("images/") + imageName + extension;
        string iName = getImagePath() + imageName + ".tga";
        tex = Texture::get(iName);
        if (!tex.getIsLoadingReady()) {
            string iBmpName = getImagePath() + imageName + ".bmp";
            tex = Texture::get(iBmpName);
        }
    } else {
        string _imageName = imageName;
        if (getImageOffsetPath().empty()) {
            _imageName = util::lowcase(_imageName);
        }
        ArrayList<string> sts;
        util::split(_imageName, '.', sts);
        string bmpName = _imageName;
        if (sts.size() < 2) {
            _imageName += extension;
            bmpName += ".bmp";
        }
        string p = getImageOffsetPath() + imagePath + _imageName;
        if (getImageOffsetPath().empty()) {
            // p = p;
        }
        tex = Texture::get(p);
        if (!tex.getIsLoadingReady()) {
            string p2 = getImageOffsetPath() + imagePath + bmpName;
            tex = Texture::get(p2);
        }
    }
}
