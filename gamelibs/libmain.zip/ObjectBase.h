#pragma once
#include "BoloObject.h"
//#include "Graphics.h"
//#include "XmlParser.h"
#include "BoloScriptManager.h"
#include "SortedSet.h"
#include "ssuiBasic.h"
#include "NodeManager.h"
#include "DataManager.h"
#include "ResPoolManager.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin
class EventNodeBase;
class DataInfoAttr;
class DataInfoNode;
class AttrSetting;
class NodeTypeSetting;
class ObjectBase : public BoloObject {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ObjectBase)

#pragma region "��������"
public:
    using Base = BoloObject;
#pragma endregion

#pragma region "��̬��Ա"
public:
    static HashMap<strHash, BoloVar>* s_pUserAttrMapNull;
#pragma endregion

#pragma region "��̬����"
public:
    inline static ObjectBase* getInitNode(NodeType_e nodeType) {
        return DataManager::getInstance()->getInitNode(nodeType);
    }
    inline static ObjectBase* createObject(NodeType_e nodeType) {
        return getInitNode(nodeType)->createCopy();
    }
    static ObjectBase* createObject(const DataInfoNode& data, bool isSetData = true);
    //��objType�ǲ���baseType�ĵ������ࡣ
    inline static bool is(NodeType_e nodeType, NodeType_e baseType) {
        return getInitNode(nodeType)->is(baseType);
    }
    inline static NodeType_e getBaseType(NodeType_e childType) {
        return getInitNode(childType)->getBaseType();
    }
    inline static void destroyFunc() {

    }
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
    //ObjectBase��ȡ����������ͨ�ú�������
public:
    template<typename DataType, AttrDataType_e adt, typename pGetFuncType>
    int getAttrValue(AttrSetting* pAs, DataType& retValue);

    template<typename DataType, AttrDataType_e adt, typename pSetFuncType>
    int setAttrValue(AttrSetting* pAs, const DataType& value, DataInfoAttr* pAttrInfo = nullptr);

    template<typename DataType, AttrDataType_e adt, typename pGetFuncType>
    int getAttrValue(const wstring& attrName, DataType& retValue);

    template<typename DataType, AttrDataType_e adt, typename pSetFuncType>
    int setAttrValue(const wstring& attrName, const DataType& value);

//     OBJECTBASE_ATTRFUNC_DECLARATION(int, S32);
//     OBJECTBASE_ATTRFUNC_DECLARATION(u32, U32);
//     OBJECTBASE_ATTRFUNC_DECLARATION(s64, S64);
//     OBJECTBASE_ATTRFUNC_DECLARATION(b2, B2);
//     OBJECTBASE_ATTRFUNC_DECLARATION(f32, F32);
//     OBJECTBASE_ATTRFUNC_DECLARATION(f64, F64);
//     OBJECTBASE_ATTRFUNC_DECLARATION(string, STR);
//     OBJECTBASE_ATTRFUNC_DECLARATION(wstring, WSTR);

public:
    //UI�༭���ã�Ψһ���id
    s64 getSsueId() const;
    void setSsueId(s64 value);
protected:
    virtual void createSelf();
    virtual void disposeSelf();
public:
    //��other����this��
    inline ObjectBase& assign(const ObjectBase& other) {
        return *this;
    }
    inline virtual void assign(ObjectBase* pSrc) {
        ObjectBase::assign(*pSrc);
    }
    inline virtual int addDataChild(DataInfoNode& childData) {
        return -1;
    }
    virtual int setData(const DataInfoNode& dataNode);
    inline virtual void create() {
        ObjectBase::createSelf();
    }
    inline virtual void assignInitNode() {
        this->create();
    }
    inline virtual void dispose() {
        ObjectBase::disposeSelf();
    }
    ObjectBase();
    inline virtual ~ObjectBase() {
        ObjectBase::disposeSelf();
    }
    inline virtual NodeType_e getBaseType() const {
        return NT_MAX;
    }
    inline virtual const string& getBaseClassName() const {
        return StringManager::getInstance()->mc_strBoloObject;
    }
    inline virtual const wstring& getBaseClassNameW() const {
        return StringManager::getInstance()->mc_wstrBoloObject;
    }
    inline virtual bool enableUserAttr() const {
        return false;
    }
    inline virtual HashMap<strHash, BoloVar>*& userAttrMap() {
        return s_pUserAttrMapNull;
    }
    inline virtual HashMap<strHash, BoloVar>* getUserAttrMap() const {
        return s_pUserAttrMapNull;
    }
    inline virtual BoloVar getUserAttr(strHash nameHash) const {
        if (getUserAttrMap() == nullptr) {
            //null
            return BoloVar();
        }
        const auto& pairUserAttr = getUserAttrMap()->find(nameHash);
        if (pairUserAttr != getUserAttrMap()->end()) {
            return pairUserAttr->second;
        }
        return BoloVar();
    }
    inline void triggerUserAttrSetter(strHash nameHash, const BoloVar& oldValue, const BoloVar& newValue) {
        if (is(NT_Control)) {

        }
    }
    inline virtual void setUserAttr(strHash nameHash, const BoloVar& value) {
        if (enableUserAttr() == false) {
            return;
        }
        if (userAttrMap() == nullptr) {
            userAttrMap() = RPM::s_rpMapUserAttr.createObject();
            userAttrMap()->insert(nameHash, value);
        } else {
            const auto& pairUserAttr = userAttrMap()->find(nameHash);
            if (pairUserAttr != userAttrMap()->end()) {
                pairUserAttr->second = value;
            } else {
                userAttrMap()->insert(nameHash, value);
            }
        }
    }
public:
    inline ObjectBase* createCopy() {
        auto pCopy = createCurObject();
        pCopy->assign(this);
        return pCopy;
    }
public:
    //�ж���������ǲ����������ͣ��������ĵ��������͡�
    inline bool is(NodeType_e type) const {
        return getNodeInheritData()[type];
    }
    bool checkValidity(AttrSetting* pAs, AttrDataType_e dataType);
    int dealAttrValueFromAttrData(AttrSetting* pAs, AttrDataType_e dataType);
    int setAttrValue(AttrSetting* pAs, AttrDataType_e dataType, const wstring& attrValue);
    int setAttrValue(DataInfoAttr* pAttrRow);
    int setAttrValue(const wstring& attrName, const wstring& attrValue);

    virtual void onEvent(SSUIEvent& event);
public:
    virtual void debugString(string& outString) {}
    virtual void treeString(string& outString, int step) {}
    virtual void printData(PrintDataType_e pdt = PDT_Debug);
#pragma endregion
};

_SSUINamespaceEnd
