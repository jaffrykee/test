#pragma once
#include "ObjectBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class SkinRow;
class ShapeGroup;
class Skin : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(Skin);
protected:
    inline virtual void createSelf() override {
        memset(m_arrShapeGroup, 0, sizeof(m_arrShapeGroup));
    }
    inline virtual void disposeSelf() override {
        releaseShapeData();
    }
    NODETYPE_COMMON_PART_DECLARATION_END(Skin, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
    const static string* s_pTmpLastSkinName;
    const static string* s_pTmpLastLanguage;
    const static string* s_pTmpLastTheme;
    static ArrayList<string> s_tmpSplitSkinNameList;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    SkinRow* m_pRow = nullptr;
    ShapeGroup* m_arrShapeGroup[SLOT_MAX][STATE_MAX];
#pragma endregion

#pragma region "����"
public:
    void releaseShapeData();
    Skin& assign(const Skin& other);
    virtual int addDataChild(DataInfoNode& childData) override;
    const string& getName() const;
    void setName(const string& value);
#pragma endregion
};

_SSUINamespaceEnd
