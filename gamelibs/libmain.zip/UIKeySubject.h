#pragma once
#include "ObjectBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class UIKeySubject : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UIKeySubject)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(UIKeySubject, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    string mt_xml = "";
	s32 mt_priority = -1;
	string mt_currency = "";
	b2 mt_isNonEvent = false;
	b2 mt_isBag = false;
	b2 mt_canShowFloat = false;
	b2 mt_canMoveRole = false;
public:
	inline int getKey() const {
		return mt_xml.hashCode();
	}
	inline const string& getXml() const {
		return mt_xml;
	}
	inline void setXml(const string& str) {
		mt_xml = str;
	}
    inline const string& getCurrency() const {
        return mt_currency;
    }
	inline void setCurrency(const string& str) {
		mt_currency = str;
	}
	inline s32 getPriority() const {
		return mt_priority;
	}
	inline void setPriority(s32 pri) {
		mt_priority = pri;
	}
	inline b2 getIsNonEvent() const {
		return mt_isNonEvent;
	}
	inline void setIsNonEvent(b2 is) {
		mt_isNonEvent = is;
	}
	inline b2 getIsBag() const {
		return mt_isBag;
	}
	inline void setIsBag(b2 is) {
		mt_isBag = is;
	}
	inline b2 getCanShowFloat() const {
		return mt_canShowFloat;
	}
	inline void setCanShowFloat(b2 is) {
		mt_canShowFloat = is;
	}
	inline b2 getCanMoveRole() const {
		return mt_canMoveRole;
	}
	inline void setCanMoveRole(b2 is) {
		mt_canMoveRole = is;
	}
#pragma endregion

#pragma region "����"
public:
    inline UIKeySubject& assign(const UIKeySubject& other) {
        Base::assign(other);
        return *this;
    }
#pragma endregion
};

_SSUINamespaceEnd
