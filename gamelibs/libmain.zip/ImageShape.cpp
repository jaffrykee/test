#include "ImageShape.h"
#include "GeometryManager.h"
#include "ImageManager.h"
#include "Control.h"
#include "BasicTransform.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ImageShape, 500, 1500);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("imageName", ImageName, ImageShape, STR);
NODEBASE_ATTR_REGISTER( "gray", Gray, ImageShape, F32 );
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ImageShape)
NBSCRIPT_ATTR_REGISTER("imageName", ImageName, ImageShape, STR);
NBSCRIPT_ATTR_REGISTER( "gray", Gray, ImageShape, F32 );

NODETYPE_COMMON_PART_DEFINITION_END

ImageShape& ssui::ImageShape::assign(const ImageShape& other) {
    Base::assign(other);
    mt_gray = other.mt_gray;
    mt_textureKey = other.mt_textureKey;
    mt_subImageKey = other.mt_subImageKey;
    return *this;
}

float ssui::ImageShape::getGray( ) const {
    return mt_gray;
}

void ssui::ImageShape::setGray( float value ) {
    value = math::clamp(value, 0.0f, 1.0f);
    if ( !math::equal( mt_gray, value ) ) {
        mt_gray = value;
        touchRenderChanged( );
    }
}

int ssui::ImageShape::getTextureKey() const {
    return mt_textureKey;
}

int ssui::ImageShape::getSubImageKey() const {
    return mt_subImageKey;
}

const string& ssui::ImageShape::getImageName() const {
    //assert(false);
    return StringManager::getInstance()->mc_strNullDef;
}

void ssui::ImageShape::setImageName(const string& value) {
    StringManager::getInstance()->m_arrTmpSplit.clear();
    util::split(value, StringManager::getInstance()->mc_wcPeriod, StringManager::getInstance()->m_arrTmpSplit);
    if (StringManager::getInstance()->m_arrTmpSplit.size() >= 2) {
        StringManager::getInstance()->m_tmpString = util::lowcase(StringManager::getInstance()->m_arrTmpSplit[0]);
        mt_textureKey = StringManager::getInstance()->m_tmpString.hashCode();
        mt_subImageKey = StringManager::getInstance()->m_arrTmpSplit[1].hashCode();
    }
    touchRenderChanged();
}

ssui::ParentAreaType_e ssui::ImageShape::getParentAreaType() const {
    return PAT_self;
}

void ImageShape::onRender(unsigned char drawStep) {
    CheckHidden();
    //releaseSrcDrawNodeList();
    auto pSubImage = ImageManager::getSubImage(getTextureKey(), getSubImageKey());
    if (pSubImage == nullptr || pSubImage->getTexture() == nullptr || pSubImage->getTexture()->m_texture.getIsLoadingReady() == false
        || getSelfMeasure().isNull()) {
        return;
    }

    //for (auto it = getHost( )->m_arrRender.begin(); it < getHost( )->m_arrRender.begin() + getHost( )->m_curRenderCount; ++it) {
    //    if ( e.size( ) == 4 ) {
    //        if ( getHost()->getBasicTransform()->getUpSideDown() ) {
    //            algo::swap( e[0].texCoord.y, e[2].texCoord.y );
    //            algo::swap( e[1].texCoord.y, e[3].texCoord.y );
    //        }

    //        if ( getHost()->getBasicTransform()->getMirror() ) {
    //            algo::swap( e[0].texCoord.x, e[2].texCoord.x );
    //            algo::swap( e[1].texCoord.x, e[3].texCoord.x );
    //        }
    //    }

    //    for ( VertexPosColorTex& t : e ) {
    //        t.color.a = getHost()->getBasicTransform()->getAlpha();
    //    }
    //}

    auto& render = getHost()->nextRender();
    const Size srcArea(getSelfMeasure().m_srcArea);
    getHost()->m_texture = pSubImage->getTexture()->m_texture;
    pSubImage->getPolyImageFromSize(render, srcArea, COLOR_V(Color::white));
    return;
}

void ssui::ImageShape::onShow() {
    if (getHost() == nullptr) {
        return;
    }
    for (int i = 0; i < getHost()->m_arrRender.size(); i++) {
        auto& render = getHost()->m_arrRender[i];
        if (getHost()->m_texture != nullptr && render.size() > 3) {
            auto nm = NodeManager::getInstance();
            auto& showCache = nm->m_showCacheVpct;
            if ( getHost( )->m_texture != nm->m_showCacheTexture || !math::equal( mt_gray, nm->m_lastGrayValue ) ) {
                nm->pushShow( );
                nm->m_showCacheTexture = getHost( )->m_texture;
                nm->m_lastGrayValue = mt_gray;
                showCache.clear();
            }
            auto itBegin = render.begin();
            auto it1 = itBegin + 1;
            auto it2 = itBegin + 2;
            for (; it2 != render.end(); ++it1, ++it2) {
                //��������˳ʱ�뻹����ʱ�룿
                showCache.push_back(*itBegin);
                showCache.back().texCoord.y = 1 - showCache.back().texCoord.y;
                showCache.push_back(*it2);
                showCache.back().texCoord.y = 1 - showCache.back().texCoord.y;
                showCache.push_back(*it1);
                showCache.back().texCoord.y = 1 - showCache.back().texCoord.y;
            }
        }

        auto nm = NodeManager::getInstance();
        auto& showCache = nm->m_showCacheVpct;
        if (showCache.size() != 0 && i == getHost()->m_arrRender.size() - 1) {
            float lastGrayValue = nm->m_lastGrayValue;
            nm->m_lastGrayValue = mt_gray;
            nm->pushShow();
            nm->m_showCacheTexture = getHost()->m_texture;
            nm->m_lastGrayValue = lastGrayValue;
            showCache.clear();
        }
    }
}
