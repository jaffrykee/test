#include "UITexture.h"
#include "UIImageBase.h"
#include "ImageManager.h"
#include "DataInfoNode.h"
#include "ResLoader.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UITexture, 10, 20);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("name", Name, UITexture, STR);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UITexture)
    NBSCRIPT_ATTR_REGISTER("name", Name, UITexture, STR);
NODETYPE_COMMON_PART_DEFINITION_END

UITexture* UITexture::createUITexture(const string& imageName, DataInfoNode& data) {
    auto pTexture = ImageManager::getUITexture(imageName);
    if (pTexture != nullptr) {
        pTexture->setData(data);
    }
    return pTexture;
}

//����һ��UI������
void UITexture::useTexture() {
    const auto& pairTexture = ImageManager::s_mapUsingTexture.find(getKey());
    if (pairTexture == ImageManager::s_mapUsingTexture.end()) {
        ImageManager::s_mapUsingTexture.insert(getKey(), this);
        ImageManager::useTexture(m_texture, getName(), ResLoader::isResInMod());
    }
}

//����һ��UI������
void UITexture::recoverTexture() {
    const auto& pairTexture = ImageManager::s_mapUsingTexture.find(getKey());
    if (pairTexture != ImageManager::s_mapUsingTexture.end()) {
        ImageManager::s_mapUsingTexture.erase(getKey());
        //ImageManager::recoverImage2D(getName());
    }
    m_texture = null;
}

void UITexture::addSubImage(UIImageBase* pSubImage) {
    auto key = pSubImage->getKey();
    const auto& pairSubImage = m_mapSubImage.find(key);
    if (pairSubImage != m_mapSubImage.end()) {
        pairSubImage->second->releaseObject();
        if (pSubImage != nullptr) {
            pSubImage->setTexture(this);
            pairSubImage->second = pSubImage;
        } else {
            m_mapSubImage.erase(pairSubImage);
        }
    } else {
        if (pSubImage != nullptr) {
            pSubImage->setTexture(this);
            m_mapSubImage.insert(key, pSubImage);
        }
    }
}

int UITexture::addDataChild(DataInfoNode& childData) {
    int ret = Base::addDataChild(childData);
    if (ret < 0) {
        if (ObjectBase::is(childData.m_objType, NT_UIImageBase)) {
            addSubImage((UIImageBase*)ObjectBase::createObject(childData));
            ret = NT_UIImageBase;
        }
    }
    return ret;
}
