#pragma once
#include "StackPanel.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class TextFlow : public StackPanel {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(TextFlow);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(TextFlow, StackPanel);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
private:
    static ArrayList<wstring> s_tmpSplitList;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    bool m_isReady = false;
    bool m_isShouldRebuild = true;
    bool m_isTouchComp = false;

    s32 mt_curConvertIndex = 0;
    string m_linkSkin;
    wstring m_textTips = "";   //��ʾ��Ϣ
    bool m_isPassword = false;
    ft m_textAx = 0;
    ft m_textAy = 0;
    pct m_textRx = 0;
    pct m_textRy = 0;
    pct m_textAnchorRx = 0;
    pct m_textAnchorRy = 0;
    bool m_isSingleLine = false;  //������ʾ

    ft mt_childrenOffsetY = 0.f;   
#pragma endregion

#pragma region "����"
public:
    TextFlow& assign(const TextFlow& other);
    virtual bool isContainerComponent() const override;
    virtual const ArrayList<SlotType_e>& getSlotList() const override;
public:
    ft getTextAx() const;
    void setTextAx(ft value);
    ft getTextAy() const;
    void setTextAy(ft value);
    int getTextRx() const;
    void setTextRx(int value);
    int getTextRy() const;
    void setTextRy(int value);
    int getTextAnchorRx() const;
    void setTextAnchorRx(int value);
    int getTextAnchorRy() const;
    void setTextAnchorRy(int value);

    s32 getCurConvertIndex() const;
    void setCurConvertIndex(s32 value);
    const string& getLinkSkin() const;
    void setLinkSkin(const string& value);
    const wstring& getTextTips() const;
    void setTextTips(const wstring& tipsText);
    b2 getIsPassword() const;
    void setIsPassword(b2 value);
    b2 getIsSingleLine() const;
    void setIsSingleLine(b2 value);
public:
    virtual bool isTouchComponent() const override;
    void setIsTouchComponent(b2 value);
    virtual void setChildrenOffsetY() override;
public:
    //draw
    virtual void onPrepareData() override;
public:
    void rebuild();
    void rebuild(const wstring& text);
    void convertChatFace(s32 index, wstring& cText);
#pragma endregion
};

_SSUINamespaceEnd
