#include "ToggleButton.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ToggleButton, 0, 0);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ToggleButton)
NODETYPE_COMMON_PART_DEFINITION_END
