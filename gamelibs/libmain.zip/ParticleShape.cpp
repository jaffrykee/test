#include "ParticleShape.h"
#include "GameTime.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ParticleShape, 0, 0);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("particleName", DataParticleName, ParticleShape, STR, AST_normal);
NODEBASE_ATTR_REGISTER("playCount", DataPlayCount, ParticleShape, S32, AST_normal);
NODEBASE_ATTR_REGISTER("particleScaleX", DataParticleScaleX, ParticleShape, F32, AST_normal);
NODEBASE_ATTR_REGISTER("particleScaleY", DataParticleScaleY, ParticleShape, F32, AST_normal);
NODEBASE_ATTR_REGISTER("particleScaleZ", DataParticleScaleZ, ParticleShape, F32, AST_normal);
NODEBASE_ATTR_REGISTER("angleX", DataAngleX, ParticleShape, F32, AST_normal);
NODEBASE_ATTR_REGISTER("angleY", DataAngleY, ParticleShape, F32, AST_normal);
NODEBASE_ATTR_REGISTER("angleZ", DataAngleZ, ParticleShape, F32, AST_normal);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ParticleShape)
NBSCRIPT_ATTR_REGISTER("particleName", DataParticleName, ParticleShape, STR);
NBSCRIPT_ATTR_REGISTER("playCount", DataPlayCount, ParticleShape, S32);
NBSCRIPT_ATTR_REGISTER("particleScaleX", DataParticleScaleX, ParticleShape, F32);
NBSCRIPT_ATTR_REGISTER("particleScaleY", DataParticleScaleY, ParticleShape, F32);
NBSCRIPT_ATTR_REGISTER("particleScaleZ", DataParticleScaleZ, ParticleShape, F32);
NBSCRIPT_ATTR_REGISTER("angleX", DataAngleX, ParticleShape, F32);
NBSCRIPT_ATTR_REGISTER("angleY", DataAngleY, ParticleShape, F32);
NBSCRIPT_ATTR_REGISTER("angleZ", DataAngleZ, ParticleShape, F32);
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::ParticleShape::createSelf()  {
}
void ssui::ParticleShape::disposeSelf()  {
	if (parEntity) {
		parEntity.destroy();
		parEntity = null;
	}
}
void ssui::ParticleShape::onRefreshChange() {
	mt_isRefresh = true;
}
const string& ssui::ParticleShape::getDataParticleName() const {
    return mt_particleName;
}
void ssui::ParticleShape::setDataParticleName(const string& value) {
    if (mt_particleName != value) {
        mt_particleName = value;
		onRefreshChange();
    }
}
int ssui::ParticleShape::getDataPlayCount() const {
    return mt_playCount;
}
void ssui::ParticleShape::setDataPlayCount(int value) {
    if (mt_playCount != value) {
        mt_playCount = value;
		onRefreshChange();
    }
}
ft ssui::ParticleShape::getDataParticleScaleX() const {
    return mt_particleScaleX;
}
void ssui::ParticleShape::setDataParticleScaleX(ft value) {
    if (mt_particleScaleX != value) {
        mt_particleScaleX = value;
		onRefreshChange();
    }
}
ft ssui::ParticleShape::getDataParticleScaleY() const {
    return mt_particleScaleY;
}
void ssui::ParticleShape::setDataParticleScaleY(ft value) {
    if (mt_particleScaleY != value) {
        mt_particleScaleY = value;
		onRefreshChange();
    }
}
ft ssui::ParticleShape::getDataParticleScaleZ() const {
    return mt_particleScaleZ;
}
void ParticleShape::setDataParticleScaleZ(ft value) {
    if (mt_particleScaleZ != value) {
        mt_particleScaleZ = value;
		onRefreshChange();
    }
}

ft ssui::ParticleShape::getDataAngleX() const {
    return mt_angleX;
}
void ssui::ParticleShape::setDataAngleX(ft value) {
    if (mt_angleX != value) {
        mt_angleX = value;
		onRefreshChange();
    }
}
ft ssui::ParticleShape::getDataAngleY() const {
    return mt_angleY;
}
void ssui::ParticleShape::setDataAngleY(ft value) {
    if (mt_angleY != value) {
        mt_angleY = value;
		onRefreshChange();
    }
}
ft ssui::ParticleShape::getDataAngleZ() const {
    return mt_angleZ;
}
void ssui::ParticleShape::setDataAngleZ(ft value) {
    if (mt_angleZ != value) {
        mt_angleZ = value;
		onRefreshChange();
    }
}

ssui::ParticleShape& ssui::ParticleShape::assign(const ssui::ParticleShape& other) {
    mt_particleName = other.mt_particleName;
    mt_playCount = other.mt_playCount;
    mt_particleScaleX = other.mt_particleScaleX;
    mt_particleScaleY = other.mt_particleScaleY;
    mt_particleScaleZ = other.mt_particleScaleZ;
    mt_angleX = other.mt_angleX;
    mt_angleY = other.mt_angleY;
    mt_angleZ = other.mt_angleZ;
    Base::assign(other);
    return *this;
}

vec3 ssui::ParticleShape::getUIPos2Pos() {
    vec2i uiPos = vec2i(getSelfDrawX(), getSelfDrawY());
    uiPos.y = Graphics::screen().y - uiPos.y;
    uiPos = Graphics::ui2screen(vec2i(uiPos.x, uiPos.y));
    vec2 scPos = Graphics::screen2graph(uiPos);
    return vec3(scPos.x, scPos.y, 0);
}

void ssui::ParticleShape::onShow() {
    if (getHost() == nullptr || getDataParticleName().empty()) {
        return;
    }
    NodeManager::getInstance()->pushShow();
    
    if (mt_isRefresh) {
		if (parEntity) {
			parEntity.destroy();
			parEntity = null;
		}
        vec3 scale(getDataParticleScaleX(), getDataParticleScaleY(), getDataParticleScaleZ());
        vec3 transAngle(getDataAngleX(), getDataAngleY(), getDataAngleZ());
        static string head = "prefab/";
        Prefab p = Prefab::get(head + getDataParticleName());
        parEntity = p.gen();
        m_innerScale = parEntity.transform()->scale();
        m_innerRotation = parEntity.transform()->rotationEuler();
        m_innerWorldPosition = parEntity.transform()->worldPosition();

        parEntity.transform()->setScale(scale * m_innerScale);
        parEntity.transform()->setRotation(quat(transAngle + m_innerRotation));
        //parEntity.transform()->setWorldPosition(pos + m_offsetWorldPosition);
        parEntity.play();
		mt_isRefresh = false;
        
    } 
    vec3 pos = getUIPos2Pos();
    parEntity.transform()->setWorldPosition(pos + m_innerWorldPosition);

    f32 timef = GameTime::getTimeDeltaConstf();
    parEntity.apply([timef](Entity e) {
        e.value()->update(timef); });
    Graphics::draw(parEntity); 
}
