#pragma once
#include "ObjectBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Geometry;
class MeasureData : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(MeasureData);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(MeasureData, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
    static Self s_null;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    Border m_srcArea;
    Geometry* m_pTransGeo = nullptr;
#pragma endregion

#pragma region "����"
public:
    MeasureData& assign(const MeasureData& other);
    void initData();
    bool isNull() const;
    void transSrcAreaToGeo();
    void transformPosition(ft x, ft y);
public:
    virtual void debugString(string& outString) override;
#pragma endregion
};

_SSUINamespaceEnd
