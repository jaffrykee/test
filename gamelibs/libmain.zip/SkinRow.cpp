#include "SkinRow.h"
#include "SkinGroup.h"
#include "LanguageManager.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(SkinRow, 10000, 20000);
#pragma region "����ע��"

#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(SkinRow)
NODETYPE_COMMON_PART_DEFINITION_END

void SkinRow::createSelf() {
    //s_mapSkinGroup.insert(0, this);
}

void SkinRow::disposeSelf() {
    for (auto& pairSkin : m_mapLanguageThemeSkin) {
        if (pairSkin.second != nullptr) {
            pairSkin.second->releaseObject();
        }
    }
    m_mapLanguageThemeSkin.clear();
}

SkinRow* SkinRow::createObject(SkinGroup* pSkinGroup, string name) {
    auto pNew = createObject();
    pNew->m_pSkinGroup = pSkinGroup;
    pNew->mt_name = name;
    return pNew;
}

void SkinRow::addSkin(Skin* pSkin, const string& lang, const string& theme) {
    s64 key = (((s64)(lang.empty() ? 0 : lang.hashCode())) << (s64)32) + theme.empty() ? 0 : theme.hashCode();
    m_mapLanguageThemeSkin[key] = pSkin;
    pSkin->m_pRow = this;
    //<inc>
    //refreshCurSkin();
}

Skin* SkinRow::getSkin(const string& lang, const string& theme) {
    s64 key = 0;
    s64 langIndex = lang.hashCode();
    s64 themeIndex = theme.hashCode();
    if (!lang.empty()) {
        if (!theme.empty()) {
            key = langIndex << (s64)32 + themeIndex;
            auto pairSkin = m_mapLanguageThemeSkin.find(key);
            if (pairSkin != m_mapLanguageThemeSkin.end()) {
                return pairSkin->second;
            } else {
                key = langIndex << (s64)32;
                auto pairSkin = m_mapLanguageThemeSkin.find(key);
                if (pairSkin != m_mapLanguageThemeSkin.end()) {
                    return pairSkin->second;
                } else {
                    key = themeIndex;
                    auto pairSkin = m_mapLanguageThemeSkin.find(key);
                    if (pairSkin != m_mapLanguageThemeSkin.end()) {
                        return pairSkin->second;
                    } else {
                        key = 0;
                    }
                }
            }
        } else {
            key = langIndex << (s64)32;
            auto pairSkin = m_mapLanguageThemeSkin.find(key);
            if (pairSkin != m_mapLanguageThemeSkin.end()) {
                return pairSkin->second;
            } else {
                key = 0;
            }
        }
    } else {
        if (!theme.empty()) {
            key = themeIndex;
            auto pairSkin = m_mapLanguageThemeSkin.find(key);
            if (pairSkin != m_mapLanguageThemeSkin.end()) {
                return pairSkin->second;
            } else {
                key = 0;
            }
        }
    }
    auto pairSkin = m_mapLanguageThemeSkin.find(key);
    if (pairSkin != m_mapLanguageThemeSkin.end()) {
        return pairSkin->second;
    }
    return nullptr;
}

void SkinRow::refreshCurSkin() {
    m_pCurSkin = getSkin(LanguageManager::getInstance()->getLanguage(), NodeManager::getInstance()->m_curTheme);
}
