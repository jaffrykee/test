#pragma once
#include "BasicContent.h"
#include "GameTime.h"
#include "Timer.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

#define TWV_MSEC    1
#define TWV_SEC     (TWV_MSEC * 1000)
#define TWV_MIN     (TWV_SEC * 60)
#define TWV_HOUR    (TWV_MIN * 60)
#define TWV_DAY     (TWV_HOUR * 24)

class TimeContent : public BasicContent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(TimeContent);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(TimeContent, BasicContent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static wstring s_tmpTimeOrderCmdData;
    static wstring s_tmpTimeTypeCmdData;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    ArrayList<wstring> m_drawData;
private:
    s64 mt_curTime = 0;
public:
    u32 m_lastSysTime = 0;
    u32 m_cycle = 0;
private:
    u16 mt_dataDays = 0;
    u8 mt_dataHours = 0;
    u16 mt_dataMinutes = 0;
    u16 mt_dataSeconds = 0;
    u16 mt_dataMSs = 0;
public:
    //%a
    u16 m_drawDays = 0;
    //%b
    u16 m_drawHours = 0;
    //%c
    u16 m_drawMinutes = 0;
    //%d
    u16 m_drawSeconds = 0;
    //%e
    u16 m_drawMSs = 0;
    u8 m_drawEnableData = 1 << TimeDigit_MSEC;
    wstring m_timePattern = "";
    s64 m_timeOut = 0;   //��λ��
private:
    TimeOrder_e mt_timeOrder = TO_CountDown;
    bool mt_isStart = true;
    b2 mt_fullDisplayNumber = true;
    b2 mt_HideLastUnitText = false;
    s32 mt_maxDisplaySectionNumber = 0;
    TimeDigit_e mt_timeType = TimeDigit_SEC;

	bool mt_isBuildOver = false;

#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    int getTimeOrder() const;
    void setTimeOrder(int value);
    int getTimeType() const;
    void setTimeType(int value);
    int getDataDays() const;
    void setDataDays(int value);
    int getDataHours() const;
    void setDataHours(int value);
    int getDataMinutes() const;
    void setDataMinutes(int value);
    int getDataSeconds() const;
    void setDataSeconds(int value);
    int getDataMSs() const;
    void setDataMSs(int value);
    const wstring& getTimePattern() const;
    void setTimePattern(const wstring& value);
    s64 getTimeOut() const;
    void setTimeOut(s64 value);
    s64 getCurTime() const;
    void setCurTime(s64 value);
    bool getIsStart() const;
    void setIsStart(bool value);

    b2 getFullDisplayNumber( ) const;
    void setFullDisplayNumber( b2 value );
    b2 getHideLastUnitText( ) const;
    void setHideLastUnitText( b2 value );
    s32 getMaxDisplaySectionNumber( ) const;
    void setMaxDisplaySectionNumber( s32 value );
#pragma endregion
public:
    Self& assign(const Self& other);
public:
    virtual void onShowTextChangedFunc() override;

private:
    //m_drawData(�����������)�Ѿ�������ֻ��Ҫ���¸���text��
    void refreshShowText();
    s64 getTimeOutValue();
public:
    void initCurTime();
    void rebuild();
    void updateCurTime();
    void createTimer();
    void clearTimer();
    void timerTrigger(u32 targerTime);
    void onCurTimeChanged();
#pragma endregion
};

_SSUINamespaceEnd
