#include "BasicMeasure.h"
#include "Control.h"
#include "Geometry.h"
#include "GeometryRect.h"
#include "GeometryPoly.h"
#include "GeometryManager.h"
#include "MeasureData.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(BasicMeasure, CONTROL_RESPOOLINIT, CONTROL_RESPOOLLIMIT);
#pragma region "����ע��"
    //BasicMeasure_ATTR_REGISTER("countId", CountId, NodeType, S64);
//     NODEBASE_ATTR_REGISTER("color", DataColor, BasicMeasure, U32);
//     NODEBASE_ATTR_REGISTER("isColorSetting", DataIsColorSetting, BasicMeasure, B2);
//     NODEBASE_ATTR_REGISTER("isClip", DataIsClip, BasicMeasure, B2);
//     NODEBASE_ATTR_REGISTER("visible", DataIsVisible, BasicMeasure, B2);
    NODEBASE_ATTR_REGISTER("aw", Aw, BasicMeasure, F32);
    NODEBASE_ATTR_REGISTER("ah", Ah, BasicMeasure, F32);
    NODEBASE_ATTR_REGISTER("rw", Rw, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("rh", Rh, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("ax", Ax, BasicMeasure, F32);
    NODEBASE_ATTR_REGISTER("ay", Ay, BasicMeasure, F32);
    NODEBASE_ATTR_REGISTER("rx", Rx, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("ry", Ry, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("anchorRx", AnchorRx, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("anchorRy", AnchorRy, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("wAuto", IsAutoWidth, BasicMeasure, B2);
    NODEBASE_ATTR_REGISTER("hAuto", IsAutoHeight, BasicMeasure, B2);
    NODEBASE_ATTR_REGISTER("minAw", MinAw, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("minAh", MinAh, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("maxAw", MaxAw, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("maxAh", MaxAh, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("minRw", MinRw, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("minRh", MinRh, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("maxRw", MaxRw, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("maxRh", MaxRh, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("marginAl", AbsoluteMarginLeft, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("marginAt", AbsoluteMarginTop, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("marginAr", AbsoluteMarginRight, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("marginAb", AbsoluteMarginBottom, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("paddingAl", AbsolutePaddingLeft, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("paddingAt", AbsolutePaddingTop, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("paddingAr", AbsolutePaddingRight, BasicMeasure, S32);
    NODEBASE_ATTR_REGISTER("paddingAb", AbsolutePaddingBottom, BasicMeasure, S32);
NODETYPE_COMMON_PART_DEFINITION_MID(BasicMeasure)
    NBSCRIPT_ATTR_REGISTER("ax", Ax, BasicMeasure, F32);
    NBSCRIPT_ATTR_REGISTER("ay", Ay, BasicMeasure,  F32);
    NBSCRIPT_ATTR_REGISTER("aw", Aw, BasicMeasure,  F32);
    NBSCRIPT_ATTR_REGISTER("ah", Ah, BasicMeasure,  F32);
    NBSCRIPT_ATTR_REGISTER("rx", Rx, BasicMeasure,  S32);
    NBSCRIPT_ATTR_REGISTER("ry", Ry, BasicMeasure,  S32);
    NBSCRIPT_ATTR_REGISTER("rw", Rw, BasicMeasure,  S32);
    NBSCRIPT_ATTR_REGISTER("rh", Rh, BasicMeasure,  S32);
    NBSCRIPT_ATTR_REGISTER("wAuto", IsAutoWidth, BasicMeasure, B2);
    NBSCRIPT_ATTR_REGISTER("hAuto", IsAutoHeight, BasicMeasure, B2);
    NBSCRIPT_ATTR_REGISTER("minAw", MinAw, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("minAh", MinAh, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("maxAw", MaxAw, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("maxAh", MaxAh, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("minRw", MinRw, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("minRh", MinRh, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("maxRw", MaxRw, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("maxRh", MaxRh, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("anchorRx", AnchorRx, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("anchorRy", AnchorRy, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("marginAl", AbsoluteMarginLeft, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("marginAt", AbsoluteMarginTop, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("marginAr", AbsoluteMarginRight, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("marginAb", AbsoluteMarginBottom, BasicMeasure, S32);
//     NBSCRIPT_ATTR_REGISTER("marginRl", RelativeMarginLeft, BasicMeasure, S32);
//     NBSCRIPT_ATTR_REGISTER("marginRt", RelativeMarginTop, BasicMeasure, S32);
//     NBSCRIPT_ATTR_REGISTER("marginRr", RelativeMarginRight, BasicMeasure, S32);
//     NBSCRIPT_ATTR_REGISTER("marginRb", RelativeMarginBottom, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("paddingAl", AbsolutePaddingLeft, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("paddingAt", AbsolutePaddingTop, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("paddingAr", AbsolutePaddingRight, BasicMeasure, S32);
    NBSCRIPT_ATTR_REGISTER("paddingAb", AbsolutePaddingBottom, BasicMeasure, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(BasicMeasure, Ax, ft)
UIComponent_ControlAttr_Def(BasicMeasure, Ay, ft)
UIComponent_ControlAttr_Def(BasicMeasure, Aw, ft)
UIComponent_ControlAttr_Def(BasicMeasure, Ah, ft)
UIComponent_ControlAttr_Def(BasicMeasure, Rx, int)
UIComponent_ControlAttr_Def(BasicMeasure, Ry, int)
UIComponent_ControlAttr_Def(BasicMeasure, Rw, int)
UIComponent_ControlAttr_Def(BasicMeasure, Rh, int)
UIComponent_ControlAttr_Def(BasicMeasure, IsAutoWidth, bool)
UIComponent_ControlAttr_Def(BasicMeasure, IsAutoHeight, bool)
UIComponent_ControlAttr_Def(BasicMeasure, MinAw, int)
UIComponent_ControlAttr_Def(BasicMeasure, MinAh, int)
UIComponent_ControlAttr_Def(BasicMeasure, MaxAw, int)
UIComponent_ControlAttr_Def(BasicMeasure, MaxAh, int)
UIComponent_ControlAttr_Def(BasicMeasure, MinRw, int)
UIComponent_ControlAttr_Def(BasicMeasure, MinRh, int)
UIComponent_ControlAttr_Def(BasicMeasure, MaxRw, int)
UIComponent_ControlAttr_Def(BasicMeasure, MaxRh, int)
UIComponent_ControlAttr_Def(BasicMeasure, AnchorRx, int)
UIComponent_ControlAttr_Def(BasicMeasure, AnchorRy, int)
UIComponent_ControlAttr_Def(BasicMeasure, AbsoluteMarginLeft, int)
UIComponent_ControlAttr_Def(BasicMeasure, AbsoluteMarginTop, int)
UIComponent_ControlAttr_Def(BasicMeasure, AbsoluteMarginRight, int)
UIComponent_ControlAttr_Def(BasicMeasure, AbsoluteMarginBottom, int)
UIComponent_ControlAttr_Def(BasicMeasure, AbsolutePaddingLeft, int)
UIComponent_ControlAttr_Def(BasicMeasure, AbsolutePaddingTop, int)
UIComponent_ControlAttr_Def(BasicMeasure, AbsolutePaddingRight, int)
UIComponent_ControlAttr_Def(BasicMeasure, AbsolutePaddingBottom, int)
#pragma endregion

void ssui::BasicMeasure::disposeSelf() {
}

#pragma region "���Է���"
#pragma region "Absolute���Է���"

ssui::ft ssui::BasicMeasure::getAx() const {
    return m_ax;
}

void ssui::BasicMeasure::setAx(ft value) {
    m_ax = value;
    getHost()->touchMeasureChanged();
}

ssui::ft ssui::BasicMeasure::getAy() const {
    return m_ay;
}

void ssui::BasicMeasure::setAy(ft value) {
    m_ay = value;
    getHost()->touchMeasureChanged();
}

ssui::ft ssui::BasicMeasure::getAw() const {
    return m_aw;
}

void ssui::BasicMeasure::setAw(ft value) {
    m_aw = value;
    getHost()->touchMeasureChanged();
}

ssui::ft ssui::BasicMeasure::getAh() const {
    return m_ah;
}

void ssui::BasicMeasure::setAh(ft value) {
    m_ah = value;
    getHost()->touchMeasureChanged();
}
#pragma endregion

#pragma region "Relative���Է���"
int ssui::BasicMeasure::getRx() const {
    return m_rx;
}

void ssui::BasicMeasure::setRx(int value) {
    m_rx = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}

int ssui::BasicMeasure::getRy() const {
    return m_ry;
}

void ssui::BasicMeasure::setRy(int value) {
    m_ry = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}

int ssui::BasicMeasure::getRw() const {
    return m_rw;
}

void ssui::BasicMeasure::setRw(int value) {
    m_rw = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}

int ssui::BasicMeasure::getRh() const {
    return m_rh;
}

void ssui::BasicMeasure::setRh(int value) {
    m_rh = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}
#pragma endregion

#pragma region "Auto���Է���"
bool ssui::BasicMeasure::getIsAutoWidth() const {
    return m_isAutoWidth;
}

void ssui::BasicMeasure::setIsAutoWidth(bool value) {
    m_isAutoWidth = value;
    getHost()->touchPrepareDataChanged();
}

bool ssui::BasicMeasure::getIsAutoHeight() const {
    return m_isAutoHeight;
}

void ssui::BasicMeasure::setIsAutoHeight(bool value) {
    m_isAutoHeight = value;
    getHost()->touchPrepareDataChanged();
}
#pragma endregion

#pragma region "AbsoluteCheck���Է���"
int ssui::BasicMeasure::getMinAw() const {
    return m_minAw;
}

void ssui::BasicMeasure::setMinAw(int value) {
    m_minAw = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getMinAh() const {
    return m_minAh;
}

void ssui::BasicMeasure::setMinAh(int value) {
    m_minAh = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getMaxAw() const {
    return m_maxAw;
}

void ssui::BasicMeasure::setMaxAw(int value) {
    m_maxAw = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getMaxAh() const {
    return m_maxAh;
}

void ssui::BasicMeasure::setMaxAh(int value) {
    m_maxAh = value;
    getHost()->touchMeasureChanged();
}

#pragma endregion

#pragma region "RelativeCheck���Է���"
int ssui::BasicMeasure::getMinRw() const {
    return m_minRw;
}

void ssui::BasicMeasure::setMinRw(int value) {
    m_minRw = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}

int ssui::BasicMeasure::getMinRh() const {
    return m_minRh;
}

void ssui::BasicMeasure::setMinRh(int value) {
    m_minRh = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}

int ssui::BasicMeasure::getMaxRw() const {
    return m_maxRw;
}

void ssui::BasicMeasure::setMaxRw(int value) {
    m_maxRw = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}

int ssui::BasicMeasure::getMaxRh() const {
    return m_maxRh;
}

void ssui::BasicMeasure::setMaxRh(int value) {
    m_maxRh = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}
#pragma endregion

#pragma region "Anchor���Է���"
int ssui::BasicMeasure::getAnchorRx() const {
    return m_anchorRx;
}

void ssui::BasicMeasure::setAnchorRx(int value) {
    m_anchorRx = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}

int ssui::BasicMeasure::getAnchorRy() const {
    return m_anchorRy;
}

void ssui::BasicMeasure::setAnchorRy(int value) {
    m_anchorRy = value;
    getHost()->touchMeasureChanged();
    getHost()->touchPrepareDataChanged();
}
#pragma endregion

#pragma region "AbsoluteMargin���Է���"
int ssui::BasicMeasure::getAbsoluteMarginLeft() const {
    return m_aml;
}

void ssui::BasicMeasure::setAbsoluteMarginLeft(int value) {
    m_aml = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getAbsoluteMarginTop() const {
    return m_amt;
}

void ssui::BasicMeasure::setAbsoluteMarginTop(int value) {
    m_amt = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getAbsoluteMarginRight() const {
    return m_amr;
}

void ssui::BasicMeasure::setAbsoluteMarginRight(int value) {
    m_amr = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getAbsoluteMarginBottom() const {
    return m_amb;
}

void ssui::BasicMeasure::setAbsoluteMarginBottom(int value) {
    m_amb = value;
    getHost()->touchMeasureChanged();
}
#pragma endregion

#pragma region "AbsolutePadding���Է���"
int ssui::BasicMeasure::getAbsolutePaddingLeft() const {
    return m_apl;
}

void ssui::BasicMeasure::setAbsolutePaddingLeft(int value) {
    m_apl = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getAbsolutePaddingTop() const {
    return m_apt;
}

void ssui::BasicMeasure::setAbsolutePaddingTop(int value) {
    m_apt = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getAbsolutePaddingRight() const {
    return m_apr;
}

void ssui::BasicMeasure::setAbsolutePaddingRight(int value) {
    m_apr = value;
    getHost()->touchMeasureChanged();
}

int ssui::BasicMeasure::getAbsolutePaddingBottom() const {
    return m_apb;
}

void ssui::BasicMeasure::setAbsolutePaddingBottom(int value) {
    m_apb = value;
    getHost()->touchMeasureChanged();
}
#pragma endregion
#pragma endregion

bool ssui::BasicMeasure::isAbsoluteCheckDataChanged() {
    return m_absoluteMinCheckData != 0 || m_absoluteMaxCheckData != UINT_MAX;
}

bool ssui::BasicMeasure::isRelativeCheckDataChanged() {
    return m_relativeMinCheckData != 0 || m_relativeMaxCheckData != UINT_MAX;
}

ssui::BasicMeasure& ssui::BasicMeasure::assign(const BasicMeasure& other) {
    Base::assign(other);
    m_ax = other.m_ax;
    m_ay = other.m_ay;
    m_aw = other.m_aw;
    m_ah = other.m_ah;
    m_relativeData = other.m_relativeData;
    m_isAuto = other.m_isAuto;
    m_absoluteMinCheckData = other.m_absoluteMinCheckData;
    m_absoluteMaxCheckData = other.m_absoluteMaxCheckData;
    m_relativeMinCheckData = other.m_relativeMinCheckData;
    m_relativeMaxCheckData = other.m_relativeMaxCheckData;
    m_anchorData = other.m_anchorData;
    m_absoluteMarginData = other.m_absoluteMarginData;
    m_absolutePaddingData = other.m_absolutePaddingData;
    return *this;
}

void ssui::BasicMeasure::onPrepareData() {
    if (getHost() == nullptr) {
        return;
    }
    if (getHost()->m_isMustParentReady == false) {
        if (m_relativeData || isRelativeCheckDataChanged()) {
            getHost()->m_isMustParentReady = true;
        }
    }
    if (m_isAutoWidth) {
        getHost()->m_isAutoWidthFrame = true;
    }
    if (m_isAutoHeight) {
        getHost()->m_isAutoHeightFrame = true;
    }
}

void ssui::BasicMeasure::onMeasure(unsigned char drawStep) {
    if (getHost() == nullptr) {
        return;
    }
    auto pParentContainer = getHost()->getParentComponent();
    ft pw, ph;
    bool isAutoWidthParent = false;
    bool isAutoHeightParent = false;
    auto pParentComp = getHost()->m_pParentComponent;
    if (pParentComp) {
        auto& parentArea = pParentComp->getChildArea(getHost());
        pw = parentArea.m_right - parentArea.m_left;
        ph = parentArea.m_bottom - parentArea.m_top;
        auto pParent = pParentComp->getHost();
        isAutoWidthParent = pParent->m_isAutoWidthFrame;
        isAutoHeightParent = pParent->m_isAutoHeightFrame;
    } else {
        pw = Engine::uiScreen().x;
        ph = Engine::uiScreen().y;
    }
    auto& ctrlArea = getHost()->measure().m_srcArea;
    auto& left = ctrlArea.m_left;
    auto& top = ctrlArea.m_top;
    auto& right = ctrlArea.m_right;
    auto& bottom = ctrlArea.m_bottom;
    //Margin_Pre
    Border exMargin;
    //AbsoluteMargin_Pre
    if (m_absoluteMarginData != 0) {
        exMargin.m_left += m_aml;
        exMargin.m_top += m_amt;
        exMargin.m_right += m_amr;
        exMargin.m_bottom += m_amb;
    }
    //RelativeMargin_Pre
//     if (pParentContainer != nullptr && m_relativeMarginData != 0) {
//         exMargin.m_left += SSUIMath::restorePct(m_rml) * pw;
//         exMargin.m_top += SSUIMath::restorePct(m_rmt) * ph;
//         exMargin.m_right += SSUIMath::restorePct(m_rmr) * pw;
//         exMargin.m_bottom += SSUIMath::restorePct(m_rmb) * ph;
//     }
    pw -= exMargin.m_left;
    ph -= exMargin.m_top;
    pw -= exMargin.m_right;
    ph -= exMargin.m_bottom;
    //Padding_Pre
    Border exPadding;
    //AbsolutePadding_Pre
    if (m_absolutePaddingData != 0) {
        exPadding.m_left += m_apl;
        exPadding.m_top += m_apt;
        exPadding.m_right += m_apr;
        exPadding.m_bottom += m_apb;
    }
    //Absolute & Relative
    if (m_relativeData != 0) {
        if (drawStep >= 1 || isAutoWidthParent == false) {
            left = m_ax + pw * SSUIMath::restorePct(m_rx);
            right = left + m_aw + pw * SSUIMath::restorePct(m_rw);
        } else {
            left = m_ax;
            right = left + m_aw;
        }
        if (drawStep >= 1 || isAutoHeightParent == false) {
            top = m_ay + ph * SSUIMath::restorePct(m_ry);
            bottom = top + m_ah + ph * SSUIMath::restorePct(m_rh);
        } else {
            top = m_ay;
            bottom = top + m_ah;
        }
    } else {
        left = m_ax;
        top = m_ay;
        right = left + m_aw;
        bottom = top + m_ah;
    }
    //AutoSize
    if (m_isAuto != 0) {
        Border tmpCurChildAabb;
        vec2 sumSelfRb;
        //if (m_absoluteMarginData == 0 && m_relativeMarginData == 0) {
        if (m_absoluteMarginData == 0) {
            if (m_absolutePaddingData == 0) {
#pragma region "��������"
                for (auto& pComp : *getHost()) {
                    for (auto& pChild : *pComp) {
                        auto pGeo = pChild->getOuterMeasure().m_pTransGeo;
                        if (pGeo) {
                            pGeo->getBorder(tmpCurChildAabb);
                            //Ĭ����չ�������ҷ����·���
                            GeometryManager::sumPointAndBorder(sumSelfRb, tmpCurChildAabb, pChild->mMeasureDir);
                        } else {
                            //Ĭ����չ�������ҷ����·���
                            GeometryManager::sumPointAndBorder(sumSelfRb, pChild->getOuterMeasure().m_srcArea);
                        }
                    }
                }
                for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
                    GeometryManager::sumPointAndPolyImage(sumSelfRb, *it);
                }
#pragma endregion
            } else {
#pragma region "��������"
                vec2 sumInnerRb;
                for (auto& pComp : *getHost()) {
                    for (auto& pChild : *pComp) {
                        auto pGeo = pChild->getOuterMeasure().m_pTransGeo;
                        if (pGeo) {
                            pGeo->getBorder(tmpCurChildAabb);
                            if (pChild->getParentAreaType() == PAT_inner) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumInnerRb, tmpCurChildAabb, pChild->mMeasureDir);
                            } else if (pChild->getParentAreaType() == PAT_self || pChild->getParentAreaType() == PAT_outer) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumSelfRb, tmpCurChildAabb, pChild->mMeasureDir);
                            }
                        } else {
                            if (pChild->getParentAreaType() == PAT_inner) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumInnerRb, pChild->getOuterMeasure().m_srcArea);
                            } else if (pChild->getParentAreaType() == PAT_self || pChild->getParentAreaType() == PAT_outer) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumSelfRb, pChild->getOuterMeasure().m_srcArea);
                            }
                        }
                    }
                }
                //image��self����text��inner����������self����
                if (getHost()->getDataCcit() == CCIT_TextShape) {
                    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
                        GeometryManager::sumPointAndPolyImage(sumInnerRb, *it);
                    }
                } else {
                    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
                        GeometryManager::sumPointAndPolyImage(sumSelfRb, *it);
                    }
                }
                if (m_isAutoWidth) {
                    sumInnerRb.x += (exPadding.m_left + exPadding.m_right);
                    if (sumInnerRb.x > sumSelfRb.x) {
                        sumSelfRb.x = sumInnerRb.x;
                    }
                }
                if (m_isAutoHeight) {
                    sumInnerRb.y += (exPadding.m_top + exPadding.m_bottom);
                    if (sumInnerRb.y > sumSelfRb.y) {
                        sumSelfRb.y = sumInnerRb.y;
                    }
                }
#pragma endregion
            }
        } else {
            if (m_absolutePaddingData == 0) {
#pragma region "��������"
                vec2 sumOuterRb;
                for (auto& pComp : *getHost()) {
                    for (auto& pChild : *pComp) {
                        auto pGeo = pChild->getOuterMeasure().m_pTransGeo;
                        if (pGeo) {
                            pGeo->getBorder(tmpCurChildAabb);
                            if (pChild->getParentAreaType() == PAT_inner || pChild->getParentAreaType() == PAT_self) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumSelfRb, tmpCurChildAabb, pChild->mMeasureDir);
                            } else if (pChild->getParentAreaType() == PAT_outer) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumOuterRb, tmpCurChildAabb, pChild->mMeasureDir);
                            }
                        } else {
                            if (pChild->getParentAreaType() == PAT_inner || pChild->getParentAreaType() == PAT_self) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumSelfRb, pChild->getOuterMeasure().m_srcArea);
                            } else if (pChild->getParentAreaType() == PAT_outer) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumOuterRb, pChild->getOuterMeasure().m_srcArea);
                            }
                        }
                    }
                }
                for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
                    GeometryManager::sumPointAndPolyImage(sumSelfRb, *it);
                }
                if (m_isAutoWidth) {
                    sumOuterRb.x -= (exMargin.m_left + exMargin.m_right);
                    if (sumOuterRb.x > sumSelfRb.x) {
                        sumSelfRb.x = sumOuterRb.x;
                    }
                }
                if (m_isAutoHeight) {
                    sumOuterRb.y -= (exMargin.m_top + exMargin.m_bottom);
                    if (sumOuterRb.y > sumSelfRb.y) {
                        sumSelfRb.y = sumOuterRb.y;
                    }
                }
#pragma endregion
            } else {
#pragma region "��������"
                vec2 sumOuterRb;
                vec2 sumInnerRb;
                for (auto& pComp : *getHost()) {
                    for (auto& pChild : *pComp) {
                        auto pGeo = pChild->getOuterMeasure().m_pTransGeo;
                        if (pGeo) {
                            pGeo->getBorder(tmpCurChildAabb);
                            if (pChild->getParentAreaType() == PAT_inner) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumInnerRb, tmpCurChildAabb, pChild->mMeasureDir);
                            } else if (pChild->getParentAreaType() == PAT_self) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumSelfRb, tmpCurChildAabb, pChild->mMeasureDir);
                            } else if (pChild->getParentAreaType() == PAT_outer) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumOuterRb, tmpCurChildAabb, pChild->mMeasureDir);
                            }
                        } else {
                            if (pChild->getParentAreaType() == PAT_inner) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumInnerRb, pChild->getOuterMeasure().m_srcArea);
                            } else if (pChild->getParentAreaType() == PAT_self) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumSelfRb, pChild->getOuterMeasure().m_srcArea);
                            } else if (pChild->getParentAreaType() == PAT_outer) {
                                //Ĭ����չ�������ҷ����·���
                                GeometryManager::sumPointAndBorder(sumOuterRb, pChild->getOuterMeasure().m_srcArea);
                            }
                        }
                    }
                }
                //image��self����text��inner����������self����
                if (getHost()->getDataCcit() == CCIT_TextShape) {
                    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
                        GeometryManager::sumPointAndPolyImage(sumInnerRb, *it);
                    }
                } else {
                    for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
                        GeometryManager::sumPointAndPolyImage(sumSelfRb, *it);
                    }
                }
                if (m_isAutoWidth) {
                    sumOuterRb.x -= (exMargin.m_left + exMargin.m_right);
                    sumInnerRb.x += (exPadding.m_left + exPadding.m_right);
                    if (sumOuterRb.x > sumSelfRb.x) {
                        sumSelfRb.x = sumOuterRb.x;
                    }
                    if (sumInnerRb.x > sumSelfRb.x) {
                        sumSelfRb.x = sumInnerRb.x;
                    }
                }
                if (m_isAutoHeight) {
                    sumOuterRb.y -= (exMargin.m_top + exMargin.m_bottom);
                    sumInnerRb.y += (exPadding.m_top + exPadding.m_bottom);
                    if (sumOuterRb.y > sumSelfRb.y) {
                        sumSelfRb.y = sumOuterRb.y;
                    }
                    if (sumInnerRb.y > sumSelfRb.y) {
                        sumSelfRb.y = sumInnerRb.y;
                    }
                }
#pragma endregion
            }
        }
        if (m_isAutoWidth) {
            auto cw = right - left;
            if (sumSelfRb.x > cw) {
                right += sumSelfRb.x - cw;
            }
        }
        if (m_isAutoHeight) {
            auto ch = bottom - top;
            if (sumSelfRb.y > ch) {
                bottom += sumSelfRb.y - ch;
            }
        }
    }
    //AbsoluteCheck
    if (isAbsoluteCheckDataChanged()) {
        auto cw = right - left;
        auto ch = bottom - top;
        if (cw < m_minAw) {
            right += m_minAw - cw;
        } else if (cw > m_maxAw) {
            right -= cw - m_maxAw;
        }
        if (ch < m_minAh) {
            bottom += m_minAh - ch;
        } else if (ch > m_maxAh) {
            bottom -= ch - m_maxAh;
        }
    }
    //RelativeCheck
    if (pParentContainer != nullptr && isRelativeCheckDataChanged()) {
        if (drawStep >= 1 || isAutoWidthParent == false) {
            auto cw = right - left;
            auto minRwValue = SSUIMath::restorePct(m_minRw) * pw;
            auto maxRwValue = SSUIMath::restorePct(m_maxRw) * pw;
            if (cw < minRwValue) {
                right += minRwValue - cw;
            } else if (cw > maxRwValue) {
                right -= cw - maxRwValue;
            }
        }
        if (drawStep >= 1 || isAutoHeightParent == false) {
            auto ch = bottom - top;
            auto minRhValue = SSUIMath::restorePct(m_minRh) * ph;
            auto maxRhValue = SSUIMath::restorePct(m_maxRh) * ph;
            if (ch < minRhValue) {
                bottom += minRhValue - ch;
            } else if (ch > maxRhValue) {
                bottom -= ch - maxRhValue;
            }
        }
    }
    //Anchor(need self static)
    if (pParentContainer != nullptr && m_anchorData != 0) {
        if (drawStep >= 1 || isAutoWidthParent == false) {
            auto cw = right - left;
            left -= SSUIMath::restorePct(m_anchorRx) * cw;
            right -= SSUIMath::restorePct(m_anchorRx) * cw;
        }
        if (drawStep >= 1 || isAutoHeightParent == false) {
            auto ch = bottom - top;
            top -= SSUIMath::restorePct(m_anchorRy) * ch;
            bottom -= SSUIMath::restorePct(m_anchorRy) * ch;
        }
    }
    //Margin_Suf
    //if (m_absoluteMarginData != 0 || (pParentContainer != nullptr && m_relativeMarginData != 0)) {
    if (m_absoluteMarginData != 0) {
        auto& pOuterMeasure = getHost()->m_pOuterMeasure;
        if (pOuterMeasure == nullptr) {
            pOuterMeasure = MeasureData::createObject();
        }
        auto& outArea = pOuterMeasure->m_srcArea;
        outArea.m_left = left;
        outArea.m_right = right + exMargin.m_left + exMargin.m_right;
        outArea.m_top = top;
        outArea.m_bottom = bottom + exMargin.m_top + exMargin.m_bottom;
        left += exMargin.m_left;
        right += exMargin.m_left;
        top += exMargin.m_top;
        bottom += exMargin.m_top;
    }
    //Padding_Suf
    if (m_absolutePaddingData != 0) {
        auto& pInnerMeasure = getHost()->m_pInnerMeasure;
        if (pInnerMeasure == nullptr) {
            pInnerMeasure = MeasureData::createObject();
        }
        auto& innerArea = pInnerMeasure->m_srcArea;
        innerArea.m_left = left + exPadding.m_left;
        innerArea.m_right = right - exPadding.m_right;
        innerArea.m_top = top + exPadding.m_top;
        innerArea.m_bottom = bottom - exPadding.m_bottom;
    }
}

void ssui::BasicMeasure::onTransform(unsigned char drawStep) {
    if (getHost() == nullptr) {
        return;
    }
    getHost()->measure().transSrcAreaToGeo();
    if (getHost()->m_pOuterMeasure) {
        getHost()->m_pOuterMeasure->transSrcAreaToGeo();
    }
    if (getHost()->m_pInnerMeasure) {
        getHost()->m_pInnerMeasure->transSrcAreaToGeo();
    }
    if (getHost()->m_curRenderCount == 0) {
        for (auto& pComp : *getHost()) {
            for (auto& pChild : *pComp) {
                auto& area = pChild->getParentArea();
                auto x = area.m_left;
                auto y = area.m_top;
                if (math::equalZero(x, 0.01f) && math::equalZero(y, 0.01f)) {
                    continue;
                }
                applyTransformToSelfChildGrandChildAndSoOn(pChild, x, y);
            }
        }
    } else {
        for (auto& pComp : *getHost()) {
            if (pComp->is(NT_ImageShape) || pComp->is(NT_TextShape)) {
                auto& selfArea = pComp->getMeasure(pComp->getParentAreaType()).m_srcArea;
                auto x = selfArea.m_left;
                auto y = selfArea.m_top;
                if (math::equalZero(x, 0.01f) && math::equalZero(y, 0.01f)) {
                    break;
                }
                for (auto it = getHost()->m_arrRender.begin(); it < getHost()->m_arrRender.begin() + getHost()->m_curRenderCount; ++it) {
                    for (auto& vpct : *it) {
                        vpct.position.x += x;
                        vpct.position.y += y;
                    }
                }
                break;
            }
        }
    }
}

void ssui::BasicMeasure::applyTransformToPosterity(Control* pPosterity) {
    auto& parentArea = getHost()->getParentArea();
    auto x = parentArea.m_left;
    auto y = parentArea.m_top;
    if (math::equalZero(x, 0.01f) && math::equalZero(y, 0.01f)) {
        return;
    }
    applyTransformToSelfChildGrandChildAndSoOn(pPosterity, x, y);
}
