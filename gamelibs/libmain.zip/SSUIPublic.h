#pragma once
#include <bitset>
#include "BoloObject.h"
#include "SS2Define.h"
#include "Graphics.h"
#include "XmlParser.h"
#include "BoloScriptManager.h"
#include "SSUIDef.h"

#define _SSUINamespaceBegin namespace ssui {
#define _SSUINamespaceEnd   }

using namespace ss2;
using namespace gstl;
using namespace bs;

#define SSUI_FTMAX 9999999.f
#define SSUI_DP 0.001f
#define SSUI_DPH 0.001f
#define SSUI_FT F32
#undef UINT_MAX
#define UINT_MAX 0xffffffff
#define U32MAX 0xffffffff
#define U16MAX 0xffff
#define U8MAX 0xff

_SSUINamespaceBegin

typedef float ft;
typedef int wstrHash;
typedef int strHash;
//����С�����ٷֱȡ�
typedef s16 pct;
typedef ArrayList<vec3> Poly;
typedef ArrayList<VertexPosColorTex> PolyImage;

//debug
enum PrintDataType_e : u8 {
    PDT_Debug,
    PDT_Tree,
    PDT_MAX,
};

//�ڵ�����ö��
enum NodeType_e : u16 {
    NT_ObjectBase,              //base
    NT_Control,                 //ObjectBase:Control
    NT_UIScene,                 //ObjectBase:Control:UIScene

    NT_UIComponent,             //ObjectBase:UIComponent
                                //Draw
    NT_BasicTransform,
    NT_BasicClip,
    NT_BasicContent,
    NT_BasicMeasure,
    NT_ImageShape,              //ObjectBase:UIComponent:ImageShape
    NT_TextShape,               //ObjectBase:UIComponent:TextShape
    NT_ParticleShape,           //ObjectBase:UIComponent:ParticleShape
                                //IDrawComponent
    NT_SimpleComponent,         //ObjectBase:UIComponent:SimpleComponent
    NT_TimeContent,             //ObjectBase:UIComponent:SimpleComponent:TimeContent
    NT_ScrollView,              //ObjectBase:UIComponent:SimpleComponent:ScrollView
    NT_Progress,                //ObjectBase:UIComponent:SimpleComponent:Progress
    NT_ProgressSlider,          //ObjectBase:UIComponent:SimpleComponent:ProgressSlider
    NT_Blink,                   //ObjectBase:UIComponent:SimpleComponent:Blink
    NT_FlowElement,             //ObjectBase:UIComponent:SimpleComponent:FlowElement
    NT_VirtualJoystick,         //ObjectBase:UIComponent:SimpleComponent:VirtualJoystick
    NT_UIDrawModel,             //ObjectBase:UIComponent:SimpleComponent:UIDrawModel
                                //IContainerComponent
    NT_ContainerComponent,      //ObjectBase:UIComponent:ContainerComponent
    NT_Grid,                    //ObjectBase:UIComponent:ContainerComponent:Grid
    NT_StackPanel,              //ObjectBase:UIComponent:ContainerComponent:StackPanel
    NT_WrapPanel,               //ObjectBase:UIComponent:ContainerComponent:StackPanel:WrapPanel
    NT_Para,                    //ObjectBase:UIComponent:ContainerComponent:StackPanel:WrapPanel:Para
    NT_AutoGrid,                //ObjectBase:UIComponent:ContainerComponent:StackPanel:AutoGrid
    NT_TextFlow,                //ObjectBase:UIComponent:ContainerComponent:StackPanel:TextFlow
    NT_SlicedPanel,             //ObjectBase:UIComponent:ContainerComponent:SlicedPanel
    NT_ImagePackage,            //ObjectBase:UIComponent:ContainerComponent:ImagePackage
                                //ChildItem
    NT_ChildItem,               //ObjectBase:UIComponent:ChildItem
    NT_GridItem,                //ObjectBase:UIComponent:ChildItem:GridItem
                                //IEventComponent
    NT_ButtonBase,              //ObjectBase:UIComponent:ButtonBase
    NT_Button,                  //ObjectBase:UIComponent:ButtonBase:Button
    NT_ToggleButton,            //ObjectBase:UIComponent:ButtonBase:ToggleButton
    NT_CheckButton,             //ObjectBase:UIComponent:ButtonBase:ToggleButton:CheckButton
    NT_RadioButton,             //ObjectBase:UIComponent:ButtonBase:ToggleButton:RadioButton
    NT_SkillButton,             //ObjectBase:UIComponent:ButtonBase:SkillButton
    NT_InputBox,                //ObjectBase:UIComponent:InputBox

    NT_EventNodeBase,           //ObjectBase:EventNodeBase
    NT_EventTrigger,            //ObjectBase:EventTrigger
    NT_EventScript,             //ObjectBase:EventTrigger:EventScript
    NT_EventNodeGroup,          //ObjectBase:EventNodeGroup
    NT_Timer,                   //ObjectBase:Timer

    NT_SkinGroup,               //ObjectBase:SkinGroup
    NT_SkinRow,                 //ObjectBase:SkinRow
    NT_Skin,                    //ObjectBase:Skin
    NT_ShapeGroup,              //ObjectBase:ShapeGroup

    NT_NodeTypeSetting,         //ObjectBase:NodeTypeSetting
    NT_NameSpaceSetting,        //ObjectBase:NameSpaceSetting
    NT_ElementSetting,          //ObjectBase:ElementSetting
    NT_AttrSetting,             //ObjectBase:AttrSetting
    NT_DataInfoNode,            //ObjectBase:DataInfoNode
    NT_DataInfoAttr,            //ObjectBase:DataInfoAttr

    NT_UITexture,               //ObjectBase:UITexture
    NT_UIImageBase,             //ObjectBase:UIImageBase
    NT_UIImageRect,             //ObjectBase:UIImageRect
    NT_UIImagePoly,             //ObjectBase:UIImagePoly

    NT_MeasureData,
    NT_Geometry,                //ObjectBase:Geometry
    NT_GeometryPoly,            //ObjectBase:Geometry:GeometryPoly
    NT_GeometryRect,            //ObjectBase:Geometry:GeometryRect
    NT_GeometryUnionPoly,       //ObjectBase:Geometry:GeometryUnionPoly

    NT_UIXmlConfig,             //ObjectBase:UIXmlConfig
    NT_UIKeySubject,            //ObjectBase:UIKeySubject

    NT_MAX,
};

#define NT_Block NT_SimpleComponent
#define NT_Panel NT_ContainerComponent

//��������ö��
enum AttrType_e : u16 {
    AT_ObjectBase_SsueId,
    AT_Control_Parent,
    AT_Control_Container,
    AT_Control_DataColor,
    AT_Control_DataIsColorSetting,
    AT_Control_DataIsClip,
    AT_Control_DataIsVisible,
    AT_Control_IsOwnEvent,
    AT_Control_CanTransHandle,
    AT_Control_CanTransScript,
    AT_Control_NextUIEvent,

    AT_BasicMeasure_Ax,
    AT_BasicMeasure_Ay,
    AT_BasicMeasure_Aw,
    AT_BasicMeasure_Ah,
    AT_BasicMeasure_Rx,
    AT_BasicMeasure_Ry,
    AT_BasicMeasure_Rw,
    AT_BasicMeasure_Rh,
    AT_BasicMeasure_IsAutoWidth,
    AT_BasicMeasure_IsAutoHeight,
    AT_BasicMeasure_MinAw,
    AT_BasicMeasure_MinAh,
    AT_BasicMeasure_MaxAw,
    AT_BasicMeasure_MaxAh,
    AT_BasicMeasure_MinRw,
    AT_BasicMeasure_MinRh,
    AT_BasicMeasure_MaxRw,
    AT_BasicMeasure_MaxRh,
    AT_BasicMeasure_AnchorRx,
    AT_BasicMeasure_AnchorRy,
    AT_BasicMeasure_AbsoluteMarginLeft,
    AT_BasicMeasure_AbsoluteMarginTop,
    AT_BasicMeasure_AbsoluteMarginRight,
    AT_BasicMeasure_AbsoluteMarginBottom,
    AT_BasicMeasure_RelativeMarginLeft,
    AT_BasicMeasure_RelativeMarginTop,
    AT_BasicMeasure_RelativeMarginRight,
    AT_BasicMeasure_RelativeMarginBottom,
    AT_BasicMeasure_AbsolutePaddingLeft,
    AT_BasicMeasure_AbsolutePaddingTop,
    AT_BasicMeasure_AbsolutePaddingRight,
    AT_BasicMeasure_AbsolutePaddingBottom,

    AT_BasicTransform_UpSideDown,
    AT_BasicTransform_Mirror,
    AT_BasicTransform_Alpha,
    AT_BasicTransform_Radian,
    AT_BasicTransform_ScaleX,
    AT_BasicTransform_ScaleY,
    AT_BasicTransform_OffsetX,
    AT_BasicTransform_OffsetY,

    AT_BasicClip_IsEnableClip,
    AT_BasicClip_ClipType,
    AT_BasicClip_ClipRoundedRadius,
    AT_BasicClip_ClipCircleRadius,
    AT_BasicClip_ClipCircleOffsestX,
    AT_BasicClip_ClipCircleOffsestY,
    AT_BasicClip_ClipBeginAngle,
    AT_BasicClip_ClipEndAngle,

    AT_Control_Id,
    AT_Control_SkinKey,
    AT_Control_SkinName,
    AT_Control_Text,
    AT_Control_TextKey,
    AT_Control_IsInput,
    AT_Control_DataIsEnable,
    AT_Control_DataIsPressed,
    AT_Control_DataIsSelected,
    AT_Control_DataIsBlink,
    AT_Control_DataCcit,
    AT_Control_DataCommand,
    AT_UIScene_DataCanClose,
    AT_UIScene_DataIsCloseWhenCheck,
    AT_UIScene_DataIsFloatUI,
    AT_UIScene_DataCanBeMask,
    AT_UIScene_DataCanEnableMask,
    AT_UIScene_DataCanEnableMaskForce,
    AT_UIScene_DataIsOwnEvent,
    AT_UIScene_DataIsCanBeCurScene,
    AT_StackPanel_DataDirection,
    AT_StackPanel_DataRowSpacing,
    AT_StackPanel_DataColumnSpacing,
    AT_TextFlow_TextAx,
    AT_TextFlow_TextAy,
    AT_TextFlow_TextRx,
    AT_TextFlow_TextRy,
    AT_TextFlow_TextAnchorRx,
    AT_TextFlow_TextAnchorRy,
    AT_TextFlow_TextTips,
    AT_TextFlow_CurConvertIndex,
    AT_TextFlow_LinkSkin,
    AT_TextFlow_IsSingleLine,
    AT_TextFlow_IsPassword,
    AT_AutoGrid_DataGridCount,
    AT_SlicedPanel_SlicedX,
    AT_SlicedPanel_SlicedY,
    AT_SlicedPanel_InnerWidth,
    AT_SlicedPanel_InnerHeight,
    AT_SlicedPanel_OuterWidth,
    AT_SlicedPanel_OuterHeight,
    AT_TimeContent_TimePattern,
    AT_TimeContent_TimeOrder,
    AT_TimeContent_DataDays,
    AT_TimeContent_DataHours,
    AT_TimeContent_DataMinutes,
    AT_TimeContent_DataSeconds,
    AT_TimeContent_DataMSs,
    AT_TimeContent_TimeType,
    AT_TimeContent_TimeOut,
    AT_TimeContent_IsStart,
    AT_TimeContent_FullDisplayNumber,
    AT_TimeContent_HideLastUnitText,
    AT_TimeContent_MaxDisplaySectionNumber,
    AT_VirtualJoystick_JoystickId,
    AT_VirtualJoystick_JoystickR,
    AT_RadioButton_RadioId,
    AT_SkinGroup_Name,
    AT_Skin_Name,
    AT_ShapeGroup_Slot,
    AT_ShapeGroup_State,
    AT_UITexture_Name,
    AT_UIImageBase_Key,
    AT_UIImageBase_Name,
    AT_UIImageRect_Width,
    AT_UIImageRect_Height,
    AT_UIImageRect_X,
    AT_UIImageRect_Y,
    AT_ImageShape_ImageName,
    AT_ImageShape_Gray,
    AT_TextShape_DataFont,
    AT_TextShape_DataFontSize,
    AT_TextShape_TextDirection,
    AT_TextShape_TextSpacing,    
    AT_TextShape_DataStyle,
    AT_TextShape_DataColorUp,
    AT_TextShape_DataColorDown,
    AT_TextShape_DataColorBorder,
    AT_TextShape_DataColorShadow,
    AT_TextShape_DataColorLight,
    AT_TextShape_DataColorUnderLine,
    AT_TextShape_DataDeleteLineWidth,
    AT_TextShape_DataColorDeleteLine,
    AT_TextShape_DataLightValue,
    AT_TextShape_DataExSizeBorder,
    AT_TextShape_DataExSizeShadow,
    AT_TextShape_DataExSizeLight,
    AT_TextShape_DataLightWeight,
    AT_TextShape_DataAngleShadow,
    AT_TextShape_DataUnderLineOffsetY,
    AT_TextShape_DataUnderLineWidth,
    AT_TextShape_DataDeleteLineOffsetY,
    AT_TextShape_DataUnderLine,
    AT_TextShape_DataDeleteLine,
    AT_TextShape_DataEnableLightFont,
    AT_TextShape_DataEnableBorderFont,
    AT_TextShape_DataEnableShadowFont,
    AT_ParticleShape_DataParticleName,
    AT_ParticleShape_DataPlayCount,
    AT_ParticleShape_DataParticleScaleX,
    AT_ParticleShape_DataParticleScaleY,
    AT_ParticleShape_DataParticleScaleZ,
    AT_ParticleShape_DataAngleX,
    AT_ParticleShape_DataAngleY,
    AT_ParticleShape_DataAngleZ,
    AT_EventNodeBase_EventName,
    AT_EventScript_ScriptData,
    AT_EventScript_Sound,
    AT_UIKeySubject_Xml,
    AT_UIKeySubject_Priority,
    AT_UIKeySubject_Currency,
    AT_UIKeySubject_IsNonEvent,
    AT_UIKeySubject_IsBag,
    AT_UIKeySubject_CanShowFloat,
    AT_UIKeySubject_CanMoveRole,
    AT_Progress_MinValue,
    AT_Progress_MaxValue,
    AT_Progress_CurValue,
    AT_Progress_ProgressDirection,
    AT_Progress_ChangedRate,
    AT_Progress_ChangedSpeed,
    AT_ProgressSlider_EnableProgSlider,
    AT_SkillButton_CdTime,
    AT_SkillButton_RemainTime,
    AT_SkillButton_SkillButtonDirection,
    AT_ScrollView_Damping,
    AT_ScrollView_Stack,
    AT_ScrollView_MinSpeed,
    AT_ScrollView_PagePanelSpeed,
    AT_ScrollView_IsPagePanel,
    AT_UIDrawModel_ModelScaleX,
    AT_UIDrawModel_ModelScaleY,
    AT_UIDrawModel_ModelScaleZ,
    AT_UIDrawModel_ModelAngleX,
    AT_UIDrawModel_ModelAngleY,
    AT_UIDrawModel_ModelAngleZ,
    AT_UIDrawModel_ModelOffsetX,
    AT_UIDrawModel_ModelOffsetY,
    AT_UIDrawModel_ModelOffsetZ,
    AT_UIDrawModel_ModelBackPrefab,
    AT_UIDrawModel_BackScaleX,
    AT_UIDrawModel_BackScaleY,
    AT_UIDrawModel_BackScaleZ,
    AT_UIDrawModel_BackAngleX,
    AT_UIDrawModel_BackAngleY,
    AT_UIDrawModel_BackAngleZ,
    AT_UIDrawModel_BackOffsetX,
    AT_UIDrawModel_BackOffsetY,
    AT_UIDrawModel_BackOffsetZ,
    AT_Grid_Cw0,
    AT_Grid_Cw1,
    AT_Grid_Cw2,
    AT_Grid_Cw3,
    AT_Grid_Cw4,
    AT_Grid_Cw5,
    AT_Grid_Cw6,
    AT_Grid_Cw7,
    AT_Grid_Rh0,
    AT_Grid_Rh1,
    AT_Grid_Rh2,
    AT_Grid_Rh3,
    AT_Grid_Rh4,
    AT_Grid_Rh5,
    AT_Grid_Rh6,
    AT_Grid_Rh7,
    AT_GridItem_ColumnIndex,
    AT_GridItem_ColumnSpan,
    AT_GridItem_RowIndex,
    AT_GridItem_RowSpan,
    AT_MAX,
};

enum AttrDataType_e : u8 {
    ADT_B2,
    ADT_S32,
    ADT_U32,
    ADT_F32,
    ADT_S64,
    ADT_HU32,
    ADT_HS64,
    ADT_STR,
    ADT_WSTR,
    ADT_MAX
};
enum ProcessType_e : u8 {
	PT_None,
	PT_BlockScript,
    PT_BlockStatusChange,
	PT_BlockHandle,
	PT_Max
};
enum EventType_e : u8 {
    WordRowRegisterWNO(EventType, ET_, Null)
    //Touch
    WordRowRegisterWNO(EventType, ET_, Press)
    WordRowRegisterWNO(EventType, ET_, Release)
    WordRowRegisterWNO(EventType, ET_, Drag)
    WordRowRegisterWNO(EventType, ET_, Click)
    WordRowRegisterWNO(EventType, ET_, LostFocus)
    WordRowRegisterWNO(EventType, ET_, Select)
    WordRowRegisterWNO(EventType, ET_, Unselect)
    //Normal
    WordRowRegisterWNO(EventType, ET_, Timer)
    WordRowRegisterWNO(EventType, ET_, AddChildNotYet)
    WordRowRegisterWNO(EventType, ET_, RemoveChildNotYet)
    WordRowRegisterWNO(EventType, ET_, ReleaseChildrenNotYet)
    WordRowRegisterWNO(EventType, ET_, AddChildDone)
    WordRowRegisterWNO(EventType, ET_, RemoveChildDone)
    WordRowRegisterWNO(EventType, ET_, ReleaseChildrenDone)
    WordRowRegisterWNO(EventType, ET_, AddComponentDone)
    //Attr
    WordRowRegisterWNO(EventType, ET_, AttrValueChanged)
    WordRowRegisterWNO(EventType, ET_, SceneChanged)
    WordRowRegisterWNO(EventType, ET_, TextChanged)
    WordRowRegisterWNO(EventType, ET_, VisibleChanged)
    WordRowRegisterWNO(EventType, ET_, EnableChanged)
    WordRowRegisterWNO(EventType, ET_, CommandChanged)
    //Draw
    WordRowRegisterWNO(EventType, ET_, LanguageThemeChanged)
    WordRowRegisterWNO(EventType, ET_, SkinGroupReplace)

    //Input & System
    WordRowRegisterWNO(EventType, ET_, Text)
    WordRowRegisterWNO(EventType, ET_, Char)
    WordRowRegisterWNO(EventType, ET_, Command)

    WordRowRegisterWNO(EventType, ET_, onSceneLoaded)
    WordRowRegisterWNO(EventType, ET_, onSceneClose)
    //CSV
    WordRowRegisterWNO(EventType, ET_, onCSVLoaded)
    WordRowRegisterWNO(EventType, ET_, onCSVAddItem)
    WordRowRegisterWNO(EventType, ET_, ItemChange)
    //TimeBlock
    WordRowRegisterWNO(EventType, ET_, CountDown)
    WordRowRegisterWNO(EventType, ET_, CountTimeOut)

    WordRowRegisterWNO(EventType, ET_, MAX)
};

enum AttrSubType_e : u8 {
    WordRowRegisterWNO(AttrSubType, AST_, halfNormal)
    WordRowRegisterWNO(AttrSubType, AST_, normal)
    WordRowRegisterWNO(AttrSubType, AST_, allBool)
    WordRowRegisterWNO(AttrSubType, AST_, MAX)
};

#pragma region "CSV"
enum CsvOptType_e : u8 {
    CSV_TYPE_ASSIGN,
    CSV_TYPE_COPY,
    CSV_TYPE_CACHE,
    CSV_TYPE_DELETE,
    CSV_TYPE_HIDE,
    CSV_TYPE_ITEM,
    CSV_TYPE_APPEND,
    CSV_TYPE_CACHE_2,
    CSV_TYPE_ASSIGN_NODELETE,
    CSV_TYPE_MAX
};

enum CsvAttrType_e : u8 {
    WordRowRegisterWNO(CsvAttrType, CAT_, Text)
    WordRowRegisterWNO(CsvAttrType, CAT_, Skin)
    WordRowRegisterWNO(CsvAttrType, CAT_, Visible)
    WordRowRegisterWNO(CsvAttrType, CAT_, IsEnable)
    WordRowRegisterWNO(CsvAttrType, CAT_, Id)
    WordRowRegisterWNO(CsvAttrType, CAT_, Value1)
    WordRowRegisterWNO(CsvAttrType, CAT_, Value2)
    WordRowRegisterWNO(CsvAttrType, CAT_, CsvData)
    WordRowRegisterWNO(CsvAttrType, CAT_, Blink)
    WordRowRegisterWNO(CsvAttrType, CAT_, Command)
    WordRowRegisterWNO(CsvAttrType, CAT_, BindId)
    WordRowRegisterWNO(CsvAttrType, CAT_, MAX)
};
#define CAT_MULTIPLEX_VALUE ((1 << CAT_Value1) | (1 << CAT_Value2))
#pragma endregion

#pragma region "Control"
typedef enum ParentAreaType_e {
    PAT_outer,
    PAT_self,
    PAT_inner,
    PAT_max,
}PAT_e;

enum ControlType_e : u16 {
    CT_Label,
    CT_Button,
    CT_CheckButton,
    CT_RadioButton,
    CT_SkillButton,
    CT_RichText,
    CT_Panel,
    CT_Grid,
    CT_Progress,
    CT_CountDown,
    CT_MAX,
};
enum SlotType_e : u8 {
    WordRowRegisterWNO(SlotType, SLOT_, body)
    WordRowRegisterWNO(SlotType, SLOT_, text)
    WordRowRegisterWNO(SlotType, SLOT_, scroll)
    WordRowRegisterWNO(SlotType, SLOT_, progFill)
    WordRowRegisterWNO(SlotType, SLOT_, progEmpty)
    WordRowRegisterWNO(SlotType, SLOT_, hSliderBack)
    WordRowRegisterWNO(SlotType, SLOT_, hSliderBody)
    WordRowRegisterWNO(SlotType, SLOT_, vSliderBack)
    WordRowRegisterWNO(SlotType, SLOT_, vSliderBody)
    WordRowRegisterWNO(SlotType, SLOT_, vJoystick)
    WordRowRegisterWNO(SlotType, SLOT_, blink)
    WordRowRegisterWNO(SlotType, SLOT_, container)
    WordRowRegisterWNO(SlotType, SLOT_, null)
    WordRowRegisterWNO(SlotType, SLOT_, progSlider)
    WordRowRegisterWNO(SlotType, SLOT_, tips)
    WordRowRegisterWNO(SlotType, SLOT_, MAX)
};
struct SlotState {
    union {
        struct {
            bool m_isPressed : 1;
            bool m_isDisable : 1;
            bool m_isSelected : 1;
        };
        unsigned char m_data = 0;
    };
};

#define SLOT_FULL 0xffff
enum StateValue_e : u8 {
    WordRowRegisterWNO(StateValue, STATE_, normal)
    WordRowRegisterWNO(StateValue, STATE_, pressed)
    WordRowRegisterWNO(StateValue, STATE_, disable)
    WordRowRegisterWNO(StateValue, STATE_, disable_pressed_x)
    WordRowRegisterWNO(StateValue, STATE_, selected)
    WordRowRegisterWNO(StateValue, STATE_, selected_pressed)
    WordRowRegisterWNO(StateValue, STATE_, selected_disable)
    WordRowRegisterWNO(StateValue, STATE_, selected_disable_pressed_x)
    WordRowRegisterWNO(StateValue, STATE_, MAX)
};
#define STATECLASS_WEIGHT 16

enum E_UI_Scene_Enable_Mode {//UI�Ƿ���õĹ���ģʽ
    E_UI_Scene_Enable_All,//����ģʽ������UI������
    E_UI_Scene_Enable_Whitelist,//������ģʽ��ֻ�а������е�UI����
    E_UI_Scene_Enable_Blacklist,//������ģʽ���������еĲ����ã���������
    E_UI_Scene_Enable_None//����UI��������
};

enum Direction_e : u16 {
    DR_L = 0x00,
    DR_T = 0x01,
    DR_R = 0x02,
    DR_B = 0x03,
    DR_MAX = 0xff,
};
enum DoubleDirection_e : u16 {
    DDR_LT = 0x01,
    DDR_LB = 0x03,
    DDR_TL = 0x10,
    DDR_TR = 0x12,
    DDR_RT = 0x21,
    DDR_RB = 0x23,
    DDR_BL = 0x30,
    DDR_BR = 0x32,
    DDR_MAX = 0xff,
};
enum ProgressDirection_e : u8 {
    WordRowRegisterWNO(ProgressDirection, PROG_DRC_, lr)
    WordRowRegisterWNO(ProgressDirection, PROG_DRC_, rl)
    WordRowRegisterWNO(ProgressDirection, PROG_DRC_, tb)
    WordRowRegisterWNO(ProgressDirection, PROG_DRC_, bt)
    WordRowRegisterWNO(ProgressDirection, PROG_DRC_, cw)
    WordRowRegisterWNO(ProgressDirection, PROG_DRC_, antiCw)
};
struct RowHy {
    ft m_h;
    ft m_y;
};
struct ColumnWx {
    ft m_w;
    ft m_x;
};
#pragma endregion

#pragma region "UIComponent"

enum TimeOrder_e : u8 {
    WordRowRegisterWNO(TimeOrder, TO_, CountDown)
    WordRowRegisterWNO(TimeOrder, TO_, Positive)
    TO_MAX,
};

enum TimeDigit_e : u8 {
    TimeDigit_MSEC = 0,
    TimeDigit_SEC,
    TimeDigit_MIN,
    TimeDigit_HOUR,
    TimeDigit_DAY,
    TimeDigit_MAX
};

#pragma endregion

enum class GraphicsEffect {
    normal,
    gray,
    stringShadow,
    stringNormal
};

struct FontDrawDataDef_S {
    const wstring* m_pText;
    int m_font;
    int m_fontSize;
    f32 m_clipX;
    f32 m_clipY;
    f32 m_clipW;
    f32 m_clipH;
    f32 m_x;
    f32 m_y;
    f32 m_z;
    u32 m_style;
    u32 m_color0;
    u32 m_color1;
    u32 m_color2;
    u32 m_colorBorder;
    u32 m_colorShadow;
    u32 m_colorLight;
    u32 m_colorLine;
    u32 m_colorStrikethrough;
    f32 m_exSizeBorder;
    f32 m_exSizeShadow;
    f32 m_exSizeLight;
    f32 m_angleShadow;
    u32 m_anchor;
    f32 m_sx;
    f32 m_sy;
    GraphicsEffect m_effect;
    bool m_isDraw;
    bool m_isGetImage;
    bool m_isUI;
};

template<class NodeType>
struct Point {
public:
    NodeType m_x;
    NodeType m_y;
    inline Point<NodeType> operator+(const Point<NodeType>& other) const {
        return { m_x + other.m_x, m_y + other.m_y };
    }
    inline Point<NodeType> operator-(const Point<NodeType>& other) const {
        return { m_x - other.m_x, m_y - other.m_y };
    }
    inline Point<NodeType> operator+=(const Point<NodeType>& other) {
        m_x += other.m_x;
        m_y += other.m_y;
        return *this;
    }
    inline Point<NodeType> operator-=(const Point<NodeType>& other) {
        m_x -= other.m_x;
        m_y -= other.m_y;
        return *this;
    }
};

template <class DataType> class Rect {
public:
    DataType m_x = 0.f;
    DataType m_y = 0.f;
    DataType m_w = 0.f;
    DataType m_h = 0.f;
    inline Rect() {

    }
    inline Rect(DataType x, DataType y, DataType w = 0.f, DataType h = 0.f) : m_x(x), m_y(y), m_w(w), m_h(h) {

    }
    inline bool operator==(const Rect& other) const {
        if (m_w == other.m_w && m_h == other.m_h && m_x == other.m_x && m_y == other.m_y) {
            return true;
        } else {
            return false;
        }
    }
    inline bool operator!=(const Rect& other) const {
        if (m_w != other.m_w || m_h != other.m_h || m_x != other.m_x || m_y != other.m_y) {
            return true;
        } else {
            return false;
        }
    }
};

enum MixColorRule_e {
    MCR_Normal,
    MCR_Alpha,
    MCR_MAX,
};

enum  E_ClipType : u8 {
    ClipType_none = 0,
    ClipType_circle, // Բ��
    ClipType_roundedRectangle, // Բ�Ǿ���
    ClipType_sixAngleRhombus, // ��������
    ClipType_custom, // �Զ���
    ClipType_max
};

_SSUINamespaceEnd
