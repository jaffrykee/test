#include "UIImagePoly.h"
#include "UITexture.h"
#include "GeometryManager.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UIImagePoly, 0, 0);
#pragma region "����ע��"
    //NODEBASE_ATTR_REGISTER("slot", Slot, ShapeGroup, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UIImagePoly)
    //NBSCRIPT_ATTR_REGISTER("slot", Slot, ShapeGroup, S32);
NODETYPE_COMMON_PART_DEFINITION_END

void UIImagePoly::getPolyImageFromSize(PolyImage& polyImage, const Size& size, const vec4& color) {
    if (mt_pTexture != nullptr && mt_pTexture->m_texture != nullptr) {
        Size scale = {size.m_w / (m_border.m_right - m_border.m_left), size.m_h / (m_border.m_bottom - m_border.m_top)};
        polyImage.clear();
        for (auto& poi : m_poly) {
            polyImage.push_back({{poi.x * scale.m_w, poi.y * scale.m_h, 0}, color, SUBIMAGE_UV(poi, mt_pTexture->m_texture)});
        }
    } else {
        GeometryManager::getPolyImageFromSize(polyImage, size, color);
    }
}