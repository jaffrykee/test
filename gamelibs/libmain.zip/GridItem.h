#pragma once
#include "ChildItem.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class GridItem : public ChildItem {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(GridItem)
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(GridItem, ChildItem);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    int getColumnIndex() const;
    void setColumnIndex(int value);
    int getColumnSpan() const;
    void setColumnSpan(int value);
    int getRowIndex() const;
    void setRowIndex(int value);
    int getRowSpan() const;
    void setRowSpan(int value);
#pragma endregion
public:
    GridItem& assign(const GridItem& other);
    virtual void onEvent(SSUIEvent& event) override;
#pragma endregion
};

_SSUINamespaceEnd
