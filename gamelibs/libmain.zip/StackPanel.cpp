#include "StackPanel.h"
#include "Control.h"
#include "Geometry.h"
#include "UIManager.h"

#include "DataHeaders.h"

gstl::wstring ssui::StackPanel::s_tmpDirectionAttrList;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(StackPanel, 100, 500);
s_tmpDirectionAttrList.clear();
s_tmpDirectionAttrList += "1";
s_tmpDirectionAttrList += '^';
s_tmpDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpDirectionAttrList += '%';
s_tmpDirectionAttrList += "3";
s_tmpDirectionAttrList += '^';
s_tmpDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpDirectionAttrList += '%';
s_tmpDirectionAttrList += "16";
s_tmpDirectionAttrList += '^';
s_tmpDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpDirectionAttrList += '%';
s_tmpDirectionAttrList += "18";
s_tmpDirectionAttrList += '^';
s_tmpDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpDirectionAttrList += '%';
s_tmpDirectionAttrList += "33";
s_tmpDirectionAttrList += '^';
s_tmpDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpDirectionAttrList += '%';
s_tmpDirectionAttrList += "35";
s_tmpDirectionAttrList += '^';
s_tmpDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpDirectionAttrList += '%';
s_tmpDirectionAttrList += "48";
s_tmpDirectionAttrList += '^';
s_tmpDirectionAttrList += util::utf2wstr(string(u8"����"));
s_tmpDirectionAttrList += '%';
s_tmpDirectionAttrList += "50";
s_tmpDirectionAttrList += '^';
s_tmpDirectionAttrList += util::utf2wstr(string(u8"����"));
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("direction", DataDirection, StackPanel, S32, s_tmpDirectionAttrList, true);
NODEBASE_ATTR_REGISTER("rowSpacing", DataRowSpacing, StackPanel, F32);
NODEBASE_ATTR_REGISTER("columnSpacing", DataColumnSpacing, StackPanel, F32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(StackPanel)
NBSCRIPT_ATTR_REGISTER("direction", DataDirection, StackPanel, S32);
NBSCRIPT_ATTR_REGISTER("rowSpacing", DataRowSpacing, StackPanel, F32);
NBSCRIPT_ATTR_REGISTER("columnSpacing", DataColumnSpacing, StackPanel, F32);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(StackPanel, DataRowSpacing, ft)
UIComponent_ControlAttr_Def(StackPanel, DataColumnSpacing, ft)
UIComponent_ControlAttr_Def(StackPanel, DataDirection, int)
#pragma endregion

void ssui::StackPanel::createSelf() {

}

void ssui::StackPanel::disposeSelf() {

}

#pragma region "���Է���"
ssui::ft ssui::StackPanel::getDataRowSpacing() const {
    return mt_dataRowSpacing;
}

void StackPanel::setDataRowSpacing(ft value) {
    if (mt_dataRowSpacing != value) {
        mt_dataRowSpacing = value;
        getHost()->touchMeasureChanged();
    }
}

ssui::ft ssui::StackPanel::getDataColumnSpacing() const {
    return mt_dataColumnSpacing;
}

void StackPanel::setDataColumnSpacing(ft value) {
    if (mt_dataColumnSpacing != value) {
        mt_dataColumnSpacing = value;
        getHost()->touchMeasureChanged();
    }
}

int ssui::StackPanel::getDataDirection() const {
    return mt_dataDirection;
}

void StackPanel::setDataDirection(int value) {
    if (mt_dataDirection != value) {
        mt_dataDirection = value;
        getHost()->touchMeasureChanged();
    }
}

gstl::u8 ssui::StackPanel::getSingleDirection() const {
    return getDataDirection() >> 4;//0123,��������
}

bool ssui::StackPanel::getIsHorizontal() const {
    return !getIsVertical();// ˮƽ
}

bool ssui::StackPanel::getIsVertical() const {
    return getDataDirection() & 0x10;
}

bool ssui::StackPanel::getIsLeft() const {
    //��λΪ0���ߵ�λΪ0��
    return getSingleDirection() == DR_L;
}

bool ssui::StackPanel::getIsTop() const {
    //��λΪ1���ߵ�λΪ1��
    return getSingleDirection() == DR_T;
}
#pragma endregion

StackPanel& ssui::StackPanel::assign(const StackPanel& other) {
    mt_dataDirection = other.mt_dataDirection;
    mt_dataRowSpacing = other.mt_dataRowSpacing;
    mt_dataColumnSpacing = other.mt_dataColumnSpacing;
    Base::assign(other);
    return *this;
}

const Border& ssui::StackPanel::getChildArea(const Control* pChild) const {
    return Base::getChildArea(pChild);
//     auto i = m_container.where(const_cast<Control*>(pChild));
//     if (i < 0 || i >= m_childrenBorder.size()) {
//         return Base::getChildArea(pChild);
//     } else {
//         return m_childrenBorder[i];
//     }
}

void ssui::StackPanel::onPrepareData() {
    if (getHost() == nullptr) {
        return;
    }
    m_childrenPosition.clear();
}

void ssui::StackPanel::setChildrenOffsetY() {

}

void ssui::StackPanel::setSelectControl(Control * value) {
    if (m_selectControl != value) {
        m_selectControl = value;
    }
}

Control* ssui::StackPanel::getSelectControl() const {
    return m_selectControl;
}

void ssui::StackPanel::onTransformChildren(unsigned char drawStep) {
    m_childrenPosition.clear();
    if (getHost() == nullptr || container().empty()) {
        return;
    }
    const auto& selfArea = getMeasure(PAT_inner).m_srcArea;
    auto selfWidth = selfArea.m_right - selfArea.m_left;
    auto selfHeight = selfArea.m_bottom - selfArea.m_top;
    switch (getSingleDirection()) {
        case DR_L:
        case DR_T:
        {
            m_childrenPosition.push_back(vec2(0, 0));
        }
        break;
        case DR_R:
        {
            m_childrenPosition.push_back(vec2(selfWidth, 0));
        }
        break;
        case DR_B:
        {
            m_childrenPosition.push_back(vec2(0, selfHeight));
        }
        break;
        default:
            break;
    }

    Border curChildBorder;
    ft curChildWidth = 0, curChildHeight = 0;
    for (auto& pChild : *this) {
        auto& pCurChildGeo = pChild->getOuterMeasure().m_pTransGeo;
        if (pCurChildGeo == nullptr) {
            continue;
        }
        pCurChildGeo->getBorder(curChildBorder);
        curChildWidth = curChildBorder.m_right - curChildBorder.m_left;
        curChildHeight = curChildBorder.m_bottom - curChildBorder.m_top;

        switch (getSingleDirection()) {
            case DR_L:
            {
                auto x = m_childrenPosition.back().x;
                auto y = m_childrenPosition.back().y;
                if (!(math::equalZero(x, 0.01f) && math::equalZero(y, 0.01f))) {
                    applyTransformToSelfChildGrandChildAndSoOn(pChild, x, y);
                }
                m_childrenPosition.push_back(m_childrenPosition.back());
                m_childrenPosition.back().x += (curChildWidth + getDataColumnSpacing());
            }
            break;
            case DR_T:
            {
                auto x = m_childrenPosition.back().x;
                auto y = m_childrenPosition.back().y;
                if (!(math::equalZero(x, 0.01f) && math::equalZero(y, 0.01f))) {
                    applyTransformToSelfChildGrandChildAndSoOn(pChild, x, y);
                }
                m_childrenPosition.push_back(m_childrenPosition.back());
                m_childrenPosition.back().y += (curChildHeight + getDataRowSpacing());
            }
            break;
            case DR_R:
            {
                m_childrenPosition.back().x -= curChildWidth;
                auto x = m_childrenPosition.back().x;
                auto y = m_childrenPosition.back().y;
                if (!(math::equalZero(x, 0.01f) && math::equalZero(y, 0.01f))) {
                    applyTransformToSelfChildGrandChildAndSoOn(pChild, x, y);
                }
                m_childrenPosition.push_back(m_childrenPosition.back());
                m_childrenPosition.back().x -= getDataColumnSpacing();
            }
            break;
            case DR_B:
            {
                //applyTransformToSelfChildGrandChildAndSoOn(pChild, m_childrenPosition.back().x - curChildBorder.m_right, m_childrenPosition.back().y);
                m_childrenPosition.back().y -= curChildHeight;
                auto x = m_childrenPosition.back().x;
                auto y = m_childrenPosition.back().y;
                if (!(math::equalZero(x, 0.01f) && math::equalZero(y, 0.01f))) {
                    applyTransformToSelfChildGrandChildAndSoOn(pChild, x, y);
                }
                m_childrenPosition.push_back(m_childrenPosition.back());
                m_childrenPosition.back().y -= getDataRowSpacing();
            }
            break;
            default:
                break;
        }
    }
    if (getNodeType() == NT_TextFlow) {
        setChildrenOffsetY();
    }
}

bool ssui::StackPanel::onDrawChildren(unsigned char drawStep, bool isReDraw) {
    if (container().empty()) {
        return true;
    }
    bool isPosterityReady = true;
    if (isReDraw == false) {
        for (auto& pChild : *this) {
            if (pChild->isDrawReady() == false) {
                isReDraw = true;
                break;
            }
        }
    }
    if (isReDraw) {
        for (auto& pChild : *this) {
            pChild->assignAllDrawChanged();
            pChild->onDraw(drawStep);
        }
        onTransformChildren(drawStep);
        if (UIManager::getInstance()->m_openDrawDebug == true) {
            printf("\n%d\t2 Parent", drawStep);
            getHost()->printData();
            for (auto& pChild : *this) {
                printf("\n%d\t2", drawStep);
                pChild->printData();
            }
        }
    } else {
        for (auto& pChild : *this) {
            pChild->onDraw(drawStep);
        }
    }
    for (auto& pChild : *this) {
        if (pChild->isDrawReady() == false || pChild->m_isPosterityReady == false) {
            isPosterityReady = false;
            break;
        }
    }
    return isPosterityReady;
}
