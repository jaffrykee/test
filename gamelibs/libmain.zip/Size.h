#pragma once
#include "SSUIPublic.h"

using namespace ss2;
using namespace gstl;

_SSUINamespaceBegin

class Border;
class Size {
public:
    static void getSumAggregate(Size& ret, const Size& sizeA, const Size& sizeB);
public:
    ft m_w = 0.f;
    ft m_h = 0.f;
public:
    Size(ft w, ft h);
    Size(const Border& aabb);
    bool operator==(const Size& other) const;
    bool operator!=(const Size& other) const;
    void sumAggregate(const Size& size, const int& retCalInitArea);
};

_SSUINamespaceEnd
