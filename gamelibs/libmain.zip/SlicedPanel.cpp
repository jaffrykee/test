#include "SlicedPanel.h"
#include "Control.h"
#include "GeometryManager.h"

#include "DataHeaders.h"

ArrayList<Vpct_t> ssui::SlicedPanel::s_renderCache[9];

NODETYPE_COMMON_PART_DEFINITION_BEGIN(SlicedPanel, 100, 300);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("slicedX", SlicedX, SlicedPanel, S32);
NODEBASE_ATTR_REGISTER("slicedY", SlicedY, SlicedPanel, S32);
NODEBASE_ATTR_REGISTER("innerW", InnerWidth, SlicedPanel, S32);
NODEBASE_ATTR_REGISTER("innerH", InnerHeight, SlicedPanel, S32);
NODEBASE_ATTR_REGISTER("outerW", OuterWidth, SlicedPanel, S32);
NODEBASE_ATTR_REGISTER("outerH", OuterHeight, SlicedPanel, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(SlicedPanel)
NBSCRIPT_ATTR_REGISTER("slicedX", SlicedX, SlicedPanel, S32);
NBSCRIPT_ATTR_REGISTER("slicedY", SlicedY, SlicedPanel, S32);
NBSCRIPT_ATTR_REGISTER("innerW", InnerWidth, SlicedPanel, S32);
NBSCRIPT_ATTR_REGISTER("innerH", InnerHeight, SlicedPanel, S32);
NBSCRIPT_ATTR_REGISTER("outerW", OuterWidth, SlicedPanel, S32);
NBSCRIPT_ATTR_REGISTER("outerH", OuterHeight, SlicedPanel, S32);
NODETYPE_COMMON_PART_DEFINITION_END

int ssui::SlicedPanel::getSlicedX() const {
    return m_slicedX;
}

void ssui::SlicedPanel::setSlicedX(int value) {
    m_slicedX = value;
    getHost()->touchRenderChanged();
}

int ssui::SlicedPanel::getSlicedY() const {
    return m_slicedY;
}

void ssui::SlicedPanel::setSlicedY(int value) {
    m_slicedY = value;
    getHost()->touchRenderChanged();
}

int ssui::SlicedPanel::getInnerWidth() const {
    return m_innerWidth;
}

void ssui::SlicedPanel::setInnerWidth(int value) {
    m_innerWidth = value;
    getHost()->touchRenderChanged();
}

int ssui::SlicedPanel::getInnerHeight() const {
    return m_innerHeight;
}

void ssui::SlicedPanel::setInnerHeight(int value) {
    m_innerHeight = value;
    getHost()->touchRenderChanged();
}

int ssui::SlicedPanel::getOuterWidth() const {
    return m_outerWidth;
}

void ssui::SlicedPanel::setOuterWidth(int value) {
    m_outerWidth = value;
    getHost()->touchRenderChanged();
}

int ssui::SlicedPanel::getOuterHeight() const {
    return m_outerHeight;
}

void ssui::SlicedPanel::setOuterHeight(int value) {
    m_outerHeight = value;
    getHost()->touchRenderChanged();
}

SlicedPanel& ssui::SlicedPanel::assign(const SlicedPanel& other) {
    Base::assign(other);
    return *this;
}

ssui::ft ssui::SlicedPanel::extensionLen(ft poiPos, ft lenPos, ft srcLen, ft dstLen) {
    return lenPos + ((poiPos - lenPos) / srcLen) * dstLen;
}

//  0   1   2
//  3   4   5
//  6   7   8
void ssui::SlicedPanel::onSliceFunc(Control* pSelf) {
    if (pSelf == nullptr) {
        return;
    }
    for (auto& pComp : pSelf->m_components) {
        for (auto& pChild : pComp->container()) {
            onSliceFunc(pChild);
        }
    }
    if (pSelf->m_curRenderCount == 0) {
        return;
    }
    auto sx = m_slicedX;
    auto sy = m_slicedY;
    auto iw = m_innerWidth;
    auto ih = m_innerHeight;
    auto ow = m_outerWidth;
    auto oh = m_outerHeight;

    const ft cx[4] = { 0, static_cast<ft>(sx), static_cast<ft>(sx + iw), static_cast<ft>(ow) };
    const ft cy[4] = { 0, static_cast<ft>(sy), static_cast<ft>(sy + ih), static_cast<ft>(oh) };
    const Border arrRect[9] = {
        { cx[0], cy[0], cx[1], cy[1] },
        { cx[1], cy[0], cx[2], cy[1] },
        { cx[2], cy[0], cx[3], cy[1] },

        { cx[0], cy[1], cx[1], cy[2] },
        { cx[1], cy[1], cx[2], cy[2] },
        { cx[2], cy[1], cx[3], cy[2] },

        { cx[0], cy[2], cx[1], cy[3] },
        { cx[1], cy[2], cx[2], cy[3] },
        { cx[2], cy[2], cx[3], cy[3] },
    };
    const auto& area = getHost()->getMeasure(getParentAreaType()).m_srcArea;
    ft fw = area.m_right - area.m_left;
    ft fh = area.m_bottom - area.m_top;
    auto mw = fw - ow + iw;
    auto mh = fh - oh + ih;
    auto oldCount = pSelf->m_curRenderCount;
    pSelf->m_curRenderCount = 0;
    ArrayList<PolyImage> oldArrRender;
    //pSelf->m_arrRender.clear();
    for (auto it = pSelf->m_arrRender.begin(); it < pSelf->m_arrRender.begin() + oldCount; ++it) {
        if (it->empty()) {
            continue;
        }
        for (int i = 0; i < 9; i++) {
            s_renderCache[i] = *it;
            GeometryManager::clipPolyImage(s_renderCache[i], arrRect[i]);
        }

        //s_renderCache[0]
        for (auto& vpct : s_renderCache[1]) {
            vpct.position.x = extensionLen(vpct.position.x, cx[1], iw, mw);
        }
        for (auto& vpct : s_renderCache[2]) {
            vpct.position.x += (fw - ow);
        }
        for (auto& vpct : s_renderCache[3]) {
            vpct.position.y = extensionLen(vpct.position.y, cy[1], ih, mh);
        }
        for (auto& vpct : s_renderCache[4]) {
            vpct.position.x = extensionLen(vpct.position.x, cx[1], iw, mw);
            vpct.position.y = extensionLen(vpct.position.y, cy[1], ih, mh);
        }
        for (auto& vpct : s_renderCache[5]) {
            vpct.position.x += (fw - ow);
            vpct.position.y = extensionLen(vpct.position.y, cy[1], ih, mh);
        }
        for (auto& vpct : s_renderCache[6]) {
            vpct.position.y += (fh - oh);
        }
        for (auto& vpct : s_renderCache[7]) {
            vpct.position.x = extensionLen(vpct.position.x, cx[1], iw, mw);
            vpct.position.y += (fh - oh);
        }
        for (auto& vpct : s_renderCache[8]) {
            vpct.position.x += (fw - ow);
            vpct.position.y += (fh - oh);
        }
        for (int i = 0; i < 9; i++) {
            if (s_renderCache[i].empty()) {
                continue;
            }
            oldArrRender.push_back(s_renderCache[i]);
        }
    }
    pSelf->swap(oldArrRender);
}

void ssui::SlicedPanel::onRender(unsigned char drawStep) {
    for (auto& pChild : container()) {
        onSliceFunc(pChild);
    }
}
