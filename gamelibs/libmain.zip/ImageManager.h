#pragma once
#include "ssuiBasic.h"
#include "NodeManager.h"
#include "UITexture.h"

_SSUINamespaceBegin

class ImageManager {
public:
    static HashMap<strHash, UITexture*> s_mapTexture;
    static HashMap<strHash, UITexture*> s_mapUsingTexture;
    //static bool s_isInMod;
private:
    static string st_artistPath;
    static string st_freePath;
    static string st_imagePath;
    static string st_skinPath;
    static string st_imageOffsetPath;
public:
    static inline void initialize() {
        destroy();
    }
    static inline void destroy() {
        for (auto& pairTexture : s_mapTexture) {
            pairTexture.second->releaseObject();
        }
        s_mapTexture.clear();
    }
#pragma region "·�����"
    inline static const string& getArtistPath() {
        return st_artistPath;
    }
    inline static void setArtistPath(const string& value) {
        if (st_artistPath != value) {
            st_artistPath = value;
            setImageOffsetPath(getArtistPath() + getFreePath() + getImagePath());
        }
    }
    inline static const string& getFreePath() {
        return st_freePath;
    }
    inline static void setFreePath(const string& value) {
        if (st_freePath != value) {
            st_freePath = value;
            setImageOffsetPath(getArtistPath() + getFreePath() + getImagePath());
        }
    }
    inline static const string& getImagePath() {
        return st_imagePath;
    }
    inline static void setImagePath(const string& value) {
        if (st_imagePath != value) {
            st_imagePath = value;
            setImageOffsetPath(getArtistPath() + getFreePath() + getImagePath());
        }
    }
    inline static const string& getSkinPath() {
        return st_skinPath;
    }
    inline static void setSkinPath(const string& value) {
        if (st_skinPath != value) {
            st_skinPath = value;
        }
    }
    inline static const string& getImageOffsetPath() {
        return st_imageOffsetPath;
    }
    inline static void setImageOffsetPath(const string& value) {
        if (st_imageOffsetPath != value) {
            st_imageOffsetPath = value;
        }
    }
#pragma endregion
    inline static UITexture* getUITexture(const string& name) {
        StringManager::getInstance()->m_tmpString = util::lowcase(name);
        const auto& pairTexture = s_mapTexture.find(StringManager::getInstance()->m_tmpString.hashCode());
        if (pairTexture != s_mapTexture.end()) {
            return pairTexture->second;
        } else {
            auto pTexture = UITexture::createUITexture(StringManager::getInstance()->m_tmpString);
            s_mapTexture.insert(StringManager::getInstance()->m_tmpString.hashCode(), pTexture);
            return pTexture;
        }
    }
    inline static UIImageBase* getSubImage(strHash keyTexture, strHash keyImage) {
        const auto& pairTexture = s_mapTexture.find(keyTexture);
        if (pairTexture != s_mapTexture.end()) {
            auto pTexture = pairTexture->second;
            if (pTexture->m_texture != nullptr) {
                const auto& pairSubImage = pTexture->m_mapSubImage.find(keyImage);
                if (pairSubImage != pTexture->m_mapSubImage.end()) {
                    return pairSubImage->second;
                }
            }
        }
        return nullptr;
    }
    static void useTexture(Texture& tex, const string& imageName, const bool isFromMod, const string& imagePath = "", const string& extension = ".tga");
};

_SSUINamespaceEnd
