#include "UIImageRect.h"
#include "UITexture.h"
#include "GeometryManager.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UIImageRect, 2500, 5000);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("width", Width, UIImageRect, F32);
    NODEBASE_ATTR_REGISTER("height", Height, UIImageRect, F32);
    NODEBASE_ATTR_REGISTER("x", X, UIImageRect, F32);
    NODEBASE_ATTR_REGISTER("y", Y, UIImageRect, F32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UIImageRect)
    NBSCRIPT_ATTR_REGISTER("width", Width, UIImageRect, F32);
    NBSCRIPT_ATTR_REGISTER("height", Height, UIImageRect, F32);
    NBSCRIPT_ATTR_REGISTER("x", X, UIImageRect, F32);
    NBSCRIPT_ATTR_REGISTER("y", Y, UIImageRect, F32);
NODETYPE_COMMON_PART_DEFINITION_END

int UIImageRect::getUvData(Rect<ft>& uvData) {
    if (mt_pTexture != nullptr && mt_pTexture->m_texture != nullptr) {
        uvData.m_x = mt_x / mt_pTexture->m_texture.width();
        uvData.m_y = mt_y / mt_pTexture->m_texture.height();
        uvData.m_w = mt_width / mt_pTexture->m_texture.width();
        uvData.m_h = mt_height / mt_pTexture->m_texture.height();
        return 0;
    } else {
        return -1;
    }
}

int UIImageRect::getUvData(PolyImage& polyImage) {
    Rect<ft> uvData;
    if (polyImage.size() == 4 && getUvData(uvData) == 0) {
        polyImage[0].texCoord = {uvData.m_x, uvData.m_y};
        polyImage[1].texCoord = {uvData.m_x + uvData.m_w, uvData.m_y};
        polyImage[2].texCoord = {uvData.m_x + uvData.m_w, uvData.m_y + uvData.m_h};
        polyImage[3].texCoord = {uvData.m_x, uvData.m_y + uvData.m_h};
        return 0;
    } else {
        return -1;
    }
}

void UIImageRect::getPolyImageFromSize(PolyImage& polyImage, const Size& size, const vec4& color) {
    GeometryManager::getPolyImageFromSize(polyImage, size, color);
    getUvData(polyImage);
}