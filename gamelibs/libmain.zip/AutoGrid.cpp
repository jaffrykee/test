#include "AutoGrid.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(AutoGrid, 20, 150);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("gridCount", DataGridCount, AutoGrid, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(AutoGrid)
    NBSCRIPT_ATTR_REGISTER("gridCount", DataGridCount, AutoGrid, S32);
NODETYPE_COMMON_PART_DEFINITION_END

void AutoGrid::refreshChildSizeCache() {
    m_drawRowHy.clear();
    m_drawColumnWx.clear();
    if (getHost()->getVControlCount() <= 0) {
        return;
    }

    const Rect<ft> tmpChildSize = {0.f, 0.f};
    int curRow = 0;
    int curColumn = 0;
    bool isHrz = getIsHorizontal();
    bool rowChanged = true;
    bool colChanged = true;
    ft rValue = 0.f;
    ft bValue = 0.f;
    for (auto& pChildDraw : container()) {
        if (pChildDraw->getDataIsVisible() == false) {
            continue;
        }
#ifdef INC
        pChildDraw->onMeasure(tmpChildSize);
        rValue = getHost()->getBraceAutoWidth(pChildDraw->m_tmpInitAabb.m_right, pChildDraw);
        bValue = getHost()->getBraceAutoHeight(pChildDraw->m_tmpInitAabb.m_bottom, pChildDraw);
#endif
        if (colChanged) {
            //��+1�ˡ�
            if (curColumn >= m_drawColumnWx.size()) {
                m_drawColumnWx.push_back({rValue, 0.f});
            } else {
                if (rValue > m_drawColumnWx[curColumn].m_w) {
                    m_drawColumnWx[curColumn].m_w = rValue;
                }
            }
        }
        if (rowChanged) {
            //��+1�ˡ�
            if (curRow >= m_drawRowHy.size()) {
                m_drawRowHy.push_back({bValue, 0.f});
            } else {
                if (bValue > m_drawRowHy[curRow].m_h) {
                    m_drawRowHy[curRow].m_h = bValue;
                }
            }
        }
        if (isHrz) {
            getHorizontalNextRowAndColumn(curRow, curColumn, rowChanged, colChanged);
        } else {
            getVerticalNextRowAndColumn(curRow, curColumn, rowChanged, colChanged);
        }
    }
    if (isHrz) {
        if (!rowChanged) {
            m_drawRowCount = ++curRow;
        } else {
            m_drawRowCount = curRow;
        }
        m_drawColumnCount = m_drawRowCount == 1 ? getHost()->getVControlCount() : getDataGridCount();
    } else {
        m_drawRowCount = getDataGridCount();
        if (!colChanged) {
            m_drawColumnCount = ++curColumn;
        } else {
            m_drawColumnCount = curColumn;
        }
        m_drawRowCount = m_drawColumnCount == 1 ? getHost()->getVControlCount() : getDataGridCount();
    }
    refreshRowAndColumnXY();
}
