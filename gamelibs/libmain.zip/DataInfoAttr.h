#pragma once
#include "ObjectBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class DataInfoAttr : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(DataInfoAttr);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
        if (m_dataType == ADT_STR) {
            delete m_pStrData;
        } else if (m_dataType == ADT_WSTR) {
            delete m_pWstrData;
        }
    }
    NODETYPE_COMMON_PART_DECLARATION_END(DataInfoAttr, ObjectBase);

#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
    static string s_tmpParseStr;
#pragma endregion

#pragma region "��̬����"
public:
    static inline DataInfoAttr* createObject(AttrType_e attrType) {
        auto pAttrInfo = createObject();
        pAttrInfo->m_attrType = (u16)attrType;
        return pAttrInfo;
    }
    static inline DataInfoAttr* createObject(AttrType_e attrType, const b2& value) {
        auto pAttrInfo = createObject(attrType);
        pAttrInfo->m_dataType = ADT_B2;
        pAttrInfo->m_bData = value;
        return pAttrInfo;
    }
    static inline DataInfoAttr* createObject(AttrType_e attrType, const int& value) {
        auto pAttrInfo = createObject(attrType);
        pAttrInfo->m_dataType = ADT_S32;
        pAttrInfo->m_iData = value;
        return pAttrInfo;
    }
    static inline DataInfoAttr* createObject(AttrType_e attrType, const u32& value) {
        auto pAttrInfo = createObject(attrType);
        pAttrInfo->m_dataType = ADT_U32;
        pAttrInfo->m_uData = value;
        return pAttrInfo;
    }
    static inline DataInfoAttr* createObject(AttrType_e attrType, const f32& value) {
        auto pAttrInfo = createObject(attrType);
        pAttrInfo->m_dataType = ADT_F32;
        pAttrInfo->m_fData = value;
        return pAttrInfo;
    }
    static inline DataInfoAttr* createObject(AttrType_e attrType, const s64& value) {
        auto pAttrInfo = createObject(attrType);
        pAttrInfo->m_dataType = ADT_S64;
        pAttrInfo->m_lData = value;
        return pAttrInfo;
    }
    static inline DataInfoAttr* createObject(AttrType_e attrType, string* value) {
        auto pAttrInfo = createObject(attrType);
        pAttrInfo->m_dataType = ADT_STR;
        pAttrInfo->m_pStrData = value;
        return pAttrInfo;
    }
    static inline DataInfoAttr* createObject(AttrType_e attrType, wstring* value) {
        auto pAttrInfo = createObject(attrType);
        pAttrInfo->m_dataType = ADT_WSTR;
        pAttrInfo->m_pWstrData = value;
        return pAttrInfo;
    }
    static DataInfoAttr* createObject(AttrType_e attrType, const wstring& wstrValue);
#pragma endregion

#pragma region "��Ա"
public:
    union {
        u16 m_attrType = (u16)AT_MAX;
        AttrType_e m_attrTypeE;
    };
    union {
        u16 m_dataType = (u16)AttrDataType_e::ADT_MAX;
        AttrDataType_e m_dataTypeE;
    };
    union {
        bool m_bData;
        int m_iData;
        u32 m_uData;
        f32 m_fData;
        s64 m_lData;
        string* m_pStrData;
        wstring* m_pWstrData;
    };
#pragma endregion

#pragma region "����"
public:
    inline DataInfoAttr& assign(const DataInfoAttr& other) {
        Base::assign(other);
        *this = other;
        if (m_dataType == ADT_STR) {
            m_pStrData = new string(*other.m_pStrData);
        } else if (m_dataType == ADT_WSTR) {
            m_pWstrData = new wstring(*other.m_pWstrData);
        }
        return *this;
    }
#pragma endregion
};

_SSUINamespaceEnd
