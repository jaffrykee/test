#pragma once
#include "UIImageBase.h"
//#include "Renderable.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class UIImageRect : public UIImageBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UIImageRect)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(UIImageRect, UIImageBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    f32 mt_width = 0.f;
    f32 mt_height = 0.f;
    f32 mt_x = 0.f;
    f32 mt_y = 0.f;
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    inline f32 getWidth() const {
        return mt_width;
    }
    inline void setWidth(f32 value) {
        mt_width = value;
    }
    inline f32 getHeight() const {
        return mt_height;
    }
    inline void setHeight(f32 value) {
        mt_height = value;
    }
    inline f32 getX() const {
        return mt_x;
    }
    inline void setX(f32 value) {
        mt_x = value;
    }
    inline f32 getY() const {
        return mt_y;
    }
    inline void setY(f32 value) {
        mt_y = value;
    }
#pragma endregion
public:
    inline UIImageRect& assign(const UIImageRect& other) {
        Base::assign(other);
        return *this;
    }
    int getUvData(Rect<ft>& uvData);
    int getUvData(PolyImage& polyImage);
    virtual void getPolyImageFromSize(PolyImage& polyImage, const Size& size, const vec4& color) override;
#pragma endregion
};

_SSUINamespaceEnd
