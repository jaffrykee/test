#include "TimeContent.h"
#include "Control.h"
#include "GameTime.h"
#include "Timer.h"
#include "BasicContent.h"

#include "DataHeaders.h"

gstl::wstring ssui::TimeContent::s_tmpTimeOrderCmdData;
gstl::wstring ssui::TimeContent::s_tmpTimeTypeCmdData;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(TimeContent, 0, 0);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("timePattern", TimePattern, TimeContent, WSTR, AST_normal);
NODEBASE_ATTR_REGISTER("timeOrder", TimeOrder, TimeContent, S32, s_tmpTimeOrderCmdData, true);
NODEBASE_ATTR_REGISTER("days", DataDays, TimeContent, S32);
NODEBASE_ATTR_REGISTER("hours", DataHours, TimeContent, S32);
NODEBASE_ATTR_REGISTER("minutes", DataMinutes, TimeContent, S32);
NODEBASE_ATTR_REGISTER("seconds", DataSeconds, TimeContent, S32);
NODEBASE_ATTR_REGISTER("mss", DataMSs, TimeContent, S32);
NODEBASE_ATTR_REGISTER("timeType", TimeType, TimeContent, S32, s_tmpTimeTypeCmdData, true);
NODEBASE_ATTR_REGISTER("timeOut", TimeOut, TimeContent, S64);
NODEBASE_ATTR_REGISTER("isStart", IsStart, TimeContent, B2);
NODEBASE_ATTR_REGISTER("FullDisplayNumber", FullDisplayNumber, TimeContent, B2);
NODEBASE_ATTR_REGISTER("HideLastUnitText", HideLastUnitText, TimeContent, B2);
NODEBASE_ATTR_REGISTER("MaxDisplaySectionNumber", MaxDisplaySectionNumber, TimeContent, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(TimeContent)
NBSCRIPT_ATTR_REGISTER("timePattern", TimePattern, TimeContent, WSTR);
NBSCRIPT_ATTR_REGISTER("timeOrder", TimeOrder, TimeContent, S32);
NBSCRIPT_ATTR_REGISTER("days", DataDays, TimeContent, S32);
NBSCRIPT_ATTR_REGISTER("hours", DataHours, TimeContent, S32);
NBSCRIPT_ATTR_REGISTER("minutes", DataMinutes, TimeContent, S32);
NBSCRIPT_ATTR_REGISTER("seconds", DataSeconds, TimeContent, S32);
NBSCRIPT_ATTR_REGISTER("mss", DataMSs, TimeContent, S32);
NBSCRIPT_ATTR_REGISTER("timeType", TimeType, TimeContent, S32);
NBSCRIPT_ATTR_REGISTER("timeOut", TimeOut, TimeContent, S64);
NBSCRIPT_ATTR_REGISTER("curTime", CurTime, TimeContent, S64);
NBSCRIPT_ATTR_REGISTER("isStart", IsStart, TimeContent, B2);
NBSCRIPT_ATTR_REGISTER("FullDisplayNumber", FullDisplayNumber, TimeContent, B2);
NBSCRIPT_ATTR_REGISTER("HideLastUnitText", HideLastUnitText, TimeContent, B2);
NBSCRIPT_ATTR_REGISTER("MaxDisplaySectionNumber", MaxDisplaySectionNumber, TimeContent, S32);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def_STR(TimeContent, TimePattern, wstring)
UIComponent_ControlAttr_Def(TimeContent, TimeOrder, int)
UIComponent_ControlAttr_Def(TimeContent, DataDays, int)
UIComponent_ControlAttr_Def(TimeContent, DataHours, int)
UIComponent_ControlAttr_Def(TimeContent, DataMinutes, int)
UIComponent_ControlAttr_Def(TimeContent, DataSeconds, int)
UIComponent_ControlAttr_Def(TimeContent, DataMSs, int)
UIComponent_ControlAttr_Def(TimeContent, TimeType, s32)
UIComponent_ControlAttr_Def(TimeContent, TimeOut, s64)
UIComponent_ControlAttr_Def(TimeContent, CurTime, s64)
UIComponent_ControlAttr_Def(TimeContent, IsStart, bool)
UIComponent_ControlAttr_Def(TimeContent, FullDisplayNumber, bool)
UIComponent_ControlAttr_Def(TimeContent, HideLastUnitText, bool)
UIComponent_ControlAttr_Def(TimeContent, MaxDisplaySectionNumber, s32)
#pragma endregion

void ssui::TimeContent::createSelf() {

}

void ssui::TimeContent::disposeSelf() {

}

#pragma region "���Է���"
int ssui::TimeContent::getTimeOrder() const {
    return mt_timeOrder;
}

void ssui::TimeContent::setTimeOrder(int value) {
    mt_timeOrder = (value == TO_Positive) ? TO_Positive : TO_CountDown;
    clearTimer();
    createTimer();
}

int ssui::TimeContent::getTimeType() const {
    return mt_timeType;
}
void ssui::TimeContent::setTimeType(int value) {
    mt_timeType = (TimeDigit_e)value;
    initCurTime();
}
int ssui::TimeContent::getDataDays() const {
    return mt_dataDays;
}

void ssui::TimeContent::setDataDays(int value) {
    mt_dataDays = value;
    initCurTime();
}

int ssui::TimeContent::getDataHours() const {
    return mt_dataHours;
}

void ssui::TimeContent::setDataHours(int value) {
    mt_dataHours = value;
    initCurTime();
}

int ssui::TimeContent::getDataMinutes() const {
    return mt_dataMinutes;
}

void ssui::TimeContent::setDataMinutes(int value) {
    mt_dataMinutes = value;
    initCurTime();
}

int ssui::TimeContent::getDataSeconds() const {
    return mt_dataSeconds;
}

void ssui::TimeContent::setDataSeconds(int value) {
    mt_dataSeconds = value;
    initCurTime();
}

int ssui::TimeContent::getDataMSs() const {
    return mt_dataMSs;
}

void ssui::TimeContent::setDataMSs(int value) {
    mt_dataMSs = value;
    initCurTime();
}
const wstring& ssui::TimeContent::getTimePattern() const {
    return m_timePattern;
}
void ssui::TimeContent::setTimePattern(const wstring& value) {
    if (m_timePattern != value) {
        m_timePattern = value;
        rebuild();
    }
}

s64 ssui::TimeContent::getTimeOut() const {
    return m_timeOut;
}
void ssui::TimeContent::setTimeOut(s64 value) {
    m_timeOut = value;

}
gstl::s64 ssui::TimeContent::getCurTime() const {
    return mt_curTime;
}

void ssui::TimeContent::setCurTime(s64 value) {
    mt_curTime = value;
    onCurTimeChanged();
}

bool ssui::TimeContent::getIsStart() const {
    return mt_isStart;
}

void ssui::TimeContent::setIsStart(bool value) {
    if (mt_isStart != value) {
        mt_isStart = value;
        if (value == true) {
            createTimer();
        } else {
            clearTimer();
        }
    }
}

gstl::b2 ssui::TimeContent::getFullDisplayNumber() const {
    return mt_fullDisplayNumber;
}

void ssui::TimeContent::setFullDisplayNumber(b2 value) {
    if (mt_fullDisplayNumber != value) {
        mt_fullDisplayNumber = value;
    }
}

gstl::b2 ssui::TimeContent::getHideLastUnitText() const {
    return mt_HideLastUnitText;
}

void ssui::TimeContent::setHideLastUnitText(b2 value) {
    if (mt_HideLastUnitText != value) {
        mt_HideLastUnitText = value;
    }
}

gstl::s32 ssui::TimeContent::getMaxDisplaySectionNumber() const {
    return mt_maxDisplaySectionNumber;
}

void ssui::TimeContent::setMaxDisplaySectionNumber(s32 value) {
    if (mt_maxDisplaySectionNumber != value) {
        mt_maxDisplaySectionNumber = value;
    }
}
#pragma endregion

TimeContent& ssui::TimeContent::assign(const Self& other) {
    Base::assign(other);
    setTimePattern(other.getTimePattern());
    mt_timeOrder = other.mt_timeOrder;
    mt_fullDisplayNumber = other.mt_fullDisplayNumber;
    mt_HideLastUnitText = other.mt_HideLastUnitText;
    mt_maxDisplaySectionNumber = other.mt_maxDisplaySectionNumber;
    mt_isStart = other.mt_isStart;
    mt_dataDays = other.mt_dataDays;
    mt_dataHours = other.mt_dataHours;
    mt_dataMinutes = other.mt_dataMinutes;
    mt_dataSeconds = other.mt_dataSeconds;
    mt_dataMSs = other.mt_dataMSs;
    mt_timeType = other.mt_timeType;
    m_timeOut = other.m_timeOut;
    return *this;
}

void ssui::TimeContent::onShowTextChangedFunc() {
    Base::onShowTextChangedFunc();
    //rebuild();
}

void ssui::TimeContent::refreshShowText() {
    if (!mt_isBuildOver || !getHost() ) {
        return;
    }
	wstring text;
    text.clear();
    s64 lastTime = getCurTime();
    s64 tmp;
    //m_lowestDigit = TimeDigit_MAX;
    u8 drawEnableData = m_drawEnableData;

    if (getMaxDisplaySectionNumber()) {
        int v = 1;
        v <<= TimeDigit_MAX - 1;
        int number = getMaxDisplaySectionNumber();
        u8 drawEnableDataInclude = 0;
        while (drawEnableData) {
            if (drawEnableData & v) {
                drawEnableDataInclude |= v;
                number--;
                if (!number)
                    break;
            }
            v >>= 1;
        }
        drawEnableData &= drawEnableDataInclude;
    }

    m_cycle = 0;
    if (SSUIMath::getAttrGroupValue(m_drawEnableData, TimeDigit_DAY)) {
        m_cycle = TWV_DAY;
        tmp = lastTime / m_cycle;
        SSUIMath::assignWithCheck(m_drawDays, tmp);
        lastTime -= (tmp * m_cycle);
        //m_lowestDigit = TimeDigit_DAY;
    }
    if (SSUIMath::getAttrGroupValue(m_drawEnableData, TimeDigit_HOUR)) {
        m_cycle = TWV_HOUR;
        tmp = lastTime / m_cycle;
        SSUIMath::assignWithCheck(m_drawHours, tmp);
        lastTime -= (tmp * m_cycle);
        //m_lowestDigit = TimeDigit_HOUR;
    }
    if (SSUIMath::getAttrGroupValue(m_drawEnableData, TimeDigit_MIN)) {
        m_cycle = TWV_MIN;
        tmp = lastTime / m_cycle;
        SSUIMath::assignWithCheck(m_drawMinutes, tmp);
        lastTime -= (tmp * m_cycle);
        //m_lowestDigit = TimeDigit_MIN;
    }
    if (SSUIMath::getAttrGroupValue(m_drawEnableData, TimeDigit_SEC)) {
        m_cycle = TWV_SEC;
        tmp = lastTime / m_cycle;
        SSUIMath::assignWithCheck(m_drawSeconds, tmp);
        lastTime -= (tmp * m_cycle);
        //m_lowestDigit = TimeDigit_SEC;
    }
    if (SSUIMath::getAttrGroupValue(m_drawEnableData, TimeDigit_MSEC)) {
        SSUIMath::assignWithCheck(m_drawMSs, lastTime);
        //m_lowestDigit = TimeDigit_MSEC;
        m_cycle = TWV_MSEC;
        //             m_drawMSs = lastTime / TWV_MSEC;
        //             lastTime -= (m_drawMSs * TWV_MSEC);
    }
    //if (m_lowestDigit == TimeDigit_MAX) {
    if (m_cycle == 0) {
        for (auto& sub : m_drawData) {
            text.append(sub);
        }
    } else {
        bool hasValue = false;
        s32 showNum = 0;
        for (int i = 0; i < m_drawData.size(); i++) {
            auto& sub = m_drawData[i];
            if (sub.size() == 1 && sub.front() < TimeDigit_MAX) {
                auto fc = sub.front();
                if (!((1 << fc) & drawEnableData)) {
                    hasValue = false;
                    continue;
                }
                hasValue = true;
                u16 value = 0;
                switch (fc) {
                    case ssui::TimeDigit_MSEC:
                        value = m_drawMSs;
                        break;
                    case ssui::TimeDigit_SEC:
                        value = m_drawSeconds;
                        break;
                    case ssui::TimeDigit_MIN:
                        value = m_drawMinutes;
                        break;
                    case ssui::TimeDigit_HOUR:
                        value = m_drawHours;
                        break;
                    case ssui::TimeDigit_DAY:
                        value = m_drawDays;
                        break;
                    default:
                        break;
                }
                if (getFullDisplayNumber()) {
                    text.append(util::format("%.2d", value).c_str());
                }
                else {
                    text.append(util::itoa_s(value));
                }
                showNum++;
                if (getMaxDisplaySectionNumber() > 0 && showNum >= getMaxDisplaySectionNumber()) {
                    hasValue = false;
                }
            } else {
                if (!hasValue) {
                    continue;
                }
                if (getHideLastUnitText() && i == m_drawData.size() - 1) {
                    continue;
                }
                text.append(sub);
            }
        }
    }
    setText(text);
    getHost()->touchPrepareDataChanged();
}


void ssui::TimeContent::rebuild() {
    Timer::clearTimer(this);

    m_drawData.clear();
    m_drawEnableData = 0;

    wstring text = getTimePattern();
    if (text.empty()) {
        return;
    }
    auto pTmpSplit = RPM::s_rpArrStringW.createObject();
    util::split(text, '%', *pTmpSplit);
    if (pTmpSplit->size() > 1) {
        auto itCurRow = pTmpSplit->begin() + 1;
        m_drawData.push_back(*pTmpSplit->begin());
        for (; itCurRow != pTmpSplit->end(); ++itCurRow) {
            if (itCurRow->empty() == true) {
                continue;
            }
            if (itCurRow->front() < 'a' || itCurRow->front() > 'e') {
                m_drawData.push_back("%");
                m_drawData.back().append(*itCurRow);
            } else {
                int dig = TimeDigit_MAX - (itCurRow->front() - 'a' + 1);
                m_drawData.push_back(wstring(dig));
                SSUIMath::setAttrGroupValue(m_drawEnableData, dig, true);
                m_drawData.push_back(itCurRow->substr(1));
            }
        }
		mt_isBuildOver = true;
        refreshShowText();
        createTimer();
    }
    RPM_Release(pTmpSplit, ArrStringW);
}

void ssui::TimeContent::initCurTime() {
    setCurTime(mt_dataDays * TWV_DAY + mt_dataHours * TWV_HOUR + mt_dataMinutes * TWV_MIN +
        mt_dataSeconds * TWV_SEC + mt_dataMSs * TWV_MSEC);
}

s64 ssui::TimeContent::getTimeOutValue() {
    switch (mt_timeType) {
    case ssui::TimeDigit_MSEC:
        return m_timeOut * TWV_MSEC;
    case ssui::TimeDigit_SEC:
        return m_timeOut * TWV_SEC;
    case ssui::TimeDigit_MIN:
        return m_timeOut * TWV_MIN;
    case ssui::TimeDigit_HOUR:
        return m_timeOut * TWV_HOUR;
    case ssui::TimeDigit_DAY:
        return m_timeOut * TWV_DAY;
    }
    return m_timeOut * TWV_SEC;
}

void ssui::TimeContent::updateCurTime() {
    auto nowSysTime = GameTime::getUseTimeStable();
    if (nowSysTime < m_lastSysTime) {
        return;
    }
    u32 dTime = nowSysTime - m_lastSysTime;
    if (mt_timeOrder == TO_Positive) {
        mt_curTime += dTime;
        if (getTimeOut() > 0 && mt_curTime >= getTimeOutValue()) {
            mt_curTime = getTimeOutValue();
            if (getHost()) {
                getHost()->TriggerEvent(ET_CountTimeOut, nullptr, nullptr);
            }
            setIsStart(false);
        }
    } else {
        mt_curTime -= dTime;
        if (mt_curTime < 0) {
            mt_curTime = 0;
            if (getHost()) {
                getHost()->TriggerEvent(ET_CountDown, nullptr, nullptr);
            }
            setIsStart(false);
        }
    }
}

void ssui::TimeContent::createTimer() {
    if (getIsStart() && m_cycle != 0) {
        u32 dTime;
        if (mt_timeOrder == TO_Positive) {
            dTime = m_cycle - mt_curTime % m_cycle;
        } else {
            if (mt_curTime == 0) {
                return;
            }
            dTime = mt_curTime % m_cycle;
        }
        Timer::createObject(this, (Timer::TimerTriggerFunc)&Self::timerTrigger, dTime);
        m_lastSysTime = GameTime::getUseTimeStable();
        return;
    }
    return;
}

void ssui::TimeContent::clearTimer() {
    Timer::clearTimer(this);
    updateCurTime();
}

void ssui::TimeContent::timerTrigger(u32 targerTime) {
    updateCurTime();
    refreshShowText();
    createTimer();
}

void ssui::TimeContent::onCurTimeChanged() {
    refreshShowText();
    createTimer();
}
