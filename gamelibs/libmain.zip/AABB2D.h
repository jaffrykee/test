#ifndef Border2D_H
#define	Border2D_H
#include <stdlib.h>

enum class BorderRelation_E {
    ON_CONTAIN = 0,     //����
    NO_CONTAIN,
    ON_EMBED_LEFT,           //��Ƕ��
    ON_EMBED_RIGHT,
    ON_EMBED_TOP,
    ON_EMBED_BOTTOM,
    NO_EMBED_LEFT,
    NO_EMBED_RIGHT,
    NO_EMBED_TOP,
    NO_EMBED_BOTTOM,
    COMMON_INTERSECT,   //��ͨ�ཻ
    DISJOINT,
    RELATION_MAX,
};

#define ON_EMBED_MIN BorderRelation_E::ON_EMBED_LEFT
#define ON_EMBED_MAX BorderRelation_E::ON_EMBED_BOTTOM
#define NO_EMBED_MIN BorderRelation_E::NO_EMBED_LEFT
#define NO_EMBED_MAX BorderRelation_E::NO_EMBED_BOTTOM

enum class BorderSubRelation_E {
    OONN = 0,
    ONON,
    ONNO,
    NNOO,
    NONO,
    NOON,
    SUB_RELATION_MAX,
};

template<class DataType>
/*static */class BorderRect {
public:
    static BorderSubRelation_E getSubRelation(const DataType& oMin, const DataType& oMax, const DataType& nMin, const DataType& nMax) {
        BorderSubRelation_E ret;

        if (oMin < nMin) {
            if (oMax < nMin) {
                ret = BorderSubRelation_E::OONN;
            } else {
                if (oMax < nMax) {
                    ret = BorderSubRelation_E::ONON;
                } else {
                    ret = BorderSubRelation_E::ONNO;
                }
            }
        } else {
            if (nMax < oMin) {
                ret = BorderSubRelation_E::NNOO;
            } else {
                if (nMax < oMax) {
                    ret = BorderSubRelation_E::NONO;
                } else {
                    ret = BorderSubRelation_E::NOON;
                }
            }
        }

        return ret;
    }
    static BorderSubRelation_E getSubRelationX(const Vector4<DataType>& oRect, const Vector4<DataType>& nRect) {
        BorderSubRelation_E rx = getSubRelation(oRect.x, oRect.z, nRect.x, nRect.z);

        return rx;
    }
    static BorderSubRelation_E getSubRelationY(const Vector4<DataType>& oRect, const Vector4<DataType>& nRect) {
        BorderSubRelation_E ry = getSubRelation(oRect.y, oRect.w, nRect.y, nRect.w);

        return ry;
    }
    static BorderRelation_E getRelation(const Vector4<DataType>& oRect, const Vector4<DataType>& nRect) {
        BorderSubRelation_E rx = getSubRelationX(oRect, nRect);

        if (rx == BorderSubRelation_E::NNOO || rx == BorderSubRelation_E::OONN) {
            return BorderRelation_E::DISJOINT;
        }

        BorderSubRelation_E ry = getSubRelationY(oRect, nRect);

        if (ry == BorderSubRelation_E::NNOO || ry == BorderSubRelation_E::OONN) {
            return BorderRelation_E::DISJOINT;
        }
        switch (rx) {
            case BorderSubRelation_E::ONNO:
            {
                switch (ry) {
                    case BorderSubRelation_E::ONNO:
                        return BorderRelation_E::ON_CONTAIN;
                    case BorderSubRelation_E::NOON:
                        return BorderRelation_E::COMMON_INTERSECT;
                    case BorderSubRelation_E::NONO:
                        return BorderRelation_E::ON_EMBED_TOP;
                    case BorderSubRelation_E::ONON:
                        return BorderRelation_E::ON_EMBED_BOTTOM;
                    default:
                        return BorderRelation_E::RELATION_MAX;
                }
            }
            break;
            case BorderSubRelation_E::NOON:
            {
                switch (ry) {
                    case BorderSubRelation_E::NOON:
                        return BorderRelation_E::NO_CONTAIN;
                    case BorderSubRelation_E::ONNO:
                        return BorderRelation_E::COMMON_INTERSECT;
                    case BorderSubRelation_E::NONO:
                        return BorderRelation_E::NO_EMBED_BOTTOM;
                    case BorderSubRelation_E::ONON:
                        return BorderRelation_E::NO_EMBED_TOP;
                    default:
                        return BorderRelation_E::RELATION_MAX;
                }
            }
            break;
            case BorderSubRelation_E::ONON:
            {
                switch (ry) {
                    case BorderSubRelation_E::ONNO:
                        return BorderRelation_E::ON_EMBED_RIGHT;
                    case BorderSubRelation_E::NOON:
                        return BorderRelation_E::NO_EMBED_LEFT;
                    default:
                        return BorderRelation_E::COMMON_INTERSECT;
                }
            }
            break;
            case BorderSubRelation_E::NONO:
            {
                switch (ry) {
                    case BorderSubRelation_E::ONNO:
                        return BorderRelation_E::ON_EMBED_LEFT;
                    case BorderSubRelation_E::NOON:
                        return BorderRelation_E::NO_EMBED_RIGHT;
                    default:
                        return BorderRelation_E::COMMON_INTERSECT;
                }
            }
            break;
            default:
                break;
        }

        return BorderRelation_E::RELATION_MAX;
    }
    static bool overRect(const Vector4<DataType>& oRect, const Vector4<DataType>& nRect, const DataType& alw) {
        if (oRect.x + alw > nRect.z || nRect.x > oRect.z - alw ||
            oRect.y + alw > nRect.w || nRect.y > oRect.w - alw) {
            return false;
        } else {
            return true;
        }
    }

public:
    static void clipEmbedIntersect(Vector4<DataType>& src, const Vector4<DataType>& other) {
        BorderRelation_E rlt = getRelation(src, other);

        switch (rlt) {
            case BorderRelation_E::NO_EMBED_LEFT:
            {
                src.z = other.x;
            }
            break;
            case BorderRelation_E::NO_EMBED_RIGHT:
            {
                src.x = other.z;
            }
            break;
            case BorderRelation_E::NO_EMBED_TOP:
            {
                src.w = other.y;
            }
            break;
            case BorderRelation_E::NO_EMBED_BOTTOM:
            {
                src.y = other.w;
            }
            break;
            default:
                break;
        }
    }
};

template<class DataType>
class Border2DLevelGroup {
public:
    DataType m_alw;
    ArrayList<Vector4<DataType>> m_arrRect;

public:
    Border2DLevelGroup(const DataType& alw) : m_alw(alw) {
    }
    ~Border2DLevelGroup() {
    }
    virtual bool checkOver(const Vector4<DataType>& rect) const = 0;
    virtual bool insertRect(const Vector4<DataType>& rect) = 0;
    void getAlwRect(Vector4<DataType>& rect) {
        if (m_alw == 0) {
            return;
        }
        DataType dx = ((rect.x - m_alw) < (rect.z + m_alw)) ? m_alw : 0;
        DataType dy = ((rect.y - m_alw) < (rect.w + m_alw)) ? m_alw : 0;
        rect.x -= dx;
        rect.y -= dy;
        rect.z += dx;
        rect.w += dy;
    }
};

template<class DataType>
class Border2DFinalLevelGroup : public Border2DLevelGroup<DataType> {
public:
    Border2DFinalLevelGroup(const DataType& alw) : Border2DLevelGroup<DataType>(alw) {
    }
    ~Border2DFinalLevelGroup() {
    }

    virtual bool checkOver(const Vector4<DataType>& rect) const {
        for (auto& localRect : Border2DLevelGroup<DataType>::m_arrRect) {
            if (localRect.x > rect.z || rect.x > localRect.z || localRect.y > rect.w || rect.y > localRect.w) {
                continue;
            } else {
                //�ཻ����
                return true;
            }
        }

        return false;
    }
    virtual bool insertRect(const Vector4<DataType>& rect) {
        Vector4<DataType> tmpRect = rect;
        Border2DLevelGroup<DataType>::getAlwRect(tmpRect);

        for (auto& localRect : Border2DLevelGroup<DataType>::m_arrRect) {
            BorderRelation_E rlt = BorderRect<DataType>::getRelation(localRect, rect);

            switch (rlt) {
                case BorderRelation_E::ON_CONTAIN:
                    return false;
                case BorderRelation_E::NO_CONTAIN:
                    localRect = tmpRect;
                    return false;
                case BorderRelation_E::ON_EMBED_LEFT:
                    tmpRect.z = localRect.x;
                    break;
                case BorderRelation_E::ON_EMBED_RIGHT:
                    tmpRect.x = localRect.z;
                    break;
                case BorderRelation_E::ON_EMBED_TOP:
                    tmpRect.w = localRect.y;
                    break;
                case BorderRelation_E::ON_EMBED_BOTTOM:
                    tmpRect.y = localRect.w;
                    break;
                case BorderRelation_E::NO_EMBED_LEFT:
                    localRect.z = tmpRect.x;
                    break;
                case BorderRelation_E::NO_EMBED_RIGHT:
                    localRect.x = tmpRect.z;
                    break;
                case BorderRelation_E::NO_EMBED_TOP:
                    localRect.w = tmpRect.y;
                    break;
                case BorderRelation_E::NO_EMBED_BOTTOM:
                    localRect.y = tmpRect.w;
                    break;
                case BorderRelation_E::COMMON_INTERSECT:
                    break;
                case BorderRelation_E::DISJOINT:
                    break;
                case BorderRelation_E::RELATION_MAX:
                    break;
                default:
                    break;
            }
        }
        Border2DLevelGroup<DataType>::m_arrRect.push_back(tmpRect);

        return true;
    }
};

template<class DataType>
class Border2DLevelGroup1 : public Border2DLevelGroup<DataType> {
public:
    Border2DLevelGroup1(const DataType& alw) : Border2DLevelGroup<DataType>(alw) {
    }
    ~Border2DLevelGroup1() {
    }

    virtual bool checkOver(const Vector4<DataType>& rect) const {
        for (auto& localRect : Border2DLevelGroup<DataType>::m_arrRect) {
            if (localRect.x > rect.z || rect.x > localRect.z || localRect.y > rect.w || rect.y > localRect.w) {
                continue;
            } else {
                //�ཻ����
                return true;
            }
        }

        return false;
    }
    virtual bool insertRect(const Vector4<DataType>& rect) {
        Vector4<DataType> tmpRect = rect;
        Border2DLevelGroup<DataType>::getAlwRect(tmpRect);

        for (bool isDirty = true; isDirty == true;) {
            isDirty = false;
            for (auto itRect = Border2DLevelGroup<DataType>::m_arrRect.begin(); itRect != Border2DLevelGroup<DataType>::m_arrRect.end();) {
                switch (BorderRect<DataType>::getRelation(*itRect, tmpRect)) {
                    case BorderRelation_E::ON_CONTAIN:
                        return false;
                    case BorderRelation_E::NO_CONTAIN:
                    {
                        Border2DLevelGroup<DataType>::m_arrRect.erase(itRect);
                        isDirty = true;
                    }
                    break;
                    case BorderRelation_E::ON_EMBED_LEFT:
                    case BorderRelation_E::ON_EMBED_RIGHT:
                    case BorderRelation_E::ON_EMBED_TOP:
                    case BorderRelation_E::ON_EMBED_BOTTOM:
                    case BorderRelation_E::NO_EMBED_LEFT:
                    case BorderRelation_E::NO_EMBED_RIGHT:
                    case BorderRelation_E::NO_EMBED_TOP:
                    case BorderRelation_E::NO_EMBED_BOTTOM:
                    case BorderRelation_E::COMMON_INTERSECT:
                    {
                        if (itRect->x < tmpRect.x) {
                            tmpRect.x = itRect->x;
                        }
                        if (itRect->y < tmpRect.y) {
                            tmpRect.y = itRect->y;
                        }
                        if (itRect->z > tmpRect.z) {
                            tmpRect.z = itRect->z;
                        }
                        if (itRect->w > tmpRect.w) {
                            tmpRect.w = itRect->w;
                        }
                        Border2DLevelGroup<DataType>::m_arrRect.erase(itRect);
                        isDirty = true;
                    }
                    break;
                    case BorderRelation_E::DISJOINT:
                        ++itRect;
                        break;
                    case BorderRelation_E::RELATION_MAX:
                        ++itRect;
                        break;
                    default:
                        ++itRect;
                        break;
                }
            }
        }
        Border2DLevelGroup<DataType>::m_arrRect.push_back(tmpRect);

        return true;
    }
};

template<class DataType>
class Border2DLevelGroup0 : public Border2DLevelGroup<DataType> {
public:
    Border2DLevelGroup0(const DataType& alw) : Border2DLevelGroup<DataType>(alw) {
    }
    ~Border2DLevelGroup0() {
    }

    virtual bool checkOver(const Vector4<DataType>& rect) const {
        for (auto& localRect : Border2DLevelGroup<DataType>::m_arrRect) {
            if (localRect.x > rect.z || rect.x > localRect.z || localRect.y > rect.w || rect.y > localRect.w) {
                continue;
            } else {
                //�ཻ����
                return true;
            }
        }
        return false;
    }
    virtual bool insertRect(const Vector4<DataType>& rect) {
        if (Border2DLevelGroup<DataType>::m_arrRect.size() == 0) {
            Border2DLevelGroup<DataType>::m_arrRect.push_back(rect);

            return true;
        } else {
            if (Border2DLevelGroup<DataType>::m_arrRect[0].x > rect.x - Border2DLevelGroup<DataType>::m_alw) {
                Border2DLevelGroup<DataType>::m_arrRect[0].x = rect.x - Border2DLevelGroup<DataType>::m_alw;
            }
            if (Border2DLevelGroup<DataType>::m_arrRect[0].y > rect.y - Border2DLevelGroup<DataType>::m_alw) {
                Border2DLevelGroup<DataType>::m_arrRect[0].y = rect.y - Border2DLevelGroup<DataType>::m_alw;
            }
            if (Border2DLevelGroup<DataType>::m_arrRect[0].z < rect.z + Border2DLevelGroup<DataType>::m_alw) {
                Border2DLevelGroup<DataType>::m_arrRect[0].z = rect.z + Border2DLevelGroup<DataType>::m_alw;
            }
            if (Border2DLevelGroup<DataType>::m_arrRect[0].w < rect.w + Border2DLevelGroup<DataType>::m_alw) {
                Border2DLevelGroup<DataType>::m_arrRect[0].w = rect.w + Border2DLevelGroup<DataType>::m_alw;
            }
            if (Border2DLevelGroup<DataType>::m_arrRect[0].z <= Border2DLevelGroup<DataType>::m_arrRect[0].x) {
                Border2DLevelGroup<DataType>::m_arrRect[0].z = Border2DLevelGroup<DataType>::m_arrRect[0].x + Border2DLevelGroup<DataType>::m_alw;
            }
            if (Border2DLevelGroup<DataType>::m_arrRect[0].w <= Border2DLevelGroup<DataType>::m_arrRect[0].y) {
                Border2DLevelGroup<DataType>::m_arrRect[0].w = Border2DLevelGroup<DataType>::m_arrRect[0].y + Border2DLevelGroup<DataType>::m_alw;
            }
        }

        return false;
    }
};

#define Border2DLEVELFINAL 0

template<class DataType>
class Border2DDepartment {
public:
    Border2DLevelGroup0<DataType> m_lg0;
    Border2DLevelGroup1<DataType> m_lg1;
    Border2DFinalLevelGroup<DataType> m_lgFinal;

public:
    Border2DDepartment(const DataType& alw) : m_lgFinal(alw), m_lg0(alw), m_lg1(alw) {
    }
    ~Border2DDepartment() {
    }

public:
    void insertRect(const Vector4<DataType>& srcRect) {
        m_lg0.insertRect(srcRect);
        m_lg1.insertRect(srcRect);
#if Border2DLEVELFINAL
        m_lgFinal.insertRect(srcRect);
#endif
    }
    bool checkOver(const Vector4<DataType>& rect) {
        if (m_lg0.checkOver(rect)) {
#if Border2DLEVELFINAL
            if (m_lg1.checkOver(rect))
            {
                return m_lgFinal.checkOver(rect);
            }
#else
            return m_lg1.checkOver(rect);
#endif
        }

        return false;
    }
    bool checkOver(const Border2DDepartment<DataType>& other) {
        bool ret = false;

        for (auto& rect : other.m_lg0.m_arrRect) {
            ret = ret || m_lg0.checkOver(rect);
            if (ret) {
                break;
            }
        }
        if (ret == false) {
            return false;
        }

        ret = false;
        for (auto& rect : other.m_lg1.m_arrRect) {
            ret = ret || m_lg1.checkOver(rect);
            if (ret) {
                break;
            }
        }
        if (ret == false) {
            return false;
        }

#if Border2DLEVELFINAL
        ret = false;
        for (auto& rect : other.m_lgFinal.m_arrRect)
        {
            ret = m_lgFinal.checkOver(rect);
            if (ret)
            {
                return ret;
            }
        }
#endif

        return ret;
    }
    void mergeOther(const Border2DDepartment& other) {
        for (auto& rect : other.m_lg0.m_arrRect) {
            m_lg0.insertRect(rect);
        }
        for (auto& rect : other.m_lg1.m_arrRect) {
            m_lg1.insertRect(rect);
        }
#if Border2DLEVELFINAL
        for (auto& rect : other.m_lgFinal.m_arrRect)
        {
            m_lgFinal.insertRect(rect);
        }
#endif
    }
};

#endif	/* Border2D_H */
