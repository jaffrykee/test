#include "SSUIMath.h"

ssui::ft ssui::SSUIMath::restorePct(pct value) {
    return value * 0.01;
}

bool ssui::SSUIMath::getAttrBitValue(int attr, int bit) {
    return (attr & (1 << bit)) != 0;
}

bool ssui::SSUIMath::getAttrBitValue(u8 attr, int bit) {
    return (attr & (1 << bit)) != 0;
}

void ssui::SSUIMath::enableAttrBitValue(int& attr, int bit) {
    attr |= (1 << bit);
}

void ssui::SSUIMath::enableAttrBitValue(u8& attr, int bit) {
    attr |= (1 << bit);
}

void ssui::SSUIMath::disableAttrBitValue(int& attr, int bit) {
    attr &= (~(1 << bit));
}

void ssui::SSUIMath::disableAttrBitValue(u8& attr, int bit) {
    attr &= (~(1 << bit));
}

void ssui::SSUIMath::setAttrBitValue(int& attr, int bit, bool value) {
    value ? enableAttrBitValue(attr, bit) : disableAttrBitValue(attr, bit);
}

void ssui::SSUIMath::setAttrBitValue(u8& attr, int bit, bool value) {
    value ? enableAttrBitValue(attr, bit) : disableAttrBitValue(attr, bit);
}

void ssui::SSUIMath::getMulti(vec2& poi, f32 per) {
    poi.x *= per;
    poi.y *= per;
}

void ssui::SSUIMath::setColorFromArgb(Color& color, u32 value) {
    color.a = ((value & 0xff000000) >> 24) / 255.f;
    color.r = ((value & 0xff0000) >> 16) / 255.f;
    color.g = ((value & 0xff00) >> 8) / 255.f;
    color.b = (value & 0xff) / 255.f;
}

void ssui::SSUIMath::assignPosition(mat4& mat, const ft x, const ft y, const ft z /*= 0.f*/) {
    mat = mat4Identity;
    mat._41 = x;
    mat._42 = y;
    mat._43 = z;
}

void ssui::SSUIMath::outMatPoi(const mat4& mat, const int lv /*= 3*/) {
    LogPrint("\nx: %f\ty: %f\tz: %f\t", lv, mat._41, mat._42, mat._43);
}

void ssui::SSUIMath::sumPosition(mat4& mat, const ft x, const ft y, const ft z /*= 0.f*/) {
    mat._41 += x;
    mat._42 += y;
    mat._43 += z;
}

bool ssui::SSUIMath::getAttrGroupValue(const u32& attrGroup, int ag) {
    return (attrGroup & (1 << ag)) != 0;
}

bool ssui::SSUIMath::getAttrGroupValue(const u16& attrGroup, int ag) {
    return (attrGroup & (1 << ag)) != 0;
}

bool ssui::SSUIMath::getAttrGroupValue(const u8& attrGroup, int ag) {
    return (attrGroup & (1 << ag)) != 0;
}

void ssui::SSUIMath::enableAttrGroupValue(u32& attrGroup, int ag) {
    attrGroup |= (1 << ag);
}

void ssui::SSUIMath::enableAttrGroupValue(u16& attrGroup, int ag) {
    attrGroup |= (1 << ag);
}

void ssui::SSUIMath::enableAttrGroupValue(u8& attrGroup, int ag) {
    attrGroup |= (1 << ag);
}

void ssui::SSUIMath::disableAttrGroupValue(u32& attrGroup, int ag) {
    attrGroup &= (~(1 << ag));
}

void ssui::SSUIMath::disableAttrGroupValue(u16& attrGroup, int ag) {
    attrGroup &= (~(1 << ag));
}

void ssui::SSUIMath::disableAttrGroupValue(u8& attrGroup, int ag) {
    attrGroup &= (~(1 << ag));
}

void ssui::SSUIMath::setAttrGroupValue(u32& attrGroup, int ag, bool value) {
    value ? enableAttrGroupValue(attrGroup, ag) : disableAttrGroupValue(attrGroup, ag);
}

void ssui::SSUIMath::setAttrGroupValue(u16& attrGroup, int ag, bool value) {
    value ? enableAttrGroupValue(attrGroup, ag) : disableAttrGroupValue(attrGroup, ag);
}

void ssui::SSUIMath::setAttrGroupValue(u8& attrGroup, int ag, bool value) {
    value ? enableAttrGroupValue(attrGroup, ag) : disableAttrGroupValue(attrGroup, ag);
}

void ssui::SSUIMath::getMixColor(Color& ret, const Color& src, const Color& dst, MixColorRule_e mcr /*= MCR_Alpha*/) {
    switch (mcr) {
        case ssui::MCR_Normal:
        {
            ret.a = src.a * dst.a;
            if (math::equal(src.a, dst.a, 0.001f)) {
                ret.r = (src.r + dst.r) * 0.5f;
                ret.g = (src.g + dst.g) * 0.5f;
                ret.b = (src.b + dst.b) * 0.5f;
            } else if (src.a > dst.a) {
                auto ds = dst.a / src.a;
                ret.r = (src.r + dst.r * ds) * 0.5f;
                ret.g = (src.g + dst.g * ds) * 0.5f;
                ret.b = (src.b + dst.b * ds) * 0.5f;
            } else {
                auto sd = src.a / dst.a;
                ret.r = (src.r * sd + dst.r) * 0.5f;
                ret.g = (src.g * sd + dst.g) * 0.5f;
                ret.b = (src.b * sd + dst.b) * 0.5f;
            }
        }
        break;
        case ssui::MCR_Alpha:
        {
            ret.a = src.a * dst.a;
            ret.r = dst.r;
            ret.g = dst.g;
            ret.b = dst.b;
        }
        break;
        case ssui::MCR_MAX:
            break;
        default:
            break;
    }
}

void ssui::SSUIMath::getMixColor(Color& src, const Color& dst, MixColorRule_e mcr /*= MCR_Alpha*/) {
    getMixColor(src, src, dst, mcr);
}

ssui::ft ssui::SSUIMath::getDistance(ft ax, ft ay, ft bx, ft by) {
    return math::sqrt(math::pow<ft>(ax - bx, 2) + math::pow<ft>(ay - by, 2));
}

ssui::ft ssui::SSUIMath::ssAngleToCounterClockAngle(ft ssAngle) {
    ft angle = 180 - ssAngle;
    return angle >= 0 ? angle : (360 + angle);
}

void ssui::SSUIMath::getCounterClockJoyStickValue(ft& angle, ft& strength, ft cx, ft cy, ft x, ft y, ft r) {
    angle = ssAngleToCounterClockAngle(math::atan2(x - cx, cy - y));
    strength = getDistance(x, y, cx, cy) / r;
}

void ssui::SSUIMath::assignWithCheck(u16& dst, const s64& value) {
    dst = value > U16MAX ? U16MAX : value;
}

void ssui::SSUIMath::assignWithCheck(u8& dst, const s64& value) {
    dst = value > U8MAX ? U8MAX : value;
}

void ssui::SSUIMath::assignWithCheck(u32& dst, const s64& value) {
    dst = value > U32MAX ? U32MAX : value;
}
