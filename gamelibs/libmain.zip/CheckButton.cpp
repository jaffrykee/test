#include "CheckButton.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(CheckButton, 100, 500);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(CheckButton)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::CheckButton::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    case ET_Click:
    {
        getHost()->setDataIsSelected(!getHost()->getDataIsSelected());
    }
    break;
    default:
    {

    }
    break;
    }
    Base::onEventScript(event);
}
