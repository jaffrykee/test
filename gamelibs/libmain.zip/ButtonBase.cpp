#include "ButtonBase.h"
#include "Control.h"
#include "Control.h"
#include "EventNodeGroup.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ButtonBase, 0, 0);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ButtonBase)
NODETYPE_COMMON_PART_DEFINITION_END

void ButtonBase::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    case ET_Press:
    {
        m_px = event.m_iData1;
        m_py = event.m_iData2;
        m_isDragged = false;
        event.m_blockAnimation = true;
        getHost()->setDataIsPressed(true);
        getHost()->setEventType(event, PT_BlockStatusChange);
    }
    break;
    case ET_Drag:
    {
        if (getHost()->getDataIsVisible() == false || getHost()->getDataIsEnable() == false ||
            getHost()->isIn(event.m_iData1, event.m_iData2) == false) {
            m_isDragged = true;
            getHost()->setDataIsPressed(false);
            setCanTriggerScript(false);
            return;
        }
        if (event.m_iData1 < m_px - s_clickTolerance || event.m_iData2 < m_py - s_clickTolerance ||
            event.m_iData1 > m_px + s_clickTolerance || event.m_iData2 > m_py + s_clickTolerance) {
            m_isDragged = true;
        }     
        event.m_blockStatusChange = true;
        event.m_blockAnimation = true;
        event.m_enDragged = true;
        getHost()->setEventType(event, PT_BlockStatusChange);
    }
    break;
    case ET_Release:
    {
        m_px = -1;
        m_py = -1;
        getHost()->setDataIsPressed(false);
//         if (getHost()->getDataIsVisible() == false || getHost()->getDataIsEnable() == false ||
//             getHost()->isIn(event.m_iData1, event.m_iData2) == false || getHost()->getEventNodeGroup() == nullptr) {
//             setCanTriggerScript(false);
//             return;
//         }        
        event.m_blockAnimation = true;
        getHost()->setEventType(event, PT_BlockStatusChange);
    }
    break;
    case ET_Click:
    {
        if (m_isDragged) {
            setCanTriggerScript(false);
            return;
        }
        if (getHost()->getDataIsVisible() == false || getHost()->getDataIsEnable() == false ||
            getHost()->isIn(event.m_iData1, event.m_iData2) == false) {
            setCanTriggerScript(false);
            return;
        }
        getHost()->setDataIsBlink(false);
        event.m_blockAnimation = true;
        getHost()->setEventType(event, PT_BlockStatusChange);
    }
    break;
    default:
    {

    }
    break;
    }
}

bool ssui::ButtonBase::isTouchComponent( ) const {
    return true;
}
