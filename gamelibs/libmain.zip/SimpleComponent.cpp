#include "SimpleComponent.h"
#include "Control.h"
#include "Skin.h"
#include "ShapeGroup.h"
#include "DataInfoNode.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(SimpleComponent, 1000, 5000);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(SimpleComponent)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::SimpleComponent::createSelf() {

}

void SimpleComponent::disposeSelf() {
    for (auto& pChild : m_container) {
        pChild->releaseObject();
    }
    m_container.clear();
}

SimpleComponent& ssui::SimpleComponent::assign(const Self& other) {
    Base::assign(other);
    return *this;
}

ArrayList<Control*>& ssui::SimpleComponent::container() {
    return m_container;
}

const ArrayList<SlotType_e>& ssui::SimpleComponent::getSlotList() const {
    return getSlotListDef(SLOT_body);
}

ssui::ParentAreaType_e ssui::SimpleComponent::getParentAreaType() const {
    return PAT_self;
}