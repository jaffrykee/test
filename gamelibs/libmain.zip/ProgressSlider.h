#pragma once
#include "SimpleComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ProgressSlider : public SimpleComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ProgressSlider);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(ProgressSlider, SimpleComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    s16 m_drawDx = 0;
    s16 m_drawDy = 0;
    s16 m_pressX = -1;
    s16 m_pressY = -1;
    s16 m_lastX;
    s16 m_lastY;
    s16 m_curX;
    s16 m_curY;
    bool m_isDragged = false;
    bool enableProgSlider = false;
#pragma endregion

#pragma region "����"
public:
    bool getEnableProgSlider() const;
    void setEnableProgSlider(bool value);
public:
    ProgressSlider& assign(const ProgressSlider& other);
    virtual void onEvent(SSUIEvent& event) override;
public:
    virtual ParentAreaType_e getParentAreaType() const;
    virtual void onTransform(unsigned char drawStep) override;
public:
    virtual bool isTouchComponent() const override;
    virtual const ArrayList<SlotType_e>& getSlotList() const override;
    virtual bool isIn(ft x, ft y) const;
    bool isInSlider(ft x, ft y) const;
    bool getBorder(Border& aabb) const;
    bool getCenter(ft& cx, ft& cy) const;
public:
    bool dragSlider(s16 dx, s16 dy);
#pragma endregion
};

_SSUINamespaceEnd
