#include "Button.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Button, 300, 1000);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(Button)
NODETYPE_COMMON_PART_DEFINITION_END

void Button::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    default:
    {

    }
    break;
    }
    Base::onEventScript(event);
}