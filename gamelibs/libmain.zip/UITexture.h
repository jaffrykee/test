#pragma once
#include "ObjectBase.h"
#include "UIImageBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class UITexture : public ObjectBase {
public:
    friend class ImageManager;
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UITexture);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
        recoverTexture();
        for (auto& pairSubImage : m_mapSubImage) {
            pairSubImage.second->releaseObject();
        }
        m_mapSubImage.clear();
    }
    NODETYPE_COMMON_PART_DECLARATION_END(UITexture, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
protected:
    inline static Self* createUITexture(const string& name) {
        auto pTexture = Self::createObject();
        pTexture->setName(name);
        return pTexture;
    }
    friend class DataManager;
    static UITexture* createUITexture(const string& imageName, DataInfoNode& data);
#pragma endregion

#pragma region "��Ա"
public:
    Texture m_texture;
private:
    int mt_useCount = 0;
public:
    inline int getUseCount() const {
        return mt_useCount;
    }
    inline void increaseUseCount() {
        if (mt_useCount == 0) {
            useTexture();
        }
        mt_useCount++;
    }
    inline void decreaseUseCount() {
        if (mt_useCount == 0) {
            return;
        }
        mt_useCount--;
        if (mt_useCount == 0) {
            recoverTexture();
        }
    }
private:
    string mt_name;
public:
    inline int getKey() const {
        return mt_name.hashCode();
    }
    inline const string& getName() const {
        return mt_name;
    }
    inline void setName(const string& value) {
        StringManager::getInstance()->m_tmpString = util::lowcase(value);
        mt_name = StringManager::getInstance()->m_tmpString;
    }
public:
    HashMap<strHash, UIImageBase*> m_mapSubImage;
#pragma endregion

#pragma region "����"
protected:
    //����һ��UI������
    void useTexture();
    //����һ��UI������
    void recoverTexture();
public:
    inline UITexture& assign(const UITexture& other) {
        Base::assign(other);
        assert(false);
        return *this;
    }
    virtual int addDataChild(DataInfoNode& childData) override;
public:
    void addSubImage(UIImageBase* pSubImage);
#pragma endregion
};

_SSUINamespaceEnd
