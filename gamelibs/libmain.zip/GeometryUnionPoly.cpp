#include "GeometryUnionPoly.h"
#include "GeometryManager.h"
#include "UIManager.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(GeometryUnionPoly, 0, 0);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(GeometryUnionPoly)
NODETYPE_COMMON_PART_DEFINITION_END

GeometryUnionPoly* ssui::GeometryUnionPoly::createObject(const ArrayList<Poly>& arrPoly) {
    auto pNew = GeometryUnionPoly::createObject();
    pNew->m_arrPoly = arrPoly;
    return pNew;
}

GeometryUnionPoly& ssui::GeometryUnionPoly::assign(const GeometryUnionPoly& other) {
    Base::assign(other);
    return *this;
}

bool GeometryUnionPoly::isIn(ft x, ft y) {
    for (auto& poly : m_arrPoly) {
        if (GeometryManager::getPointIsInPoly(x, y, poly)) {
            return true;
        }
    }
    return false;
}

void GeometryUnionPoly::appendOutline(Poly& poly) {
    Border aabb;
    getBorder(aabb);
    GeometryManager::getPolyFromBorder(poly, aabb);
    return;
}

void ssui::GeometryUnionPoly::getCenter(ft& cx, ft& cy) const {
    Border aabb;
    getBorder(aabb);
    cx = (aabb.m_left + aabb.m_right) * 0.5;
    cy = (aabb.m_top + aabb.m_bottom) * 0.5;
}

void ssui::GeometryUnionPoly::getBorder(Border& aabb) const {
    bool isInit = false;
    if (m_arrPoly.empty()) {
        return;
    }
    for (auto& poly : m_arrPoly) {
        for (auto& poi : poly) {
            if (isInit == false) {
                isInit = true;
                aabb.m_left = poi.x;
                aabb.m_right = poi.x;
                aabb.m_top = poi.y;
                aabb.m_bottom = poi.y;
            } else {
                aabb.m_left = math::minimum(aabb.m_left, poi.x);
                aabb.m_right = math::maximum(aabb.m_right, poi.x);
                aabb.m_top = math::minimum(aabb.m_top, poi.y);
                aabb.m_bottom = math::maximum(aabb.m_bottom, poi.y);
            }
        }
    }
}

void ssui::GeometryUnionPoly::transformPosition(ft x, ft y) {
    for (auto& poly : m_arrPoly) {
        for (auto& poi : poly) {
            poi.x += x;
            poi.y += y;
        }
    }
}

bool ssui::GeometryUnionPoly::isNull() {
    return m_arrPoly.empty();
}

void ssui::GeometryUnionPoly::refreshNull() {
    for (auto& poly : m_arrPoly) {
        if (poly.size() >= 3) {
            return;
        }
    }
    m_arrPoly.clear();
    return;
}
