#include "Control.h"
#include "UIScene.h"
#include "NodeManager.h"
#include "GeometryManager.h"
#include "InputBox.h"
#include "Blink.h"
#include "EventNodeGroup.h"
#include "DataInfoNode.h"
#include "DataInfoAttr.h"
#include "UIManager.h"
#include "BasicContent.h"
#include "MeasureData.h"
#include "Geometry.h"
#include "Progress.h"
#include "BasicClip.h"
#include "BasicMeasure.h"
#include "TimeContent.h"
#include "ScrollView.h"
#include "Control.h"
#include "UIDrawModel.h"
#include "StackPanel.h"
#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Control, CONTROL_RESPOOLINIT, CONTROL_RESPOOLLIMIT);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("id", Id, Control, STR, AST_normal);
//=============================================
NODEBASE_ATTR_REGISTER("skin", SkinName, Control, STR, AST_normal);
NODEBASE_ATTR_REGISTER("text", Text, Control, WSTR, AST_normal);
NODEBASE_ATTR_REGISTER("textKey", TextKey, Control, WSTR, AST_normal);
NODEBASE_ATTR_REGISTER("isInput", IsInput, Control, B2);
//=============================================
NODEBASE_ATTR_REGISTER("visible", DataIsVisible, Control, B2);
NODEBASE_ATTR_REGISTER("isEnable", DataIsEnable, Control, B2);
NODEBASE_ATTR_REGISTER("isPressed", DataIsPressed, Control, B2);
NODEBASE_ATTR_REGISTER("isSelected", DataIsSelected, Control, B2);
NODEBASE_ATTR_REGISTER("isBlink", DataIsBlink, Control, B2);
//=============================================
NODEBASE_ATTR_REGISTER("isOwnEvent", IsOwnEvent, Control, B2);
NODEBASE_ATTR_REGISTER("canTransHandle", CanTransHandle, Control, B2);
NODEBASE_ATTR_REGISTER("canTransScript", CanTransScript, Control, B2);
NODEBASE_ATTR_REGISTER("nextUIEvent", NextUIEvent, Control, B2);
//=============================================
NODEBASE_ATTR_REGISTER("ccit", DataCcit, Control, S32, StringManager::getInstance()->mc_wstrdisable);
NODEBASE_ATTR_REGISTER("command", DataCommand, Control, WSTR);
NODETYPE_COMMON_PART_DEFINITION_MID(Control)
NBSCRIPT_ATTR_REGISTER("id", Id, Control, STR);
//=============================================
NBSCRIPT_ATTR_REGISTER("skin", SkinName, Control, STR);
NBSCRIPT_ATTR_REGISTER("text", Text, Control, WSTR);
NBSCRIPT_ATTR_REGISTER("textKey", TextKey, Control, WSTR);
NBSCRIPT_ATTR_REGISTER("isInput", IsInput, Control, B2);
//=============================================
NBSCRIPT_ATTR_REGISTER("visible", DataIsVisible, Control, B2);
NBSCRIPT_ATTR_REGISTER("isEnable", DataIsEnable, Control, B2);
NBSCRIPT_ATTR_REGISTER("isPressed", DataIsPressed, Control, B2);
NBSCRIPT_ATTR_REGISTER("isSelected", DataIsSelected, Control, B2);
NBSCRIPT_ATTR_REGISTER("isBlink", DataIsBlink, Control, B2);
//=============================================
NBSCRIPT_ATTR_REGISTER("isOwnEvent", IsOwnEvent, Control, B2);
NBSCRIPT_ATTR_REGISTER("canTransHandle", CanTransHandle, Control, B2);
NBSCRIPT_ATTR_REGISTER("canTransScript", CanTransScript, Control, B2);
NBSCRIPT_ATTR_REGISTER("nextUIEvent", NextUIEvent, Control, B2);
//=============================================
NBSCRIPT_ATTR_REGISTER("csvData", DataCsvData, Control, WSTR);
NBSCRIPT_ATTR_REGISTER("command", DataCommand, Control, WSTR);

NBSCRIPT_ATTR_REGISTER_GETTER("isCopyAdd", IsCopyAdd, Control, B2);
NBSCRIPT_ATTR_REGISTER_GETTER("parentId", ParentId, Control, STR);
//=====================================
BoloRegisterPropReadOnly("scene", getSceneObject);
BoloRegisterProp("selectControl", getSelectControlObject, setSelectControlObject);
BoloRegisterProp("parent", getParentObject, setParentObject);
BoloRegisterPropReadOnly("drawX", getDrawX);
BoloRegisterPropReadOnly("drawY", getDrawY);
BoloRegisterPropReadOnly("drawWidth", getDrawWidth);
BoloRegisterPropReadOnly("drawHeight", getDrawHeight);
BoloRegisterPropReadOnly("realVisible", getRealVisible);
//=================BasicMeasure=================
NBSCRIPT_ATTR_REGISTER("ax", Ax, Control, F32);
NBSCRIPT_ATTR_REGISTER("ay", Ay, Control, F32);
NBSCRIPT_ATTR_REGISTER("aw", Aw, Control, F32);
NBSCRIPT_ATTR_REGISTER("ah", Ah, Control, F32);
NBSCRIPT_ATTR_REGISTER("rx", Rx, Control, S32);
NBSCRIPT_ATTR_REGISTER("ry", Ry, Control, S32);
NBSCRIPT_ATTR_REGISTER("rw", Rw, Control, S32);
NBSCRIPT_ATTR_REGISTER("rh", Rh, Control, S32);
NBSCRIPT_ATTR_REGISTER("wAuto", IsAutoWidth, Control, B2);
NBSCRIPT_ATTR_REGISTER("hAuto", IsAutoHeight, Control, B2);
NBSCRIPT_ATTR_REGISTER("minAw", MinAw, Control, S32);
NBSCRIPT_ATTR_REGISTER("minAh", MinAh, Control, S32);
NBSCRIPT_ATTR_REGISTER("maxAw", MaxAw, Control, S32);
NBSCRIPT_ATTR_REGISTER("maxAh", MaxAh, Control, S32);
NBSCRIPT_ATTR_REGISTER("minRw", MinRw, Control, S32);
NBSCRIPT_ATTR_REGISTER("minRh", MinRh, Control, S32);
NBSCRIPT_ATTR_REGISTER("maxRw", MaxRw, Control, S32);
NBSCRIPT_ATTR_REGISTER("maxRh", MaxRh, Control, S32);
NBSCRIPT_ATTR_REGISTER("anchorRx", AnchorRx, Control, S32);
NBSCRIPT_ATTR_REGISTER("anchorRy", AnchorRy, Control, S32);
NBSCRIPT_ATTR_REGISTER("marginAl", AbsoluteMarginLeft, Control, S32);
NBSCRIPT_ATTR_REGISTER("marginAt", AbsoluteMarginTop, Control, S32);
NBSCRIPT_ATTR_REGISTER("marginAr", AbsoluteMarginRight, Control, S32);
NBSCRIPT_ATTR_REGISTER("marginAb", AbsoluteMarginBottom, Control, S32);
NBSCRIPT_ATTR_REGISTER("paddingAl", AbsolutePaddingLeft, Control, S32);
NBSCRIPT_ATTR_REGISTER("paddingAt", AbsolutePaddingTop, Control, S32);
NBSCRIPT_ATTR_REGISTER("paddingAr", AbsolutePaddingRight, Control, S32);
NBSCRIPT_ATTR_REGISTER("paddingAb", AbsolutePaddingBottom, Control, S32);
//=================BasicClip=================
NBSCRIPT_ATTR_REGISTER("isEnableClip", IsEnableClip, Control, B2);
NBSCRIPT_ATTR_REGISTER("clipType", ClipType, Control, S32);
NBSCRIPT_ATTR_REGISTER("clipRoundedRadius", ClipRoundedRadius, Control, S32);
NBSCRIPT_ATTR_REGISTER("clipCircleRadius", ClipCircleRadius, Control, S32);
NBSCRIPT_ATTR_REGISTER("clipCircleOffsestX", ClipCircleOffsestX, Control, S32);
NBSCRIPT_ATTR_REGISTER("clipCircleOffsestY", ClipCircleOffsestY, Control, S32);
NBSCRIPT_ATTR_REGISTER("clipBeginAngle", ClipBeginAngle, Control, S32);
NBSCRIPT_ATTR_REGISTER("clipEndAngle", ClipEndAngle, Control, S32);
//=================BasicTransform=================
NBSCRIPT_ATTR_REGISTER("upSideDown", UpSideDown, Control, B2);
NBSCRIPT_ATTR_REGISTER("mirror", Mirror, Control, B2);
NBSCRIPT_ATTR_REGISTER("alpha", Alpha, Control, F32);
NBSCRIPT_ATTR_REGISTER("radian", Radian, Control, F32);
NBSCRIPT_ATTR_REGISTER("scaleX", ScaleX, Control, F32);
NBSCRIPT_ATTR_REGISTER("scaleY", ScaleY, Control, F32);
NBSCRIPT_ATTR_REGISTER("offsetX", OffsetX, Control, F32);
NBSCRIPT_ATTR_REGISTER("offsetY", OffsetY, Control, F32);
//=================RadioButton=================
NBSCRIPT_ATTR_REGISTER("radioId", RadioId, Control, STR);
//=================SkillButton=================
NBSCRIPT_ATTR_REGISTER("cdTime", CdTime, Control, S32);
NBSCRIPT_ATTR_REGISTER("remainTime", RemainTime, Control, S32);
NBSCRIPT_ATTR_REGISTER("skillButtonDirection", SkillButtonDirection, Control, S32);
//=================ScrollView=================
NBSCRIPT_ATTR_REGISTER("damping", Damping, Control, F32);
NBSCRIPT_ATTR_REGISTER("stack", Stack, Control, F32);
NBSCRIPT_ATTR_REGISTER("minSpeed", MinSpeed, Control, F32);
NBSCRIPT_ATTR_REGISTER("pagePanelSpeed", PagePanelSpeed, Control, F32);
NBSCRIPT_ATTR_REGISTER("isPagePanel", IsPagePanel, Control, B2);
//=================Progress=================
NBSCRIPT_ATTR_REGISTER("minValue", MinValue, Control, F32);
NBSCRIPT_ATTR_REGISTER("maxValue", MaxValue, Control, F32);
NBSCRIPT_ATTR_REGISTER("curValue", CurValue, Control, F32);
NBSCRIPT_ATTR_REGISTER("progDirection", ProgressDirection, Control, S32);
NBSCRIPT_ATTR_REGISTER("changedRate", ChangedRate, Control, F32);
NBSCRIPT_ATTR_REGISTER("changedSpeed", ChangedSpeed, Control, F32);
//=================VirtualJoystick=================
NBSCRIPT_ATTR_REGISTER("joystickId", JoystickId, Control, S32);
NBSCRIPT_ATTR_REGISTER("joystickR", JoystickR, Control, S32);
//=================TimeContent=================
NBSCRIPT_ATTR_REGISTER("timeOrder", TimeOrder, Control, S32);
NBSCRIPT_ATTR_REGISTER("days", DataDays, Control, S32);
NBSCRIPT_ATTR_REGISTER("hours", DataHours, Control, S32);
NBSCRIPT_ATTR_REGISTER("minutes", DataMinutes, Control, S32);
NBSCRIPT_ATTR_REGISTER("seconds", DataSeconds, Control, S32);
NBSCRIPT_ATTR_REGISTER("mss", DataMSs, Control, S32);
NBSCRIPT_ATTR_REGISTER("curTime", CurTime, Control, S64);
NBSCRIPT_ATTR_REGISTER("isStart", IsStart, Control, B2);
NBSCRIPT_ATTR_REGISTER("FullDisplayNumber", FullDisplayNumber, Control, B2);
NBSCRIPT_ATTR_REGISTER("HideLastUnitText", HideLastUnitText, Control, B2);
NBSCRIPT_ATTR_REGISTER("MaxDisplaySectionNumber", MaxDisplaySectionNumber, Control, S32);
//=================StackPanel=================
NBSCRIPT_ATTR_REGISTER("direction", DataDirection, Control, S32);
NBSCRIPT_ATTR_REGISTER("rowSpacing", DataRowSpacing, Control, F32);
NBSCRIPT_ATTR_REGISTER("columnSpacing", DataColumnSpacing, Control, F32);
//=================TextFlow=================
NBSCRIPT_ATTR_REGISTER("textAx", TextAx, TextFlow, F32);
NBSCRIPT_ATTR_REGISTER("textAy", TextAy, TextFlow, F32);
NBSCRIPT_ATTR_REGISTER("textRx", TextRx, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("textRy", TextRy, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("textAnchorRx", TextAnchorRx, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("textAnchorRy", TextAnchorRy, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("textTips", TextTips, TextFlow, WSTR);
NBSCRIPT_ATTR_REGISTER("curConvertIndex", CurConvertIndex, Control, S32);
NBSCRIPT_ATTR_REGISTER("linkSkin", LinkSkin, Control, STR);
NBSCRIPT_ATTR_REGISTER("isPassword", IsPassword, TextFlow, B2);
//=================UIDrawModel=================
NBSCRIPT_ATTR_REGISTER("modelBackPrefab", ModelBackPrefab, Control, STR);
NBSCRIPT_ATTR_REGISTER("modelScaleAndAngle", ModelScaleAndAngle, Control, STR);
NBSCRIPT_ATTR_REGISTER("modelScaleStr", ModelScaleStr, Control, STR);
NBSCRIPT_ATTR_REGISTER("modelAngleStr", ModelAngleStr, Control, STR);
NBSCRIPT_ATTR_REGISTER("modelOffset", ModelOffset, Control, STR);
NBSCRIPT_ATTR_REGISTER("modelId", ModelId, Control, U32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "Create, Dispose, Assign, AddChild(Parse)"
void Control::createSelf() {
    m_pMeasure = MeasureData::createObject();
    memset(m_arrSlotState, 0, SLOT_MAX);
}

void Control::disposeSelf() {
    setId(StringManager::getInstance()->mc_strNullDef);
#ifdef _WIN32
    if (UIManager::getInstance() != nullptr && UIManager::getInstance()->m_pCurSsueControl == this) {
        UIManager::getInstance()->m_pCurSsueControl = nullptr;
    }
#endif
    safe_release(mt_pDataEventGroup);
    safe_release(m_pOuterMeasure);
    safe_release(m_pInnerMeasure);
    safe_release(m_pMeasure);
    m_texture = nullptr;
    m_arrRender.clear();
    m_curRenderCount = 0;
    releaseAllComponents();
    UIManager::getInstance()->disposeFunc(this);
    safe_delete(mt_pCsvData);
    safe_delete(mt_pCommand);
    for (auto& pairAttrInfo : m_mapExpansionAttr) {
        safe_release(pairAttrInfo.second);
    }
    m_mapExpansionAttr.clear();
}

Control* Control::createObject(int ccit) {
    auto pCtrl = Control::createObject(DataManager::getInstance()->m_ccitData[ccit].m_data);
    pCtrl->setDataCcit(ccit);
    return pCtrl;
}

Control* Control::createObject(NodeType_e compInfo[], int count) {
    auto pSelf = Control::createObject();
    for (int i = 0; i < count; i++) {
        auto pComp = ObjectBase::createObject(compInfo[i]);
        if (pComp->is(NT_UIComponent)) {
            pSelf->addComponent((UIComponent*)pComp);
        } else {
            pComp->releaseObject();
        }
    }
    return pSelf;
}

Control* Control::createObject(const ArrayList<NodeType_e>& compInfo) {
    auto pSelf = Control::createObject();
    for (auto& compType : compInfo) {
        auto pComp = ObjectBase::createObject(compType);
        if (pComp->is(NT_UIComponent)) {
            pSelf->addComponent((UIComponent*)pComp);
        } else {
            pComp->releaseObject();
        }
    }
    return pSelf;
}

Control& Control::assign(const Control& other) {
    setDataIsEnable(other.getDataIsEnable());
    setDataIsSelected(false);
    setIsOwnEvent(other.getIsOwnEvent());
    setCanTransHandle(other.getCanTransHandle());
    setCanTransScript(other.getCanTransScript());
    Base::assign(other);
    setIdJustData(other.getId());
    setScene(other.getScene());
    releaseAllComponents();
    for (auto& pSrcComp : other.m_components) {
        auto pNewComp = (UIComponent*)pSrcComp->createCopy();
        addComponent(pNewComp);
        if (pSrcComp->isContainerComponent()) {
            for (auto& pSrcChild : pSrcComp->container()) {
                pNewComp->addChild((Control*)pSrcChild->createCopy());
            }
        }
    }
    safe_release(mt_pDataEventGroup);
    if (other.mt_pDataEventGroup) {
        mt_pDataEventGroup = (EventNodeGroup*)other.mt_pDataEventGroup->createCopy();
    }
    m_drawInitData = other.m_drawInitData;
    touchPrepareDataChanged();
    for (auto& pairAttrInfo : other.m_mapExpansionAttr) {
        m_mapExpansionAttr.insert(pairAttrInfo.first, (DataInfoAttr*)pairAttrInfo.second->createCopy());
    }
    //<inc>Skin
    return *this;
}

int Control::addDataChild(DataInfoNode& childData) {
    int ret = Base::addDataChild(childData);
    if (ret < 0) {
        if (ObjectBase::is(childData.m_objType, NT_Control)) {
            ControlParser(addChild);
        } else if (ObjectBase::is(childData.m_objType, NT_EventNodeBase)) {
            if (mt_pDataEventGroup == nullptr) {
                mt_pDataEventGroup = EventNodeGroup::createObject();
            }
            mt_pDataEventGroup->addEventNode((EventNodeBase*)ObjectBase::createObject(childData));
            ret = NT_EventNodeBase;
        }
    }
    return ret;
}
#pragma endregion

void Control::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
        case ET_Press:
        case ET_Release:
        case ET_Drag:
        case ET_Click:
        case ET_LostFocus:
        {
            if (!checkCanEvent() || isIn(event.m_iData1, event.m_iData2) == false) {
                return;
            }
            if (children().empty() == false) {
                for (auto pChild = children().end() - 1; pChild != children().begin() - 1; --pChild) {
                    if ((*pChild) && (!(*pChild)->checkCanEvent() || (*pChild)->isIn(event.m_iData1, event.m_iData2) == false)) {
                        continue;
                    }
					if (event.isBlockHandle()) {
						return;
					}
                    if (event.m_type == ET_Press && (*pChild)->getParentComponent() &&  
                        (*pChild)->getParentComponent()->getNodeType() == NT_StackPanel) {
                        static_cast<StackPanel*>((*pChild)->getParentComponent())->setSelectControl((*pChild));
                    }
                    (*pChild)->onEvent(event);
					(*pChild)->onEventEnd(event);
                }
            } 
            if (event.isBlockHandle()) {
                return;
            }
            b2 isTriggerScript = false;
            for (auto pComp = m_components.end() - 1; pComp != m_components.begin() - 1; --pComp) {
                if ((*pComp) && (*pComp)->isIn(event.m_iData1, event.m_iData2)) {
                    (*pComp)->onEvent(event);
                    if ((*pComp) && (*pComp)->getIsTriggerScript()) {
                        isTriggerScript = true;
                    } 
                }
            }
            if (!isTriggerScript && event.m_blockScript == false ) {
                if (getEventNodeGroup()){
                    getEventNodeGroup()->triggerEventNode(event, this);
                }
                //setEventType(event, ProcessType_e::PT_BlockScript);
            }
            onEventEnd(event);
        }
        break;
        case ET_LanguageThemeChanged:
        case ET_SkinGroupReplace:
        case ET_SceneChanged:
        {
            touchPrepareDataChanged();
            if (getEventNodeGroup() == nullptr)
                return;
            getEventNodeGroup()->triggerEventNode(event, this);
        }
        break;
        default:
        {
            if (getEventNodeGroup() == nullptr)
                return;
            getEventNodeGroup()->triggerEventNode(event, this);
        }
        break;
    }
}

void Control::onEventEnd(SSUIEvent& event) {
	if (getIsOwnEvent()) {
		setEventType(event, ProcessType_e::PT_BlockHandle);
	}
    if (getNextUIEvent()) {
        event.m_nextUI = true;
    } else {
        event.m_nextUI = false;
    }
}
void Control::setEventType(SSUIEvent& event, const s32 type) {
	if (type == ProcessType_e::PT_None) {
		return;
	}
	if (type == ProcessType_e::PT_BlockScript) {
		if (!getCanTransScript()) {
			event.m_blockScript = true;
		}
	}
	else if (type == ProcessType_e::PT_BlockHandle) {
		if (!getCanTransHandle()) {
			event.m_blockHandle = true;
		}
		if (!getCanTransScript()) {
			event.m_blockScript = true;
		}
	}
}

b2 ssui::Control::checkCanEvent() {
    return getDataIsVisible() && getDataIsEnable();
}

ssui::DataInfoAttr* ssui::Control::getExpansionAttr(AttrType_e attrIndex) {
    const auto& pairAttrInfo = m_mapExpansionAttr.find(attrIndex);
    if (pairAttrInfo != m_mapExpansionAttr.end()) {
        return pairAttrInfo->second;
    } else {
        return nullptr;
    }
}

int ssui::Control::getExpansionAttrS32(AttrType_e attrIndex) {
    auto pAttrInfo = getExpansionAttr(attrIndex);
    if (pAttrInfo != nullptr) {
        return pAttrInfo->m_iData;
    } else {
        return 0;
    }
}

void ssui::Control::setExpansionAttr(DataInfoAttr* pAttrInfo) {
    const auto& pairAttrInfo = m_mapExpansionAttr.find(pAttrInfo->m_attrType);
    if (pairAttrInfo != m_mapExpansionAttr.end()) {
        safe_release(pairAttrInfo->second);
        m_mapExpansionAttr[pAttrInfo->m_attrType] = pAttrInfo;
    } else {
        m_mapExpansionAttr.insert(pAttrInfo->m_attrType, pAttrInfo);
    }
}

void ssui::Control::setExpansionAttr(AttrType_e attrIndex, int value) {
    const auto& pairAttrInfo = m_mapExpansionAttr.find(attrIndex);
    if (pairAttrInfo != m_mapExpansionAttr.end()) {
        pairAttrInfo->second->m_iData = value;
    } else {
        m_mapExpansionAttr.insert(attrIndex, DataInfoAttr::createObject(attrIndex, value));
    }
}

void ssui::Control::pushRender(const PolyImage& render) {
    if (m_curRenderCount < m_arrRender.size()) {
        m_arrRender[m_curRenderCount] = render;
    } else {
        m_arrRender.push_back(render);
    }
    m_curRenderCount++;
}

PolyImage& ssui::Control::nextRender() {
    if (m_curRenderCount < m_arrRender.size()) {
        auto& render = m_arrRender[m_curRenderCount++];
        render.resize(4);
        return render;
    } else {
        m_arrRender.push_back(PolyImage());
        m_curRenderCount++;
        m_arrRender.back().resize(4);
        return m_arrRender.back();
    }
}

void ssui::Control::swap(ArrayList<PolyImage>& renderCache) {
    m_curRenderCount = renderCache.size();
    renderCache.swap(m_arrRender);
}

#pragma region "Parent, Components, Children"
UIComponent* Control::getParentComponent() const {
    return m_pParentComponent;
}

Control* Control::getParent() const {
    return m_pParentComponent ? m_pParentComponent->getHost() : nullptr;
}

BoloObject* Control::getParentObject() const {
    return (BoloObject*)getParent();
}

void Control::setParentObject(BoloObject* value) {
    if (value == getParentObject()) {
        return;
    }
    auto pObj = (ObjectBase*)value;
    if (pObj->is(NT_Control)) {
        setParent((Control*)value);
        touchPrepareDataChanged();
    }
}

void Control::setParent(Control* value) {
    if (value == getParent()) {
        return;
    }
    if (getParent() != nullptr) {
        getParent()->removeChild(this);
    }
    if (value != nullptr) {
        ((Control*)value)->addChild(this);
    } else {
        m_pParentComponent = nullptr;
    }
    touchPrepareDataChanged();
}

//=======================================================================================
UIComponent** Control::begin() const {
    return m_components.begin();
}

UIComponent** Control::end() const {
    return m_components.end();
}

void Control::addComponent(UIComponent* pComp) {
    if (pComp->is(NT_BasicContent)) {
        m_contentComponent = (BasicContent*)pComp;
    } else if (pComp->getNodeType() == NT_BasicClip) {
        m_clipComponent = (BasicClip*)pComp;
    }
    if (pComp->isContainerComponent()) {
        setChildrenComponent(pComp);
    } else {
        m_components.push_back(pComp);
    }
    pComp->setHost(this);
    pComp->TriggerEvent(ET_AddComponentDone);
    touchPrepareDataChanged();
}

BasicContent* ssui::Control::enableBasicContent() {
    auto pComp = getBasicContent();
    if (pComp != nullptr) {
        return pComp;
    }
    pComp = BasicContent::createObject();
    m_components.insert(m_components.begin(), pComp);
    m_contentComponent = pComp;
    return pComp;
}

void ssui::Control::disableBasicContent() {
    releaseComponentByClass(NT_BasicContent);
}

void Control::releaseAllComponents() {
    for (auto& pComp : m_components) {
        pComp->releaseObject();
    }
    m_components.clear();
    m_pChildrenComponent = nullptr;
    m_contentComponent = nullptr;
    m_clipComponent = nullptr;
    touchPrepareDataChanged();
}

bool Control::releaseComponent(UIComponent* pComp) {
    if (pComp == nullptr) {
        return false;
    }
    for (auto& pc : m_components) {
        if (pc == pComp) {
            if (pComp == m_pChildrenComponent) {
                m_pChildrenComponent = nullptr;
            }
            if (pComp == m_contentComponent) {
                m_contentComponent = nullptr;
            } else if (pComp == m_clipComponent) {
                m_clipComponent = nullptr;
            }
            pComp->releaseObject();
            m_components.erase(&pc);
            touchPrepareDataChanged();
            return true;
        }
    }
    return false;
}

bool Control::releaseComponentByClass(NodeType_e nodeType) {
    if (!ObjectBase::is(nodeType, NT_UIComponent)) {
        return false;
    }
    bool ret = false;
    for (auto& pComp : m_components) {
        if (pComp->is(nodeType)) {
            releaseComponent(pComp);
            ret = true;
        }
    }
    if (ret == true) {
        touchPrepareDataChanged();
    }
    return ret;
}

bool Control::releaseComponentByType(NodeType_e nodeType) {
    if (!ObjectBase::is(nodeType, NT_UIComponent)) {
        return false;
    }
    bool ret = false;
    for (auto& pComp : m_components) {
        if (pComp->getNodeType() == nodeType) {
            releaseComponent(pComp);
            ret = true;
        }
    }
    if (ret == true) {
        touchPrepareDataChanged();
    }
    return ret;
}

ssui::UIComponent* ssui::Control::getComponent(NodeType_e nodeType) const {
    for (const auto& pComp : m_components) {
        if (pComp->getNodeType() == nodeType) {
            return pComp;
        }
    }
    return nullptr;
}

UIComponent* Control::getComponentByClass(NodeType_e nodeType) const {
    for (const auto& pComp : m_components) {
        if (pComp->is(nodeType)) {
            return pComp;
        }
    }
    return nullptr;
}

ssui::BasicMeasure* ssui::Control::getBasicMeasure() const {
    return (BasicMeasure*)getComponentByClass(NT_BasicMeasure);
}

ssui::BasicClip* ssui::Control::getBasicClip() const {
    return m_clipComponent;
    //return (BasicClip*)getComponentByClass(NT_BasicClip);
}

bool ssui::Control::isEnableClip() const {
    if (m_clipComponent) {
        return m_clipComponent->getIsEnableClip();
    }
    return true;
}

ssui::BasicContent* ssui::Control::getBasicContent() const {
    return m_contentComponent;
    //return (BasicContent*)getComponentByClass(NT_BasicContent);
}

ssui::BasicTransform* ssui::Control::getBasicTransform() const {
    return (BasicTransform*)getComponentByClass(NT_BasicTransform);
}

void Control::setChildrenComponent(UIComponent* pCtnComp) {
    if (m_pChildrenComponent != nullptr) {
        m_pChildrenComponent->releaseObject();
    }
    m_pChildrenComponent = pCtnComp;
    m_components.push_back(pCtnComp);
    touchPrepareDataChanged();
}

int Control::getDataCcit() const {
    return mt_dataCcit;
}

void Control::setDataCcit(int value) {
    mt_dataCcit = (CCIT_e)value;
}

//=======================================================================================
const ArrayList<Control*>& ssui::Control::getChildren() const {
    return m_pChildrenComponent ? m_pChildrenComponent->container() : UIComponent::s_nullContainer;
}

gstl::ArrayList<Control*>& Control::children() {
    return m_pChildrenComponent ? m_pChildrenComponent->container() : UIComponent::s_nullContainer;
}

void Control::addChild(Control* pChild, UIComponent* pParentComp) {
    if (pParentComp == nullptr || pParentComp->isEnableContainer() == false) {
        return;
    }
    pParentComp->addChild(pChild);
}

void Control::addChild(Control* pChild) {
    if (m_pChildrenComponent == nullptr) {
        return;
    }
    addChild(pChild, m_pChildrenComponent);
}

void Control::removeChildFunc(Control** ppChild, bool isRelease) {
    if (isRelease) {
        (*ppChild)->releaseObject();
    }
    if (children().empty()) {
        return;
    }
    children().erase(ppChild);
    touchPrepareDataChanged();
}

void Control::removeChild(Control* pChild) {
    if (children().empty()) {
        return;
    }
    auto index = children().where(pChild);
    if (index != -1) {
        removeChildFunc(children().begin() + index, false);
    }
    touchPrepareDataChanged();
}

void ssui::Control::deleteAllAddChild() {
    if (getChildren().empty()) {
        return;
    }
    for (auto ppCtrl = getChildren().begin(); ppCtrl != getChildren().end(); ++ppCtrl) {
        if (*ppCtrl && (*ppCtrl)->getIsCopyAdd()) {
            deleteChild(*ppCtrl);
            ppCtrl--;
        }
    }
}

void ssui::Control::deleteAddChild(Control* pChild) {
    if (pChild && pChild->getIsCopyAdd()) {
        deleteChild(pChild);
    }
}

void ssui::Control::deleteAddChildWithID(const string & name) {
    if (getChildren().empty()) {
        return;
    }
    for (auto ppCtrl = getChildren().begin(); ppCtrl != getChildren().end(); ++ppCtrl) {
        if (*ppCtrl && (*ppCtrl)->getIsCopyAdd()&& ((*ppCtrl)->getsourceID()==name)) {
            deleteChild(*ppCtrl);
            ppCtrl--;
        }
    }
}

void ssui::Control::deleteImportChild(const string& name) {
    if (getChildren().empty()) {
        return;
    }
    for (auto ppChild = getChildren().begin(); ppChild != getChildren().end(); ++ppChild) {
        if ((*ppChild)->getImportUIName() == name) {
            deleteChild(*ppChild);
            ppChild--;
        }
    }
}


void ssui::Control::deleteAllImportChild() {
    if (getChildren().empty()) {
        return;
    }
    for (auto ppChild = getChildren().begin(); ppChild != getChildren().end(); ++ppChild) {
        if (*ppChild && !(*ppChild)->getImportUIName().empty()) {
            deleteChild(*ppChild);
            ppChild--;
        }
    }
}

void Control::releaseChildren() {
    if (m_pChildrenComponent != nullptr) {
        m_pChildrenComponent->releaseChildren();
        touchPrepareDataChanged();
    }
}

void Control::releaseChildrenClass(NodeType_e nodeType) {
    if (children().empty()) {
        return;
    }
    for (auto itChild = children().begin(); itChild != children().end(); ++itChild) {
        if ((*itChild)->is(nodeType)) {
            removeChildFunc(itChild, true);
            itChild--;
        }
    }
    touchPrepareDataChanged();
}

void Control::deleteChild(Control* pChild) {
    if (children().empty()) {
        return;
    }
    removeChild(pChild);
    pChild->releaseObject();
    touchPrepareDataChanged();
}

//=======================================================================================
int Control::getAddControlCount() {
    int size = 0;
    for (auto& pChild : children()) {
        if (pChild && pChild->getIsCopyAdd()) {
            size++;
        }
    }
    return size;
}

int Control::getVControlCount() {
    int size = 0;
    for (auto& pChild : children()) {
        if (pChild && pChild->getDataIsVisible()) {
            size++;
        }
    }
    return size;
}

Control* Control::getVControlWithIndex(int index) {
    int size = 0;
    for (auto& pChild : children()) {
        if (pChild && pChild->getDataIsVisible()) {
            if (size == index) {
                return pChild;
            }
            size++;
        }
    }
    return nullptr;
}

Control* Control::getControlWithIndex(int index) {
    int size = 0;
    for (auto& pChild : children()) {
        if (size == index) {
            return pChild;
        }
        size++;
    }
    return nullptr;
}

int Control::getControlIndexWithID(const string& id) {
    if (children().empty() == false) {
        int size = 0;
        for (auto& pChild : children()) {
            if (pChild->getId() == id) {
                return size;
            }
            size++;
        }
    }
    return -1;
}

int Control::getVControlIndexWithID(const string& id) {
    if (children().empty() == false) {
        int size = 0;
        for (auto& pChild : children()) {
            if (pChild->getDataIsVisible()) {
                if (pChild->getId() == id) {
                    return size;
                }
                size++;
            }
        }
    }
    return -1;
}

bool Control::setControlIndex(Control* ctrl, int index) {
    if (children().empty() == false) {
        if (ctrl != nullptr && index >= 0 && index < children().size()) {
            int indx = children().where(ctrl);
            if (indx >= 0 && indx < children().size()) {
                if (index == indx) {
                    return true;
                }
                children().erase(children().begin() + indx);
                if (index < children().size()) {
                    children().insert(children().begin() + index, ctrl);
                } else {
                    children().push_back(ctrl);
                }
                touchPrepareDataChanged();
                return true;
            }
        }
    }
    return false;
}

#pragma endregion

#pragma region "Draw"

#pragma region "change-trigger"
void Control::touchPrepareDataChanged() {
    if (m_isLockDrawTouch == true) {
        return;
    }
    m_isPrepareDataReady = false;
    onDrawChanged();
}

void Control::touchMeasureChanged() {
    if (m_isLockDrawTouch == true) {
        return;
    }
    m_isMeasureReady = false;
    onDrawChanged();
}

void Control::touchRenderChanged() {
    if (m_isLockDrawTouch == true) {
        return;
    }
    m_isRenderReady = false;
    onDrawChanged();
}

void ssui::Control::touchPosterityChanged() {
    if (m_isPosterityReady == false) {
        return;
    }
    m_isPosterityReady = false;
    auto pParent = getParent();
    if (pParent) {
        pParent->touchPosterityChanged();
    }
}

void Control::onDrawChanged() {
    touchPosterityChanged();
    auto pParent = getParent();
    if (pParent != nullptr) {
        if (pParent->m_isAutoFrameData) {
            pParent->touchMeasureChanged();
        }
    }
}

bool Control::isDrawReady() {
    return m_isDrawReady == 0x7;
}

void Control::assignAllDrawChanged() {
    if (m_isLockDrawTouch == true) {
        return;
    }
    m_isDrawReady = 0;
}

void ssui::Control::touchAllChildrenDrawChanged() {
    for (auto& pComp : *this) {
        for (auto& pChild : *pComp) {
            pChild->assignAllDrawChanged();
            pChild->onDrawChanged();
        }
    }
}

void Control::assignAllDrawReady() {
    m_isDrawReady = 0x7;
}
#pragma endregion "change-trigger"

#pragma region "Measure"
ParentAreaType_e Control::getParentAreaType() const {
    if (m_pParentComponent) {
        return m_pParentComponent->getParentAreaType();
    } else {
        return (ParentAreaType_e)PAT_inner;
    }
}

//�õ����������ĸ��ӿؼ��ĸ�����
const Border& Control::getParentArea() const {
    return m_pParentComponent ? m_pParentComponent->getChildArea(this) : Border::s_null;
}

MeasureData& ssui::Control::measure() {
    return *m_pMeasure;
}

const MeasureData& Control::getSelfMeasure() const {
    return *m_pMeasure;
}

const MeasureData& Control::getOuterMeasure() const {
    return m_pOuterMeasure ? *m_pOuterMeasure : getSelfMeasure();
}

const MeasureData& Control::getInnerMeasure() const {
    return m_pInnerMeasure ? *m_pInnerMeasure : getSelfMeasure();
}

const MeasureData& Control::getMeasure(ParentAreaType_e pat) const {
    switch (pat) {
        case PAT_inner:
            return getInnerMeasure();
        case PAT_self:
            return getSelfMeasure();
        case PAT_outer:
            return getOuterMeasure();
        case PAT_max:
            break;
        default:
            break;
    }
    return getSelfMeasure();
}

bool ssui::Control::isHaveOuterMeasure() const {
    return m_pOuterMeasure != nullptr;
}

bool ssui::Control::isHaveInnerMeasure() const {
    return m_pInnerMeasure != nullptr;
}
#pragma endregion "Measure"

#pragma region "onDraw"

bool ssui::Control::isWaitingParentMeasureReady() const {
    return m_isMustParentReady == true &&
        (getParent() != nullptr && getParent()->m_isMeasureReady == false);
}

void Control::onDraw(unsigned char drawStep) {
    bool isChildrenReady = true;
    if (m_isPrepareDataReady == false) {
        onPrepareData();
    }
    if (isDrawReady() == false) {
        if (mt_isHidden == true) {
            initPrepareData();
            initMeasure();
            initRender();
            assignAllDrawReady();
            goto gtDrawFinish;
        }
        //         if (isWaitingParentMeasureReady() && drawStep >= 1) {
        //             printf("\n%d\t1", drawStep);
        //             printData();
        //             goto gtDrawFinish;
        //         }

        refreshScrollState();
        onMeasure(drawStep, -1);
        for (int i = 0; i <= m_measureReadyMinimumTimes; i++) {
            if (m_isAutoFrameData) {
                int childDrawStep = (m_isAutoFrameData != 0 && i == 0) ? 0 : 1;
                isChildrenReady = onDrawComponents(childDrawStep, true);
            }
            //��Ϊ����Ӧ�����ԡ�
            onMeasure(drawStep);
        }
        if (m_measureReadyMinimumTimes <= 0) {
            m_isLockDrawTouch = true;
            //����ר��
            isChildrenReady = onDrawComponents(2, true);
            m_isLockDrawTouch = false;
        }

        m_isPrepareDataReady = true;
        m_isMeasureReady = true;
        onRender(drawStep);
        assignAllDrawReady();
        if (getParent() != nullptr && getParent()->isDrawReady()) {
            onTransformAndClipPosterityByParentArea(this);
        }
        if (drawStep == 0) {
            assignAllDrawChanged();
        } else {
            assignAllDrawReady();
        }
    } else {
        if (mt_isHidden == true) {
            goto gtDrawFinish;
        }
        if (m_isPosterityReady == false) {
            //����ר��
            //isChildrenReady = onDrawComponents(1, false);
            isChildrenReady = onDrawComponents(1, true);
        }
    }
gtDrawFinish:
    if (m_isRefreshScrollStateReady == false) {
        auto pScroll = (ScrollView*)getComponentByClass(NT_ScrollView);
        if (pScroll) {
            pScroll->refreshTouchComp();
        }
    }
    if (isDrawReady() == true) {
        m_isPosterityReady = isChildrenReady;
    }
    return;
}

bool ssui::Control::onDrawComponents(unsigned char drawStep, bool isReDraw) {
    bool isChildrenReady = true;
    for (auto& pComp : m_components) {
        if (pComp->onDrawChildren(drawStep, isReDraw) == false) {
            isChildrenReady = false;
        }
    }
    for (auto& pComp : m_components) {
        pComp->onChildrenTransformSuf(1, isReDraw);
    }
    for (auto& pComp : m_components) {
        for (auto& pChild : *pComp) {
            pChild->m_isDidRender = false;
        }
    }
    return isChildrenReady;
}

void Control::initPrepareData() {
    m_measureReadyMinimumTimes = 0;
    m_isAutoFrameData = 0;
    m_isMustParentReady = false;
}

void Control::onPrepareData() {
    if (m_isPrepareDataReady == false) {
        assignAllDrawChanged();
        initPrepareData();
        if (getParentComponent()) {
            getParentComponent()->onChildPrepareData();
        }
        ForeachComp(onPrepareData());
        m_isPrepareDataReady = true;
    }
}

void Control::initMeasure() {
    if (m_pOuterMeasure != nullptr) {
        m_pOuterMeasure->releaseObject();
        m_pOuterMeasure = nullptr;
    }
    if (m_pInnerMeasure != nullptr) {
        m_pInnerMeasure->releaseObject();
        m_pInnerMeasure = nullptr;
    }
    measure().initData();
}

void Control::onMeasure(unsigned char drawStep, int times/* = 0*/) {
    if (m_isMeasureReady == false) {
        m_isRenderReady = false;
        initMeasure();
        ForeachComp(onMeasure(drawStep));
        if (m_measureReadyMinimumTimes > times) {
            return;
        }
        m_isPrepareDataReady = true;
        if (isWaitingParentMeasureReady() == false || drawStep >= 1) {
            m_isMeasureReady = true;
        }
    }
}

void Control::initRender() {
    m_texture = nullptr;
    m_curRenderCount = 0;
    //m_arrRender.clear();
}

void Control::onRender(unsigned char drawStep) {
    if (m_isRenderReady == false) {
//         measure().transSrcAreaToGeo();
//         if (m_pOuterMeasure) {
//             m_pOuterMeasure->transSrcAreaToGeo();
//         }
//         if (m_pInnerMeasure) {
//             m_pInnerMeasure->transSrcAreaToGeo();
//         }
        if (m_isAutoFrameData == 0 && isWaitingParentMeasureReady() && drawStep == 0) {
            return;
        }
        m_isDidRender = true;
        //assignAllDrawChanged();
        initRender();
        ForeachComp(onRender(drawStep));
        ForeachComp(onTransform(drawStep));
        ForeachComp(onClip(drawStep));
        if (isWaitingParentMeasureReady() && drawStep == 0) {

        } else {
            m_isRenderReady = true;
        }
    }
}

void Control::onTransformAndClipPosterityByParentArea(Control* pPosterity) {
    ForeachComp(applyTransformToPosterity(pPosterity));
    ForeachComp(applyClipToPosterity(pPosterity));
    if (getParent()->getParent() && getParent()->getParent()->isDrawReady()) {
        getParent()->onTransformAndClipPosterityByParentArea(pPosterity);
    }
}

void ssui::Control::onShow() {
    if (mt_isHidden == true) {
        return;
    }
    ForeachComp(onShow());
}

void ssui::Control::refreshScrollState() {
    m_isRefreshScrollStateReady = false;
    auto pParent = getParent();
    if (pParent) {
        pParent->m_isRefreshScrollStateReady = false;
    }
}

#pragma endregion "onDraw"
bool Control::getRealVisible() const {
    if (!getDataIsVisible())
        return false;

    if (getParent()) {
        return getParent()->getRealVisible();
    }
    return true;
}
bool Control::getDataIsVisible() const {
    return !mt_isHidden;
}

void Control::setDataIsVisible(bool value) {
    if (mt_isHidden != !value) {
        mt_isHidden = !value;
        onDataVisibleChangedFunc();
        touchPrepareDataChanged();
    }
}
void Control::onDataVisibleChangedFunc() {
    TriggerEvent(ET_VisibleChanged, nullptr, nullptr);
}
ft Control::getDrawX() const {
    auto pGeo = getSelfMeasure().m_pTransGeo;
    if (pGeo != nullptr) {
        Border area;
        pGeo->getBorder(area);
        return area.m_left;
    }
    return 0;
}

ft Control::getDrawY() const {
    auto pGeo = getSelfMeasure().m_pTransGeo;
    if (pGeo != nullptr) {
        Border area;
        pGeo->getBorder(area);
        return area.m_top;
    }
    return 0;
}

ft Control::getDrawWidth() const {
    auto pGeo = getSelfMeasure().m_pTransGeo;
    if (pGeo != nullptr) {
        Border area;
        pGeo->getBorder(area);
        return Math::abs(area.m_right - area.m_left);
    }
    return 0;
}

ft Control::getDrawHeight() const {
    auto pGeo = getSelfMeasure().m_pTransGeo;
    if (pGeo != nullptr) {
        Border area;
        pGeo->getBorder(area);
        return Math::abs(area.m_top - area.m_bottom);
    }
    return 0;
}
#pragma endregion

#pragma region "transform"
void ssui::Control::transformPosition(ft x, ft y) {
    for (auto it = m_arrRender.begin(); it < m_arrRender.begin() + m_curRenderCount; ++it) {
        if (it->empty() == false) {
            GeometryManager::transformPosition(*it, x, y);
        }
    }
    measure().transformPosition(x, y);
    if (m_pOuterMeasure) {
        m_pOuterMeasure->transformPosition(x, y);
    }
    if (m_pInnerMeasure) {
        m_pInnerMeasure->transformPosition(x, y);
    }
}
#pragma endregion

#pragma region "Id, Scene"
const gstl::string& Control::getId() const {
    return (mt_pId == nullptr) ? StringManager::getInstance()->mc_strNullDef : *mt_pId;
}

void Control::setId(const string& value) {
    if (getId() != value) {
        if (getScene() != nullptr) {
            if (mt_pId != nullptr) {
                auto pairOld = getScene()->m_mapIdNode.find(mt_pId->hashCode());
                if (pairOld != getScene()->m_mapIdNode.end() && pairOld->second == this) {
                    getScene()->m_mapIdNode.erase(pairOld);
                }
            }
            if (!value.empty()) {
                auto pairOld = getScene()->m_mapIdNode.find(value.hashCode());
                if (pairOld != getScene()->m_mapIdNode.end()) {
                    //�������ظ�id���������Ҫ�ѾɵĿؼ���id�ÿա�
                    //(pairOld)->second->setId(StringManager::getInstance()->mc_strNullDef);
                    //�ı�����ˣ����Ǿɵ��ÿգ������µĲ��ӵ�map�
                } else {
                    getScene()->m_mapIdNode.insert(value.hashCode(), this);
                }
            }
        }
        setIdJustData(value);
    }
}

void Control::setIdJustData(const string& value) {
    if (value.empty()) {
        safe_delete(mt_pId);
    } else {
        if (mt_pId == nullptr) {
            mt_pId = new string(value);
        } else {
            *mt_pId = value;
        }
    }
}
BoloObject* Control::getSelectControlObject() const {
    if (m_pChildrenComponent->is(NT_StackPanel)) {
        return (BoloObject*)static_cast<StackPanel*>(m_pChildrenComponent)->getSelectControl();
    }
    return nullptr;
}
void Control::setSelectControlObject(BoloObject* value) {
    if (m_pChildrenComponent->is(NT_StackPanel)) {
        auto pStackPanel = static_cast<StackPanel*>(m_pChildrenComponent);
        if (value == pStackPanel->getSelectControl()) {
            return;
        }
        auto pSelect = (ObjectBase*)value;
        if (pSelect->is(NT_Control)) {
            pStackPanel->setSelectControl((Control*)pSelect);
        }
    }
}
UIScene* Control::getScene() const {
    return mt_pScene;
}

BoloObject* Control::getSceneObject() const {
    return (BoloObject*)mt_pScene;
}

void Control::setScene(UIScene* pScene) {
    auto id = getId();
    setId(StringManager::getInstance()->mc_strNullDef);
    mt_pScene = pScene;
    TriggerEvent(ET_SceneChanged, 0, 0);
    setId(id);
}
#pragma endregion

#pragma region "event"
b2 ssui::Control::getIsOwnEvent() const{
	return m_isOwnEvent;
}
void ssui::Control::setIsOwnEvent(b2 value) {
    if (m_isOwnEvent != value) {
        m_isOwnEvent = value;
    }
}
b2 ssui::Control::getCanTransHandle() const {
	return m_canTransHandle;
}
void ssui::Control::setCanTransHandle(b2 value) {
    if (m_canTransHandle != value) {
        m_canTransHandle = value;
    }
}
b2 ssui::Control::getCanTransScript() const {
	return m_canTransScript;
}
void ssui::Control::setCanTransScript(b2 value) {
    if (m_canTransScript != value) {
        m_canTransScript = value;
    }
}

b2 ssui::Control::getNextUIEvent() const {
    return m_nextUIevent;
}
void ssui::Control::setNextUIEvent(b2 value) {
    if (m_nextUIevent != value) {
        m_nextUIevent = value;
    }
}

#pragma endregion

#pragma region "Skin, Text, Input"
const gstl::string& ssui::Control::getSkinName() const {
    return getBasicContent() ? getBasicContent()->getSkinName() : StringManager::getInstance()->mc_strNullDef;
}

void ssui::Control::setSkinName(const string& value) {
    auto pComp = getBasicContent();
    if (pComp == nullptr) {
        if (value.empty()) {
            return;
        }
        pComp = enableBasicContent();
    }
    pComp->setSkinName(value);
}

const string& ssui::Control::getBeforeSkinName(const string& value) const {
    return getBasicContent() ? getBasicContent()->getBeforeSkinName(value) : StringManager::getInstance()->mc_strNullDef;
}
void ssui::Control::addBeforeSkinName(const string& value) {
    auto pComp = getBasicContent();
    if (pComp == nullptr) {
        if (value.empty()) {
            return;
        }
        pComp = enableBasicContent();
    }
    pComp->addBeforeSkinName(value);
}


const gstl::wstring& ssui::Control::getText() const {
    return getBasicContent() ? getBasicContent()->getText() : StringManager::getInstance()->mc_wstrNullDef;
}

void ssui::Control::setText(const wstring& value) {
    auto pComp = getBasicContent();
    if (pComp == nullptr) {
        if (value.empty()) {
            return;
        }
        pComp = enableBasicContent();
    }
    pComp->setText(value);
}

const gstl::wstring& ssui::Control::getTextKey() const {
    return getBasicContent() ? getBasicContent()->getTextKey() : StringManager::getInstance()->mc_wstrNullDef;
}

void ssui::Control::setTextKey(const wstring& value) {
    auto pComp = getBasicContent();
    if (pComp == nullptr) {
        if (value.empty()) {
            return;
        }
        pComp = enableBasicContent();
    }
    pComp->setTextKey(value);
}

bool Control::getIsInput() const {
    return mt_isEnableInput;
}

void Control::setIsInput(bool value) {
    mt_isEnableInput = value;
    if (mt_isEnableInput) {
        if (getComponent(NT_InputBox) == nullptr) {
            addComponent(InputBox::createObject());
        }
        touchPrepareDataChanged();
    } else {
        releaseComponentByType(NT_InputBox);
        touchPrepareDataChanged();
    }
}

Skin* Control::getSkin() const {
    return getBasicContent() ? getBasicContent()->getSkin() : nullptr;
}

const gstl::string& ssui::Control::getSkinGroupOfCurSkin() const {
    if (getBasicContent()) {
        return getBasicContent()->getSkinGroupOfCurSkin();
    } else {
        return StringManager::getInstance()->mc_strNullDef;
    }
}
#pragma endregion

#pragma region "Slot, State"
SlotState Control::getDataSlotState(SlotType_e slot) const {
    return m_arrSlotState[slot];
}

//=======================================================================================
bool Control::getDataIsEnable() const {
    return !m_arrSlotState[SLOT_body].m_isDisable;
}

void Control::setDataIsEnable(bool value) {
    b2 isChange = false;
    for (auto& slotState : m_arrSlotState) {
        if (slotState.m_isDisable != !value) {
            slotState.m_isDisable = !value;
            isChange = true;
        }
    }
    if (isChange) {
        TriggerEvent(ET_EnableChanged, nullptr, nullptr);
    }
    touchPrepareDataChanged();
}

bool Control::getDataSlotIsEnable(SlotType_e slot) const {
    return !m_arrSlotState[slot].m_isDisable;
}

void Control::setDataSlotIsEnable(SlotType_e slot, bool value) {
    m_arrSlotState[slot].m_isDisable = !value;
    touchPrepareDataChanged();
}

//=======================================================================================
bool Control::getDataIsPressed() const {
    return m_arrSlotState[SLOT_body].m_isPressed;
}

void Control::setDataIsPressed(bool value) {
    for (auto& slotState : m_arrSlotState) {
        slotState.m_isPressed = value;
    }
    touchPrepareDataChanged();
}

bool Control::getDataSlotIsPressed(SlotType_e slot) const {
    return m_arrSlotState[slot].m_isPressed;
}

void Control::setDataSlotIsPressed(SlotType_e slot, bool value) {
    m_arrSlotState[slot].m_isPressed = value;
    touchPrepareDataChanged();
}

//=======================================================================================
bool Control::getDataIsSelected() const {
    return m_arrSlotState[SLOT_body].m_isSelected;
}

void Control::setDataIsSelected(bool value) {
    if (value != getDataIsSelected()) {
        if (mt_selectBindingControlId.empty() == false && getScene() != nullptr) {
            auto pCtrl = getScene()->getControlWithId(mt_selectBindingControlId);
            if (pCtrl != nullptr) {
                pCtrl->setDataIsVisible(value);
            }
        }
        for (auto& slotState : m_arrSlotState) {
            slotState.m_isSelected = value;
        }
        if (value == true && getDataCcit() == ssui::CCIT_Radio) {
            ForeachComp(onSelect());
        }
        touchPrepareDataChanged();
    }
    if (UIScene::s_isParsing == false) {
        TriggerEvent(value ? ET_Select : ET_Unselect, this, nullptr);
    }
}

void Control::setDataIsSelectedNonScript(bool value) {
    if (value != getDataIsSelected()) {
        if (mt_selectBindingControlId.empty() == false && getScene() != nullptr) {
            auto pCtrl = getScene()->getControlWithId(mt_selectBindingControlId);
            if (pCtrl != nullptr) {
                pCtrl->setDataIsVisible(value);
            }
        }
        for (auto& slotState : m_arrSlotState) {
            slotState.m_isSelected = value;
        }
        if (value == true && getDataCcit() == ssui::CCIT_Radio) {
            ForeachComp(onSelect());
        }
        touchPrepareDataChanged();
    }
}

bool Control::getDataSlotIsSelected(SlotType_e slot) const {
    return m_arrSlotState[slot].m_isSelected;
}

void Control::setDataSlotIsSelected(SlotType_e slot, bool value) {
    m_arrSlotState[slot].m_isSelected = value;
    touchPrepareDataChanged();
}

void Control::setSelectBindingControlId(const string& value) {
    mt_selectBindingControlId = value;
    auto pCtrl = getScene()->getControlWithId(mt_selectBindingControlId);
    if (pCtrl != nullptr) {
        pCtrl->setDataIsVisible(getDataIsSelected());
    }
    touchMeasureChanged();
}

//=======================================================================================
bool Control::getDataIsBlink() const {
    return mt_isBlink;
}

void Control::setDataIsBlink(bool value) {
    if (mt_isBlink != value) {
        mt_isBlink = value;
        if (mt_isBlink) {
            releaseComponentByType(NT_Blink);
            addComponent(Blink::createObject());
        } else {
            releaseComponentByType(NT_Blink);
        }
        touchPrepareDataChanged();
    }
}
#pragma endregion

//=======================================================================================

#pragma region "Event, Script, Csv"
EventNodeGroup* Control::getEventNodeGroup() const {
    return mt_pDataEventGroup;
}

void Control::setControlScript(EventType_e type, const wstring& scriptStr, bool isClear) {
    setControlScript(DictionaryManager::getInstance()->m_arrEventType[type], scriptStr, isClear);
}

void Control::setControlScript(const string& type, const wstring& scriptStr, bool isClear) {
    if (mt_pDataEventGroup == nullptr) {
        mt_pDataEventGroup = EventNodeGroup::createObject();
    }
    mt_pDataEventGroup->setScript(type, scriptStr, isClear);
}

//=======================================================================================
bool Control::getIsCopyAdd() const {
    return mt_isCopyAdd;
}

void Control::setIsCopyAdd(bool value) {
    mt_isCopyAdd = value;
}

void Control::setsourceID(const string & aimID) {
    sourceID = aimID;
}

string Control::getsourceID() {
    return sourceID;
}

const string& ssui::Control::getImportUIName() const {
    return mt_importUIName;
}

void ssui::Control::setImportUIName(const string& value) {
    mt_importUIName = value;
}

//=======================================================================================
const gstl::wstring& Control::getDataCsvData() const {
    if (mt_pCsvData != nullptr) {
        return *mt_pCsvData;
    } else {
        return StringManager::getInstance()->mc_wstrNullDef;
    }
}

void Control::setDataCsvData(const wstring& value) {
    if (value.empty()) {
        safe_delete(mt_pCsvData);
        mt_pCsvData = nullptr;
    } else {
        if (mt_pCsvData != nullptr && *mt_pCsvData != value) {
            delete mt_pCsvData;
        }
        mt_pCsvData = new wstring(value);
    }
}

const gstl::wstring& Control::getDataCommand() const {
    if (mt_pCommand != nullptr) {
        return *mt_pCommand;
    } else {
        return StringManager::getInstance()->mc_wstrNullDef;
    }
}

void Control::setDataCommand(const wstring& value) {
    b2 isChange = false;
    if (value.empty()) {
        if (mt_pCommand) {
            isChange = true;
        }
        safe_delete(mt_pCommand);
        mt_pCommand = nullptr;
    } else {
        if (mt_pCommand != nullptr && *mt_pCommand != value) {
            delete mt_pCommand;
            isChange = true;
        }else if (mt_pCommand == nullptr) {
            isChange = true;
        }
        mt_pCommand = new wstring(value);
    }
    if (isChange) {
        TriggerEvent(ET_CommandChanged, nullptr, nullptr);
    }
}

int Control::parseCsvValue1(const wstring& data) {
    switch (getDataCcit()) {
        case CCIT_NULL:
            //<inc>
            break;
        case CCIT_Label: {
            if (getBasicContent()) {
                setIsInput(StringManager::getInstance()->getBoolValue(data));
            }
        }break;
        case CCIT_Panel:
            break;
        case CCIT_Button:
            break;
        case CCIT_Radio: {
            setDataIsSelected(StringManager::getInstance()->getBoolValue(data));
        }break;
        case CCIT_Check:
            setDataIsSelected(StringManager::getInstance()->getBoolValue(data));
            break;
        case CCIT_InputBox:
            if (getBasicContent()) {
                setIsInput(StringManager::getInstance()->getBoolValue(data));
            }
            break;
        case CCIT_TextFlow:
            if (getBasicContent()) {
                setIsInput(StringManager::getInstance()->getBoolValue(data));
            }
            break;
        case CCIT_Progress: {
            auto pComp = (Progress*)getComponentByClass(NT_Progress);
            if (pComp) {
                string str;
                util::str2str(data, str);
                pComp->setCurValue(util::atof_s(str));
            }
        } break;
        case CCIT_TimeBlock: {
            auto pComp = (TimeContent*)getComponentByClass(NT_TimeContent);
            if (pComp) {
                pComp->setIsStart(StringManager::getInstance()->getBoolValue(data));
            }
        }break;
        case CCIT_Para:
            break;
        case CCIT_FlowElement:
            break;
        case CCIT_Grid:
            break;
        case CCIT_StackPanel:
            break;
        case CCIT_WrapPanel:
            break;
        case CCIT_AutoGrid:
            break;
        case CCIT_SlicedPanel:
            break;
        case CCIT_VirtualJoystick:
            break;
        case CCIT_UIDrawModel: {  //scalex,scaley,scalez:anglex,angley,anglez
            auto pComp = (UIDrawModel*)getComponentByClass(NT_UIDrawModel);
            if (pComp) {
                pComp->setModelScaleAndAngle(util::convert2str(data));
            }
        }break;
        case CCIT_MAX:
            break;
        default:
            break;
    }
    return 0;
}

int Control::parseCsvValue2(const wstring& data) {
    switch (getDataCcit()) {
        case CCIT_NULL:
            //<inc>
            break;
        case CCIT_Label:
            break;
        case CCIT_Panel:
            break;
        case CCIT_Button:
            break;
        case CCIT_Radio:
            setDataIsSelectedNonScript(StringManager::getInstance()->getBoolValue(data));
            break;
        case CCIT_Check:
            setDataIsSelectedNonScript(StringManager::getInstance()->getBoolValue(data));
            break;
        case CCIT_InputBox:
            break;
        case CCIT_TextFlow:
            break;
        case CCIT_Para:
            break;
        case CCIT_FlowElement:
            break;
        case CCIT_Progress: {
            auto pComp = (Progress*)getComponentByClass(NT_Progress);
            if (pComp) {
                string str;
                util::str2str(data, str);
                pComp->setMaxValue(util::atof_s(str));
            }
        } break;
        case CCIT_TimeBlock: {
            auto pComp = (TimeContent*)getComponentByClass(NT_TimeContent);
            if (pComp) {
                string str;
                util::str2str(data, str);
                pComp->setCurTime(util::aton_s(str, 10) * 1000);
            }
        } break;
        case CCIT_Grid:
            break;
        case CCIT_StackPanel:
            break;
        case CCIT_WrapPanel:
            break;
        case CCIT_AutoGrid:
            break;
        case CCIT_SlicedPanel:
            break;
        case CCIT_VirtualJoystick:
            break;
        case CCIT_UIDrawModel: {  //offsetx,offsety
            auto pComp = (UIDrawModel*)getComponentByClass(NT_UIDrawModel);
            if (pComp) {
                pComp->setModelOffset(util::convert2str(data));
            }
        } break;
        case CCIT_MAX:
            break;
        default:
            break;
    }
    return 0;
}

int Control::parseCsvWordList(ArrayList<wstring>* pWordList) {
    const wstring& csvWord = pWordList->front();
    unsigned int wv = util::aton_s(csvWord, 10);
    int size = pWordList->size();
    int curIndex = 3;
    auto pTmpStr = RPM::s_rpString.createObject();
    pTmpStr->clear();
    if (wv == 0) {
        //<inc>parseCsvWordOld
    } else {
        static wstring value1;
        value1.clear();
        if (wv & (1 << CAT_Text)) {
            if (curIndex < size) {
                if (getBasicContent()) {
                    setText((*pWordList)[curIndex]);
                }
                curIndex++;
            }
        }
        if (wv & (1 << CAT_Skin)) {
            if (curIndex < size) {
                util::str2str((*pWordList)[curIndex], *pTmpStr);
                if (getBasicContent()) {
                    setSkinName(*pTmpStr);
                }
                pTmpStr->clear();
                curIndex++;
            }
        }
        if (wv & (1 << CAT_Visible)) {
            if (curIndex < size) {
                setDataIsVisible(StringManager::getInstance()->getBoolValue((*pWordList)[curIndex]));
                curIndex++;
            }
        }
        if (wv & (1 << CAT_IsEnable)) {
            if (curIndex < size) {
                setDataIsEnable(StringManager::getInstance()->getBoolValue((*pWordList)[curIndex]));
                curIndex++;
            }
        }
        if (wv & (1 << CAT_Id)) {
            if (curIndex < size) {
                util::str2str((*pWordList)[curIndex], *pTmpStr);
                setId(*pTmpStr);
                pTmpStr->clear();
                curIndex++;
            }
        } 
        if (wv & (1 << CAT_Value1)) {
            if (curIndex < size) {
                value1 = (*pWordList)[curIndex];
                curIndex++;
            }
        }
        if (wv & (1 << CAT_Value2)) {
            if (curIndex < size) {
                parseCsvValue2((*pWordList)[curIndex]);
                curIndex++;
            }
        }
        if (wv & (1 << CAT_CsvData)) {
            if (curIndex < size) {
                //<inc>
                setDataCsvData((*pWordList)[curIndex]);
                curIndex++;
            }
        }
        if (wv & (1 << CAT_Blink)) {
            if (curIndex < size) {
                setDataIsBlink(StringManager::getInstance()->getBoolValue((*pWordList)[curIndex]));
                curIndex++;
            }
        }
        if (wv & (1 << CAT_Command)) {
            if (curIndex < size) {
                parseCommand((*pWordList)[curIndex]);
                curIndex++;
            }
        }
        if (wv & (1 << CAT_BindId)) {
            if (curIndex < size) {
                if (getDataCcit() == ssui::CCIT_Radio) {
                    string str = "";
                    StringManager::wstringToString((*pWordList)[curIndex], str);
                    setSelectBindingControlId(str);
                }
                curIndex++;
            }
        }
        if (!value1.empty()) {
            parseCsvValue1(value1);
        }
        if (getDataCsvData() != StringManager::getInstance()->mc_wstrNullDef) {
            parseDataCSvData(getDataCsvData());
        }
    }
    RPM_Release(pTmpStr, String);
    return 0;
}

void Control::parseDataCSvData(const wstring& value) {
    if (value.length() > 0) {
        if (value != "null") {
            wstring head = "";
            util::substrfast(value, head, 0, 3);
            if (head == "run") {//���нű� run@script@argString    UIDraw��run@UIDraw_onClick@cloth:isplayer:sex:weapontype
                ArrayList<wstring> sts;
                util::split(value, '@', sts);
                if (sts.size() > 1) {
                    string script = "";
                    util::str2str(sts[1], script);
                    ArrayList<BoloVar> args;
                    //args.push_back(BoloVar(id));
                    if (sts.size() > 2) {
                        for (int i = sts.size() - 1; i >= 2; i--) {
                            args.push_back(BoloVar(sts[i]));
                        }
                    }
                    args.push_back(BoloVar(this, false));
                    UIManager::loadScriptInner(script, args);
                }
            }
        }
    }
}

void Control::parseCommand(const wstring& value) {
    if (value.length() > 0) {
        if (value != "null") {
            setDataCommand(value);
            if (value.length() > 2) {
                wstring head = "";
                util::substrfast(value, head, 0, 3);
                if (head == "pop") {//���ÿؼ��¼� ����ÿؼ��󵯳���ʾ�� ��Ϊok��ť����������������� pop%des%cmd%okText%cancelText
                    setControlScript(ET_Click, "showSerMessage");
                } else if (head == "csp") {//���ÿؼ�����¼� csp@script@argString 
                    ArrayList<wstring> sts;
                    util::split(value, '@', sts);
                    if (sts.size() > 1) {
                        wstring scriptInfo = "";
                        //string script = "";
                        for (int i = 1; i < sts.size(); i++) {
                            scriptInfo += sts[i];
                            if (i < sts.size() - 1) {
                                scriptInfo += ' ';
                            }
                        }
                        //util::str2str(scriptInfo, script);
                        setControlScript(ET_Click, scriptInfo);
                    }
                } else if (head == "snd") {//���ÿؼ�����¼�ΪsendCmd ͬʱ��ֵcmd snd@cmd
                    ArrayList<wstring> sts;
                    util::split(value, '@', sts);
                    if (sts.size() > 1) {
                        setControlScript(ET_Click, "sendCmdCtrl");
                        setDataCommand(sts[1]);
                    }
                } else if (head == "sel") {//���ÿؼ�onSelect�¼�ΪsendCmd ͬʱ��ֵcmd sel@cmd
                    ArrayList<wstring> sts;
                    util::split(value, '@', sts);
                    if (sts.size() > 1) {
                        setControlScript(ET_Select, "sendCmdCtrl");
                        setDataCommand(sts[1]);
                    }
                } else if (head == "exe") {//ִ�нű� exe@eventType        //
                    ArrayList<wstring> sts;
                    util::split(value, '@', sts);
                    if (sts.size() > 1) {
                        EventType_e eventType = (EventType_e)util::atoi_s(sts[1]);
                        onEvent(SSUIEvent::createSSUIEvent(eventType));
                        // 						if (getCanOneventList().where(eventType.hashCode()) != -1) {
                        //							bb->event(eventType);
                        //						}
                    }
                } else if (head == "run") {//���нű� run@script@argString
                    ArrayList<wstring> sts;
                    util::split(value, '@', sts);
                    if (sts.size() > 1) {
                        string script = "";
                        util::str2str(sts[1], script);
                        ArrayList<BoloVar> args;
                        //args.push_back(BoloVar(id));
                        if (sts.size() > 2) {
                            for (int i = sts.size() - 1; i >= 2; i--) {
                                args.push_back(BoloVar(sts[i]));
                            }
                        }
                        args.push_back(BoloVar(this, false));
                        UIManager::loadScriptInner(script, args);
                    }
                } else if (head == "scs") {//���ÿؼ��¼� scs@eventType@script@argString
                    ArrayList<wstring> sts;
                    util::split(value, '@', sts);
                    if (sts.size() > 2) {
                        EventType_e eventType = (EventType_e)util::atoi_s(sts[1]);
                        wstring script_wstr = "";
                        //string script = "";
                        for (int i = 2; i < sts.size(); i++) {
                            script_wstr += sts[i];
                            if (i < sts.size() - 1) {
                                script_wstr += " ";
                            }
                        }
                        //util::str2str(script_wstr, script);
                        setControlScript(eventType, script_wstr);
                        //setControlScript(bb, eventType, script, argString);
                    }
                } else if (head == "tab") {//���ÿؼ��¼� tab@cmd0&cmd1&cmd2....
                    ArrayList<wstring> sts;
                    util::split(value, '@', sts);
                    if (sts.size() > 1) {
                        string eventType;
                        util::str2str(sts[0], eventType);
                        setDataCommand(sts[1]);
                        //setControlScript(EventType_e::EVENT_VALUE_CHANGE, "tabChangeCmd", "");
                    }
                } else if (head == "tau") {//���ÿؼ��¼� tau@cmdString
                    ArrayList<wstring> sts;
                    util::split(value, '@', sts);
                    if (sts.size() > 1) {
                        string eventType;
                        util::str2str(sts[0], eventType);
                        setDataCommand(sts[1]);
                        // 						if (bb->getTypeHashcode() == BoloUIBase::XML_HASHCODE_NAME_TABPANEL) {
                        // 							BoloUITabPanel* tb = static_cast<BoloUITabPanel*> (bb);
                        // 							tb->setFlag_beginOnceevent(true);
                        // 						}
                        // 						setControlScript(bb, BoloEvent::EVENT_VALUE_CHANGE_ONCE, "tabChangeCmd", "");
                    }
                }
            }
        } else {
            setDataCommand("");
        }
    }
}

bool ssui::Control::isIn(ft x, ft y) const {
    return isIn(x, y, ParentAreaType_e::PAT_self);
}

bool ssui::Control::isIn(ft x, ft y, ParentAreaType_e pat) const {
    return getMeasure(pat).m_pTransGeo ? getMeasure(pat).m_pTransGeo->isIn(x, y) : false;
}

void ssui::Control::refreshSsueControls(ft x, ft y) {
    if (this->isIn(x, y)) {
        #ifdef _WIN32
        UIManager::getInstance()->m_pArrSsueControl.push_back((Control*)this);
#endif
        if (UIManager::getInstance()->m_isAllLine == true) {
            for (auto& pComp : *this) {
                for (auto& pChild : *pComp) {
                    pChild->refreshSsueControls(x, y);
                }
            }
        } else {
            for (auto& pChild : children()) {
                pChild->refreshSsueControls(x, y);
            }
        }
    }
}

void ssui::Control::appendOutline(Poly& poly) const {
    if (getSelfMeasure().m_pTransGeo) {
        getSelfMeasure().m_pTransGeo->appendOutline(poly);
    } else {
        GeometryManager::getPolyFromBorder(poly, getSelfMeasure().m_srcArea);
    }
}

void ssui::Control::appendOutlineForeach(ArrayList<Poly>& arrPoly) const {
    arrPoly.push_back(Poly());
    appendOutline(arrPoly.back());
    if (UIManager::getInstance()->m_isAllLine) {
        for (auto& pComp : *this) {
            for (auto& pChild : *pComp) {
                pChild->appendOutlineForeach(arrPoly);
            }
        }
    } else {
        if (m_pChildrenComponent == nullptr) {
            return;
        }
        for (auto& pChild : *m_pChildrenComponent) {
            pChild->appendOutlineForeach(arrPoly);
        }
    }
}

void ssui::Control::getOutline(Poly& poly) const {
    if (getSelfMeasure().m_pTransGeo) {
        getSelfMeasure().m_pTransGeo->appendOutline(poly);
    } else {
        GeometryManager::getPolyFromBorder(poly, getSelfMeasure().m_srcArea);
    }
}

void ssui::Control::getCenter(ft& cx, ft& cy) {
    if (measure().m_pTransGeo) {
        measure().m_pTransGeo->getCenter(cx, cy);
    } else {
        //assert(false);
        LogPrintf("[SSUI]Control getCenter error.", 1);
    }
}

#pragma endregion

void ssui::Control::debugString(string& outString) {
    string ccitName;
    DataManager::getInstance()->getCcitName(ccitName, mt_dataCcit);
//     auto pParent = getParent();
//     if (pParent == nullptr) {
//         outString.append("\n==============ROOT===============");
//     }
    outString.append("\n[Control]");
    outString.append(ccitName);
    outString.append("\t");
    if (mt_pId) {
        outString.append(*mt_pId);
    }
//     if (m_pOuterMeasure != nullptr) {
//         outString.append("\n<outMeasure>");
//         m_pOuterMeasure->debugString(outString);
//     }
//     outString.append("\n<selfMeasure>");
//     measure().debugString(outString);
//     if (m_pInnerMeasure != nullptr) {
//         outString.append("\n<innerMeasure>");
//         m_pInnerMeasure->debugString(outString);
//     }
}

void ssui::Control::treeString(string& outString, int step) {
    string ccitName;
    DataManager::getInstance()->getCcitName(ccitName, mt_dataCcit);
    outString.append('\n');
    for (int i = 0; i < step; i++) {
        outString.append('\t');
    }
    outString.append('<');
    outString.append(ccitName);
    outString.append(">");
    if (getId().empty() == false) {
        outString.append('\t');
        outString.append(getId());
        outString.append('\t');
        outString.append(util::i64toa_c8s((s64)this));
        outString.append('\t');
        if (getId().empty() == false && getScene()) {
            outString.append('\t');
            outString.append(util::i64toa_c8s((s64)getScene()->getControlWithId(getId())));
        }
    }
    step++;
    for (auto& pComp : m_components) {
        pComp->treeString(outString, step);
    }
}