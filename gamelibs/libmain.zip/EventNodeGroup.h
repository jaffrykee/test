#pragma once
#include "ObjectBase.h"
#include "EventNodeBase.h"
#include "ResPool.h"
#include "ResPoolManager.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class EventNodeGroup : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(EventNodeGroup);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
        for (auto& pairEventList : m_mapEvent) {
            if (pairEventList.second != nullptr) {
                releaseEventList(pairEventList.second);
            }
        }
        m_mapEvent.clear();
    }
    NODETYPE_COMMON_PART_DECLARATION_END(EventNodeGroup, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
    static void releaseEventList(ArrayList<EventNodeBase*>* pSelf) {
        if (pSelf != nullptr) {
            for (auto& pEvent : *pSelf) {
                pEvent->releaseObject();
            }
            pSelf->clear();
        }
    }
#pragma endregion

#pragma region "��Ա"
public:
    //Event::EventType_e
    HashMap<int, ArrayList<EventNodeBase*>*> m_mapEvent;
#pragma endregion

#pragma region "����"
public:
    inline Self& assign(const Self& other) {
        Base::assign(other);
        m_mapEvent.clear();
        for (auto& pairEventList : other.m_mapEvent) {
            for (auto& eventList : *pairEventList.second) {
                addEventNode((EventNodeBase*)(eventList)->createCopy());
            }
        }
        return *this;
    }
public:
    inline void addEventNode(EventNodeBase* pEventNode) {
        if (pEventNode == nullptr || pEventNode->getEventType() >= ET_MAX || pEventNode->getEventType() < 0) {
            return;
        }
        auto pairEvent = m_mapEvent.find(pEventNode->getEventType());
        if (pairEvent != m_mapEvent.end()) {
            pairEvent->second->push_back(pEventNode);
        } else {
            m_mapEvent.insert(pEventNode->getEventType(), RPM::s_rpEventNode.createObject())->second->push_back(pEventNode);
        }
    }

    inline void eraseEventNodeByEventType(EventType_e type) {
        auto pairEvent = m_mapEvent.find(type);
        if (pairEvent != m_mapEvent.end()) {
            auto eventList = pairEvent->second;
            for (int i = 0; i < (*eventList).size();) {
                eraseEventNode((*eventList)[i]);
            }
        }
    }
    inline void eraseEventNode(EventNodeBase* pEventNode) {
        if (pEventNode == nullptr) {
            return;
        }
        auto pairEvent = m_mapEvent.find(pEventNode->getEventType());
        if (pairEvent != m_mapEvent.end()) {
            auto index = pairEvent->second->where(pEventNode);
            if (index >= 0) {
                pairEvent->second->erase(pairEvent->second->begin() + index);
                if (pairEvent->second->empty()) {
                    RPM::s_rpEventNode.releaseObject(pairEvent->second, releaseEventList);
                    m_mapEvent.erase(pairEvent);
                }
            }
        }
    }
    inline void triggerEventNode(const SSUIEvent& event, ObjectBase* pObj) {
        if (event.m_blockScript) {
            return;
        }
        auto pairEvent = m_mapEvent.find(event.m_type);
        if (pairEvent != m_mapEvent.end()) {
            for (const auto& pEventNode : *pairEvent->second) {
                pEventNode->onEventTrigger(pObj);
            }
        }
    }
    void setScript(const string& type, const wstring& scriptStr, bool isClear = true);
#pragma endregion
};

_SSUINamespaceEnd
