#pragma once
#include "EventTrigger.h"
#include "UIManager.h"
//#include "Bolo.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class EventScript : public EventTrigger {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(EventScript);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(EventScript, EventTrigger);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    ArrayList<wstring> mt_scriptArgs;
    string mt_sound;
#pragma endregion

#pragma region "����"
public:
    inline const wstring& getScriptData() const {
        return mt_scriptArgs.empty() ? StringManager::getInstance()->mc_wstrNullDef : mt_scriptArgs[0];
    }
    inline void setScriptData(const wstring& value) {
        mt_scriptArgs.clear();
        util::split(value, ' ', mt_scriptArgs);
    }
    inline const string& getSound() const {
        return mt_sound;
    }
    inline void setSound(const string& value) {
        mt_sound = value;
    }
public:
    inline EventScript& assign(const EventScript& other) {
        Base::assign(other);
        mt_scriptArgs.clear();
        for (auto& str : other.mt_scriptArgs) {
            mt_scriptArgs.push_back(str);
        }
        return *this;
    }
    virtual void onTrigger(ObjectBase* pObj) override;
#pragma endregion
};

_SSUINamespaceEnd
