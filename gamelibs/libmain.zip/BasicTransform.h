#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class BasicTransform : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(BasicTransform);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(BasicTransform, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    f32 mt_alpha = 1;
    s32 mt_radian = 0;
    s32 mt_scaleX = 100;
    s32 mt_scaleY = 100;
    s32 mt_offsetX = 0;
    s32 mt_offsetY = 0;
    b2 mt_upSideDown = false;
    b2 mt_mirror = false;
    bool m_isSetting = false;

#pragma endregion

#pragma region "����"
private:
    void applyTransform(Control* control, s32 offsetX, s32 offsetY, s32 scaleX, s32 scaleY, s32 radian, f32 alpha);

public:
    float getAlpha() const;
    void setAlpha(float value);
    b2 getUpSideDown() const;
    void setUpSideDown(b2 value);
    b2 getMirror() const;
    void setMirror(b2 value);

    s32 getRadian() const;
    void setRadian(s32 value);
    s32 getScaleX() const;
    void setScaleX(s32 value);
    s32 getScaleY() const;
    void setScaleY(s32 value);
    s32 getOffsetX() const;
    void setOffsetX(s32 value);
    s32 getOffsetY() const;
    void setOffsetY(s32 value);

public:
    BasicTransform& assign(const BasicTransform& other);
    virtual void onRender(unsigned char drawStep) override;
    virtual void onTransform(unsigned char drawStep) override;
    virtual void applyTransformToPosterity(Control* pPosterity) override;

#pragma endregion
};

_SSUINamespaceEnd
