#pragma once
#include "ssuiBasic.h"
#include "BoloScriptManager.h"
#include "BoloObject.h"
#include "Controller.h"
#include "StringManager.h"
#include "Bolo.h"
#include "ResLoader.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class UIScene;
class InputBox;
class ObjectBase;
class Control;
class Timer;
//һ��������
class UIManager : public BoloObject {
public:
    static string s_className;
    static UIManager* s_pInstance;
#ifdef _WIN32
    static HWND s_hUe;
#endif
public:
    static string script_modName;
    static string script_sourcePath;
public:
    inline static UIManager* getInstance() {
        if (s_pInstance == nullptr) {
            s_pInstance = new UIManager();
        }
        return s_pInstance;
    }
    static void initialize();
    static void destroy();
    static void registerReflection(int id);

    static void loadScriptInner(const string& name, const ArrayList<BoloVar>& args, bool inMod = ResLoader::isResInMod());
    static void setScriptModName(const string& mod);//����ʹ�õİ��� - ʹ�ô����Դʱ����
    static void setScriptSourcePath(const string& path);//���ñ���ԭʼ��Դ·�� - ʹ��ԭʼ��Դʱ����
public:
    static wstring default_canNotInputWstr;     //0157514: �ͻ��˴������������ĸ��ֿ��ܵĻ����ַ����������ַ���
    static ArrayList<wstring> arr_canNotInputWstr;     //����ʱ������\r\n�Ϳͻ����Զ���Ļ���[`]  0157514
    static void initCanNotInputWstrList();
    static void setDefaultCanNotInputWstr(const wstring& str);
    static void initCanNotInputWstring(const wstring& str);
public:  //�ı������滻
    static const s32 RICHTEXT_FACE_MAX;
    static LinkedHashMap<wstring, wstring> s_replaceString[3];
    static void initReplaceString();
public:
    void setUISceneEnableMode(E_UI_Scene_Enable_Mode mode);
    void changeUISceneEnableWhiteList(const string& uiname, b2 isAdd);
    void changeUISceneEnableBlackList(const string& uiname, b2 isAdd);
    void clearUISceneEnableWhiteList();
    void clearUISceneEnableBlackList();
    E_UI_Scene_Enable_Mode getUISceneEnableMode();
    ArrayList<string>& getEnableWhiteList();
    ArrayList<string>& getEnableBlackList();
public:
    E_UI_Scene_Enable_Mode UI_Scene_Enable_Mode = E_UI_Scene_Enable_All;
    ArrayList<string> enableWhiteList;
    ArrayList<string> enableBlackList;
#pragma region "��Ա"
private:
    ft m_fontDefaultLineHeight = 1.3f;
    HashMap<int, ft> m_mapFontLineHeight;
public:
    InputBox* m_pCurInputBox = nullptr;
    HashMap<s64, __ptr> m_mapSsueIdNode;
    HashMap<__ptr, s64> m_mapSsueNodeId;
    bool m_isTextSnapToPixel = true;
    bool m_isImageSnapToPixel = true;
    bool m_isShowOutLine = true;
    bool m_isShowBorder = false;
    Color m_ssueColor = Color(0.f, 0.f, 1.f, 0.5f);
    HashMap<strHash, HashMap<strHash, string>> m_mapUserAttrTriggerData;
    int m_settingScreenX;
    int m_settingScreenY;
    int m_settingScreenVx = 0.f;
    int m_settingScreenVy = 0.f;
    ft m_screenScaleX = 1.f;
    ft m_screenScaleY = 1.f;
#ifdef _WIN32
    Control* m_pCurSsueControl = nullptr;
    ArrayList<Control*> m_pArrSsueControl;
#endif // _WIN32
    bool m_isAllLine = false;
    bool m_openDrawDebug = false;
    string m_curUeLanguage;
#pragma endregion

#pragma region "��Ա����"
public:
    UIManager();
    inline virtual ~UIManager() {

    }
    inline virtual const string& getClassName() const override {
        return UIManager::s_className;
    }
    bool isUeMode() const;
    void update();
    UIScene* loadUI(const string& name, bool isFindFromUpdate = false);
    UIScene* loadUI(const wstring& name, bool isFindFromUpdate = false);
    void loadXmlConfig();
    void closeUI(const string& name);
    void closeUI(const wstring& name);
    void closeAllUI();
    void regUserAttr(const string& className, const string& attrName);
    inline const string& getUserAttrTriggerName(const string& className, const string& attrName) {
        const auto& pairClassData = m_mapUserAttrTriggerData.find(className.hashCode());
        if (pairClassData != m_mapUserAttrTriggerData.end()) {
            const auto& pairTriggerData = pairClassData->second.find(attrName.hashCode());
            if (pairTriggerData != pairClassData->second.end()) {
                return pairTriggerData->second;
            }
        }
        return StringManager::getInstance()->mc_strNullDef;
    }

    UIScene* getUI(const string& uiName);
    bool existUI(const string& name);
    Control* getControl(const string& uiName, const string& ctrlName);
    void setUIVisible(const string& uiName, bool isVis);
    void setAllUIVisible(b2 isVis);
    b2 getUIVisible(const string& uiName);
    void checkAllUIWithWar(const string& uiName);
    void drawImage(const Texture& tex, const vec4& rect, const vec4& clipRect, const Color & color);
public:
    struct  JoyStickInfo {
        s32 joystickId = -1;
        ft angle = -1;
        ft strength = 0;
        JoyStickInfo(s32 id, ft ang, ft str) :joystickId(id), angle(ang), strength(str) {}
        void setJoyStickInfo(ft ang, ft str) {
            angle = ang;
            strength = str;
        }
        ft getJoyStickAngle() {
            return angle;
        }
        ft getJoyStickStrength() {
            return strength;
        }
    };
    static HashMap<int, JoyStickInfo*> m_mapJoyStickInfo;
    static void addJoyStickInfo(s32 joystickId, ft angle, ft strength);
    static void clearJoyStickInfo();
    static ft getJoyStickAngleById(s32 joystickId);
    static ft getJoyStickStrengthById(s32 joystickId);
private:
    void resize(int w, int h);
public:
    inline ft getFontLineHeightRatio(int font) const {
        if (m_mapFontLineHeight.empty()) {
            return m_fontDefaultLineHeight;
        }
        const auto& pairFontLineHeight = m_mapFontLineHeight.find(font);
        if (pairFontLineHeight != m_mapFontLineHeight.end()) {
            return pairFontLineHeight->second;
        } else {
            return m_fontDefaultLineHeight;
        }
    }
    void dealCommand(const InputEvent& input);
    void setViewSize(const vec2i& size, const vec2i& vsize);
    
    s64 getSsueNodeId(const ObjectBase* pNode) const;
    ObjectBase* getSsueNode(s64 id) const;
    void insertSsueNode(s64 id, ObjectBase* pNode);
    void deleteSsueNode(ObjectBase* pNode);
    int setAttrValueBySsueId(s64 id, const wstring& attrName, const wstring& attrValue);
    int loadCsvData(const wstring& csvData);
#ifdef _WIN32
    static void sendUiCommand(int tag, const wstring& message);
    static void sendNodeAttrData();
    void toNextSsueControl();
    void selectCurSsueControl(ft x, ft y);
    void selectCurSsueControl(const wstring& ssueId);
    void showBorder(const wstring& value);
#endif // _WIN32
    void disposeFunc(ObjectBase* pSelf);

public:
    void outScreen(int lv = 1) const;
#pragma endregion
};

_SSUINamespaceEnd
