#include "ElementSetting.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(ElementSetting, 50, 200);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(ElementSetting)
NODETYPE_COMMON_PART_DEFINITION_END

wstring ElementSetting::s_tmpAttrName;
wstring ElementSetting::s_tmpAttrValue;

ssui::ElementSetting* ssui::ElementSetting::createObject(NameSpaceSetting* pNameSpace, const wstring& name, NodeType_e objType, CCIT_e ccit /*= CCIT_NULL*/) {
    auto pSelf = createObject();
    pSelf->m_name = name;
    pSelf->m_objType = objType;
    pSelf->initAttrClass(objType);
    if (ccit >= 0) {
        for (auto compNodeType : DataManager::getInstance()->m_ccitData[ccit].m_data) {
            pSelf->initAttrClass(compNodeType);
        }
    }
    pNameSpace->addElementSetting(pSelf);
    pSelf->m_pParent = pNameSpace;
    return pSelf;
}

void ssui::ElementSetting::addChild(const wstring& childName) {
    if (m_pParent != nullptr) {
        const auto& pairChild = m_pParent->m_lmapElementSetting.find(childName.hashCode());
        if (pairChild != m_pParent->m_lmapElementSetting.end()) {
            addChild(pairChild->second);
        }
    }
}

void ssui::ElementSetting::initAttrClass(NodeType_e nt) {
    m_lhsAttrClass.insert(nt);
    if (nt != NT_ObjectBase) {
        initAttrClass(ObjectBase::getBaseType(nt));
    }
}

DataInfoNode* ElementSetting::parseXml(XmlParser& parser) {
    wstring nodeName;
    parser.getName(nodeName);
    auto pNode = DataInfoNode::createObject(m_pParent->m_name, nodeName);
    for (int i = 0; i < parser.getAttributeCount(); i++) {
        if (parser.getAttributeName(i, s_tmpAttrName) != nullptr && parser.getAttributeValue(i, s_tmpAttrValue) != nullptr) {
            for (auto acnt : m_lhsAttrClass) {
                const auto& lmapAs = DataManager::getInstance()->m_arrNodeTypeSetting[acnt]->m_lmapAttrSetting;
                const auto& pairAs = lmapAs.find(s_tmpAttrName);
                if (pairAs != lmapAs.end()) {
                    pNode->addAttr(DataInfoAttr::createObject(pairAs->second->m_attrType, s_tmpAttrValue));
                    break;
                }
            }
            //���������Ի��Ԥ�����ԣ�ChildItem����
            const auto& mapAs = DataManager::getInstance()->m_mapAttrSetting;
            const auto& pairAs = mapAs.find(s_tmpAttrName.hashCode());
            if (pairAs != mapAs.end()) {
                pNode->addAttr(DataInfoAttr::createObject(pairAs->second->m_attrType, s_tmpAttrValue));
            }
        }
    }
    parser.require(START_TAG, StringManager::getInstance()->mc_wstrNullDef, m_name);
    int depth = parser.getDepth();
    for (; true;) {
        parser.next();
        parser.getName(nodeName);
        if (parser.getEventType() == START_TAG) {
            const auto& pairNode = m_lmapChildNode.find(nodeName.hashCode());
            if (pairNode != m_lmapChildNode.end()) {
                pNode->addNode(pairNode->second->parseXml(parser));
            }
            parser.require(END_TAG, StringManager::getInstance()->mc_wstrNullDef, nodeName);
        } else if (parser.getEventType() == END_TAG) {
            if (depth == parser.getDepth() && nodeName == m_name) {
                break;
            }
        } else if (parser.getEventType() == END_DOCUMENT) {
            break;
        }
    }
    //parser.toEndTag(nodeName);
    return pNode;
}

const gstl::wstring& ssui::ElementSetting::getAttrTypeWstringFromCode(int code) {
    int nodeType = code >> 16;
    int attrType = code & 0xffff;
    if (nodeType == 0) {
        return DataManager::getInstance()->m_arrAttrSetting[attrType]->m_attrName;
    } else {
        auto pairAttr = StringManager::getInstance()->m_mapAttrSetting.find(code);
        if (pairAttr != StringManager::getInstance()->m_mapAttrSetting.end()) {
            return pairAttr->second;
        } else {
            return StringManager::getInstance()->m_mapAttrSetting.insert(code, DataManager::getInstance()->m_arrNodeTypeSetting[nodeType]->m_name + wstring(".") +
                DataManager::getInstance()->m_arrAttrSetting[attrType]->m_attrName)->second;
        }
    }
    return StringManager::getInstance()->mc_wstrNullDef;
}

