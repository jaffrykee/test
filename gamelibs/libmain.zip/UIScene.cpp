#include "UIScene.h"
#include "NodeHeaders.h"
#include "EventNodeGroup.h"
#include "DataHeaders.h"
#include "ObjectAttrDef.hpp"

ArrayList<UIScene*> UIScene::s_arrScene;
HashMap<wstring, wstring> UIScene::memory;
HashMap<wstring, wstring> UIScene::auctionMemory;
string UIScene::Public_loaded_script = "Public_loaded_script";
string UIScene::Public_closed_script = "Public_closed_script";
int UIScene::LogPriority = 4;
bool UIScene::logCSV = true;
bool ssui::UIScene::s_isParsing = false;

UIScene* UIScene::s_curUIScene = nullptr;
b2 UIScene::isChangeCurScene = false;

ssui::Control* ssui::UIScene::getControlWithIdW(const wstring& id) {
    auto pTmpId = RPM::s_rpString.createObject();
    pTmpId->clear();
    util::str2str(id, *pTmpId);
    auto pCtrl = getControlWithId(*pTmpId);
    RPM::s_rpString.releaseObject(pTmpId);
    return pCtrl;
}

Control* UIScene::copyAndAddToWithId(const string& id, const string& copyID, const string& parentID) {
    auto bub = getControlWithId(copyID);
    auto p = getControlWithId(parentID);
    return copyAndAddToFunc(id, bub, p, this);
}

Control* UIScene::copyAndAddToFunc(const string& nId,Control* copyAim, Control* addToParent, UIScene* addToScene, bool isCheckId) {
    Control* exist = addToScene->getControlWithId(nId);
    if (exist && isCheckId) {
        string s = "copyAndAddToFunc id = <";
        s += nId;
        s += "> is already exist!--------";
        LOG(s, LogPriority);
        return nullptr;
    }
    if (copyAim && addToParent && addToParent->children().empty() == false) {
        //copyAim->printData(PDT_Tree);
        auto cb = (Control*)copyAim->createCopy();
        cb->setId(nId);
        cb->setIsCopyAdd(true);
        cb->setsourceID(copyAim->getId());
        addToParent->addChild(cb);
        addToScene->updateCopyID(cb);
        //cb->printData(PDT_Tree);
        return cb;
    }
    return nullptr;
}
void UIScene::updateCopyID(Control* pCtrl) {
    if (pCtrl == nullptr || pCtrl->children().empty())
        return;
    for (auto& pChild : pCtrl->children()) {
        updateCopyControlID(pChild, pCtrl->getId());
    }
}
void UIScene::updateCopyControlID(Control* pCtrl, const string& copyid) {
    if (pCtrl == nullptr) {
        return;
    }
    string id = pCtrl->getId();
    id += "_";
    id += copyid;
    pCtrl->setId(id);
    if (pCtrl->children().empty()) {
        return;
    }
    for (auto& pChild : pCtrl->children()) {
        updateCopyControlID(pChild, copyid);
    }
}

BoloVar bolo_ui_getControlWithID(bolo_stack stack, void* self) {
    if (self) {
        return bolo_create(stack, ((UIScene*)self)->getControlWithId(bolo_string(stack)), false);
    } else {
        return bolo_create(stack, nullptr, false);
    }
}
BoloVar bolo_ui_copyAndAddToWithID(bolo_stack stack, void* self) {
    string id = bolo_string(stack);
    string copyID = bolo_string(stack);
    string parentID = bolo_string(stack);
    Control* ctrl = nullptr;
    if (self) {
        ctrl = ((UIScene*)self)->copyAndAddToWithId(id, copyID, parentID);
    }
    return bolo_create(stack, ctrl, false);
}

BoloVar bolo_ui_deleteControlWithID(bolo_stack stack, void* self) {
    string id = bolo_string(stack);
    if (self) {
        Control* ctrl = ((UIScene*)self)->getControlWithId(id);
        if (ctrl && ctrl->getParent()) {
            ctrl->getParent()->deleteChild(ctrl);
        } else {
            string st;
            util::str2str(id, st);
            LogPrintf("ui <baseID = %s>not found!\n", UIScene::LogPriority, st.c_str());
        }
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_deleteAddControlWithID(bolo_stack stack, void* self) {
    string id = bolo_string(stack);
    if (self) {
        Control* ctrl = ((UIScene*)self)->getControlWithId(id);
        if (ctrl && ctrl->getParent()) {
            ctrl->getParent()->deleteAddChild(ctrl);
        } else {
            string st;
            util::str2str(id, st);
            LogPrintf("ui <baseID = %s>not found!\n", UIScene::LogPriority, st.c_str());
        }
    }
    return bolo_create(stack);
}
//deleteAddChildWithID
BoloVar bolo_ui_deleteAddChildWithID(bolo_stack stack, void* self) {
    string sourceID = bolo_string(stack);
    string id = bolo_string(stack);
    if (self) {
        Control* ctrl = ((UIScene*)self)->getControlWithId(id);
        if (ctrl) {
            ctrl->deleteAddChildWithID(sourceID);
        } else {
            string st;
            util::str2str(id, st);
            LogPrintf("ui <baseID = %s>not found!\n", UIScene::LogPriority, st.c_str());
        }
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_clearAddControlWithID(bolo_stack stack, void* self) {
    string id = bolo_string(stack);
    if (self) {
        Control* ctrl = ((UIScene*)self)->getControlWithId(id);
        if (ctrl) {
            ctrl->deleteAllAddChild();
        } else {
            string st;
            util::str2str(id, st);
            LogPrintf("ui <baseID = %s>not found!\n", UIScene::LogPriority, st.c_str());
        }
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_setControlScriptWithID(bolo_stack stack, void* self) {
    string id = bolo_string(stack);
    string type = bolo_string(stack);
    wstring scriptStr = bolo_wstring(stack);   //�ű��� ����
    if (self) {
        Control* ctrl = ((UIScene*)self)->getControlWithId(id);
        if (ctrl) {
            ctrl->setControlScript(type, scriptStr);
        } else {
            string st;
            util::str2str(id, st);
            LogPrintf("ui <baseID = %s>not found!\n", UIScene::LogPriority, st.c_str());
        }
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_setControlScriptWithID_notClear(bolo_stack stack, void* self) {
    string id = bolo_string(stack);
    string type = bolo_string(stack);
    wstring scriptStr = bolo_wstring(stack);   //�ű��� ����
    if (self) {
        Control* ctrl = ((UIScene*)self)->getControlWithId(id);
        if (ctrl) {
            ctrl->setControlScript(type, scriptStr, false);
        } else {
            string st;
            util::str2str(id, st);
            LogPrintf("ui <baseID = %s>not found!\n", UIScene::LogPriority, st.c_str());
        }
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_setControlAttrWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string id = bolo_string(stack);
    wstring attr = bolo_wstring(stack);
    wstring value = bolo_wstring(stack);
    Control* bub = bus->getControlWithId(id);
    if (bub) {
        bub->setAttrValue(attr, value);
    } else {
        string st;
        util::str2str(id, st);
        LogPrintf("ui <baseID = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_getControlAttrWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string id = bolo_string(stack);
    wstring attr = bolo_wstring(stack);
    Control* bub = bus->getControlWithId(id);
    if (bub) {
        const auto& pairAttrRow = DataManager::getInstance()->m_mapAttrSetting.find(attr.hashCode());
        if (pairAttrRow != DataManager::getInstance()->m_mapAttrSetting.end()) {
            if (pairAttrRow->second) {
                switch (pairAttrRow->second->m_dataType) {
                    case ssui::ADT_B2:
                    {
                        b2 value = false;
                        bub->getAttrValue<bool, ADT_B2, boloClassGetFuncB2>(attr, value);
                        return bolo_create(stack, value);
                    } break;
                    case ssui::ADT_S32:
                    {
                        s32 value = 0;
                        bub->getAttrValue<int, ADT_S32, boloClassGetFuncS32>(attr, value);
                        return bolo_create(stack, value);
                    } break;
                    case ssui::ADT_U32:
                    {
                        u32 value = 0;
                        bub->getAttrValue<u32, ADT_U32, boloClassGetFuncU32>(attr, value);
                        return bolo_create(stack, (s32)value);
                    }break;
                    case ssui::ADT_F32:
                    {
                        f32 value = 0;
                        bub->getAttrValue<f32, ADT_F32, boloClassGetFuncF32>(attr, value);
                        return bolo_create(stack, value);
                    }break;
                    case ssui::ADT_S64:
                    {
                        s64 value = false;
                        bub->getAttrValue<s64, ADT_S64, boloClassGetFuncS64>(attr, value);
                        return bolo_create(stack, value);
                    }break;
                    case ssui::ADT_HU32:
                    {
                        u32 value = 0;
                        bub->getAttrValue<u32, ADT_HU32, boloClassGetFuncU32>(attr, value);
                        string strValue = util::u32toa_c8s(value, 16);
                        return bolo_create(stack, strValue);
                    }break;
                    case ssui::ADT_HS64:
                    {
                        s64 value = false;
                        bub->getAttrValue<s64, ADT_S64, boloClassGetFuncS64>(attr, value);
                        string strValue = util::i64toa_c8s(value, 16);
                        return bolo_create(stack, strValue);
                    }break;
                    case ssui::ADT_STR:
                    {
                        string value = "";
                        bub->getAttrValue<string, ADT_STR, boloClassGetFuncString>(attr, value);
                        return bolo_create(stack, value);
                    }break;
                    case ssui::ADT_WSTR:
                    {
                        wstring value = "";
                        bub->getAttrValue<wstring, ADT_WSTR, boloClassGetFuncWString>(attr, value);
                        return bolo_create(stack, value);
                    }break;
                    case ssui::ADT_MAX:
                    {
                        return bolo_create(stack, -1);
                    }break;
                    default:
                    {
                        return bolo_create(stack, -1);
                    }break;
                }
            }
        } else {
            string st, st1;
            util::str2str(id, st);
            util::str2str(attr, st1);
            LogPrintf("ui <baseID = %s,  attr = %s>not found!\n", UIScene::LogPriority, st1.c_str());
        }
    } else {
        string st;
        util::str2str(id, st);
        LogPrintf("ui <baseID = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack, -1);
}

BoloVar bolo_ui_setRadioSelectBindingControlId(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string baseID = bolo_string(stack);
    string bindingID = bolo_string(stack);

    Control* bub = bus->getControlWithId(baseID);
    if (bub && bub->getDataCcit() == ssui::CCIT_Radio){
        bub->setSelectBindingControlId(bindingID);
        //        ra->checkOtherRadioButton();
    }
    else {
        string st;
        util::str2str(baseID, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_getAddcontrolSizeWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string id = bolo_string(stack);
    Control* bub = bus->getControlWithId(id);
    if (bub) {
        return bolo_create(stack, bub->getAddControlCount());
    }
    else {
        string st;
        util::str2str(id, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack, 0);
}

BoloVar bolo_ui_getVcontrolSizeWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string id = bolo_string(stack);
    Control* bub = bus->getControlWithId(id);
    if (bub) {
        return bolo_create(stack, bub->getVControlCount());
    }
    else {
        string st;
        util::str2str(id, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack, 0);
}

BoloVar bolo_ui_getVControlWithIndexWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string id = bolo_string(stack);
    int index = bolo_int(stack);
    Control* bub = bus->getControlWithId(id);
    if (bub) {
        return bolo_create(stack, (BoloObject*)bub->getVControlWithIndex(index), false);
    }
    else {
        string st;
        util::str2str(id, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack, nullptr, false);
}

BoloVar bolo_ui_getControlWithIndexWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string id = bolo_string(stack);
    int index = bolo_int(stack);
    Control* bub = bus->getControlWithId(id);
    if (bub) {
        return bolo_create(stack, (BoloObject*)bub->getControlWithIndex(index), false);
    }
    else {
        string st;
        util::str2str(id, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack, nullptr, false);
}

BoloVar bolo_ui_getControlIndexWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string idw = bolo_string(stack);
    string idc = bolo_string(stack);
    Control* bw = bus->getControlWithId(idw);

    if (bw && bw->children().empty() == false) {
        return bolo_create(stack, bw->getControlIndexWithID(idc));
    }
    else {
        string st;
        util::str2str(idw, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack, -1);
}

BoloVar bolo_ui_getVControlIndexWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string idw = bolo_string(stack);
    string idc = bolo_string(stack);
    Control* bw = bus->getControlWithId(idw);

    if (bw && bw->children().empty() == false) {
        return bolo_create(stack, bw->getVControlIndexWithID(idc));
    }
    else {
        string st;
        util::str2str(idw, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack, -1);
}

BoloVar bolo_ui_setControlIndexWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string idw = bolo_string(stack);
    string idc = bolo_string(stack);
    int index = bolo_int(stack);
    Control* bw = bus->getControlWithId(idw);
    Control* ctrl = bus->getControlWithId(idc);

    int ok = 0;
    if (bw && bw->children().empty() == false) {
        ok = bw->setControlIndex(ctrl, index);
        return bolo_create(stack, ok);
    }
    else {
        string st;
        util::str2str(idw, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack, ok);
}

BoloVar bolo_ui_loadImportXml(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string xmlName = bolo_string(stack);
    if (bus) {
        bus->loadImportXml(xmlName);
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_deleteImportXml(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string xmlName = bolo_string(stack);
    if (bus) {
        bus->deleteImportXml(xmlName);
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_deleteAllImportXml(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    if (bus) {
        bus->deleteAllImportXml();
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_getVcontrolListWithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string id = bolo_string(stack);
    Control* bub = bus->getControlWithId(id);
    if (bub) {
        s32 size = bub->getVControlCount();
        BoloVar* arr = stack->createArray(size);
        for (s32 i = 0; i < size; i++) {
            arr[i] = bolo_create(stack, bub->getVControlWithIndex(i), false);
        }
        return bolo_create(stack, arr, size);
    } else {
        string st;
        util::str2str(id, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    BoloVar* arr = stack->createArray(0);
    return bolo_create(stack, arr, 0);
}

BoloVar bolo_ui_onDraw(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    if (bus && bus->m_pRootControl) {
        bus->m_pRootControl->onDraw(1);
        bus->m_pRootControl->touchAllChildrenDrawChanged();
    }
    return bolo_create(stack);
}

BoloVar bolo_ui_onEvent_WithID(bolo_stack stack, void* self) {
    UIScene* bus = static_cast<UIScene*> (self);
    string id = bolo_string(stack);
    string eventType = bolo_string(stack);
    Control* bub = bus->getControlWithId(id);
    if (bub) {
        const auto& pairEvent = DictionaryManager::getInstance()->m_mapEventType.find(eventType);
        if (pairEvent != DictionaryManager::getInstance()->m_mapEventType.end()) {
            bub->TriggerEvent((EventType_e)pairEvent->second, bub, nullptr);
        } 
    } else {
        string st;
        util::str2str(id, st);
        LogPrintf("ui <id = %s>not found!\n", UIScene::LogPriority, st.c_str());
    }
    return bolo_create(stack);
}

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UIScene, 10, 100)
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("canClose", DataCanClose, UIScene, B2);
NODEBASE_ATTR_REGISTER("isCloseWhenCheck", DataIsCloseWhenCheck, UIScene, B2);
NODEBASE_ATTR_REGISTER("isFloatUI", DataIsFloatUI, UIScene, B2);
NODEBASE_ATTR_REGISTER("canBeMask", DataCanBeMask, UIScene, B2);
NODEBASE_ATTR_REGISTER("canEnableMask", DataCanEnableMask, UIScene, B2);
NODEBASE_ATTR_REGISTER("canEnableMaskForce", DataCanEnableMaskForce, UIScene, B2);
NODEBASE_ATTR_REGISTER("ownEvent", DataIsOwnEvent, UIScene, B2);
NODEBASE_ATTR_REGISTER("isCanBeCurScene", DataIsCanBeCurScene, UIScene, B2);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UIScene)
registerFunc(id, "getControlWithID", bolo_ui_getControlWithID, "(Control)get control with Id()");
registerFunc(id, "copyAndAddToWithID", bolo_ui_copyAndAddToWithID, "(Control)copyAndAddToWithId(String id,String copyID,String parentID)");
registerFunc(id, "deleteControlWithID", bolo_ui_deleteControlWithID, "(void)deleteControlWithID(String controlID)"); //
registerFunc(id, "deleteAddControlWithID", bolo_ui_deleteAddControlWithID, "(void)deleteAddControlWithID(String controlID)"); //
registerFunc(id, "clearAddControlWithID", bolo_ui_clearAddControlWithID, "(void)clearAddControlWithId(String id)");
registerFunc(id, "setControlScriptWithID", bolo_ui_setControlScriptWithID, "(void)setControlScriptWithID(String baseID,String type,String scriptStr)");
registerFunc(id, "setControlScriptWithID_notClear", bolo_ui_setControlScriptWithID_notClear, "(void)setControlScriptWithID_notClear(String baseID,String type,String scriptStr)");
registerFunc(id, "deleteAddChildWithID", bolo_ui_deleteAddChildWithID, "test");

registerFunc(id, "setRadioSelectBindingControlId", bolo_ui_setRadioSelectBindingControlId, "(void)setRadioSelectBindingControlId(String baseID, String bindingID)"); //
registerFunc(id, "getAddcontrolSizeWithID", bolo_ui_getAddcontrolSizeWithID, "(int)getAddcontrolSizeWithID(String baseID)"); ////
registerFunc(id, "getVcontrolSizeWithID", bolo_ui_getVcontrolSizeWithID, "(int)getVcontrolSizeWithID(String baseID)"); ////
registerFunc(id, "getVControlWithIndexWithID", bolo_ui_getVControlWithIndexWithID, "(Control)getVControlWithIndexWithID(String baseID,s32 index)"); ////
registerFunc(id, "getControlWithIndexWithID", bolo_ui_getControlWithIndexWithID, "(Control)getControlWithIndexWithID(String baseID,s32 index)"); //
registerFunc(id, "getControlIndexWithID", bolo_ui_getControlIndexWithID, "(int)getControlIndexWithID(String pw,String baseID)");
registerFunc(id, "getVControlIndexWithID", bolo_ui_getVControlIndexWithID, "(int)getVControlIndexWithID(String pw,String baseID)");
registerFunc(id, "setControlIndexWithID", bolo_ui_setControlIndexWithID, "(b2)getControlIndexWithID(String pw,String baseID,int index)");
registerFunc(id, "setControlAttrWithID", bolo_ui_setControlAttrWithID, "(void)setControlAttrWithID(String baseID,String attr,String value)");
registerFunc(id, "getControlAttrWithID", bolo_ui_getControlAttrWithID, "(b2)getControlAttrWithID(String baseID,String attr)");

registerFunc(id, "loadImportXml", bolo_ui_loadImportXml, "(void)loadImportXml(String xmlName)");
registerFunc(id, "deleteImportXml", bolo_ui_deleteImportXml, "(void)deleteImportXml(String xmlName)");
registerFunc(id, "deleteAllImportXml", bolo_ui_deleteAllImportXml, "(void)deleteAllImportXml()");

registerFunc(id, "getVcontrolListWithID", bolo_ui_getVcontrolListWithID, "(arr)getVcontrolListWithID(String baseID)"); ////
registerFunc(id, "onDraw", bolo_ui_onDraw, "void onDraw()");
registerFunc(id, "onEvent_WithID", bolo_ui_onEvent_WithID, "(void)onEvent with baseID(String id, String eventType)");
NBSCRIPT_ATTR_REGISTER("isFloatUI", DataIsFloatUI, Control, B2);
BoloRegisterPropReadOnly("name", getName);
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::UIScene::createSelf() {

}

void UIScene::disposeSelf() {
    safe_release(m_pRootControl);
    safe_release(mt_pDataEventGroup);
}

UIScene* UIScene::createScene(const string& name, DataInfoNode& data) {
    auto pScene = UIScene::createScene(name);
    s_isParsing = true;
    pScene->setData(data);
    pScene->setOtherData();
    rankScenes(s_arrScene);
    s_isParsing = false;
    return pScene;
}

ssui::UIScene* ssui::UIScene::createScene(const string& name) {
    s_arrScene.push_back(UIScene::createObject());
    string t_fileName = name;
    if (ResLoader::isResInMod()) {
        t_fileName = util::lowcase(name);
    }
    auto pairSkinGroup = SkinGroup::s_mapSkinGroup.find(t_fileName.hashCode());
    if (pairSkinGroup != SkinGroup::s_mapSkinGroup.end()) {
        s_arrScene.back()->setSelfSkinGroup(pairSkinGroup->second);
    }
    s_arrScene.back()->mt_name = name;
    return s_arrScene.back();
}

const gstl::string& ssui::UIScene::getName() const {
    return mt_name;
}

ssui::SkinGroup* ssui::UIScene::getSelfSkinGroup() const {
    return m_pSelfSkinGroup;
}

ssui::Skin* ssui::UIScene::getSkinTemplate(int key) const {
    if (m_pSelfSkinGroup != nullptr) {
        auto pSkin = m_pSelfSkinGroup->getCurSkin(key);
        if (pSkin != nullptr) {
            return pSkin;
        }
        for (auto& pairSkinGroup : m_mapSkinGroup) {
            pSkin = SkinGroup::getCurSkinBySkinGroupKey(pairSkinGroup.first, key);
            if (pSkin != nullptr) {
                return pSkin;
            }
        }
    }
    return nullptr;
}

void ssui::UIScene::setSelfSkinGroup(SkinGroup* pValue) {
    if (m_pSelfSkinGroup != nullptr) {
        m_pSelfSkinGroup->decreaseUseCount();
    }
    m_pSelfSkinGroup = pValue;
    pValue->increaseUseCount();
}

int ssui::UIScene::addSkinGroupQuote(const string& skinGroupName) {
    string t_fileName = skinGroupName;
    if (ResLoader::isResInMod()) {
        t_fileName = util::lowcase(skinGroupName);
    }
    auto key = t_fileName.hashCode();
    auto pairSkinGroup = SkinGroup::s_mapSkinGroup.find(key);
    if (pairSkinGroup != SkinGroup::s_mapSkinGroup.end() && pairSkinGroup->second != nullptr) {
        m_mapSkinGroup.insert(key, 0);
        pairSkinGroup->second->increaseUseCount();
        return 0;
    }
    return -1;
}

ssui::UIScene& ssui::UIScene::assign(const UIScene& other) {
    Base::assign(other);
    m_pSelfSkinGroup = other.m_pSelfSkinGroup;
    m_mapSkinGroup = other.m_mapSkinGroup;
    safe_release(mt_pDataEventGroup);
    if (other.mt_pDataEventGroup) {
        mt_pDataEventGroup = (EventNodeGroup*)other.mt_pDataEventGroup->createCopy();
    }
    return *this;
}

int UIScene::addDataChild(DataInfoNode& childData) {
    int ret = Base::addDataChild(childData);
    if (ret < 0) {
        if (ObjectBase::is(childData.m_objType, NT_SkinGroup)) {
            for (auto& pAttrInfo : childData.m_arrAttr) {
                if (pAttrInfo->m_attrType == (u16)AT_SkinGroup_Name) {
                    addSkinGroupQuote(*pAttrInfo->m_pStrData);
                    ret = NT_SkinGroup;
                    break;
                }
            }
        } else if (ObjectBase::is(childData.m_objType, NT_Control)) {
            if (!getCurImportUIName().empty()) {
                ControlParser(addImportControl);
            } else {
                ControlParser(setRootControl);
            }
        } else if (ObjectBase::is(childData.m_objType, NT_Skin)) {
            if (m_pSelfSkinGroup != nullptr) {
                m_pSelfSkinGroup->addSkinWithRefresh((Skin*)ObjectBase::createObject(childData));
                ret = NT_Skin;
            }
        } else if (ObjectBase::is(childData.m_objType, NT_EventNodeBase)) {
            if (mt_pDataEventGroup == nullptr) {
                mt_pDataEventGroup = EventNodeGroup::createObject();
            }
            mt_pDataEventGroup->addEventNode((EventNodeBase*)ObjectBase::createObject(childData));
            ret = NT_EventNodeBase;
        }
    }
    return ret;
}

void UIScene::addImportControl(Control* pCtrl) {
    if (m_pRootControl && pCtrl) {
        pCtrl->setImportUIName(getCurImportUIName());
        m_pRootControl->addChild(pCtrl);
    }
}

void UIScene::setOtherData() {
    auto it = DataManager::getInstance()->xmlPriorityConfig.find(getName());
    if (it != DataManager::getInstance()->xmlPriorityConfig.end()) {
        setPriority(it->second);
    }
    auto it2 = DataManager::getInstance()->xmlNoneventConfig.find(getName());
    if (it2 != DataManager::getInstance()->xmlNoneventConfig.end()) {
        setIsNonEvent(it2->second);
    }
}

void UIScene::setRootControl(Control* pCtrl) {
    if (m_pRootControl != nullptr) {
        m_pRootControl->releaseObject();
    }
    m_pRootControl = pCtrl;
    pCtrl->setScene(this);
}

void UIScene::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    case ET_SkinGroupReplace:
    {
        if (m_pSelfSkinGroup == event.m_pData1) {
            m_pSelfSkinGroup = (SkinGroup*)event.m_pData2;
            if (m_pRootControl != nullptr && m_pRootControl->getDataIsVisible()) {
                m_pRootControl->onEvent(event);
            }
        } else {
            for (auto& pairSkinGroup : m_mapSkinGroup) {
                if (pairSkinGroup.first == ((SkinGroup*)event.m_pData1)->getName().hashCode()) {
                    if (m_pRootControl != nullptr && m_pRootControl->getDataIsVisible()) {
                        m_pRootControl->onEvent(event);
                    }
                }
            }
        }
    }
    break;
    case ET_onSceneLoaded:
    {
        if (!Public_loaded_script.empty() && Public_loaded_script != "<null>") {
            ArrayList<BoloVar> args;
            args.push_back(BoloVar(getName()));
            args.push_back(BoloVar(this, false));
            UIManager::loadScriptInner(Public_loaded_script, args);
        }
        if (getEventNodeGroup() != nullptr) {
            getEventNodeGroup()->triggerEventNode(event, this);
        }
    }
    break;
    case ET_onSceneClose:
    {
        if (!Public_closed_script.empty() && Public_closed_script != "<null>") {
            ArrayList<BoloVar> args;
            args.push_back(BoloVar(getName()));
            args.push_back(BoloVar(this, false));
            UIManager::loadScriptInner(Public_closed_script, args);
        }
        if (getEventNodeGroup() != nullptr) {
            getEventNodeGroup()->triggerEventNode(event, this);
        }
    }break;
    case ET_onCSVLoaded:
    {
        if (getEventNodeGroup() != nullptr) {
            getEventNodeGroup()->triggerEventNode(event, this);
        }
    }
    break;
    default:
    {

    }
    break;
    }
}

ssui::Control* ssui::UIScene::getControlWithId(const string& id) {
    auto pairControl = m_mapIdNode.find(id.hashCode());
    return (pairControl != m_mapIdNode.end()) ? pairControl->second : nullptr;
}

wstring ssui::UIScene::CSVtoLogStr(ArrayList<wstring>* pWordList) {
    wstring logStr = "";
    s32 size = pWordList->size();
    for (s32 i = 0; i < 3 + CAT_MAX; i++) {
        if (i < 3) {
            logStr += (*pWordList)[i];
            logStr += "|";
        } else {
            s32 index = getRowIndexByAttrType((*pWordList)[0], CsvAttrType_e(i - 3));
            if (index == -1) {
                ;
            } else if (index > 0 & index < size) {
                string name = DictionaryManager::getInstance()->m_arrCsvAttrType[i - 3];
                wstring name_wstr = "";
                name_wstr.clear();
                util::str2str(name, name_wstr);
                logStr += name_wstr;
                logStr += ":";
                logStr += (*pWordList)[index];
                logStr += "|";
            }
// 			else if(index > 0 & index < size ){
// 				logStr += (*pWordList)[index];
// 			}
// 			if (i != 2 + CAT_MAX) {
// 				logStr += "|";
// 			}
        }
    }
    return logStr;
}

int ssui::UIScene::parseCsvRow(const wstring& csvRow, ArrayList<Control*>& cannotRemoveAddControl) {
    if (csvRow.empty()) {
        return -1;
    }
    auto pTmpArrWStr = RPM::s_rpArrStringW.createObject();
    pTmpArrWStr->clear();
    util::split(csvRow, '|', *pTmpArrWStr);
    if (pTmpArrWStr->size() < 3) {
        //�������٣������塣
        RPM_Release(pTmpArrWStr, ArrStringW);
        return -2;
    }
    if (logCSV) {
        wstring logStr = CSVtoLogStr(pTmpArrWStr);
        LOG(logStr,LogPriority);
    }
    auto pCtrl = getControlWithIdW((*pTmpArrWStr)[1]);
    if (pCtrl == nullptr) {
        RPM_Release(pTmpArrWStr, ArrStringW);
        return -3;
    }
    parseCsvWordList(pCtrl, pTmpArrWStr, cannotRemoveAddControl);
    RPM_Release(pTmpArrWStr, ArrStringW);
    return 0;
}

int ssui::UIScene::parseCsvWordList(Control *& ctrl, ArrayList<wstring>* pWordList, ArrayList<Control*>& cannotRemoveAddControl) {
    if (ctrl == nullptr) {
        return -1;
    }
    wstring type = (*pWordList)[2];
    int type_int = util::atoi_s(type);
    if (type.length() == 0 || type_int == CSV_TYPE_ASSIGN || type_int == CSV_TYPE_ASSIGN_NODELETE) {
        if (type_int == CSV_TYPE_ASSIGN) {
            if (ctrl->getParent() && cannotRemoveAddControl.where(ctrl->getParent()) == -1) {//���û���ڲ���ɾ�����б��� ��������ӵĿؼ�
                ctrl->getParent()->deleteAllAddChild();
                cannotRemoveAddControl.push_back(ctrl->getParent());
            }
        }
        ctrl->parseCsvWordList(pWordList);
    }
    else if (type_int == CSV_TYPE_COPY) {
        if (ctrl->getParent() && cannotRemoveAddControl.where(ctrl->getParent()) == -1) {//���û���ڲ���ɾ�����б��� ��������ӵĿؼ�
            ctrl->getParent()->deleteAllAddChild();
            cannotRemoveAddControl.push_back(ctrl->getParent());
        }
        auto ctrlCopy = (Control*)ctrl->createCopy();
        if (ctrlCopy && ctrl->getParent() && ctrl->getScene()) {
            ctrlCopy->parseCsvWordList(pWordList);
            ctrlCopy->setIsCopyAdd(true);
            ctrl->getParent()->addChild(ctrlCopy);
            updateCopyID(ctrlCopy);
        }
    }
    else if (type_int == CSV_TYPE_CACHE) {
        int textIndex = getRowIndexByAttrType((*pWordList)[0], CAT_Text);
        if (textIndex >= 0 && textIndex < (*pWordList).size()) {
            memory.insert((*pWordList)[1], (*pWordList)[textIndex]);
        }
    }
    else if (type_int == CSV_TYPE_DELETE) {
        if (ctrl->getParent()) {
            ctrl->getParent()->deleteChild(ctrl);
        }
        else {
            ctrl->releaseObject();
        }
    } else if (type_int == CSV_TYPE_HIDE) {//���ص�ǰxml
        setUIVisible(false);
    } else if (type_int == CSV_TYPE_ITEM) {//����װ������Ʒ
        s32 textIndex = getRowIndexByAttrType((*pWordList)[0], CAT_Text);
        if (textIndex >= 0 && textIndex < (*pWordList).size()) {
            ArrayList<BoloVar> args;
            args.push_back(BoloVar((*pWordList)[1]));    //ctrlid
            args.push_back(BoloVar((*pWordList)[textIndex]));   //text
            args.push_back(BoloVar(this, false));
            UIManager::loadScriptInner("Scene_addItem", args);
            for (s32 i = 0; i < DataManager::getInstance()->refreshBagItemXmlList.size(); i++) {
                string freshName = DataManager::getInstance()->refreshBagItemXmlList[i];
                UIScene* fresh = UIManager::getInstance()->getUI(freshName);
                if (fresh) {
                    fresh->onEvent(SSUIEvent::createSSUIEvent(ET_ItemChange));
                }
            }
        }
    }
    else if (type_int == CSV_TYPE_APPEND) {//���ӿ��������������Ŀ��ؼ��������ڵ��������������ؼ�
        auto ctrlCopy = (Control*)ctrl->createCopy();
        if (ctrlCopy && ctrl->getParent() && ctrl->getScene()) {
            ctrlCopy->parseCsvWordList(pWordList);
            ctrlCopy->setIsCopyAdd(true);
            ctrl->getParent()->addChild(ctrl);
            updateCopyID(ctrl);
        }
    }
    else if (type_int == CSV_TYPE_CACHE_2) {//�洢������������Ʒ
        int textIndex = getRowIndexByAttrType((*pWordList)[0], CAT_Text);
        if (textIndex >= 0 && textIndex < (*pWordList).size()) {
            auctionMemory.insert((*pWordList)[1], (*pWordList)[textIndex]);
            wstring tgtID = getAuctionMemory("auction_windowID");
            auto ctrl = getControlWithIdW(tgtID);
            if (ctrl) {
                ctrl->onEvent(SSUIEvent::createSSUIEvent(ET_onCSVAddItem));
            }
        }
    }
    return 0;
}

int ssui::UIScene::getRowIndexByAttrType(const wstring& csvWord, CsvAttrType_e type) {
    unsigned int wv = util::aton_s(csvWord, 10);
    int curIndex = 3;
    if (wv & (1 << CAT_Text)) {
        if (type == CAT_Text) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_Skin)) {
        if (type == CAT_Skin) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_Visible)) {
        if (type == CAT_Visible) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_IsEnable)) {
        if (type == CAT_IsEnable) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_Id)) {
        if (type == CAT_Id) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_Value1)) {
        if (type == CAT_Value1) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_Value2)) {
        if (type == CAT_Value2) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_CsvData)) {
        if (type == CAT_CsvData) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_Blink)) {
        if (type == CAT_Blink) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_Command)) {
        if (type == CAT_Command) {
            return curIndex;
        }
        curIndex++;
    }
    if (wv & (1 << CAT_BindId)) {
        if (type == CAT_BindId) {
            return curIndex;
        }
        curIndex++;
    }
    return -1;
}

bool UIScene::setCurScene(UIScene* bus) {
    if (bus != nullptr && (!bus->getIsVisible() || !bus->isEnable() || bus->getDataIsFloatUI() || !bus->getDataIsCanBeCurScene())) {
        return false;
    }
    auto oldScene = s_curUIScene;
    s_curUIScene = bus;
    if (oldScene != s_curUIScene ) {
        isChangeCurScene = true;
    }
    if (s_curUIScene && oldScene != s_curUIScene) {
        printlog("set curScene = %s\n", bus->getName().c_str());
        static string oldSceneName = "";
        //ZH2����,���ҽ�����ʾ by ghw 20161114
        if (DataManager::getInstance()->currencyXmlList.size() > 0) {
            ArrayList<BoloVar> args;
            HashMap<string, string>::iterator itor = DataManager::getInstance()->currencyXmlList.find(s_curUIScene->getName());
            if (itor != DataManager::getInstance()->currencyXmlList.end()) {
                string value = itor->second;
                args.push_back(BoloVar(value));
            } else {
                string t = "";
                args.push_back(BoloVar(t));
            }
            args.push_back(BoloVar(oldSceneName));
            args.push_back(BoloVar(s_curUIScene, false));
            UIManager::loadScriptInner("UI_showCurrencyXml", args);
        }
        //��ʾ������ť����
        if (DataManager::getInstance()->canShowFloatXmlList.size() > 0) {
            ArrayList<BoloVar> args;
            HashMap<string, b2>::iterator itor = DataManager::getInstance()->canShowFloatXmlList.find(s_curUIScene->getName());
            if (itor != DataManager::getInstance()->canShowFloatXmlList.end()) {
                b2 value = itor->second;
                args.push_back(BoloVar(value));
                args.push_back(BoloVar(s_curUIScene, false));
            } else {
                args.push_back(BoloVar(""));
                args.push_back(BoloVar(s_curUIScene, false));
            }
            UIManager::loadScriptInner("UI_showFloatPanelBtn", args);
        }
        oldSceneName = s_curUIScene->getName();
    }
    return true;
}

void UIScene::rankScenes(ArrayList<UIScene*>& scns) {
    s32 swaptime = 0;
    s32 size = scns.size();
    do {
        swaptime = 0;
        for (s32 i = 0; i < size - 1; i++) {
            auto first = scns[i]->m_priority;
            auto second = scns[i + 1]->m_priority;
            if (first < second) {
                UIScene* bus = scns[i];
                scns[i] = scns[i + 1];
                scns[i + 1] = bus;
                swaptime++;
            }
        }
    } while (swaptime > 0);
    updateCurScene();
}

void UIScene::updateCurScene() {
    bool set = false;
    int index = 0;
    int checkSize = s_arrScene.size();
    if (checkSize <= 0) {
        setCurScene(nullptr);
    }
    while (!set && index < checkSize) {
        UIScene* bus = s_arrScene[checkSize - index - 1];

        set = setCurScene(bus);
        index++;
    }
    if (index == checkSize && !set) {
        setCurScene(nullptr);
    }
}

void UIScene::updateUIIsDraw() {
    if (UIScene::getIsChangeCurScene()) {
        for (s32 i = 0; i < s_arrScene.size(); i++) {
            UIScene* bus = s_arrScene[i];
            if (bus) {
                /*���ƿؼ�*/
                b2 isMask = false;
                b2 isMaskForce = false;

                for (s32 j = i + 1; j < s_arrScene.size(); j++) {
                    UIScene* busCheck = s_arrScene[j];
                    if (busCheck->m_canEnableMaskByDraw && busCheck->getIsVisible() && busCheck->isEnable()) {
                        isMask = true;
                        break;
                    }
                }
                for (s32 j = s_arrScene.size() - 1; j >= i + 1; j--) {
                    UIScene* busCheck = s_arrScene[j];
                    if (busCheck->m_canEnableMaskByDrawForce && busCheck->getIsVisible() && busCheck->isEnable()) {
                        isMaskForce = true;
                        break;
                    }
                }
                if (!(isMask && bus->m_canBeMaskByDraw || isMaskForce) && bus->getIsVisible() && bus->isEnable() || bus->getDataIsFloatUI()) {
                    bus->setRootCtrlVisible(true);
                } else {
                    bus->setRootCtrlVisible(false);
                }
            }
        }
        UIScene::setIsChangeCurScene(false);
    }
}

b2 UIScene::getIsChangeCurScene() {
    return isChangeCurScene;
}

void UIScene::setIsChangeCurScene(b2 is) {
    isChangeCurScene = is;
}

void ssui::UIScene::closeAllScene() {
    for (auto& pScene : UIScene::s_arrScene) {
        pScene->releaseObject();
    }
    UIScene::s_arrScene.clear();
    updateCurScene();
}

void ssui::UIScene::closeScene(const string& name) {
    ArrayList<ArrayList<UIScene*>::iterator> arrTmp;
    for (auto& pScene : UIScene::s_arrScene) {
        if (pScene && pScene->mt_name == name) {
            if (pScene->getDataCanClose()) {
                pScene->onEvent(SSUIEvent::createSSUIEvent(ET_onSceneClose));
                pScene->releaseObject();
                arrTmp.insert(arrTmp.begin(), &pScene);
            } else {
                pScene->setUIVisible(false);
            }
        }
    }
    for (auto& it : arrTmp) {
        UIScene::s_arrScene.erase(it);
    }
    updateCurScene();
}

ssui::UIScene* ssui::UIScene::getCurScene() {
    return s_curUIScene;
}

void ssui::UIScene::destroyFunc() {
    closeAllScene();
}

ssui::UIScene* ssui::UIScene::setFocus(const string& name) {
    for (auto& pScene : UIScene::s_arrScene) {
        if (pScene->getName() == name) {
            auto tpScene = pScene;
            s_arrScene.erase(&pScene);
            s_arrScene.push_back(tpScene);
            rankScenes(s_arrScene);
            updateCurScene();
            return tpScene;
        }
    }
    return nullptr;
}

wstring UIScene::getMemory(const wstring& key) {
    wstring st = "";
    auto it = UIScene::memory.find(key);
    if (it != UIScene::memory.end()) {
        st = it->second;
    }
    return st;
}

void UIScene::setMemory(const wstring& key, const wstring& value) {
    UIScene::memory[key] = value;
}

wstring UIScene::getAuctionMemory(const wstring& key) {
    auto it = UIScene::auctionMemory.find(key);
    wstring st;
    if (it != UIScene::auctionMemory.end()) {
        st = it->second;
    }
    return st;
}
void UIScene::initScene() {
    checkEnable();
}
void UIScene::setEnable(b2 _enable) {
    if (m_isEnable != _enable) {
        m_isEnable = _enable;
        updateCurScene();
        isChangeCurScene = true;
    }
}

b2 UIScene::isEnable() {
    return m_isEnable;
}

b2 UIScene::checkEnable() {
    b2 enable = true;
    switch (UIManager::getInstance()->getUISceneEnableMode()) {
        case E_UI_Scene_Enable_All:
        {
            enable = true;
            break;
        }
        case E_UI_Scene_Enable_Whitelist:
        {
            enable = UIManager::getInstance()->getEnableWhiteList().where(mt_name) != -1;
            break;
        }
        case E_UI_Scene_Enable_Blacklist:
        {
            enable = UIManager::getInstance()->getEnableBlackList().where(mt_name) == -1;
            break;
        }
        case E_UI_Scene_Enable_None:
        {
            enable = false;
            break;
        }
    }
    setEnable(enable);
    return isEnable();
}


TextShape* UIScene::getStringBoardDataFromSkin(const string& value) {
    ssui::Skin* skin = getSkinTemplate(value.hashCode());
    if (skin) {
        auto* shapeGroup = skin->m_arrShapeGroup[SLOT_body][STATE_normal];
        if (shapeGroup) {
            for (auto pShapeInfo : *(shapeGroup->m_pQuoteArrAttrInfo)) {
                if (pShapeInfo->m_objType == NT_Control) {
                    for (auto& pAttrInfo : pShapeInfo->m_arrAttr) {
                        if (pAttrInfo->m_attrType == (u16)AT_Control_DataCcit) {
                            if ((CCIT_e)pAttrInfo->m_iData == CCIT_TextShape) {
                                auto textShape = (TextShape*)ObjectBase::createObject(NT_TextShape);
                                textShape->setData(*pShapeInfo);
                                return textShape;
                            }
                        }
                    }
                }
            }
        }
    }
    return nullptr;
}

void UIScene::deleteImportXml(const string& xmlName) {
    if (m_pRootControl) {
        m_pRootControl->deleteImportChild(xmlName);
        auto xml = m_mapImportUIName.find(xmlName);
        if (xml != m_mapImportUIName.end()) {
            m_mapImportUIName.erase(xml);
        }
    }
}

void UIScene::deleteAllImportXml() {
    if (m_pRootControl) {
        m_pRootControl->deleteAllImportChild();
        m_mapImportUIName.clear();
    }
}

void UIScene::loadImportXml(const string& xmlName) {
    string t_fileName = xmlName;
    if (ResLoader::isResInMod()) {
        t_fileName = util::lowcase(xmlName);
    }
    const auto& pairTemplate = DataManager::getInstance()->m_mapSceneTemplate.find(t_fileName);
    UIScene* pNew = nullptr;
    if (pairTemplate != DataManager::getInstance()->m_mapSceneTemplate.end()) {
        if (m_mapImportUIName.find(xmlName) == m_mapImportUIName.end()) {
            setCurImportUIName(xmlName);
            m_mapImportUIName[xmlName] = xmlName;
            s_isParsing = true;
            b2 old_canClose = m_canClose;
            b2 old_closeWhenCheck = m_closeWhenCheck;
            b2 old_isFloatUI = m_isFloatUI;
            b2 old_canBeMaskByDraw = m_canBeMaskByDraw;
            b2 old_canEnableMaskByDraw = m_canEnableMaskByDraw;
            b2 old_canEnableMaskByDrawForce = m_canEnableMaskByDrawForce;
            setData(*pairTemplate->second);
            m_canClose = old_canClose;
            m_closeWhenCheck = old_closeWhenCheck;
            m_isFloatUI = old_isFloatUI;
            m_canBeMaskByDraw = old_canBeMaskByDraw;
            m_canEnableMaskByDraw = old_canEnableMaskByDraw;
            m_canEnableMaskByDrawForce = old_canEnableMaskByDrawForce;
            s_isParsing = false;
            setCurImportUIName("");
        }
    }
}

void UIScene::setCurImportUIName(const string& value) {
    m_curImportUIName = value;
}
const string& UIScene::getCurImportUIName() const {
    return m_curImportUIName;
}

void UIScene::setUIVisible(bool isVis) {
    setDataIsVisible(isVis);
    if (isVis) {
        rankScenes(s_arrScene);
    } else {
        updateCurScene();
    }
}

void UIScene::setRootCtrlVisible(bool isVis) {
    if (m_pRootControl) {
        m_pRootControl->setDataIsVisible(isVis);
    }
}

bool UIScene::getUIVisible(){
    if (m_pRootControl) {
        return m_pRootControl->getDataIsVisible();
    }
    return false;
}

void UIScene::setPriority(s32 pri) {
    m_priority = pri;
    rankScenes(s_arrScene);
}

s32 UIScene::getPriority() const {
    return m_priority;
}

b2 UIScene::getIsNonEvent() const {
    return m_nonEvent;
}
void UIScene::setIsNonEvent(b2 is) {
    m_nonEvent = is;
}

b2 UIScene::getDataCanClose() const {
    return m_canClose;
}
void UIScene::setDataCanClose(b2 value) {
    m_canClose = value;
}

b2 UIScene::getDataIsCloseWhenCheck() const {
    return m_closeWhenCheck;
}
void UIScene::setDataIsCloseWhenCheck(b2 value) {
    m_closeWhenCheck = value;
}

b2 UIScene::getDataIsFloatUI() const {
    return m_isFloatUI;
}
void UIScene::setDataIsFloatUI(b2 value) {
    m_isFloatUI = value;
}

b2 UIScene::getDataCanBeMask() const {
    return m_canBeMaskByDraw;
}
void UIScene::setDataCanBeMask(b2 value) {
    m_canBeMaskByDraw = value;
}

b2 UIScene::getDataCanEnableMask() const {
    return m_canEnableMaskByDraw;
}
void UIScene::setDataCanEnableMask(b2 value) {
    m_canEnableMaskByDraw = value;
}

b2 UIScene::getDataCanEnableMaskForce() const {
    return m_canEnableMaskByDrawForce;
}
void UIScene::setDataCanEnableMaskForce(b2 value) {
    m_canEnableMaskByDrawForce = value;
}

b2 UIScene::getDataIsOwnEvent() const {
    return m_isOwnEvent;
}
void UIScene::setDataIsOwnEvent(b2 value) {
    m_isOwnEvent = value;
}
b2 UIScene::getDataIsCanBeCurScene() const {
    return m_isCanBeCurScene;
}
void UIScene::setDataIsCanBeCurScene(b2 value) {
    m_isCanBeCurScene = value;
}
EventNodeGroup* UIScene::getEventNodeGroup() const {
    return mt_pDataEventGroup;
}

void UIScene::setControlScript(EventType_e type, const wstring& scriptStr, bool isClear) {
    setControlScript(DictionaryManager::getInstance()->m_arrEventType[type], scriptStr, isClear);
}

void UIScene::setControlScript(const string& type, const wstring& scriptStr, bool isClear) {
    if (mt_pDataEventGroup == nullptr) {
        mt_pDataEventGroup = EventNodeGroup::createObject();
    }
    mt_pDataEventGroup->setScript(type, scriptStr, isClear);
}

void ssui::UIScene::debugString(string& outString) {
    outString.append("\nname:");
    outString += mt_name;
}
