#include "WrapPanel.h"
#include "Control.h"
#include "Geometry.h"
#include "BasicMeasure.h"
#include "TextFlow.h"
#include "FlowElement.h"
#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(WrapPanel, 20, 100);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(WrapPanel)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::WrapPanel::createSelf() {
    mt_dataDirection = DDR_LT;
}

void ssui::WrapPanel::disposeSelf() {

}

void ssui::WrapPanel::setDataDirection(int value) {
    if (mt_dataDirection != value) {
        mt_dataDirection = value;
        getHost()->touchMeasureChanged();
    }
}

int ssui::WrapPanel::getDrawLineCount() const {
    return m_drawLineCount;
}

bool ssui::WrapPanel::getIsHorizontal() const {
    return getDataDirection() & 0x01;
}

bool ssui::WrapPanel::getIsVertical() const {
    return !getIsHorizontal();
}

bool ssui::WrapPanel::getIsLeft() const {
    //��λΪ0���ߵ�λΪ0��
    return ((!(getDataDirection() & 0xf0)) || (!(getDataDirection() & 0x0f)));
}

bool ssui::WrapPanel::getIsTop() const {
    //��λΪ1���ߵ�λΪ1��
    return ((getDataDirection() & 0xf0) == 0x10) || ((getDataDirection() & 0x0f) == 0x01);
}

WrapPanel& ssui::WrapPanel::assign(const WrapPanel& other) {
    Base::assign(other);
    return *this;
}

void ssui::WrapPanel::onTransformChildren(unsigned char drawStep) {
    if (drawStep < 1) {
        return;
    }
    m_childrenPosition.clear();
    if (getHost() == nullptr || container().empty()) {
        return;
    }
    const auto& selfArea = getMeasure(PAT_inner).m_srcArea;
    auto selfWidth = selfArea.m_right - selfArea.m_left;
    auto selfHeight = selfArea.m_bottom - selfArea.m_top;
    switch (getSingleDirection()) {
        case DR_L:
        case DR_T:
        {
            m_childrenPosition.push_back(vec2(0, 0));
        }
        break;
        case DR_R:
        {
            m_childrenPosition.push_back(vec2(selfWidth, 0));
        }
        break;
        case DR_B:
        {
            m_childrenPosition.push_back(vec2(0, selfHeight));
        }
        break;
        default:
            break;
    }
    //wrapPanel
    ft curX = 0.f, curY = 0.f;
    ft lineMax = 0.f;
    ft lineFirstIndex = 0;
    int index = 0;
    switch (getDataDirection()) {
        case DoubleDirection_e::DDR_LT:
            curX = 0.f;
            curY = 0.f;
            break;
            //<inc>
        default:
            break;
    }
    //base
    Border curChildBorder;
    ft curChildWidth = 0, curChildHeight = 0;
    bool isTextFlow = false;
    Border parentArea;
    bool isTextSingle = false;
    if (is(NT_Para)) {
        isTextFlow = true;
        parentArea = getHost()->getParentComponent()->getMeasure(PAT_inner).m_srcArea;
        isTextSingle = static_cast<TextFlow*>(getHost()->getParentComponent())->getIsSingleLine();
    }
    s32 lineNo = 0;
    for (auto& pChild : *this) {
        auto& pCurChildGeo = pChild->getOuterMeasure().m_pTransGeo;
        if (pCurChildGeo == nullptr) {
            continue;
        }
        pCurChildGeo->getBorder(curChildBorder);
        curChildWidth = curChildBorder.m_right - curChildBorder.m_left;
        curChildHeight = curChildBorder.m_bottom - curChildBorder.m_top;
        switch (getDataDirection()) {
            case DoubleDirection_e::DDR_LT:
            {
                if (!isTextFlow && curX + curChildWidth < selfWidth || isTextFlow &&  
                    (curX + curChildWidth < parentArea.m_right - parentArea.m_left || isTextSingle)) {
                    lineMax = Math::maximum(lineMax, curChildHeight);
                    m_childrenPosition.push_back(vec2(curX, curY));
                    curX += curChildWidth;
                    curX += getDataColumnSpacing();
                } else {
                    //���С�
                    lineNo++;
                    if (lineFirstIndex == index) {
                        //����ֻ����һ���ӽڵ㡣
                        m_childrenPosition.push_back(vec2(curX, curY));
                        lineFirstIndex = index + 1;
                        curX = 0;
                        curY += curChildHeight;
                        curY += getDataRowSpacing();
                        lineMax = 0.f;
                    } else {
                        //                         for (auto i = lineFirstIndex; i < index; i++) {
                        //                             m_tmpChildSize[i].m_h = lineMax;
                        //                         }
                        lineFirstIndex = index;
                        curX = 0;
                        curY += lineMax;
                        curY += getDataRowSpacing();
                        lineMax = curChildHeight;
                        if (curX + curChildWidth > selfWidth) {
                            //����ֻ����һ���ӽڵ㡣
                            m_childrenPosition.push_back(vec2(curX, curY));
                            lineFirstIndex = index + 1;
                            curX = 0;
                            curY += curChildHeight;
                            curY += getDataRowSpacing();
                            lineMax = 0.f;
                        } else {
                            //m_tmpChildSize.push_back({ curX, curY, curChildWidth, 0.f });
                            m_childrenPosition.push_back(vec2(curX, curY));
                            curX += curChildWidth;
                            curX += getDataColumnSpacing();
                        }
                    }
                }
                if (isTextFlow) {
                    auto pComp = (FlowElement*)pChild->getComponentByClass(NT_FlowElement);
                    if (pComp) {
                        pComp->setLineNo(lineNo);
                    }
                }
                auto lastX = m_childrenPosition.back().x;
                auto lastY = m_childrenPosition.back().y;
                if (!(math::equalZero(lastX, 0.01f) && math::equalZero(lastY, 0.01f))) {
                    applyTransformToSelfChildGrandChildAndSoOn(pChild, lastX, lastY);
                }
                index++;
                //                 for (auto i = lineFirstIndex; i < m_tmpChildSize.size(); i++) {
                //                     m_tmpChildSize[i].m_h = lineMax;
                //                 }
            }
            break;
            case DoubleDirection_e::DDR_LB:
            {
                //<inc>
            }
            break;
            case DoubleDirection_e::DDR_TL:
            {

            }
            break;
            case DoubleDirection_e::DDR_TR:
            {

            }
            break;
            case DoubleDirection_e::DDR_RT:
            {

            }
            break;
            case DoubleDirection_e::DDR_RB:
            {

            }
            break;
            case DoubleDirection_e::DDR_BL:
            {

            }
            break;
            case DoubleDirection_e::DDR_BR:
            {

            }
            break;
            default:
                break;
        }
    }
}

void ssui::WrapPanel::onPrepareData() {
    if (getHost() == nullptr) {
        return;
    }
    m_childrenPosition.clear();
    if (getHost()->m_isAutoFrameData) {
        getHost()->m_measureReadyMinimumTimes = 1;
    }
}
