#pragma once
#include "ObjectBase.h"
#include "Control.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class DataInfoNode;
class ShapeGroup : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ShapeGroup)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(ShapeGroup, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static wstring s_tmpSlotCmdData;
    static wstring s_tmpStateCmdData;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    ArrayList<DataInfoNode*>* m_pQuoteArrAttrInfo = nullptr;
private:
    u8 mt_slot = 0;
public:
    inline int getSlot() const {
        return mt_slot;
    }
    inline void setSlot(int value) {
        mt_slot = value;
    }
private:
    u8 mt_state = 0;
public:
    inline int getState() const {
        return mt_state;
    }
    inline void setState(int value) {
        mt_state = value;
    }
public:
#pragma endregion

#pragma region "����"
public:
    inline ShapeGroup& assign(const ShapeGroup& other) {
        Base::assign(other);
        m_pQuoteArrAttrInfo = other.m_pQuoteArrAttrInfo;
        mt_slot = other.mt_slot;
        mt_state = other.mt_state;
        return *this;
    }
#pragma endregion
};

_SSUINamespaceEnd
