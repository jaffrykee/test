#pragma once
#include "ButtonBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class SkillButton : public ButtonBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(SkillButton);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(SkillButton, ButtonBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
    //UIComponent��̳У�
private:
    ArrayList<Control*> m_container;
    bool m_isReady = false;
    //SkillButton
public:
    //��ȴʱ��(����)
    s32 m_cdTime = 1000;
    ProgressDirection_e m_direction = PROG_DRC_antiCw;
    //���������ʣʱ��
    s32 m_remainTime = 0;
public:
    //��һ��ʱ�䡣
    u32 m_lastTime = 0;
public:
    Border m_clipArea;
    bool m_isRect = true;
#pragma endregion

#pragma region "����"
public:
    s32 getCdTime() const;
    void setCdTime(s32 value);
    s32 getRemainTime() const;
    void setRemainTime(s32 value);
    int getSkillButtonDirection() const;
    void setSkillButtonDirection(int value);
public:
    Self& assign(const Self& other);
    virtual void onEvent(SSUIEvent& event) override;
public:
    virtual ArrayList<Control*>& container() override final;
    virtual ParentAreaType_e getParentAreaType() const;
    virtual const ArrayList<SlotType_e>& getSlotList() const override;
public:
    virtual void onPrepareData() override;
    virtual void onClip(unsigned char drawStep) override;
    virtual void applyClipToPosterity(Control* pPosterity) override;
public:
    void createTimer();
    void timerTrigger(u32 targerTime);
public:
    void correctValidity();
    void rebuild();
public:
    virtual void debugString(string& outString) override;
#pragma endregion
};

_SSUINamespaceEnd
