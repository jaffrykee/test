#pragma once
#include "Control.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ImagePackage : public Control {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ImagePackage)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(ImagePackage, Control);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
public:
    inline ImagePackage& assign(const ImagePackage& other) {
        Base::assign(other);
        return *this;
    }
#pragma endregion
};

_SSUINamespaceEnd
