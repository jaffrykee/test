#include "Engine.h"
#include "UIManager.h"
#include "VirtualJoystick.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(VirtualJoystick, 5, 20);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("joystickId", JoystickId, VirtualJoystick, S32);
NODEBASE_ATTR_REGISTER("joystickR", JoystickR, VirtualJoystick, S32);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(VirtualJoystick)
NBSCRIPT_ATTR_REGISTER("joystickId", JoystickId, VirtualJoystick, S32);
NBSCRIPT_ATTR_REGISTER("joystickR", JoystickR, VirtualJoystick, S32);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(VirtualJoystick, JoystickId, int)
UIComponent_ControlAttr_Def(VirtualJoystick, JoystickR, int)
#pragma endregion

void VirtualJoystick::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
        case ET_Press:
        {
            event.m_blockAnimation = true;
            getHost()->setDataIsPressed(true);
            getHost()->getCenter(m_hostCx, m_hostCy);
            m_drawCx = event.m_iData1 - m_hostCx;
            m_drawCy = event.m_iData2 - m_hostCy;
            m_drawStickX = event.m_iData1 - m_hostCx;
            m_drawStickY = event.m_iData2 - m_hostCy;
            getHost()->touchMeasureChanged();
            getHost()->setEventType(event, PT_BlockStatusChange);
        }
        break;
        case ET_Release:
        {
            getHost()->setDataIsPressed(false);
            m_drawCx = 0;
            m_drawCy = 0;
            m_drawStickX = 0;
            m_drawStickY = 0;
            Engine::controllerRouter().joystickRelease(mt_joystickId);
            UIManager::getInstance()->addJoyStickInfo(mt_joystickId, -1, 0);
            getHost()->touchMeasureChanged();
            event.m_blockAnimation = true;
            getHost()->setEventType(event, PT_BlockStatusChange);
        }
        break;
        case ET_Drag:
        {
            ft angle, strength;
            m_drawStickX = event.m_iData1 - m_hostCx;
            m_drawStickY = event.m_iData2 - m_hostCy;
            SSUIMath::getCounterClockJoyStickValue(angle, strength, m_drawCx, m_drawCy, m_drawStickX, m_drawStickY, getJoystickR());
            if (strength > 1) {
                m_drawStickX = m_drawCx + math::cos((s32)(angle + 270) % 360) * getJoystickR();
                m_drawStickY = m_drawCy - math::sin((s32)(angle + 270) % 360) * getJoystickR();
                strength = 1;
            }
            Engine::controllerRouter().joystickMove(mt_joystickId, angle, strength);
            UIManager::addJoyStickInfo(mt_joystickId, angle, strength);
            //outString();
            getHost()->touchMeasureChanged();
            event.m_blockAnimation = true;
            event.m_enDragged = true;
            getHost()->setEventType(event, PT_BlockStatusChange);
        }
        break;
#ifdef INC
        case ET_AddChildDone:
        {
            if (event.m_pData1 != nullptr) {
                auto pChild = (Control*)event.m_pData1;
                pChild->setDataIsClip(false);
            }
        }
        break;
        case ET_OnSrcTransformSuf:
        {
            //         auto matCenter = getHost()->getSrcCurTransform();
            //         auto matStick = getHost()->getSrcCurTransform();
            //         SSUIMath::sumPosition(matCenter, m_curCx, m_curCy);
            //         SSUIMath::sumPosition(matStick, m_curStickX, m_curStickY);
            if (getHost()->m_pDrawComponents == nullptr || m_drawCx == 0xffff) {
                return;
            }
            for (auto& pComp : *getHost()->m_pDrawComponents) {
                if (pComp == this) {
                    for (auto& pChild : *pComp) {
                        pChild->appendSrcCurTransformPoint(m_drawStickX, m_drawStickY);
                    }
                } else {
                    for (auto& pChild : *pComp) {
                        pChild->appendSrcCurTransformPoint(m_drawCx, m_drawCy);
                    }
                }
            }
        }
        break;
        case ET_AddComponentDone:
        {
            getHost()->setDataIsClip(false);
            if (getHost()->m_pDrawComponents == nullptr) {
                return;
            }
            for (auto& pComp : *getHost()->m_pDrawComponents) {
                for (auto& pChild : *pComp) {
                    pChild->setDataIsClip(false);
                }
            }
        }
        break;
#endif
        default:
        {

        }
        break;
    }
    Base::onEventScript(event);
}

bool ssui::VirtualJoystick::isTouchComponent() const {
    return true;
}

void ssui::VirtualJoystick::debugString(string& outString) {
    outString = util::itoa_c8s(m_drawStickX) + '\t' + util::itoa_c8s(m_drawStickY);
}
