#include "SSUIEvent.h"

StaticCache<SSUIEvent, UIEVENT_CACHE_WB> SSUIEvent::s_cache;
ssui::SSUIEvent ssui::SSUIEvent::s_null;
