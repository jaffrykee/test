#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class BasicClip : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(BasicClip);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(BasicClip, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static wstring s_tmpClipTypeCmdData;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    E_ClipType m_clipType = ClipType_none; // �и�����
    s16 m_clipRoundedRadius = 0; // Բ�Ǿ��ε�Բ�ǰ뾶
    s16 m_clipBeginAngle = 0;
    s16 m_clipEndAngle = 360;
    s16 m_clipCircleOffsetX = 0;
    s16 m_clipCircleOffsetY = 0;
    s16 m_clipCircleRadius = 0;
    bool m_isEnableClip = true;
    bool m_clipCircle = false;
#pragma endregion

#pragma region "����"
public:
    bool getIsEnableClip() const;
    void setIsEnableClip(bool value);
    int getClipType() const;
    void setClipType(int value);
    int getClipRoundedRadius()const;
    void setClipRoundedRadius(int value);
    int getClipCircleRadius() const;
    void setClipCircleRadius(int value);
    int getClipCircleOffsestX() const;
    void setClipCircleOffsestX(int value);
    int getClipCircleOffsestY() const;
    void setClipCircleOffsestY(int value);
    int getClipBeginAngle() const;
    void setClipBeginAngle(int value);
    int getClipEndAngle() const;
    void setClipEndAngle(int value);


public:
    BasicClip& assign(const BasicClip& other);
    virtual void onClip(unsigned char drawStep) override;
    virtual void applyClipToPosterity(Control* pPosterity) override;
    
private:
    void clipDefault();
    void clipCircle();
    void clipRoundedRectangle();
    void clipSixAngleRhombus();
    void clipCustom();

#pragma endregion
};

_SSUINamespaceEnd
