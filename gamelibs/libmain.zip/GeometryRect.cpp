#include "GeometryRect.h"
#include "GeometryManager.h"
#include "UIManager.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(GeometryRect, 5000, 10000);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(GeometryRect)
NODETYPE_COMMON_PART_DEFINITION_END

GeometryRect* ssui::GeometryRect::createObject(const Border& aabb) {
    auto pNew = GeometryRect::createObject();
    pNew->m_aabb = aabb;
    return pNew;
}


GeometryRect& ssui::GeometryRect::assign(const GeometryRect& other) {
    Base::assign(other);
    m_aabb = other.m_aabb;
    return *this;
}

bool GeometryRect::isIn(ft x, ft y) {
    return GeometryManager::getPointIsInAabb(x, y, m_aabb);
}

void GeometryRect::appendOutline(Poly& poly) {
    poly.push_back(vec3(m_aabb.m_left, m_aabb.m_top, 0.f));
    poly.push_back(vec3(m_aabb.m_left, m_aabb.m_bottom, 0.f));
    poly.push_back(vec3(m_aabb.m_right, m_aabb.m_bottom, 0.f));
    poly.push_back(vec3(m_aabb.m_right, m_aabb.m_top, 0.f));
    return;
}

void ssui::GeometryRect::getCenter(ft& cx, ft& cy) const {
    cx = (m_aabb.m_left + m_aabb.m_right) * 0.5f;
    cy = (m_aabb.m_top + m_aabb.m_bottom) * 0.5f;
}

void ssui::GeometryRect::getBorder(Border& aabb) const {
    aabb = m_aabb;
}

void ssui::GeometryRect::transformPosition(ft x, ft y) {
    m_aabb += vec2(x, y);
}
