#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ContainerComponent : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ContainerComponent);
protected:
    inline virtual void createSelf() override {
    }
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(ContainerComponent, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    ArrayList<Control*> m_container;
#pragma endregion

#pragma region "����"
public:
    ContainerComponent& assign(const ContainerComponent& other);
    virtual bool isContainerComponent() const override;
    virtual ArrayList<Control*>& container() override;
    virtual const ArrayList<SlotType_e>& getSlotList() const override;
public:
    virtual void onPrepareData() override;
#pragma endregion
};

using Panel = ContainerComponent;

_SSUINamespaceEnd
