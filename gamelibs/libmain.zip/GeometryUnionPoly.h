#pragma once
#include "Geometry.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class RenderCacheImage;
class GeometryUnionPoly : public Geometry {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(GeometryUnionPoly);
protected:
    inline virtual void createSelf() override {}
    inline virtual void disposeSelf() override {}
    NODETYPE_COMMON_PART_DECLARATION_END(GeometryUnionPoly, Geometry);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
public:
    static GeometryUnionPoly* createObject(const ArrayList<Poly>& arrPoly);
#pragma endregion

#pragma region "��Ա"
public:
    ArrayList<Poly> m_arrPoly;
#pragma endregion

#pragma region "����"
public:
    GeometryUnionPoly& assign(const GeometryUnionPoly& other);
    virtual bool isIn(ft x, ft y) override;
    virtual void appendOutline(Poly& poly) override;
    virtual void getCenter(ft& cx, ft& cy) const override;
    virtual void getBorder(Border& aabb) const override;
    virtual void transformPosition(ft x, ft y) override;
    bool isNull();
    void refreshNull();

#pragma endregion
};

_SSUINamespaceEnd
