#pragma once
#include "UIComponent.h"
#include "ContainerComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

#define GRID_INDEXMAX 8

class GridItem;
class Grid : public ContainerComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(Grid);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(Grid, ContainerComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    union {
        //�п�
        s16 m_cw[GRID_INDEXMAX] = { 0 };
        struct {
            unsigned long long m_cwlData;
            unsigned long long m_cwhData;
        };
    };
    union {
        //�и�
        s16 m_rh[GRID_INDEXMAX] = { 0 };
        struct {
            unsigned long long m_rhlData;
            unsigned long long m_rhhData;
        };
    };
public:
    u16 m_sumWidthStarCount = 0;
    u16 m_sumHeightStarCount = 0;
    ft m_starWidth = 0.f;
    ft m_starHeight = 0.f;
    union {
        struct {
            bool m_isAutoWidth : 1;
            bool m_isAutoHeight : 1;
        };
        u8 m_isAutoData = 0;
    };
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    int getColumnWidth(int index) const;
    void setColumnWidth(int index, int value);
    int getRowHeight(int index) const;
    void setRowHeight(int index, int value);
public:
    int getCw0() const;
    void setCw0(int value);
    int getCw1() const;
    void setCw1(int value);
    int getCw2() const;
    void setCw2(int value);
    int getCw3() const;
    void setCw3(int value);
    int getCw4() const;
    void setCw4(int value);
    int getCw5() const;
    void setCw5(int value);
    int getCw6() const;
    void setCw6(int value);
    int getCw7() const;
    void setCw7(int value);
public:
    int getRh0() const;
    void setRh0(int value);
    int getRh1() const;
    void setRh1(int value);
    int getRh2() const;
    void setRh2(int value);
    int getRh3() const;
    void setRh3(int value);
    int getRh4() const;
    void setRh4(int value);
    int getRh5() const;
    void setRh5(int value);
    int getRh6() const;
    void setRh6(int value);
    int getRh7() const;
    void setRh7(int value);
#pragma endregion
public:
    Grid& assign(const Grid& other);
public:
    virtual int addChild(Control* pChild) override;
public:
    void getItemArea(Border& area, int columnIndex, int columnSpan, int rowIndex, int rowSpan) const;
    void getItemArea(Border& area, GridItem* pItem) const;
    virtual const Border& getChildArea(const Control* pChild) const override;
public:
    virtual void onPrepareData() override;
    virtual bool onDrawChildren(unsigned char drawStep, bool isReDraw) override;
public:
    void refreshStarSize();
#pragma endregion
};

_SSUINamespaceEnd
