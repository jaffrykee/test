#pragma once
#include "SimpleComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Blink : public SimpleComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(Blink);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(Blink, SimpleComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
#pragma endregion

#pragma region "����"
public:
    inline Self& assign(const Self& other) {
        Base::assign(other);
        return *this;
    }
    virtual void onEvent(SSUIEvent& event) override;
    virtual const ArrayList<SlotType_e>& getSlotList() const override {
        return getSlotListDef(SLOT_blink);
    }
#pragma endregion
};

_SSUINamespaceEnd
