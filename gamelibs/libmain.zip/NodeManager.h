#pragma once
/*
    ��׵ı�ǣ�ʼ��2017-01-11
*/
#include <stdlib.h>
#include "BoloVM.h"
#include "ssuiBasic.h"
#include "StringManager.h"
#include "DictionaryManager.h"
#include "SSUIEvent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Control;
class ObjectBase;
class RenderCacheBase;
//һ����̬��
class NodeManager : public BoloObject {
#pragma region "��������"
public:
    typedef int(*GetCountFunc_t)();
    struct ClassTestData {
        GetCountFunc_t m_pFuncGetCountObject;
        GetCountFunc_t m_pFuncGetSizeObject;
        GetCountFunc_t m_pFuncGetResPoolCount;
    };
#pragma endregion

#pragma region "��̬��Ա"
public:
    static string s_className;
    static NodeManager* s_pInstance;
#pragma endregion

#pragma region "��̬����"
public:
    inline static NodeManager* getInstance() {
        if (s_pInstance == nullptr) {
            s_pInstance = new NodeManager();
        }
        return s_pInstance;
    }
    static void initialize();
    static void destroy();
    static void registerReflection(int id);
#pragma endregion

#pragma region "��Ա"
public:
    HashMap<string, ClassTestData> m_mapClassTestData;
    string m_curTheme = StringManager::getInstance()->mc_strNullDef;;
    HashMap<int, string> m_mapLanguageIdName;
    HashMap<int, string> m_mapThemeIdName;
    HashMap<string, int> m_mapLanguageNameId;
    HashMap<string, int> m_mapThemeNameId;
    const int mc_initCacheCount = 1000;
    Texture m_showCacheTexture;
    float m_lastGrayValue = 0.0f;
    ArrayList<Vpct_t> m_showCacheVpct;
#ifdef _WIN32
    Poly m_curOutLine;
    Color m_outLineColor = Color(0.0f, 0.5f, 1.f, 0.9f);
    Poly m_curBackArea;
    Color m_backColor = Color(0.5f, 0.5f, 0.5f, 1.f);
    f32 m_outLineWidth = 2.f;
    ArrayList<Poly> m_allBorder;
    Color m_borderColor = Color(8.f, 0.4f, 8.f, 0.9f);
    f32 m_borderWidth = 1.f;
#endif // _WIN32
    bool m_isReady = false;
#pragma endregion

#pragma region "����"
public:
    inline NodeManager() {
    }
    inline virtual ~NodeManager() {
    }
    inline virtual const string& getClassName() const override {
        return NodeManager::s_className;
    }
public:
    template <typename srcType>
    inline static void* getVoidPtr(const srcType& srcPtr) {
        union {
            srcType _srcPtr;
            void* _dstPtr;
        }utPtr;
        utPtr._srcPtr = srcPtr;
        return utPtr._dstPtr;
    }
    void createFast();
    void onDraw();
    void onShow();
    void pushShow();
    void showObjectCount();
    inline const string& getTheme() const {
        return m_curTheme;
    }
    void setTheme(const string& value);
    void onLanguageThemeChanged();
#pragma endregion
};

_SSUINamespaceEnd
