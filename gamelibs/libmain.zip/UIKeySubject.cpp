#include "UIKeySubject.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UIKeySubject, 20, 100);
#pragma region "����ע��"
	NODEBASE_ATTR_REGISTER("xml", Xml, UIKeySubject, STR);
	NODEBASE_ATTR_REGISTER("priority", Priority, UIKeySubject, S32);
	NODEBASE_ATTR_REGISTER("currency", Currency, UIKeySubject, STR);
	NODEBASE_ATTR_REGISTER("isNonEvent", IsNonEvent, UIKeySubject, B2);
	NODEBASE_ATTR_REGISTER("isBag", IsBag, UIKeySubject, B2);
	NODEBASE_ATTR_REGISTER("canShowFloat", CanShowFloat, UIKeySubject, B2);
	NODEBASE_ATTR_REGISTER("canMoveRole", CanMoveRole, UIKeySubject, B2);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UIKeySubject)
//     NBSCRIPT_ATTR_REGISTER("key", Key, UIImageBase, S32);
//     NBSCRIPT_ATTR_REGISTER("name", Name, UIImageBase, STR);
NODETYPE_COMMON_PART_DEFINITION_END
