#pragma once
#include "ObjectBase.h"
#include "EventScript.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class EventNodeBase : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(EventNodeBase);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
        for (auto& pTrigger : m_eventTriggers) {
            pTrigger->releaseObject();
        }
        m_eventTriggers.clear();
    }
    NODETYPE_COMMON_PART_DECLARATION_END(EventNodeBase, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static wstring s_tmpEventList;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    EventType_e mt_eventType = ET_MAX;
public:
    ArrayList<EventTrigger*> m_eventTriggers;
    
#pragma endregion

#pragma region "����"
public:
    inline int getEventType() const {
        return mt_eventType;
    }
    inline void setEventType(int value) {
        mt_eventType = (EventType_e)value;
    }
    inline const string& getEventName() const {
        return DictionaryManager::getInstance()->m_arrEventType[mt_eventType];
    }
    inline void setEventName(const string& value) {
        const auto& pairEvent = DictionaryManager::getInstance()->m_mapEventType.find(value);
        if (pairEvent != DictionaryManager::getInstance()->m_mapEventType.end()) {
            setEventType(pairEvent->second);
        } else {
            setEventType(ET_MAX);
        }
    }
public:
    inline EventNodeBase& assign(const EventNodeBase& other) {
        mt_eventType = other.mt_eventType;
        Base::assign(other);
        m_eventTriggers.clear();
        for (auto& pEventTrg : other.m_eventTriggers) {
            m_eventTriggers.push_back((EventTrigger*)pEventTrg->createCopy());
        }
        return *this;
    }
    virtual int addDataChild(DataInfoNode& childData) override;
    inline void onEventTrigger(ObjectBase* pObj) {
        for (auto& pTrigger : m_eventTriggers) {
            pTrigger->onTrigger(pObj);
        }
    }
#pragma endregion
};

_SSUINamespaceEnd
