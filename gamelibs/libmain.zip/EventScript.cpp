#include "EventScript.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(EventScript, 100, 500);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("scriptData", ScriptData, EventScript, WSTR, AST_normal);
    NODEBASE_ATTR_REGISTER("sound", Sound, EventScript, STR, AST_normal);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(EventScript)
    NBSCRIPT_ATTR_REGISTER("scriptData", ScriptData, EventScript, WSTR);
    NBSCRIPT_ATTR_REGISTER("sound", Sound, EventScript, STR);
NODETYPE_COMMON_PART_DEFINITION_END

void EventScript::onTrigger(ObjectBase* pObj){
    if (mt_scriptArgs.empty() == true) { 
        return;
    }
    ArrayList<BoloVar> arrArgs;
    string scriptName;
    StringManager::getInstance()->wstringToString(mt_scriptArgs[0], scriptName);
    for (auto itArg = &mt_scriptArgs.back(); itArg != mt_scriptArgs.begin(); --itArg) {
        arrArgs.push_back(BoloVar(*itArg));
    }
    arrArgs.push_back(BoloVar(pObj, false));
    if (UIManager::getInstance()->isUeMode() == false) {
        UIManager::loadScriptInner(scriptName, arrArgs);
    }
    //         if (mt_sound.size() > 0) {
    //             if (mt_sound[0] == '@') {
    //                 BoloUIScene::getListener()->soundPlayBig(be->sound.substr(1, be->sound.length() - 1), true, be->volume);
    //             } else {
    //                 BoloUIScene::getListener()->soundPlay(be->sound, false, be->volume);
    //             }
    //        
}