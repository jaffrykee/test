#include "MeasureData.h"
#include "Geometry.h"
#include "GeometryRect.h"
#include "GeometryPoly.h"

#include "DataHeaders.h"

ssui::MeasureData::Self ssui::MeasureData::s_null;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(MeasureData, 1000, 2000);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(MeasureData)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::MeasureData::disposeSelf() {
    safe_release(m_pTransGeo);
}

ssui::MeasureData& ssui::MeasureData::assign(const MeasureData& other) {
    Base::assign(other);
    m_srcArea = other.m_srcArea;
    safe_release(m_pTransGeo);
    if (other.m_pTransGeo != nullptr) {
        m_pTransGeo = (Geometry*)other.m_pTransGeo->createCopy();
    }
    return *this;
}

void ssui::MeasureData::initData() {
    m_srcArea = {0.f, 0.f, 0.f, 0.f};
    safe_release(m_pTransGeo);
}

bool ssui::MeasureData::isNull() const {
    return this == &s_null;
}

void ssui::MeasureData::transSrcAreaToGeo() {
    safe_release(m_pTransGeo);
    m_pTransGeo = GeometryRect::createObject(m_srcArea);
}

void ssui::MeasureData::transformPosition(ft x, ft y) {
    if (m_pTransGeo == nullptr) {
        m_pTransGeo = GeometryRect::createObject(m_srcArea);
    }
    m_pTransGeo->transformPosition(x, y);
}

void ssui::MeasureData::debugString(string& outString) {
    //outString.append();
    outString.append("\n[MeasureData]\nm_srcArea");
    m_srcArea.debugString(outString);
    if (m_pTransGeo != nullptr) {
        Border geoBorder;
        m_pTransGeo->getBorder(geoBorder);
        outString.append("\ngeoBorder");
        geoBorder.debugString(outString);
    } else {
        outString.append("\ngeoBorder\nnullptr");
    }
}
