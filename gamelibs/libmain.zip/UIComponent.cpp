#include "UIComponent.h"
#include "Control.h"
#include "EventNodeGroup.h"
#include "UIController.h"
#include "DataInfoNode.h"
#include "Skin.h"
#include "ShapeGroup.h"
#include "GeometryManager.h"
#include "GeometryHeaders.h"
#include "BasicClip.h"

#include "DataHeaders.h"

ArrayList<Control*> UIComponent::s_nullContainer;
const gstl::ArrayList<ssui::SlotType_e> ssui::UIComponent::sc_nullSlotList;
ArrayList<SlotType_e> ssui::UIComponent::s_arrSlotList[SLOT_MAX];
gstl::s16 ssui::UIComponent::s_clickTolerance = 10;

const ArrayList<SlotType_e>& ssui::UIComponent::getSlotListDef(SlotType_e slot) {
    return s_arrSlotList[slot];
}

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UIComponent, 0, 0);
for (int i = 0; i < SLOT_MAX; i++) {
    s_arrSlotList[i].push_back((SlotType_e)i);
}
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UIComponent)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::UIComponent::createSelf() {

}

void ssui::UIComponent::disposeSelf() {
#ifdef _WIN32
    UIManager::getInstance()->disposeFunc(this);
#endif
    if (isTouchComponent() == true) {
        for (auto pComp = UIController::s_arrPressOwner.begin(); pComp != UIController::s_arrPressOwner.end(); ++pComp) {
            if (*pComp == this) {
                UIController::s_arrPressOwner.erase(pComp);
                --pComp;
                break;
            }
        }
    }
}

ssui::UIComponent& ssui::UIComponent::assign(const UIComponent& other) {
    Base::assign(other);
    return *this;
}

void UIComponent::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    setCanTriggerScript(true);
    switch (event.m_type) {
        case ET_Press:
        {
            if (isTouchComponent() == false) {
                break;
            }
            if (getHost() && !getHost()->getDataIsVisible())
                break;            
            UIController::s_arrPressOwner.push_back(this);
            for (auto pChild = container().end() - 1; pChild != container().begin() - 1; --pChild) {
                if ((*pChild)->isIn(event.m_iData1, event.m_iData2)) {
                    (*pChild)->onEvent(event);
                }
            }
        }
        break;
        default:
        {

        }
        break;
    }
}
b2 UIComponent::canTriggerScript() {
    return m_canTriggerScript;
}
void UIComponent::setCanTriggerScript(b2 value) {
    m_canTriggerScript = value;
}
b2 UIComponent::getIsTriggerScript() const {
    return m_isTriggerScript;
}
b2 UIComponent::onEventScript(SSUIEvent& event) {
    m_isTriggerScript = false;
    if (isTouchComponent() && getHost() && !event.m_blockScript && canTriggerScript()) {
        switch (event.m_type) {
        case ET_Press:
        case ET_Drag:
        case ET_Release:
        case ET_Click:
//             if (isIn(event.m_iData1, event.m_iData2) == false) {
//                 return false;
//             }
            if (getHost()->getEventNodeGroup()) {
                getEventNodeGroup()->triggerEventNode(event, getHost());
                m_isTriggerScript = true;
            }
            if (getHost()) {
                getHost()->setEventType(event, ProcessType_e::PT_BlockScript);
            }else {
                return m_isTriggerScript;
            }
            break;
        default:
            break;
        }
    }
    return m_isTriggerScript;
}

int UIComponent::addDataChild(DataInfoNode& childData) {
    int ret = Base::addDataChild(childData);
    if (ret < 0) {
        if (ObjectBase::is(childData.m_objType, NT_Control)) {
            ControlParser(addChild);
        }
    }
    return ret;
}

void ssui::UIComponent::releaseChildren() {
    for (auto& pChild : container()) {
        pChild->releaseObject();
    }
    container().clear();
}

ssui::Control* ssui::UIComponent::getHost() const {
    return m_pHost;
}

void ssui::UIComponent::setHost(Control* pHost) {
    m_pHost = pHost;
}

bool ssui::UIComponent::isEnableContainer() {
    return &container() != &s_nullContainer;
}

const ArrayList<Control*>& ssui::UIComponent::getContainer() const {
    return const_cast<UIComponent*>(this)->container();
}

gstl::ArrayList<Control*>& ssui::UIComponent::container() {
    return s_nullContainer;
}

ssui::Control** ssui::UIComponent::begin() {
    return container().begin();
}

ssui::Control** ssui::UIComponent::end() {
    return container().end();
}

int ssui::UIComponent::addChild(Control* pChild) {
    if (&container() != &s_nullContainer) {
        container().push_back(pChild);
        pChild->m_pParentComponent = this;
        pChild->setScene(getScene());
        pChild->touchPrepareDataChanged();
        if (getHost()) {
            getHost()->touchPrepareDataChanged();
        }
    }
    return pChild->getNodeType();
}

ssui::ParentAreaType_e ssui::UIComponent::getParentAreaType() const {
    return PAT_inner;
}

const ssui::MeasureData& ssui::UIComponent::getSelfMeasure() const {
    return getHost() ? getHost()->getSelfMeasure() : MeasureData::s_null;
}

const ssui::MeasureData& ssui::UIComponent::getOuterMeasure() const {
    return getHost() ? getHost()->getOuterMeasure() : MeasureData::s_null;
}

const ssui::MeasureData& ssui::UIComponent::getInnerMeasure() const {
    return getHost() ? getHost()->getInnerMeasure() : MeasureData::s_null;
}

const ssui::MeasureData& ssui::UIComponent::getMeasure(ParentAreaType_e pat) const {
    return getHost() ? getHost()->getMeasure(pat) : MeasureData::s_null;
}

const ssui::Border& ssui::UIComponent::getChildArea(const Control* pChild) const {
    return getHost() ? getMeasure(getParentAreaType()).m_srcArea : Border::s_null;
}

bool ssui::UIComponent::isContainerComponent() const {
    return false;
}

bool ssui::UIComponent::isTouchComponent() const {
    return false;
}

ft ssui::UIComponent::getSelfDrawX() const {
    return getHost() ? getHost()->getDrawX() : 0.f;
}

ft ssui::UIComponent::getSelfDrawY() const {
    return getHost() ? getHost()->getDrawY() : 0.f;
}
ft ssui::UIComponent::getSelfWidth() const {
    return getHost() ? getHost()->getDrawWidth() : 0.f;
}
ft ssui::UIComponent::getSelfHeight() const {
    return getHost() ? getHost()->getDrawHeight() : 0.f;
}
const ArrayList<SlotType_e>& ssui::UIComponent::getSlotList() const {
    return sc_nullSlotList;
}

EventNodeGroup* UIComponent::getEventNodeGroup() const {
    if (getHost() == nullptr) {
        return nullptr;
    }
    return getHost()->getEventNodeGroup();
}

void UIComponent::touchPrepareDataChanged() {
    if (getHost() != nullptr) {
        getHost()->touchPrepareDataChanged();
    }
}

void UIComponent::touchMeasureChanged() {
    if (getHost() != nullptr) {
        getHost()->touchMeasureChanged();
    }
}

void UIComponent::touchRenderChanged() {
    if (getHost() != nullptr) {
        getHost()->touchRenderChanged();
    }
}

bool ssui::UIComponent::onDrawChildren(unsigned char drawStep, bool isReDraw) {
    if (container().empty()) {
        return true;
    }
    bool isPosterityReady = true;
    if (isReDraw) {
        for (auto& pChild : *this) {
            pChild->assignAllDrawChanged();
            pChild->onDraw(drawStep);
        }
        onTransformChildren(drawStep);
        if (UIManager::getInstance()->m_openDrawDebug == true) {
            printf("\n%d\t2 Parent", drawStep);
            getHost()->printData();
            for (auto& pChild : *this) {
                printf("\n%d\t2", drawStep);
                pChild->printData();
            }
        }
    } else {
        for (auto& pChild : *this) {
            pChild->onDraw(drawStep);
        }
    } 
    for (auto& pChild : *this) {
        if (pChild->isDrawReady() == false || pChild->m_isPosterityReady == false) {
            isPosterityReady = false;
            break;
        }
    }
    return isPosterityReady;
}

SlotState ssui::UIComponent::getDrawState(SlotType_e slot) const {
    if (getHost() != nullptr && slot != SLOT_null) {
        return getHost()->getDataSlotState(slot);
    }
    return SlotState();
}

void ssui::UIComponent::addSlotChildren(Skin* pSkin, SlotType_e slot) {
    const auto& pShapeGroup = pSkin->m_arrShapeGroup[slot][getDrawState(slot).m_data];
    if (pShapeGroup != nullptr) {
        for (auto& pShapeInfo : *pShapeGroup->m_pQuoteArrAttrInfo) {
            addDataChild(*pShapeInfo);
        }
    }
}

void ssui::UIComponent::onPrepareData() {
    releaseChildren();
    if (getHost() != nullptr) {
        auto pSkin = getHost()->getSkin();
        if (pSkin != nullptr && getHost()->getSkinGroupOfCurSkin().empty() == false) {
            for (const auto& slotId : getSlotList()) {
                addSlotChildren(pSkin, slotId);
            }
        }
    }
}

ssui::UIScene* ssui::UIComponent::getScene() {
    return getHost() ? getHost()->getScene() : nullptr;
}

bool ssui::UIComponent::isIn(ft x, ft y) const {
    return getHost() ? getHost()->isIn(x, y, getParentAreaType()) : false;
}

void ssui::UIComponent::onShow() {
    for (auto& pChild : container()) {
        pChild->onShow();
    }
}

void ssui::UIComponent::applyTransformToSelfChildGrandChildAndSoOn(Control* pSelf, ft x, ft y) {
    pSelf->transformPosition(x, y);
    for (auto& pComp : *pSelf) {
        for (auto& pChild : *pComp) {
            applyTransformToSelfChildGrandChildAndSoOn(pChild, x, y);
        }
    }
}

void ssui::UIComponent::applyClipToSelfChildGrandChildAndSoOn(Control* pSelf, const Border& rect) {
    if (pSelf->isEnableClip() == false) {
        return;
    }
    for (auto it = pSelf->m_arrRender.begin(); it < pSelf->m_arrRender.begin() + pSelf->m_curRenderCount; ++it) {
        if (it->empty() == false) {
            GeometryManager::clipPolyImage(*it, rect);
        }
    }
    for (auto& pComp : *pSelf) {
        for (auto& pChild : *pComp) {
            applyClipToSelfChildGrandChildAndSoOn(pChild, rect);
        }
    }
}

void ssui::UIComponent::applyClipToSelfChildGrandChildAndSoOn(Control* pSelf, const Poly& polyClip) {
    if (pSelf->isEnableClip() == false) {
        return;
    }
    for (auto it = pSelf->m_arrRender.begin(); it < pSelf->m_arrRender.begin() + pSelf->m_curRenderCount; ++it) {
        if (it->empty() == false) {
            GeometryManager::clipPolyImage(*it, polyClip);
        }
    }
    for (auto& pComp : *pSelf) {
        for (auto& pChild : *pComp) {
            applyClipToSelfChildGrandChildAndSoOn(pChild, polyClip);
        }
    }
}

void ssui::UIComponent::applyClipToSelfChildGrandChildAndSoOn(Control* pSelf, const Geometry* pGeo) {
    if (pSelf->isEnableClip() == false) {
        return;
    }
    if (pGeo == nullptr) {
        return;
    }
    if (pGeo->is(NT_GeometryRect)) {
        applyClipToSelfChildGrandChildAndSoOn(pSelf, ((GeometryRect*)pGeo)->m_aabb);
    } else if (pGeo->is(NT_GeometryPoly)) {
        applyClipToSelfChildGrandChildAndSoOn(pSelf, ((GeometryPoly*)pGeo)->m_poly);
    } else if (pGeo->is(NT_GeometryUnionPoly)) {
        auto pGeoUnion = (GeometryUnionPoly*)pGeo;
        if (pGeoUnion->isNull()) {
            pSelf->m_curRenderCount = 0;
            //pSelf->m_arrRender.clear();
        } else {
            static ArrayList<PolyImage> tmpArrRender1;
            static ArrayList<PolyImage> tmpArrRender2;
            tmpArrRender1 = pSelf->m_arrRender;
            pSelf->m_curRenderCount = 0;
            //pSelf->m_arrRender.clear();
            for (auto clipPoly : pGeoUnion->m_arrPoly) {
                tmpArrRender2 = tmpArrRender1;
                for (auto& render : tmpArrRender2) {
                    if (render.empty() == false) {
                        GeometryManager::clipPolyImage(render, clipPoly);
                    }
                }
                for (auto& render : tmpArrRender2) {
                    if (render.empty() == false) {
                        pSelf->pushRender(render);
                    }
                }
            }
        }
        for (auto& pComp : *pSelf) {
            for (auto& pChild : *pComp) {
                applyClipToSelfChildGrandChildAndSoOn(pChild, pGeo);
            }
        }
    }
}

void ssui::UIComponent::applyChildTransformPolyImage(Control* pSelf, ft cX, ft cY, ft scaleX, ft scaleY, ft radian, ft alpha) {
    aff4 originalTransform(vec3(-cX, -cY, 0.0f), quat());
    aff4 posTransform(vec3(cX, cY, 0.0f), quat());
    aff4 transform(vec3::zero, quat(0.0f, 0.0, radian), vec3(scaleX, scaleY, 1.0f));
    for (auto it = pSelf->m_arrRender.begin(); it < pSelf->m_arrRender.begin() + pSelf->m_curRenderCount; ++it) {
        for (VertexPosColorTex& v : *it) {
            v.position = originalTransform * v.position;
            v.position = transform * v.position;
            v.position = posTransform * v.position;

            v.color.a *= alpha;
        }
    }

    for (auto& pComp : *pSelf) {
        for (auto& pChild : *pComp) {
            applyChildTransformPolyImage(pChild, cX, cY, scaleX, scaleY, radian, alpha);
        }
    }
}

void ssui::UIComponent::treeString(string& outString, int step) {
    outString.append('\n');
    for (int i = 0; i < step; i++) {
        outString.append('\t');
    }
    outString.append('<');
    outString.append("container");
    outString.append(">");
    step++;
    for (auto& pChild : container()) {
        pChild->treeString(outString, step);
    }
}
