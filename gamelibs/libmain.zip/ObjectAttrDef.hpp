#pragma once
#include "AttrSetting.h"
#include "DataInfoAttr.h"

template<typename DataType, AttrDataType_e adt, typename pGetFuncType>
inline int ObjectBase::getAttrValue(AttrSetting* pAs, DataType& retValue) {
    int ret = dealAttrValueFromAttrData(pAs, adt);
    if (ret >= 0) {
        retValue = pAs->getFuncDef<DataType, pGetFuncType>(this);
    } else if (getNodeType() == NT_Control) {
        for (const auto& pComp : ((Control*)this)->m_components) {
            int retChild = pComp->getAttrValue<DataType, adt, pGetFuncType>(pAs, retValue);
            if (retChild >= 0) {
                return retChild;
            }
        }
    }
    return ret;
}

template<typename DataType, AttrDataType_e adt, typename pSetFuncType>
inline int ObjectBase::setAttrValue(AttrSetting* pAs, const DataType& value, DataInfoAttr* pAttrInfo) {
    int ret = dealAttrValueFromAttrData(pAs, adt);
    if (ret >= 0) {
        pAs->setFuncDef<DataType, pSetFuncType>(this, value);
    } else if (getNodeType() == NT_Control) {
        auto pSelf = (Control*)this;
        if (pAttrInfo != nullptr && ObjectBase::is(pAs->m_nodeType, NT_ChildItem)) {
            pSelf->setExpansionAttr((DataInfoAttr*)pAttrInfo->createCopy());
            return 0;
        } else {
            for (const auto& pComp : (pSelf->m_components)) {
                int retChild = pComp->setAttrValue<DataType, adt, pSetFuncType>(pAs, value);
                if (retChild >= 0) {
                    return retChild;
                }
            }
        }
    }
    return ret;
}

template<typename DataType, AttrDataType_e adt, typename pGetFuncType>
inline int ObjectBase::getAttrValue(const wstring& attrName, DataType& retValue) {
    const auto& pairAttrType = DataManager::getInstance()->m_mapAttrSetting.find(attrName.hashCode());
    if (pairAttrType == DataManager::getInstance()->m_mapAttrSetting.end()) {
        /*û���ҵ�����������*/
        return -3;
    }
    return getAttrValue<DataType, adt, pGetFuncType>(pairAttrType->second, retValue);
}

template<typename DataType, AttrDataType_e adt, typename pSetFuncType>
inline int ObjectBase::setAttrValue(const wstring& attrName, const DataType& value) {
    const auto& pairAttrType = DataManager::getInstance()->m_mapAttrSetting.find(attrName.hashCode());
    if (pairAttrType == DataManager::getInstance()->m_mapAttrSetting.end()) {
        /*û���ҵ�����������*/
        return -3;
    }
    return setAttrValue<DataType, adt, pSetFuncType>(pairAttrType->second, value);
}
