#include "UIXmlConfig.h"
#include "DataInfoNode.h"
#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(UIXmlConfig, 1, 2);
#pragma region "����ע��"
    //NODEBASE_ATTR_REGISTER("name", Name, UITexture, STR);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(UIXmlConfig)
    //NBSCRIPT_ATTR_REGISTER("name", Name, UITexture, STR);
NODETYPE_COMMON_PART_DEFINITION_END

void UIXmlConfig::addKeySubject(UIKeySubject* pKeySubject) {
    auto key = pKeySubject->getXml();
    const auto& pairKeySubject = m_mapKeySubject.find(key);
    if (pairKeySubject != m_mapKeySubject.end()) {
		pairKeySubject->second->releaseObject();
        if (pKeySubject != nullptr) {
			pairKeySubject->second = pKeySubject;
        } else {
			m_mapKeySubject.erase(pairKeySubject);
        }
    } else {
        if (pKeySubject != nullptr) {
			m_mapKeySubject.insert(key, pKeySubject);
        }
    }
}

int UIXmlConfig::addDataChild(DataInfoNode& childData) {
    int ret = Base::addDataChild(childData);
    if (ret < 0) {
        if (ObjectBase::is(childData.m_objType, NT_UIKeySubject)) {
			addKeySubject((UIKeySubject*)ObjectBase::createObject(childData));
            ret = NT_UIKeySubject;
        }
    }
    return ret;
}

void UIXmlConfig::loadXmlConfigInfo() {
	for (auto pairKeySubject : m_mapKeySubject) {
		auto pKeySubject = pairKeySubject.second;
        if (!pKeySubject) {
            continue;
        }
		if (pKeySubject->getPriority() >= 0) {
			DataManager::getInstance()->xmlPriorityConfig.insert(pKeySubject->getXml(), pKeySubject->getPriority());
		}
		if (pKeySubject->getIsNonEvent()) {
			DataManager::getInstance()->xmlNoneventConfig.insert(pKeySubject->getXml(), pKeySubject->getIsNonEvent());
		}
		if (pKeySubject->getIsBag()) {
			DataManager::getInstance()->refreshBagItemXmlList.push_back(pKeySubject->getXml());
		}
		if (pKeySubject->getCanMoveRole()) {
			DataManager::getInstance()->canMoveRoleXmlList.push_back(pKeySubject->getXml());
		}
		if (pKeySubject->getCurrency() != "") {
			DataManager::getInstance()->currencyXmlList.insert(pKeySubject->getXml(), pKeySubject->getCurrency());
		}
		if (pKeySubject->getCanShowFloat()) {
			DataManager::getInstance()->canShowFloatXmlList.insert(pKeySubject->getXml(), pKeySubject->getCanShowFloat());
		}
	}
}