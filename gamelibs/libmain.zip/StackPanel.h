#pragma once
#include "UIComponent.h"
#include "ContainerComponent.h"
#include "Control.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class StackPanel : public ContainerComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(StackPanel);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(StackPanel, ContainerComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static wstring s_tmpDirectionAttrList;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    ArrayList<vec2> m_childrenPosition;
    Control* m_selectControl;
private:
    //�м��(y)
    ft mt_dataRowSpacing = 0.f;
    //�м��(x)
    ft mt_dataColumnSpacing = 0.f;
    //����
    friend class WrapPanel;
    friend class AutoGrid;
    u8 mt_dataDirection = DDR_TL;
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    ft getDataRowSpacing() const;
    void setDataRowSpacing(ft value);
    ft getDataColumnSpacing() const;
    void setDataColumnSpacing(ft value);
    int getDataDirection() const;
    virtual void setDataDirection(int value);
public:
    u8 getSingleDirection() const;
    //�Ƿ��Ⱥ�������
    virtual bool getIsHorizontal() const;
    //�Ƿ������ٺᡣ
    virtual bool getIsVertical() const;
    virtual bool getIsLeft() const;
    virtual bool getIsTop() const;
#pragma endregion
public:
    StackPanel& assign(const StackPanel& other);
public:
    virtual const Border& getChildArea(const Control* pChild) const override;
    virtual void setChildrenOffsetY();
    void setSelectControl(Control * value);
    Control* getSelectControl() const;
public:
    virtual void onPrepareData() override;
    virtual void onTransformChildren(unsigned char drawStep) override;
    virtual bool onDrawChildren(unsigned char drawStep, bool isReDraw) override; 
};

_SSUINamespaceEnd
