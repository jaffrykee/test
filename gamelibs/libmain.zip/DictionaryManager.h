#pragma once
#include "ssuiBasic.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

//һ����̬��
class DictionaryManager {
#pragma region "��̬��Ա"
public:
    static string s_className;
    static DictionaryManager* s_pInstance;
#pragma endregion

#pragma region "��̬����"
public:
    inline static DictionaryManager* getInstance() {
        if (s_pInstance == nullptr) {
            s_pInstance = new DictionaryManager();
        }
        return s_pInstance;
    }
    static void initialize();
    static void destroy();
    static void registerReflection(int id);

    template<class TypeIn, class TypeOut, size_t Count>
    inline static void RegisterWordRow(TypeIn(&arr)[Count], HashMap<TypeIn, int>& map, TypeOut& outStr) {
        int i = 0;
        map.clear();
        outStr.clear();
        for (const auto& rowName : arr) {
            map.insert(rowName, i);
            outStr += TypeOut(rowName.c_str());
            outStr += '%';
            i++;
        }
        outStr.pop_back();
    }
    template<class TypeIn, class TypeOut, size_t Count>
    inline static void RegisterWordRowWithNumValue(TypeIn(&arr)[Count], HashMap<TypeIn, int>& map, TypeOut& outStr) {
        int i = 0;
        map.clear();
        outStr.clear();
        for (const auto& rowName : arr) {
            map.insert(rowName, i);
            outStr += util::itoa_s(i);
            outStr += '^';
            outStr += TypeOut(rowName.c_str());
            outStr += '%';
            i++;
        }
        outStr.pop_back();
    }
    template<class TypeIn, size_t Count>
    inline static void RegisterWordRow(TypeIn(&arr)[Count], HashMap<TypeIn, int>& map) {
        int i = 0;
        map.clear();
        for (const auto& rowName : arr) {
            map.insert(rowName, i);
            i++;
        }
    }
#pragma endregion

#pragma region "��Ա"
public:
    string m_arrEventType[ET_MAX];
    HashMap<string, int> m_mapEventType;
    wstring m_arrAttrSubType[AST_MAX];
    HashMap<wstring, int> m_mapAttrSubType;
    string m_arrSlotType[SLOT_MAX];
    HashMap<string, int> m_mapSlotType;
    string m_arrStateValue[STATE_MAX];
    HashMap<string, int> m_mapStateValue;
    string m_arrCsvAttrType[CAT_MAX];
    HashMap<string, int> m_mapCsvAttrType;
    string m_arrTimeOrder[TO_MAX];
    HashMap<string, int> m_mapTimeOrder;
    string m_arrTimeType[TimeDigit_MAX];
    HashMap<string, int> m_mapTimeType;
    string m_arrProgressDirection[SLOT_MAX];
    HashMap<string, int> m_mapProgressDirection;
    string m_arrClipType[ClipType_max];
    HashMap<string, int> m_mapClipType;
#pragma endregion

#pragma region "����"
public:
    DictionaryManager();
#pragma endregion
};

_SSUINamespaceEnd
