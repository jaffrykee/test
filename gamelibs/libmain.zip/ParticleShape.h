#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ParticleShape : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ParticleShape)
protected:
	virtual void createSelf() override;
	virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(ParticleShape, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    string mt_particleName = "";
    s32 mt_playCount;
    f32 mt_particleScaleX = 1.f;
    f32 mt_particleScaleY = 1.f;
    f32 mt_particleScaleZ = 1.f;
    f32 mt_angleX = 0.f;
    f32 mt_angleY = 0.f;
    f32 mt_angleZ = 0.f;
    Entity parEntity = null;
	b2 mt_isRefresh = false;

    vec3 m_innerScale = vec3(1.0f, 1.0f, 1.0f);
    vec3 m_innerRotation = vec3::zero;
    vec3 m_innerWorldPosition = vec3::zero;
#pragma endregion
#pragma region "���Է���"
public:
    const string& getDataParticleName() const;
    void setDataParticleName(const string& value);
    int getDataPlayCount() const;
    void setDataPlayCount(int value);
    ft getDataParticleScaleX() const;
    void setDataParticleScaleX(ft value);
    ft getDataParticleScaleY() const;
    void setDataParticleScaleY(ft value);
    ft getDataParticleScaleZ() const;
    void setDataParticleScaleZ(ft value);
    ft getDataAngleX() const;
    void setDataAngleX(ft value);
    ft getDataAngleY() const;
    void setDataAngleY(ft value);
    ft getDataAngleZ() const;
    void setDataAngleZ(ft value);
#pragma endregion
#pragma region "����"
public:
    vec3 getUIPos2Pos();
	void onRefreshChange();
    ParticleShape& assign(const ParticleShape& other);
public:
    virtual void onShow() override;
#pragma endregion
};

_SSUINamespaceEnd
