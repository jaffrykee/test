#pragma once
#include "ObjectBase.h"
#include "Skin.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class SkinGroup;
class SkinRow : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(SkinRow);
protected:
    virtual void createSelf() override;
    virtual void disposeSelf() override;
    NODETYPE_COMMON_PART_DECLARATION_END(SkinRow, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
    static SkinRow* createObject(SkinGroup* pSkinGroup, string name);
#pragma endregion

#pragma region "��Ա"
public:
    HashMap<s64, Skin*> m_mapLanguageThemeSkin;
    Skin* m_pCurSkin = nullptr;
    SkinGroup* m_pSkinGroup = nullptr;
private:
    string mt_name;
#pragma endregion

#pragma region "����"
public:
    inline SkinRow& assign(const SkinRow& other) {
        Base::assign(other);
        assert(false);
        return *this;
    }
public:
    const string& getName() const {
        return mt_name;
    }
    void addSkin(Skin* pSkin, const string& lang = StringManager::getInstance()->mc_strNullDef, const string& theme = StringManager::getInstance()->mc_strNullDef);
    Skin* getSkin(const string& lang, const string& theme);
    void refreshCurSkin();
#pragma endregion
};

_SSUINamespaceEnd
