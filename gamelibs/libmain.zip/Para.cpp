#include "Para.h"
#include "FlowElement.h"
#include "BasicContent.h"
#include "BasicMeasure.h"
#include "MeasureData.h"
#include "Control.h"
#include "UIComponent.h"
#include "TextFlow.h"
#include "TextShape.h"
#include "DataHeaders.h"

ArrayList<wstring> Para::s_tmpSplitList;
ArrayList<wstring> Para::s_tmpSplitList2;
ArrayList<wstring> Para::s_tmpSplitList3;
string Para::s_tmpSkinName;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Para, 100, 500);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(Para)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::Para::rebuild(const wstring& text, string& lastSkinName, u8& lastSlot, u8& lastState) {
    releaseChildren();
    if (text.empty() == true) {
        return;
    }
    ft lineWidth = getHost()->getInnerMeasure().m_srcArea.width();
    s_tmpSplitList.clear();
    util::split(text, StringManager::getInstance()->mc_wcOpenBracket, s_tmpSplitList);
    if (text.at(0) != StringManager::getInstance()->mc_wcOpenBracket) {
        for (auto& c : s_tmpSplitList[0]) {
            auto pCtrl = Control::createObject(CCIT_e::CCIT_FlowElement);
            pCtrl->setSkinName(lastSkinName);
            if (getHost()->getParentComponent() && static_cast<TextFlow*>(getHost()->getParentComponent())->getIsPassword()) {
                pCtrl->enableBasicContent()->setTextWithChar(StringManager::getInstance()->mc_wcPasswordChar);
            }else {
                pCtrl->enableBasicContent()->setTextWithChar(c);
            }
            auto pMComp = (BasicMeasure*)pCtrl->getComponent(NT_BasicMeasure);
            if (pMComp != nullptr) {
                pMComp->setIsAutoWidth(true);
                pMComp->setIsAutoHeight(true);
            }
            addChild(pCtrl);
            auto pFe = (FlowElement*)pCtrl->getComponentByClass(NT_FlowElement);
            if (pFe != nullptr) {
                pFe->m_curSlot = lastSlot;
                pFe->m_curState = lastState;
                pCtrl->touchPrepareDataChanged();
            }
        }
    }
    const string* pSkinName = nullptr;
    int state;
    int slot;
    for (int i = 1; i < s_tmpSplitList.size(); i++) {
        wstring scriptStr;
        scriptStr.clear();
        s_tmpSplitList2.clear();
        util::split(s_tmpSplitList[i], StringManager::getInstance()->mc_wcCloseBracket, s_tmpSplitList2);
        if (s_tmpSplitList2.empty() == true) {
            continue;
        }
        if (s_tmpSplitList2.size() == 1) {
            s_tmpSplitList2[0].insert(s_tmpSplitList2[0].begin(), StringManager::getInstance()->mc_wcOpenBracket);
            for (auto& c : s_tmpSplitList2[0]) {
                auto pCtrl = Control::createObject(CCIT_e::CCIT_FlowElement);
                pCtrl->setSkinName(lastSkinName);
                if(getHost()->getParent() && getHost()->getParent()->getIsPassword()){
                    pCtrl->enableBasicContent()->setTextWithChar(StringManager::getInstance()->mc_wcPasswordChar);
                }else {
                    pCtrl->enableBasicContent()->setTextWithChar(c);
                }
                auto pMComp = (BasicMeasure*)pCtrl->getComponent(NT_BasicMeasure);
                if (pMComp != nullptr) {
                    pMComp->setIsAutoWidth(true);
                    pMComp->setIsAutoHeight(true);
                }
                addChild(pCtrl);
                auto pFe = (FlowElement*)pCtrl->getComponentByClass(NT_FlowElement);
                if (pFe != nullptr) {
                    pFe->m_curSlot = lastSlot;
                    pFe->m_curState = lastState;
                    pCtrl->touchPrepareDataChanged();
                }
            }
            continue;
        }
        state = 0xff;
        slot = 0xff;
        s_tmpSplitList3.clear();
        util::split(s_tmpSplitList2[0], StringManager::getInstance()->mc_wcPeriod, s_tmpSplitList3);
        auto psize = s_tmpSplitList3.size();
        if (psize <= 0) {
            pSkinName = &getHost()->getSkinName();
        } else {
            if (!pSkinName) {
                getHost()->addBeforeSkinName(getHost()->getSkinName());
            }else if(!(*pSkinName).empty()){
                getHost()->addBeforeSkinName(*pSkinName);
            }
            if (s_tmpSplitList3[0] == StringManager::getInstance()->mc_wstrDefault) {
                pSkinName = &getHost()->getSkinName();
            }else if (s_tmpSplitList3[0] == StringManager::getInstance()->mc_wstrBefore) {
                pSkinName = &getHost()->getBeforeSkinName(*pSkinName);
            }else if (s_tmpSplitList3[0] == StringManager::getInstance()->mc_wstrLinkSkin && getHost()->getParentComponent() &&
                static_cast<TextFlow*>(getHost()->getParentComponent())->getLinkSkin().empty() == false) {
                pSkinName = &static_cast<TextFlow*>(getHost()->getParentComponent())->getLinkSkin();
            }
            else {
                StringManager::wstringToString(s_tmpSplitList3[0], s_tmpSkinName);
                pSkinName = &s_tmpSkinName;
            }
            if (psize >= 2) {  /*[skin.slot.state.@;script;arg0;arg1;arg2...]*/
                slot = util::atoi_s(s_tmpSplitList3[1]);
                if (psize >= 3) {
                    state = util::atoi_s(s_tmpSplitList3[2]);
                }
                if (psize >= 4) {
                    wstring linkWstr = s_tmpSplitList3[3];
                    if (!linkWstr.empty() && linkWstr[0] == StringManager::getInstance()->mc_wcTextFlowScript) {
                        for (s32 k = 4; k < s_tmpSplitList3.size(); k++) {
                            linkWstr += ".";
                            linkWstr += s_tmpSplitList3[k];
                        }
                        ArrayList<wstring> its;
                        util::split(linkWstr, StringManager::getInstance()->mc_wcSkinSep, its);
                        if (its.size() >= 2) {
                            scriptStr = its[1];
                            for (s32 j = 2; j < its.size(); j++) {
                                scriptStr += " ";
                                scriptStr += its[j];
                            }
                        }
                        
                    }
                }
            }
        }
        if (pSkinName == nullptr) {
            pSkinName = &StringManager::getInstance()->mc_strNullDef;
        }
        if (s_tmpSplitList2.size() >= 2 && !s_tmpSplitList2[1].empty()) {
            for (auto& c : s_tmpSplitList2[1]) {
                auto pCtrl = Control::createObject(CCIT_e::CCIT_FlowElement);
                pCtrl->setSkinName(*pSkinName);
                if (getHost()->getParentComponent() && static_cast<TextFlow*>(getHost()->getParentComponent())->getIsPassword()) {
                    pCtrl->enableBasicContent()->setTextWithChar(StringManager::getInstance()->mc_wcPasswordChar);
                } else {
                    pCtrl->enableBasicContent()->setTextWithChar(c);
                }
                auto pMComp = (BasicMeasure*)pCtrl->getComponent(NT_BasicMeasure);
                if (pMComp != nullptr) {
                    pMComp->setIsAutoWidth(true);
                    pMComp->setIsAutoHeight(true);
                }
                addChild(pCtrl);
                auto pFe = (FlowElement*)pCtrl->getComponentByClass(NT_FlowElement);
                if (pFe != nullptr) {
                    if (!scriptStr.empty()) {
                        pFe->setIsTouchComponent(true);
                        pCtrl->setControlScript(ET_Click, scriptStr);
                        pCtrl->setCanTransScript(true);
                        pCtrl->setCanTransHandle(true);
                        static_cast<TextFlow*>(getHost()->getParentComponent())->setIsTouchComponent(true);
                    }
                    pFe->m_curSlot = slot;
                    pFe->m_curState = state;
                    pCtrl->touchPrepareDataChanged();
                }
            }
        }
//         else {
//             auto pCtrl = Control::createObject(CCIT_e::CCIT_FlowElement);
//             pCtrl->setSkinName(*pSkinName);
//             pCtrl->enableBasicContent()->setText("");
//             auto pMComp = (BasicMeasure*)pCtrl->getComponent(NT_BasicMeasure);
//             if (pMComp != nullptr) {
//                 pMComp->setIsAutoWidth(true);
//                 pMComp->setIsAutoHeight(true);
//             }
//             addChild(pCtrl);
//             auto pFe = (FlowElement*)pCtrl->getComponentByClass(NT_FlowElement);
//             if (pFe != nullptr) {
//                 pFe->m_curSlot = slot;
//                 pFe->m_curState = state;
//                 pCtrl->touchPrepareDataChanged();
//             }
//         }
    }
    if (pSkinName != nullptr) {
        lastSkinName = *pSkinName;
        lastSlot = slot;
        lastState = state;
    }
    getHost()->touchPrepareDataChanged();
}
void ssui::Para::onRender(unsigned char drawStep) {
    Base::onRender(drawStep);
    m_mapAreaInfo.clear();
}
void ssui::Para::getMinAndMaxPos(s32 lineNo, vec3& minPos, vec3& maxPos) {
    if (container().empty())
        return;
    b2 isModify = false;
    auto it = m_mapAreaInfo.find(lineNo);
    if (it != m_mapAreaInfo.end()) {
        if (!it->second.m_isSetTextArea) {
            isModify = true;
        }
    } else {
        isModify = true;
    }
    if (isModify) {
        T_AreaInfo t_info;
        for (auto& pChild : *this) {
            auto pFlowComp = (FlowElement*)pChild->getComponentByClass(NT_FlowElement);
            if (pFlowComp && pFlowComp->getLineNo() == lineNo) {
                for (auto pShapeCtrl : *pFlowComp) {
                    auto pTextShape = (TextShape*)pShapeCtrl->getComponentByClass(NT_TextShape);
                    if (pTextShape) {
                        (pTextShape)->getMinAndMaxPos(t_info.m_minTextPos, t_info.m_maxTextPos);
                    }
                }
            }
        }
        t_info.m_isSetTextArea = true;
        if (it != m_mapAreaInfo.end()) {
            it->second.m_isSetTextArea = true;
            it->second.m_minTextPos = t_info.m_minTextPos;
            it->second.m_maxTextPos = t_info.m_maxTextPos;
        }
        else {
            m_mapAreaInfo.insert(lineNo, t_info);
        }
    }
     it = m_mapAreaInfo.find(lineNo);
    if (it != m_mapAreaInfo.end()) {
        minPos.y = it->second.m_minTextPos.y;
        maxPos.y = it->second.m_maxTextPos.y;
    }
}
