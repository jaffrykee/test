#pragma once
#include "UIComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class ImageShape : public UIComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(ImageShape);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(ImageShape, UIComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    float mt_gray = 0.0f;
    strHash mt_textureKey;
    strHash mt_subImageKey;
#pragma endregion

#pragma region "����"
public:
    ImageShape& assign(const ImageShape& other);
public:
    float getGray( ) const;
    void setGray( float value );
    int getTextureKey() const;
    int getSubImageKey() const;
    const string& getImageName() const;
    void setImageName(const string& value);
    virtual ParentAreaType_e getParentAreaType() const override;
public:
    virtual void onRender(unsigned char drawStep) override;
    virtual void onShow();
#pragma endregion
};

_SSUINamespaceEnd
