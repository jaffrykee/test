#pragma once
#include "ObjectBase.h"
#include "SkinRow.h"
#include "UITexture.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Skin;
class SkinGroup : public ObjectBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(SkinGroup);
protected:
    inline virtual void createSelf() override {
        //s_mapSkinGroup.insert(0, this);
    }
    inline virtual void disposeSelf() override {
        //s_mapSkinGroup.erase(mt_key);
        recoverSkinGroup();
        for (auto& pairSkinRow : m_mapSkinRow) {
            if (pairSkinRow.second != nullptr) {
                pairSkinRow.second->releaseObject();
            }
        }
    }
    NODETYPE_COMMON_PART_DECLARATION_END(SkinGroup, ObjectBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static HashMap<strHash, SkinGroup*> s_mapSkinGroup;
protected:
    static HashMap<strHash, SkinGroup*> s_mapUsingSkinGroup;
public:
    static HashMap<strHash, UITexture*> s_mapQuoteTexture;
#pragma endregion

#pragma region "��̬����"
public:
    static inline SkinGroup* createSkinGroup(const string& name) {
        auto pNew = createObject();
        pNew->setName(name);
        return pNew;
    }
    static SkinGroup* createSkinGroup(const string& sceneName, DataInfoNode& data);
    static void addQuoteTexture(const string& imageName);
public:
    inline static void clearCache() {
        SkinGroup::releaseAllSkinGroup();
        s_mapQuoteTexture.clear();
    }
    inline static void releaseAllSkinGroup() {
        for (auto& pairSkinGroup : s_mapSkinGroup) {
            pairSkinGroup.second->releaseObject();
        }
        s_mapSkinGroup.clear();
        s_mapUsingSkinGroup.clear();
    }
    //���ݱ仯������Ժ�������������ˢ������SkinGroup�µ�����SkinRow�ĵ�ǰƤ����
    inline static void refreshAllCurSkin() {
        for (auto& pairSkinGroup : s_mapSkinGroup) {
            for (auto& pairSkinRow : pairSkinGroup.second->m_mapSkinRow) {
                pairSkinRow.second->refreshCurSkin();
            }
        }
    }
    inline static SkinGroup* getSkinGroupByKey(int key) {
        auto pairSkinGroup = s_mapSkinGroup.find(key);
        if (pairSkinGroup != s_mapSkinGroup.end()) {
            return pairSkinGroup->second;
        }
        return nullptr;
    }
    inline static Skin* getCurSkinBySkinGroupKey(int skinGroupKey, int skinKey) {
        auto pairSkinGroup = s_mapSkinGroup.find(skinGroupKey);
        if (pairSkinGroup != s_mapSkinGroup.end()) {
            return pairSkinGroup->second->getCurSkin(skinKey);
        }
        return nullptr;
    }
    inline static void destroyFunc() {
        SkinGroup::clearCache();
    }
#pragma endregion

#pragma region "��Ա"
private:
    int mt_useCount = 0;
public:
    inline int getUseCount() const {
        return mt_useCount;
    }
    inline void increaseUseCount() {
        if (mt_useCount == 0) {
            useSkinGroup();
        }
        mt_useCount++;
    }
    inline void decreaseUseCount() {
        if (mt_useCount == 0) {
            return;
        }
        mt_useCount--;
        if (mt_useCount == 0) {
            recoverSkinGroup();
        }
    }
private:
    string mt_name;
public:
    //ռλ�á�
    inline const string& getName() const {
        return mt_name;
    }
    void setName(const string& value);
public:
    HashMap<int, SkinRow*> m_mapSkinRow;
#pragma endregion

#pragma region "����"
protected:
    //����һ��Ƥ���顣
    inline void useSkinGroup() {
        auto key = mt_name.empty() ? 0 : mt_name.hashCode();
        const auto& pairSkinGroup = s_mapUsingSkinGroup.find(key);
        if (pairSkinGroup == s_mapUsingSkinGroup.end()) {
            s_mapUsingSkinGroup.insert(key, this);
        }
        for (const auto& pairTexture : s_mapQuoteTexture) {
            pairTexture.second->increaseUseCount();
        }
    }
    //����һ��Ƥ���顣
    inline void recoverSkinGroup() {
        auto key = mt_name.empty() ? 0 : mt_name.hashCode();
        const auto& pairSkinGroup = s_mapUsingSkinGroup.find(key);
        if (pairSkinGroup != s_mapUsingSkinGroup.end()) {
            s_mapUsingSkinGroup.erase(key);
        }
        for (const auto& pairTexture : s_mapQuoteTexture) {
            pairTexture.second->decreaseUseCount();
        }
    }
    //ͨ��Ƥ�����õ�SkinRow��
    inline SkinRow* getSkinRow(const string& name) {
        if (!name.empty()) {
            const auto& pair = m_mapSkinRow.find(name.hashCode());
            if (pair != m_mapSkinRow.end()) {
                return pair->second;
            }
        }
        return nullptr;
    }
    //ͨ��Ƥ������HashCode�õ�SkinRow��
    inline SkinRow* getSkinRow(int key) {
        if (key != 0) {
            const auto& pair = m_mapSkinRow.find(key);
            if (pair != m_mapSkinRow.end()) {
                return pair->second;
            }
        }
        return nullptr;
    }
    //ͨ��Ƥ������hashCode�����Ժ�����õ�Ƥ��
    inline Skin* getSkin(int key, const string& language = 0, const string& theme = 0) {
        auto pRow = getSkinRow(key);
        return (pRow != nullptr) ? (pRow->getSkin(language, theme)) : nullptr;
    }
    //ͨ��Ƥ���������Ժ�����õ�Ƥ��
    inline Skin* getSkin(const string& name, const string& language = 0, const string& theme = 0) {
        return getSkin(name.hashCode(), language, theme);
    }
public:
    inline SkinGroup& assign(const SkinGroup& other) {
        Base::assign(other);
        assert(false);
        return *this;
    }
    virtual int addDataChild(DataInfoNode& childData) override;
    inline void addSkinFunc(const string& skinName, Skin* pSkin, const string& lang = StringManager::getInstance()->mc_strNullDef,
        const string& theme = StringManager::getInstance()->mc_strNullDef) {

        auto pSkinRow = getSkinRow(skinName);
        if (pSkinRow != nullptr) {
            pSkinRow->addSkin(pSkin, lang, theme);
        } else {
            const auto& pairRow = m_mapSkinRow.insert(skinName.hashCode(), SkinRow::createObject(this, skinName));
            pairRow->second->addSkin(pSkin, lang, theme);
        }
    }
    inline void addSkin(Skin* pSkin) {
        if (pSkin != nullptr) {
            addSkinFunc(*Skin::s_pTmpLastSkinName, pSkin, *Skin::s_pTmpLastLanguage, *Skin::s_pTmpLastTheme);
        }
    }
    inline void addSkinWithRefresh(Skin* pSkin) {
        addSkin(pSkin);
        refreshAllCurSkin();
    }
public:
    inline Skin* getCurSkin(int key) {
        auto pSkinRow = getSkinRow(key);
        return (pSkinRow != nullptr) ? (pSkinRow->m_pCurSkin) : nullptr;
    }
#pragma endregion
};

_SSUINamespaceEnd
