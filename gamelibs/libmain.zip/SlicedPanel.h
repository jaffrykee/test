#pragma once
#include "UIComponent.h"
#include "ContainerComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class SlicedPanel : public ContainerComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(SlicedPanel);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(SlicedPanel, ContainerComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
public:
    static ArrayList<Vpct_t> s_renderCache[9];
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    s16 m_slicedX;
    s16 m_slicedY;
    s16 m_outerWidth;
    s16 m_outerHeight;
    s16 m_innerWidth;
    s16 m_innerHeight;
#pragma endregion

#pragma region "����"
#pragma region "����"
public:
    int getSlicedX() const;
    void setSlicedX(int value);
    int getSlicedY() const;
    void setSlicedY(int value);

    //===============================================================
    int getInnerWidth() const;
    void setInnerWidth(int value);
    int getInnerHeight() const;
    void setInnerHeight(int value);

    //===============================================================
    int getOuterWidth() const;
    void setOuterWidth(int value);
    int getOuterHeight() const;
    void setOuterHeight(int value);
#pragma endregion
public:
    SlicedPanel& assign(const SlicedPanel& other);
    //��poiPos��srcLen��չ��dstLen��ͬʱ����lenPos��ƫ��
    ft extensionLen(ft poiPos, ft lenPos, ft srcLen, ft dstLen);
    void onSliceFunc(Control* pNode);
    virtual void onRender(unsigned char drawStep) override;
#pragma endregion
};

_SSUINamespaceEnd
