#include "TextFlow.h"
#include "Control.h"
#include "Skin.h"
#include "ShapeGroup.h"
#include "Para.h"
#include "BasicContent.h"
#include "BasicMeasure.h"
#include "Geometry.h"
#include "UIManager.h"
#include "DataHeaders.h"

ArrayList<wstring> TextFlow::s_tmpSplitList;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(TextFlow, 20, 100);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("textAx", TextAx, TextFlow, F32);
NODEBASE_ATTR_REGISTER("textAy", TextAy, TextFlow, F32);
NODEBASE_ATTR_REGISTER("textRx", TextRx, TextFlow, S32);
NODEBASE_ATTR_REGISTER("textRy", TextRy, TextFlow, S32);
NODEBASE_ATTR_REGISTER("textAnchorRx", TextAnchorRx, TextFlow, S32);
NODEBASE_ATTR_REGISTER("textAnchorRy", TextAnchorRy, TextFlow, S32);
NODEBASE_ATTR_REGISTER("textTips", TextTips, TextFlow, WSTR, AST_normal);
NODEBASE_ATTR_REGISTER("curConvertIndex", CurConvertIndex, TextFlow, S32, AST_normal);
NODEBASE_ATTR_REGISTER("linkSkin", LinkSkin, TextFlow, STR, AST_normal);
NODEBASE_ATTR_REGISTER("isSingleLine", IsSingleLine, TextFlow, B2);
NODEBASE_ATTR_REGISTER("isPassword", IsPassword, TextFlow, B2);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(TextFlow)
NBSCRIPT_ATTR_REGISTER("textAx", TextAx, TextFlow, F32);
NBSCRIPT_ATTR_REGISTER("textAy", TextAy, TextFlow, F32);
NBSCRIPT_ATTR_REGISTER("textRx", TextRx, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("textRy", TextRy, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("textAnchorRx", TextAnchorRx, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("textAnchorRy", TextAnchorRy, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("textTips", TextTips, TextFlow, WSTR);
NBSCRIPT_ATTR_REGISTER("curConvertIndex", CurConvertIndex, TextFlow, S32);
NBSCRIPT_ATTR_REGISTER("linkSkin", LinkSkin, TextFlow, STR);
NBSCRIPT_ATTR_REGISTER("isSingleLine", IsSingleLine, TextFlow, B2);
NBSCRIPT_ATTR_REGISTER("isPassword", IsPassword, TextFlow, B2);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(TextFlow, TextAx, ft)
UIComponent_ControlAttr_Def(TextFlow, TextAy, ft)
UIComponent_ControlAttr_Def(TextFlow, TextRx, s32)
UIComponent_ControlAttr_Def(TextFlow, TextRy, s32)
UIComponent_ControlAttr_Def(TextFlow, TextAnchorRx, s32)
UIComponent_ControlAttr_Def(TextFlow, TextAnchorRy, s32)
UIComponent_ControlAttr_Def_STR(TextFlow, TextTips, wstring)
UIComponent_ControlAttr_Def(TextFlow, CurConvertIndex, s32)
UIComponent_ControlAttr_Def_STR(TextFlow, LinkSkin, string)
UIComponent_ControlAttr_Def(TextFlow, IsSingleLine, b2)
UIComponent_ControlAttr_Def(TextFlow, IsPassword, b2)
#pragma endregion

void ssui::TextFlow::createSelf() {

}

void TextFlow::disposeSelf() {
    for (auto& pChild : m_container) {
        pChild->releaseObject();
    }
    m_container.clear();
}

TextFlow& ssui::TextFlow::assign(const TextFlow& other) {
    m_textTips = other.m_textTips;
    m_isPassword = other.m_isPassword;
    mt_curConvertIndex = other.mt_curConvertIndex;
    m_linkSkin = other.m_linkSkin;
    Base::assign(other);
    return *this;
}

bool ssui::TextFlow::isContainerComponent() const {
    return false;
}

const ArrayList<SlotType_e>& ssui::TextFlow::getSlotList() const {
    return getSlotListDef(SLOT_body);
}

ssui::ft ssui::TextFlow::getTextAx() const {
    return m_textAx;
}

void ssui::TextFlow::setTextAx(ft value) {
    if (m_textAx != value) {
        m_textAx = value;
        getHost()->touchPrepareDataChanged();
    }
}
ft ssui::TextFlow::getTextAy() const {
    return m_textAy;
}
void ssui::TextFlow::setTextAy(ft value) {
    if (m_textAy != value) {
        m_textAy = value;
        getHost()->touchPrepareDataChanged();
    }
}
int ssui::TextFlow::getTextRx() const {
    return m_textRx;
}
void ssui::TextFlow::setTextRx(int value) {
    if (m_textRx != value) {
        m_textRx = value;
        getHost()->touchPrepareDataChanged();
    }
}
int ssui::TextFlow::getTextRy() const {
    return m_textRy;
}
void ssui::TextFlow::setTextRy(int value) {
    if (m_textRy != value) {
        m_textRy = value;
        getHost()->touchPrepareDataChanged();
    }
}
int ssui::TextFlow::getTextAnchorRx() const {
    return m_textAnchorRx;
}
void ssui::TextFlow::setTextAnchorRx(int value) {
    if (m_textAnchorRx != value) {
        m_textAnchorRx = value;
        getHost()->touchPrepareDataChanged();
    }
}
int ssui::TextFlow::getTextAnchorRy() const {
    return m_textAnchorRy;
}
void ssui::TextFlow::setTextAnchorRy(int value) {
    if (m_textAnchorRy != value) {
        m_textAnchorRy = value;
        getHost()->touchPrepareDataChanged();
    }
}

s32 ssui::TextFlow::getCurConvertIndex() const {
    return mt_curConvertIndex;
}
void ssui::TextFlow::setCurConvertIndex(s32 value) {
    if (mt_curConvertIndex != value) {
        mt_curConvertIndex = value;
        getHost()->touchPrepareDataChanged();
    }
}
const string& ssui::TextFlow::getLinkSkin() const {
    return m_linkSkin;
}
void ssui::TextFlow::setLinkSkin(const string& value) {
    if (m_linkSkin != value) {
        m_linkSkin = value;
        getHost()->touchPrepareDataChanged();
    }
}
void ssui::TextFlow::setTextTips(const wstring& tipsText) {
    if (m_textTips != tipsText) {
        m_textTips = tipsText;
        getHost()->touchPrepareDataChanged();
    }
}
const wstring& ssui::TextFlow::getTextTips() const {
    return m_textTips;
}
b2 ssui::TextFlow::getIsPassword() const {
    return m_isPassword;
}
void ssui::TextFlow::setIsPassword(b2 value) {
    if (m_isPassword != value) {
        m_isPassword = value;
        getHost()->touchPrepareDataChanged();
    }
}
b2 ssui::TextFlow::getIsSingleLine() const {
    return m_isSingleLine;
}
void ssui::TextFlow::setIsSingleLine(b2 value) {
    if (m_isSingleLine != value) {
        m_isSingleLine = value;
        getHost()->touchPrepareDataChanged();
    }
}
bool ssui::TextFlow::isTouchComponent() const {
    return m_isTouchComp;
}
void ssui::TextFlow::setIsTouchComponent(b2 value) {
    m_isTouchComp = value;
}
void ssui::TextFlow::setChildrenOffsetY() {
    if (getTextAnchorRy() <= 0 && getTextRy() <= 0) {
        return;
    }
    mt_childrenOffsetY = 0;
    const auto& selfArea = getMeasure(PAT_inner).m_srcArea;
    auto selfHeight = selfArea.m_bottom - selfArea.m_top;
    Border tmpAabb;
    Border t_childAabb;
    for (auto& pChild : *this) {
        const auto& pChildGeo = pChild->getOuterMeasure().m_pTransGeo;
        if (pChildGeo != nullptr) {
            pChildGeo->getBorder(tmpAabb);
            if (t_childAabb == Border(0, 0, 0, 0)) {
                t_childAabb = tmpAabb;
            }else {
                t_childAabb |= tmpAabb;
            }
        }
    }
    mt_childrenOffsetY = selfHeight* SSUIMath::restorePct(getTextRy()) - t_childAabb.height() * SSUIMath::restorePct(getTextAnchorRy()) ;
    if (!math::equalZero(mt_childrenOffsetY, 0.01f)) {
        for (auto& pChild : *this) {
            applyTransformToSelfChildGrandChildAndSoOn(pChild, 0, mt_childrenOffsetY);
        }
    }
}
void ssui::TextFlow::onPrepareData() {
    Base::onPrepareData();
    rebuild();
}

void TextFlow::rebuild() {
    releaseChildren();
    auto pText = getHost()->enableBasicContent()->getShowText();
    if (pText == nullptr) {
        return;
    }
    rebuild(*pText);
}

void TextFlow::rebuild(const wstring& text) {
    wstring showText = text;
    u8 lastSlot = 0xff;
    u8 lastState = 0xff;
    if (showText.empty()) {
        showText = getTextTips();
        lastSlot = SLOT_tips;
    }
    convertChatFace(getCurConvertIndex(), showText);
    s_tmpSplitList.clear();
    util::split(showText, StringManager::getInstance()->mc_wcTextFlowEnter, s_tmpSplitList);
    auto lastSkinName = getHost()->getSkinName();
    for (const auto& subText : s_tmpSplitList) {
        auto pCtrl = Control::createObject(CCIT_Para);
        addChild(pCtrl);
        pCtrl->setSkinName(getHost()->getSkinName());
        auto pMComp = (BasicMeasure*)pCtrl->getComponent(NT_BasicMeasure);
        if (pMComp != nullptr) {
            pMComp->setIsAutoHeight(true);
            pMComp->setAx(getTextAx());
            pMComp->setAy(getTextAy());
            pMComp->setRx(getTextRx());
            pMComp->setAnchorRx(getTextAnchorRx());
            if (getHost()->getBasicMeasure() && getHost()->getBasicMeasure()->getIsAutoWidth() || getTextRx() > 0 ||
                getTextAnchorRx() > 0 ) {
                pMComp->setIsAutoWidth(true);
            }else {
                pMComp->setRw(100);
            }
        }
        auto pPara = (Para*)pCtrl->getComponent(NT_Para);
        pPara->rebuild(subText, lastSkinName, lastSlot, lastState);
    }
    getHost()->touchPrepareDataChanged();
}

void TextFlow::convertChatFace(s32 index, wstring& cText) {
    for (const auto& pairReplace : UIManager::s_replaceString[index]) {
        cText.replace(pairReplace.first, pairReplace.second);
    }
}