#pragma once
#include "ssuiBasic.h"
#include "NodeManager.h"

_SSUINamespaceBegin

using CCIT_e = enum ControlCompInfoType_e : s8 {
    CCIT_NULL = -1,
    CCIT_Panel = 0,
    CCIT_Label,
    CCIT_Button,
    CCIT_Radio,
    CCIT_Check,
    CCIT_SkillButton,
    CCIT_InputBox,
    CCIT_TextFlow,
    CCIT_Progress,
    CCIT_VirtualJoystick,
    CCIT_TimeBlock,
	CCIT_UIDrawModel,
    CCIT_ImageShape,
    CCIT_TextShape,
    CCIT_ParticleShape,
    
    //=================
    CCIT_StackPanel,
    //==================
    //==================
    CCIT_Para,
    CCIT_FlowElement,
    CCIT_Grid,
    CCIT_WrapPanel,
    CCIT_AutoGrid,
    CCIT_SlicedPanel,
    //==================
    CCIT_MAX,
};

class ElementSetting;
class AttrSetting;
class UIScene;
class DataInfoNode;
class SkinGroup;
class UITexture;
class NodeTypeSetting;
class NameSpaceSetting;
class DataManager : public BoloObject {
#pragma region "��������"
    typedef struct CcitData_s {
        CCIT_e m_id;
        ArrayList<NodeType_e> m_data;
        ElementSetting* m_pEs = nullptr;

        inline void addComps(NodeType_e compType, ...) {
            //http://blog.csdn.net/weiwangchao_/article/details/4857567
            va_list args;
            va_start(args, compType);
            int curComp = compType;
            if (curComp != NT_MAX) {
                m_data.push_back((NodeType_e)curComp);
                while (1) {
                    curComp = va_arg(args, int);
                    if (curComp == NT_MAX) {
                        break;
                    }
                    m_data.push_back((NodeType_e)curComp);
                }
            }
            va_end(args);
        }

        double sum(unsigned int n, ...) {
            double sum = 0;
            va_list args;//����һ���ɱ�����б�  
            va_start(args, n);//��ʼ��argsָ��ǿ�Ʋ���arg����һ������  
            while (n > 0) {
                //ͨ��va_arg(args, double)���λ�ȡ������ֵ  
                sum += va_arg(args, double);
                n--;
            }
            va_end(args);//�ͷ�args  
            return sum;
        }
    }CcitData_t;
#pragma endregion

#pragma region "��̬��Ա"
public:
    static string s_className;
    static DataManager* s_pInstance;
#pragma endregion

#pragma region "��̬����"
public:
    inline static DataManager* getInstance() {
        if (s_pInstance == nullptr) {
            s_pInstance = new DataManager();
        }
        return s_pInstance;
    }
    static void initialize();
    static void destroy();
    static void registerReflection(int id);
#pragma endregion

#pragma region "��Ա"
public:
    LinkedHashMap<wstrHash, NameSpaceSetting*> m_lmapNameSpaceSetting;
    //��¼������NodeTypeSetting(NodeType)
    NodeTypeSetting* m_arrNodeTypeSetting[NT_MAX] = {nullptr};
    HashMap<wstrHash, NodeTypeSetting*> m_mapNodeTypeSetting;
    //����������Ϣ������index��AttrType_e
    AttrSetting* m_arrAttrSetting[AT_MAX] = {nullptr};
    HashMap<wstrHash, AttrSetting*> m_mapAttrSetting;
    //��¼�˿ؼ���Ԥ��������͡�
    CcitData_t m_ccitData[CCIT_MAX];
    //���е�Ԥ��ȡSceneģ�壬����UI��Դ��ʱ����Ҫ����clearCache������
    HashMap<string, DataInfoNode*> m_mapSceneTemplate;
    HashMap<string, DataInfoNode*> m_mapImageTemplate;

    //xmlConfg.xml
    DataInfoNode* m_xmlConfigTemplate = nullptr;    
    HashMap<string, s32> xmlPriorityConfig;
    HashMap<string, b2> xmlNoneventConfig;
    ArrayList<string> refreshBagItemXmlList;
    ArrayList<string> canMoveRoleXmlList;
    HashMap<string, string> currencyXmlList;
    HashMap<string, b2> canShowFloatXmlList;

    LinkedHashMap<wstrHash, CcitData_t*> m_lmapCcit;

    wstring m_tmpFileName;
    ArrayList<string> m_tmpArrSplit;
#pragma endregion

#pragma region "����"
public:
    inline DataManager() {
    }
    inline virtual ~DataManager() {
    }
    inline virtual const string& getClassName() const override {
        return DataManager::s_className;
    }
public:
    void clearCache();
    void loadXmlFromBuff(const string& fileName, const c8* pData, int size = -1);
    void loadXmlFromString(const string& fileName, const string& strData);
    void loadXmlFromQuoteSkinGroup(const string& fileName);
    void reloadAllUITexture();
    void loadXmlFromMsgData(const string& msgData);
    void loadXmlFromFile(const string& fileName, const string& exPack = "", bool isInMod = true);
    UIScene* loadUISceneFromTemplate(const string& fileName, bool isFindFromUpdate = false);
    SkinGroup* loadSkinGroupFromTemplate(const string& fileName);
    UITexture* loadUITextureFromTemplate(const string& fileName);
    void loadXmlConfigFromTemplate();
    void getFiles(ArrayList<string>& arrFiles, const string& path, const string& fix, bool isIterative);
    void preReadData();
    void preReadUIFileData(const string& fileName, const string& folder = "");
    void initSSUIFunc();
    void resetProjPath(const string& artistPath);
    void initCcitData();
    const std::bitset<NT_MAX>& getNodeInheritData(NodeType_e nt);
    ObjectBase* getInitNode(NodeType_e nodeType);
    void getAttrInitData(wstring& initData);
    void getNodeInitData(wstring& initData);
    void getLanguageSettingInitData(wstring& initData);
    NameSpaceSetting* getSSUINameSpace();
    NameSpaceSetting* getSSUIImageNameSpace();
    void getCcitName(string& ccitName, CCIT_e ccit);

    inline void regNodeAttrs(NodeType_e nodeType, AttrType_e attrType) {

    }
    void regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
        const NodeType_e& nodeType, boloClassGetFuncB2 getFunc, boloClassSetFuncB2 setFunc, const wstring& subType, bool isEnum = false);
    void regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
        const NodeType_e& nodeType, boloClassGetFuncS32 getFunc, boloClassSetFuncS32 setFunc, const wstring& subType, bool isEnum = false);
    void regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
        const NodeType_e& nodeType, boloClassGetFuncU32 getFunc, boloClassSetFuncU32 setFunc, const wstring& subType, bool isEnum = false);
    void regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
        const NodeType_e& nodeType, boloClassGetFuncF32 getFunc, boloClassSetFuncF32 setFunc, const wstring& subType, bool isEnum = false);
    void regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
        const NodeType_e& nodeType, boloClassGetFuncS64 getFunc, boloClassSetFuncS64 setFunc, const wstring& subType, bool isEnum = false);
    void regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
        const NodeType_e& nodeType, boloClassGetFuncString getFunc, boloClassSetFuncString setFunc, const wstring& subType, bool isEnum = false);
    void regAttrSetting(const AttrType_e& attrType, const wstring& attrName, const AttrDataType_e& dataType,
        const NodeType_e& nodeType, boloClassGetFuncWString getFunc, boloClassSetFuncWString setFunc, const wstring& subType, bool isEnum = false);
public:
    template <class TGetFunc, class TSetFunc>
    void regAttrFunc(const AttrType_e& attrType, const wstring& attrName,
        const AttrDataType_e& dataType, const NodeType_e& nodeType, TGetFunc getFunc, TSetFunc setFunc, const wstring& subType, bool isEnum = false) {
        using Type = typename remove_reference<typename function_traits<TGetFunc>::return_type>::Type;
        using GetFunc = typename MemberFuncTrait<Type>::GetFunc;
        using SetFunc = typename MemberFuncTrait<Type>::SetFunc;
        static_assert(!type_equal<GetFunc, void>::value, "property type not support!");
        static_assert(function_traits<TGetFunc>::isConst, "get function must be const!");
        regAttrSetting(attrType, attrName, dataType, nodeType, (GetFunc)getFunc, (SetFunc)setFunc, subType, isEnum);
    }
    template <class TGetFunc, class TSetFunc>
    void regAttrFunc(const AttrType_e& attrType, const wstring& attrName,
        const AttrDataType_e& dataType, const NodeType_e& nodeType, TGetFunc getFunc, TSetFunc setFunc, AttrSubType_e subType = AST_halfNormal, bool isEnum = false) {
        using Type = typename remove_reference<typename function_traits<TGetFunc>::return_type>::Type;
        using GetFunc = typename MemberFuncTrait<Type>::GetFunc;
        using SetFunc = typename MemberFuncTrait<Type>::SetFunc;
        static_assert(!type_equal<GetFunc, void>::value, "property type not support!");
        static_assert(function_traits<TGetFunc>::isConst, "get function must be const!");
        regAttrSetting(attrType, attrName, dataType, nodeType, (GetFunc)getFunc, (SetFunc)setFunc, DictionaryManager::getInstance()->m_arrAttrSubType[subType], isEnum);
    }
#pragma endregion
};

_SSUINamespaceEnd
