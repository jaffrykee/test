#pragma once
#include "WrapPanel.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class Para : public WrapPanel {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(Para);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(Para, WrapPanel);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
    static ArrayList<wstring> s_tmpSplitList;
    static ArrayList<wstring> s_tmpSplitList2;
    static ArrayList<wstring> s_tmpSplitList3;
    static string s_tmpSkinName;
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    typedef struct {
        b2 m_isSetTextArea = false;
        vec3 m_minTextPos = vec3::zero;
        vec3 m_maxTextPos = vec3::zero;
    } T_AreaInfo;
    HashMap<s32, T_AreaInfo> m_mapAreaInfo;
#pragma endregion

#pragma region "����"
public:
    inline Para& assign(const Para& other) {
        Base::assign(other);
        return *this;
    }
    void rebuild(const wstring& text, string& lastSkinName, u8& lastSlot, u8& lastState);
public:
    void getMinAndMaxPos(s32 lineNo, vec3& minPos, vec3& maxPos) ;
    virtual void onRender(unsigned char drawStep) override;
#pragma endregion
};

_SSUINamespaceEnd
