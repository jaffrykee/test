#pragma once
#include "NodeTypeSetting.h"
#include "NameSpaceSetting.h"
#include "ElementSetting.h"
#include "AttrSetting.h"
#include "DataInfoNode.h"
#include "DataInfoAttr.h"
