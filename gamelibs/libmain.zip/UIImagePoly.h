#pragma once
#include "UIImageBase.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

class UIImagePoly : public UIImageBase {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(UIImagePoly)
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(UIImagePoly, UIImageBase);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
private:
    ArrayList<vec2> m_poly;
    Border m_border;
#pragma endregion

#pragma region "����"
public:
    void addPoint(vec2 poi) {
        if (m_poly.empty()) {
            m_border.m_left = poi.x;
            m_border.m_top = poi.y;
            m_border.m_right = poi.x;
            m_border.m_bottom = poi.y;
        } else {
            if (poi.x < m_border.m_left) {
                m_border.m_left = poi.x;
            } else if (poi.x > m_border.m_right) {
                m_border.m_right = poi.x;
            }
            if (poi.y < m_border.m_top) {
                m_border.m_top = poi.y;
            } else if (poi.y > m_border.m_bottom) {
                m_border.m_bottom = poi.y;
            }
        }
        m_poly.push_back(poi);
    }
public:
    inline UIImagePoly& assign(const UIImagePoly& other) {
        Base::assign(other);
        return *this;
    }
    virtual void getPolyImageFromSize(PolyImage& polyImage, const Size& size, const vec4& color) override;
#pragma endregion
};

_SSUINamespaceEnd
