#include "Skin.h"
#include "SkinRow.h"
#include "Control.h"
#include "ShapeGroup.h"
#include "DataInfoNode.h"

#include "DataHeaders.h"

const string* Skin::s_pTmpLastSkinName = &StringManager::getInstance()->mc_strNullDef;
const string* Skin::s_pTmpLastLanguage = &StringManager::getInstance()->mc_strNullDef;
const string* Skin::s_pTmpLastTheme = &StringManager::getInstance()->mc_strNullDef;
ArrayList<string> Skin::s_tmpSplitSkinNameList;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Skin, 5000, 10000);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("name", Name, Skin, STR);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(Skin)
    NBSCRIPT_ATTR_REGISTER("name", Name, Skin, STR);
NODETYPE_COMMON_PART_DEFINITION_END

void Skin::releaseShapeData() {
    for (auto& pSlotData : m_arrShapeGroup) {
        for (auto& pShapeGroup : pSlotData) {
            if (pShapeGroup != nullptr) {
                pShapeGroup->releaseObject();
            }
        }
    }
}

Skin& Skin::assign(const Skin& other) {
    Base::assign(other);
    for (int i = 0; i < SLOT_MAX; i++) {
        for (int j = 0; j < STATE_MAX; j++) {
            if (other.m_arrShapeGroup[i][j] != nullptr) {
                if (m_arrShapeGroup[i][j] != nullptr) {
                    m_arrShapeGroup[i][j]->releaseObject();
                }
                m_arrShapeGroup[i][j] = (ShapeGroup*)other.m_arrShapeGroup[i][j]->createCopy();
            }
        }
    }
    return *this;
}

int Skin::addDataChild(DataInfoNode& childData) {
    int ret = Base::addDataChild(childData);
    if (ret < 0) {
        if (ObjectBase::is(childData.m_objType, NT_ShapeGroup)) {
            auto pShapeGroup = (ShapeGroup*)ObjectBase::createObject(childData);
            pShapeGroup->m_pQuoteArrAttrInfo = &childData.m_arrNode;
            if (pShapeGroup->getSlot() < SLOT_MAX && pShapeGroup->getState() < STATE_MAX) {
                m_arrShapeGroup[pShapeGroup->getSlot()][pShapeGroup->getState()] = pShapeGroup;
            } else {
                pShapeGroup->releaseObject();
            }
            ret = NT_ShapeGroup;
        }
    }
    return ret;
}

const string& Skin::getName() const {
    if (m_pRow != nullptr) {
        return m_pRow->getName();
    } else {
        return StringManager::getInstance()->mc_strNullDef;
    }
}

void Skin::setName(const string& value) {
    //���������ݽ�����
    s_tmpSplitSkinNameList.clear();
    util::split(value, StringManager::getInstance()->mc_wcOpenBrace, s_tmpSplitSkinNameList);
    //Ƥ����{����}{���԰�}
    //Ƥ���� ����} ���԰�}
    if (!s_tmpSplitSkinNameList.empty()) {
        //Ƥ����
        s_pTmpLastSkinName = s_tmpSplitSkinNameList.begin();
        if (s_tmpSplitSkinNameList.size() >= 3) {
            if (s_tmpSplitSkinNameList[1].size() > 1) {
                //ȥ��ĩβ�Ҵ����š�
                s_tmpSplitSkinNameList[1].erase(&s_tmpSplitSkinNameList[1].back());
                s_pTmpLastTheme = &s_tmpSplitSkinNameList[1];
            } else {
                s_pTmpLastTheme = &StringManager::getInstance()->mc_strNullDef;
            }
            if (s_tmpSplitSkinNameList[2].size() > 1) {
                //ȥ��ĩβ�Ҵ����š�
                s_tmpSplitSkinNameList[2].erase(&s_tmpSplitSkinNameList[2].back());
                s_pTmpLastLanguage = &s_tmpSplitSkinNameList[2];
            } else {
                s_pTmpLastLanguage = &StringManager::getInstance()->mc_strNullDef;
            }
        } else {
            s_pTmpLastLanguage = &StringManager::getInstance()->mc_strNullDef;
            s_pTmpLastTheme = &StringManager::getInstance()->mc_strNullDef;
        }
    } else {
        s_pTmpLastSkinName = &StringManager::getInstance()->mc_strNullDef;
        s_pTmpLastLanguage = &StringManager::getInstance()->mc_strNullDef;
        s_pTmpLastTheme = &StringManager::getInstance()->mc_strNullDef;
    }
    if (s_pTmpLastTheme != &StringManager::getInstance()->mc_strNullDef) {
        auto pairTheme = StringManager::getInstance()->m_hsThemeName.find(*s_pTmpLastTheme);
        if (pairTheme == StringManager::getInstance()->m_hsThemeName.end()) {
            StringManager::getInstance()->m_hsThemeName.insert(*s_pTmpLastTheme);
        }
    }
}
