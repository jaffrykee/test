#include "EventNodeBase.h"
#include "DataInfoNode.h"

#include "DataHeaders.h"

wstring EventNodeBase::s_tmpEventList;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(EventNodeBase, 100, 500);
#pragma region "����ע��"
    NODEBASE_ATTR_REGISTER("eventName", EventName, EventNodeBase, STR, s_tmpEventList, true);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(EventNodeBase)
    NBSCRIPT_ATTR_REGISTER("eventName", EventName, EventNodeBase, STR);
NODETYPE_COMMON_PART_DEFINITION_END

int EventNodeBase::addDataChild(DataInfoNode& childData) {
    int ret = Base::addDataChild(childData);
    if (ret < 0) {
        if (ObjectBase::is(childData.m_objType, NT_EventScript)) {
            m_eventTriggers.push_back((EventScript*)ObjectBase::createObject(childData));
            ret = (int)NT_EventScript;
        }
    }
    return ret;
}
