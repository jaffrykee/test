#include "Blink.h"
#include "Control.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(Blink, 0, 0);
#pragma region "����ע��"
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(Blink)
NODETYPE_COMMON_PART_DEFINITION_END

void ssui::Blink::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    case ET_Click:
    {
        //����ButtonBase���ˡ�
    }
        break;
    default:
        break;
    }
}
