#pragma once
#include "SimpleComponent.h"

using namespace ss2;
using namespace gstl;
using namespace ssui;

_SSUINamespaceBegin

//����ҡ��
class VirtualJoystick : public SimpleComponent {
    NODETYPE_COMMON_PART_DECLARATION_BEGIN(VirtualJoystick);
protected:
    inline virtual void createSelf() override {
    }
    inline virtual void disposeSelf() override {
    }
    NODETYPE_COMMON_PART_DECLARATION_END(VirtualJoystick, SimpleComponent);
#pragma region "��������"
#pragma endregion

#pragma region "��̬��Ա"
#pragma endregion

#pragma region "��̬����"
#pragma endregion

#pragma region "��Ա"
public:
    int mt_joystickId = 0;
    int mt_joystickR = 100;

public:
    s16 m_drawCx = 0xffff;
    s16 m_drawCy = 0;
    s16 m_drawStickX = 0;
    s16 m_drawStickY = 0;
    ft m_hostCx;
    ft m_hostCy;
#pragma endregion

#pragma region "����"
#pragma region "���Է���"
public:
    inline int getJoystickId() const {
        return mt_joystickId;
    }
    inline void setJoystickId(int value) {
        mt_joystickId = value;
    }
    inline int getJoystickR() const {
        return mt_joystickR;
    }
    inline void setJoystickR(int value) {
        mt_joystickR = value;
    }
#pragma endregion

public:
    inline Self& assign(const Self& other) {
        Base::assign(other);
        return *this;
    }
    virtual void onEvent(SSUIEvent& event) override;
public:
    virtual bool isTouchComponent() const override;
    virtual const ArrayList<SlotType_e>& getSlotList() const override {
        return getSlotListDef(SLOT_vJoystick);
    }
    virtual void debugString(string& outString) override;
#pragma endregion
};

_SSUINamespaceEnd
