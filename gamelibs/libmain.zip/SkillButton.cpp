#include "SkillButton.h"
#include "Control.h"
#include "GeometryManager.h"
#include "GeometryRect.h"
#include "GeometryPoly.h"
#include "GeometryUnionPoly.h"
#include "Timer.h"
#include "UIScene.h"
#include "BasicClip.h"
#include "Progress.h"

#include "DataHeaders.h"

NODETYPE_COMMON_PART_DEFINITION_BEGIN(SkillButton, 10, 20);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("cdTime", CdTime, SkillButton, S32);
NODEBASE_ATTR_REGISTER("remainTime", RemainTime, SkillButton, S32);
NODEBASE_ATTR_REGISTER("skillButtonDirection", SkillButtonDirection, SkillButton, S32, Progress::s_tmpProgressDirectionCmdData, true);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(SkillButton)
NBSCRIPT_ATTR_REGISTER("cdTime", CdTime, SkillButton, S32);
NBSCRIPT_ATTR_REGISTER("remainTime", RemainTime, SkillButton, S32);
NBSCRIPT_ATTR_REGISTER("skillButtonDirection", SkillButtonDirection, SkillButton, S32);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def(SkillButton, CdTime, int)
UIComponent_ControlAttr_Def(SkillButton, RemainTime, int)
UIComponent_ControlAttr_Def(SkillButton, SkillButtonDirection, int)
#pragma endregion

void ssui::SkillButton::createSelf() {
}

void ssui::SkillButton::disposeSelf() {
}

gstl::s32 ssui::SkillButton::getCdTime() const {
    return m_cdTime;
}

void ssui::SkillButton::setCdTime(s32 value) {
    m_cdTime = value;
    if (UIScene::s_isParsing == false) {
        rebuild();
    }
}

gstl::s32 ssui::SkillButton::getRemainTime() const {
    return m_remainTime;
}

void ssui::SkillButton::setRemainTime(s32 value) {
    m_remainTime = value;
    if (UIScene::s_isParsing == false) {
        rebuild();
    }
}

int ssui::SkillButton::getSkillButtonDirection() const {
    return m_direction;
}

void ssui::SkillButton::setSkillButtonDirection(int value) {
    m_direction = (ProgressDirection_e)value;
    if (UIScene::s_isParsing == false) {
        rebuild();
    }
}

SkillButton& ssui::SkillButton::assign(const Self& other) {
    Base::assign(other);
    m_cdTime = other.m_cdTime;
    m_direction = other.m_direction;
    if (getHost()) {
        getHost()->touchRenderChanged();
    }
    return *this;
}

void ssui::SkillButton::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
        case ET_Click:
        {
            m_remainTime = m_cdTime;
            rebuild();
        }
        break;
        default:
        {

        }
        break;
    }
    Base::onEventScript(event);
}

ArrayList<Control*>& ssui::SkillButton::container() {
    return m_container;
}

ssui::ParentAreaType_e ssui::SkillButton::getParentAreaType() const {
    return PAT_inner;
}

const ArrayList<SlotType_e>& ssui::SkillButton::getSlotList() const {
    return getSlotListDef(SLOT_progFill);
}

void ssui::SkillButton::onPrepareData() {
    Base::onPrepareData();
    rebuild();
}

void ssui::SkillButton::onClip(unsigned char drawStep) {
    if (m_isRect) {
        m_clipArea = getHost()->getInnerMeasure().m_srcArea;
        float per = 0;
        if (m_cdTime != 0) {
            per = m_remainTime / m_cdTime;
        }
        if (per > 1) {
            per = 1;
        } else if (per < 0) {
            per = 0;
        }
        switch (m_direction) {
            case ssui::PROG_DRC_lr:
            {
                auto w = m_clipArea.width();
                auto pw = per * w;
                m_clipArea.m_right = m_clipArea.m_left + pw;
            }
            break;
            case ssui::PROG_DRC_rl:
            {
                auto w = m_clipArea.width();
                auto pw = per * w;
                m_clipArea.m_left = m_clipArea.m_right - pw;
            }
            break;
            case ssui::PROG_DRC_tb:
            {
                auto h = m_clipArea.height();
                auto ph = per * h;
                m_clipArea.m_bottom = m_clipArea.m_top + ph;
            }
            break;
            case ssui::PROG_DRC_bt:
            {
                auto h = m_clipArea.height();
                auto ph = per * h;
                m_clipArea.m_top = m_clipArea.m_bottom - ph;
            }
            break;
            default:
                break;
        }
        for (auto& pChild : *this) {
            applyClipToSelfChildGrandChildAndSoOn(pChild, m_clipArea);
        }
    }
}

void ssui::SkillButton::applyClipToPosterity(Control* pPosterity) {
    if (m_isRect && pPosterity != getHost()) {
        applyClipToSelfChildGrandChildAndSoOn(pPosterity, m_clipArea);
    }
}

void ssui::SkillButton::createTimer() {
    Timer::createObject(this, (Timer::TimerTriggerFunc)&Self::timerTrigger);
    return;
}

void ssui::SkillButton::timerTrigger(u32 targerTime) {
    rebuild();
    createTimer();
}

void ssui::SkillButton::correctValidity() {
}

void ssui::SkillButton::rebuild() {
    if (getHost() == nullptr || m_remainTime <= 0 || m_cdTime == 0) {
        return;
    }
    correctValidity();
    u32 dTime = 0;
    auto nowTime = GameTime::getUseTimeStable();
    if (m_lastTime == 0) {
        dTime = 0;
    } else {
        dTime = nowTime - m_lastTime;
        if (dTime <= 0) {
            dTime = 1;
        }
    }
    m_lastTime = nowTime;
    m_remainTime -= dTime;

    if (m_remainTime > 0) {
        createTimer();
    } else {
        m_lastTime = 0;
        m_remainTime = 0;
    }
    m_isRect = false;
    switch (m_direction) {
        case ssui::PROG_DRC_lr:
        case ssui::PROG_DRC_rl:
        case ssui::PROG_DRC_tb:
        case ssui::PROG_DRC_bt:
        {
            m_isRect = true;
            touchRenderChanged();
        }
        break;
        case ssui::PROG_DRC_cw:
        case ssui::PROG_DRC_antiCw:
        {
            float per = m_remainTime / (f32)m_cdTime;
            if (per > 1) {
                per = 1;
            } else if (per < 0) {
                per = 0;
            }
            auto clipComp = getHost()->getBasicClip();
            if (clipComp) {
                float bAngle = clipComp->getClipBeginAngle();
                auto dAngle = 360.f * per;
                if (m_direction == PROG_DRC_cw) {
                    clipComp->setClipEndAngle(bAngle + dAngle);
                } else {
                    clipComp->setClipEndAngle(bAngle - dAngle + 360.f);
                }
            }
        }
        break;
        default:
            break;
    }
}

void ssui::SkillButton::debugString(string& outString) {
    outString.append("\n[SkillButton]");
    outString.append(string("\nm_remainTime: ") + util::ftoa_c8s(m_remainTime));
    outString.append(string("\nm_cdTime: ") + util::ftoa_c8s(m_cdTime));
}
