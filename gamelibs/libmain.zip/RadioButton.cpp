#include "RadioButton.h"
#include "Control.h"

#include "DataHeaders.h"

gstl::HashMap<gstl::string, HashSet<RadioButton*>> ssui::RadioButton::s_mapRadio;

NODETYPE_COMMON_PART_DEFINITION_BEGIN(RadioButton, 33, 100);
#pragma region "����ע��"
NODEBASE_ATTR_REGISTER("radioId", RadioId, RadioButton, STR);
#pragma endregion
NODETYPE_COMMON_PART_DEFINITION_MID(RadioButton)
NBSCRIPT_ATTR_REGISTER("radioId", RadioId, RadioButton, STR);
NODETYPE_COMMON_PART_DEFINITION_END

#pragma region "control����ע��"
UIComponent_ControlAttr_Def_STR(RadioButton, RadioId, string)
#pragma endregion

void ssui::RadioButton::setRadioId(const string& value) {
    if (getRadioId() != value) {
        setRadioIdFunc(value);
    }
}

void ssui::RadioButton::onSelect() {
    checkOtherRadioButton();
}

void ssui::RadioButton::checkOtherRadioButton() {
    if (mt_pairRadio != nullptr) {
        string str = mt_pairRadio->first;
        for (auto& pBrother : mt_pairRadio->second) {
            if (pBrother && pBrother->getHost() && pBrother->getHost() != this->getHost()) {
                if (pBrother->getHost()->getDataIsSelected() == true) {
                    pBrother->getHost()->setDataIsSelected(false);
                    break;
                }
            }
        }
    }
}

void ssui::RadioButton::onEvent(SSUIEvent& event) {
    Base::onEvent(event);
    switch (event.m_type) {
    case ET_Click:
    {
        if (getHost()->getDataIsSelected() == false) {
            //checkOtherRadioButton();
            getHost()->setDataIsSelected(true);
        }
    }
    break;
    default:
    {

    }
    break;
    }
    Base::onEventScript(event);
}
