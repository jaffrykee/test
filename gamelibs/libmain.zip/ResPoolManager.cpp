#include "ResPoolManager.h"

ResPool<ArrayList<EventNodeBase*>> RPM::s_rpEventNode = ResPool<ArrayList<EventNodeBase*>>();
ResPool<ArrayList<UIComponent*>> RPM::s_rpIEventComponent = ResPool<ArrayList<UIComponent*>>();
ResPool<ArrayList<UIComponent*>> RPM::s_rpIDrawComponent = ResPool<ArrayList<UIComponent*>>();
ResPool<gstl::HashMap<ssui::strHash, BoloVar>> ssui::ResPoolManager::s_rpMapUserAttr = ResPool<gstl::HashMap<ssui::strHash, BoloVar>>();
ssui::ResPool<gstl::ArrayList<gstl::wstring>> ssui::ResPoolManager::s_rpArrStringW;

ssui::ResPool<gstl::string> ssui::ResPoolManager::s_rpString;
ssui::ResPool<gstl::wstring> ssui::ResPoolManager::s_rpStringW;
